import message from './message.js';

console.log(message);