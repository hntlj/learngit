export default {
	name: 'Dell Lee'
}