import * as math from './math';
import * as string from './string';

export default { math, string }