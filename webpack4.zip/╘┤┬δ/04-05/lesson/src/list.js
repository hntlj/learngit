import React, { Component } from 'react';

class List extends Component {
	render() {
		return <div>ListPage</div>
	}
}

export default List;