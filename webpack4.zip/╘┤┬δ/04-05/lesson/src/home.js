import React, { Component } from 'react';

class Home extends Component {
	render() {
		return <div>HomePage</div>
	}
}

export default Home;