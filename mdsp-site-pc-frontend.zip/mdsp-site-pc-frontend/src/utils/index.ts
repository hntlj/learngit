/**
 * 深拷贝
 * @param {*} obj 拷贝对象(object or array)
 * @param {*} cache 缓存数组
 */
export const deepCopy = (obj: any, cache: Array<any> = []): any => {
  if (obj === null || typeof obj !== 'object') {
    return obj
  }
  // 如果传入的对象与缓存的相等, 则递归结束, 这样防止循环
  /**
   * 类似下面这种
   * var a = {b:1}
   * a.c = a
   * 资料: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Errors/Cyclic_object_value
   */
  const hit = cache.filter(c => c.original === obj)[0]
  if (hit) {
    return hit.copy
  }

  const copy = Array.isArray(obj) ? [] : {}
  // 将copy首先放入cache, 因为我们需要在递归deepCopy的时候引用它
  cache.push({
    original: obj,
    copy
  })

  Object.keys(obj).forEach(key => {
    copy[key] = deepCopy(obj[key], cache)
  })

  return copy
}

/**
 * Parse simple path.
 */
const bailRE = /[^\w.$]/
export function parsePath (path: string): any {
  if (bailRE.test(path)) {
    return
  }
  const segments = path.split('.')
  return function (obj: any) {
    for (let i = 0; i < segments.length; i++) {
      if (!obj) return
      obj = obj[segments[i]]
    }
    return obj
  }
}

/**
 * Automatic registration 自动化注册
 */
export const installComs = (context: any, type: string): any => {
  return context.keys().reduce((acc: any, cur: any) => {
    const name: string = type + cur.match(/^.\/(.*).vue$/)[1]
    acc[name] = context(cur).default
    return acc
  }, {})
}
/**
 * 根据url获取params
 */
export const getUrlParams = (url: string): any => {
  if (url.length > 3) {
    // const paramsArr: Array<any> = url.split('?')[1].split('&')
    let paramsArr: Array<any> = []
    if (/\?/.test(url)) paramsArr = url.split('?')[1].split('&')
    let result: any = {}
    let temp: Array<any> = []
    const len = paramsArr.length
    for (let i = 0; i < len; i++) {
      temp = paramsArr[i].split('=')
      if (temp.length === 1) {
        result[temp[0]] = ''
      } else if (temp.length > 1) {
        result[temp[0]] = temp[1]
      }
    }
    return result
  }
}
