<template>
  <div class="com-sort com-img-slider"
    :class="{'com-sort_active': showDel | isActive}"
    :data-code="content.code"
    :style="attrModule"
    @mouseenter="onMouseenter"
    @mouseleave="onMouseleave">
    <div class="com-slider-wrap">
      <slider ref="slider" :options="sliderOptions" v-if="showSlider">
          <slideritem v-for="item in content.urls" :key="item.src"><img :src="item.src" alt=""></slideritem>
        <div slot="loading">loading...</div>
      </slider>
      <div class="com-slider__empty" v-if="!content.urls.length"></div>
    </div>
    <DeleteCp :showDel="showDel" :sortIdx="sortIdx"></DeleteCp>
  </div>
</template>

<script lang="ts">
import { Vue, Component, Prop, Watch } from 'vue-property-decorator'
import { slider, slideritem } from 'vue-concise-slider'
import DeleteCp from '@/components/common/DeleteCp.vue'
import SiteComAct from '@/mixins/siteComAct.ts'

@Component({
  name: 'SiteImgSlider',
  components: {
    DeleteCp, slider, slideritem
  },
  mixins: [SiteComAct]
})
export default class SiteImgSlider extends Vue {
  @Prop(Object) content: any
  showSlider: boolean = true
  sliderOptions: any = {
    autoplay: Number(this.content.slideSpeed)*1000,
    loop: true
  }
  @Watch('content', { deep: true })
  onComDataDownloadChanged (newVal: any, oldVal: any) {
    this.sliderOptions.autoplay = Number(newVal.slideSpeed)*1000
    this.showSlider = false
    this.$nextTick(() => {
      this.showSlider = true
    })
  }
}
</script>
<style lang="scss" scoped>
.com-slider-wrap {
  min-height: 50px;
  img {
    width: 100%;
  }
  .com-slider__empty {
    height: 280px;
    background: url('~assets/img/back_slider.png') no-repeat center;
  }
}
</style>
