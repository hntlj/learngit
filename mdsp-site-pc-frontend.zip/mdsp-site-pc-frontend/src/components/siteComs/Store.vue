<template>
  <div class="com-sort"
    :class="{'com-sort_active': showDel | isActive}"
    :data-code="content.code"
    :style="attrModule"
    @mouseenter="onMouseenter"
    @mouseleave="onMouseleave">
    <div class="store-wrap">
      <div class="store-app">
        <img class="store-app__icon" :class="{'icon-border': !appInfo.icon }" :src="appInfo.icon" alt="">
        <span class="store-app__name">{{appInfo.name}}</span>
      </div>
      <div class="store-btn" :style="attrStyle">{{content.buttonText}}</div>
    </div>
    <DeleteCp :showDel="showDel" :sortIdx="sortIdx"></DeleteCp>
  </div>
</template>

<script lang="ts">
import { Vue, Component } from 'vue-property-decorator'
import { State, Action, Getter, Mutation } from 'vuex-class'
import DeleteCp from '@/components/common/DeleteCp.vue'
import SiteComAct from '@/mixins/siteComAct.ts'
@Component({
  name: 'SiteStore',
  components: {
    DeleteCp
  },
  mixins: [SiteComAct]
})

export default class SiteDlBtn extends Vue {
  @State appInfo: any
}
</script>
<style lang="scss">
.store-wrap {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 20px;
  background: #fff;
  .store-app {
    height: 50px;
    display: flex;
    align-items: center;
    .store-app__icon {
      width: 50px;
      height: 50px;
      margin-right: 10px;
    }
    .icon-border {
      border: 1px solid $backGray;
    }
  }
  .store-btn {
    height: 30px;
    line-height: 30px;
    padding: 0 20px;
    border-radius: 3px;
  }
}
</style>
