<template>
  <div class="com-sort"
    :class="{'com-sort_active': showDel | isActive}"
    :data-code="content.code"
    :style="attrModule"
    @mouseenter="onMouseenter"
    @mouseleave="onMouseleave">
    <div class="mdsewindow-wrap">
      <div class="mdse"
        :class="{'mdse-style2': content.mdseStyle==='column'}"
        v-for="mdse in content.urls"
        :key="mdse.src">
        <div class="mdse-img">
          <img :src="mdse.src">
        </div>
        <div class="mdse-bottom">
          <div class="mdse-bottom__desc mdse-bottom__item">{{mdse.describe}}</div>
          <div class="mdse-bottom__price mdse-bottom__item" v-show="mdse.price">
            <span>¥</span><span>{{mdse.price}}</span>
          </div>
        </div>
      </div>
      <div class="mdsewindow__empty" v-if="!content.urls.length"></div>
    </div>
    <DeleteCp :showDel="showDel" :sortIdx="sortIdx"></DeleteCp>
  </div>
</template>

<script lang="ts">
import { Vue, Component } from 'vue-property-decorator'
import DeleteCp from '@/components/common/DeleteCp.vue'
import SiteComAct from '@/mixins/siteComAct.ts'
@Component({
  name: 'SiteMdseWindow',
  components: {
    DeleteCp
  },
  mixins: [SiteComAct]
})

export default class SiteDlBtn extends Vue {}
</script>
<style lang="scss" scoped>
.mdsewindow-wrap {
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  justify-content: space-between;
  padding: 3px;
  min-height: 100px;
  .mdse {
    width: 49%;
    .mdse-img {
      img {
        width: 100%;
      }
    }
    .mdse-bottom {
      display: flex;
      justify-content: space-between;
      padding: 5px;
      .mdse-bottom__item {
        line-height: 25px;
        min-height: 25px;
      }
      .mdse-bottom__desc {
        width: 60%;
        @include ellipsis
      }
      .mdse-bottom__price {
        width: 40%;
        text-align: right;
        @include ellipsis
      }
    }
  }
  .mdse-style2 {
    .mdse-bottom {
      display: block;
      .mdse-bottom__item {
        width: 100%;
        text-align: left;
        @include ellipsis
      }
    }
  }
  .mdsewindow__empty {
    width: 100%;
    height: 280px;
    background: url('~assets/img/back_mdse.png') no-repeat center;
  }
}

</style>
