<template>
  <div class="btn-box com-sort"
    :class="{'com-sort_active': showDel | isActive}"
    :data-code="content.code"
    :style="attrModule"
    @mouseenter="onMouseenter"
    @mouseleave="onMouseleave">
    <div class="btn-wrap">
      <div class="btn btn_size_large" :style="attrStyle">
        <span class="iconfont iconfont-consult"></span> {{ content.buttonText }}
      </div>
    </div>
    <DeleteCp :showDel="showDel" :sortIdx="sortIdx"></DeleteCp>
  </div>
</template>

<script lang="ts">
import { Vue, Component } from 'vue-property-decorator'
import DeleteCp from '@/components/common/DeleteCp.vue'
import SiteComAct from '@/mixins/siteComAct.ts'
@Component({
  name: 'SiteConsult',
  components: {
    DeleteCp
  },
  mixins: [SiteComAct]
})

export default class SiteDlBtn extends Vue {}
</script>

<style lang="scss" scoped>
</style>
