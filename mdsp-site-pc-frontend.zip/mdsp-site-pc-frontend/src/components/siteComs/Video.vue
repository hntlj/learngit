<template>
  <div class="com-sort com-video"
    :class="{'com-sort_active': showDel | isActive}"
    :data-code="content.code"
    :style="attrModule"
    @mouseenter="onMouseenter"
    @mouseleave="onMouseleave">
    <div class="video-wrap" v-if="content.videoUrl && showVideo">
      <video class="video-player" ref="video" controls name="media">
        <source :src="content.videoUrl" type="video/mp4">
      </video>
      <img class="video-cover-img"
        v-if="showCoverImg && content.coverUrl"
        :src="content.coverUrl"
        @click="onPlayVideo">
      <img class="play-img" v-if="showCoverImg && content.coverUrl" @click="onPlayVideo" src="~assets/img/icon-play.png" alt="">
    </div>
    <div class="video__empty" v-if="!content.videoUrl"></div>
    <DeleteCp :showDel="showDel" :sortIdx="sortIdx"></DeleteCp>
  </div>
</template>

<script lang="ts">
import { Vue, Component, Watch } from 'vue-property-decorator'
import DeleteCp from '@/components/common/DeleteCp.vue'
import SiteComAct from '@/mixins/siteComAct.ts'
@Component({
  name: 'SiteVideo',
  components: {
    DeleteCp
  },
  mixins: [SiteComAct]
})

export default class SiteDlBtn extends Vue {
  showVideo: boolean = true
  showCoverImg: boolean = true
  onPlayVideo () {
    this.showVideo = false
    this.$nextTick(() => {
      this.showVideo = true
      this.$nextTick(() => {
        this.$refs.video['autoplay'] = true
        this.showCoverImg = false
      })
    })
  }
  initVideoStatus () {
    this.showVideo = false
    this.showCoverImg = false
    this.$nextTick(() => {
      this.showVideo = true
      this.showCoverImg = true
    })
  }
  @Watch('content.videoUrl')
  onVideoUrlChanged (newVal: any, oldVal: any) {
    this.initVideoStatus()
  }
  @Watch('content.coverUrl')
  onCoverUrlChanged (newVal: any, oldVal: any) {
    this.initVideoStatus()
  }
}
</script>
<style lang="scss" scoped>
.com-video {
  overflow: hidden;
  .video-wrap {
    position: relative;
    overflow: hidden;
    .video-player {
      width: 100%;
      float: left;
    }
    .video-cover-img {
      width: 100%;
      height: 100%;
      position: absolute;
      left: 0;
      top: 0;
    }
    .play-img {
      position: absolute;
      width: 50px;
      left: 50%;
      top: 50%;
      transform: translate(-50%, -50%);
    }
  }
  .video__empty {
    height: 280px;
    background: url('~assets/img/back_video.png') no-repeat center;
  }
}
</style>
