<template>
  <div class="delete-compontent-box">
    <div v-if="showDel" class="el-icon-close el-icon-close_bg_blue remove-component" @click.stop="dailogStatu"></div>
    <el-dialog
      title="提示"
      :visible.sync="dialogVisible"
      :append-to-body="appendToBody"
      width="430px">
      <div class="el-message-box__content">
        <div class="el-message-box__status el-icon-warning"></div>
        <div class="el-message-box__message dialog-message">此操作将删除该模块, 是否继续?</div>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false" size="small">取 消</el-button>
        <el-button type="primary" @click="onRemove(sortIdx)" size="small">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script lang="ts">
import { Vue, Component, Prop } from 'vue-property-decorator'
import { State, Mutation } from 'vuex-class'
import { DOWNLOAD_COMP } from '@/enums/index.ts'

@Component
export default class DeleteCp extends Vue {
  dialogVisible: boolean = false
  appendToBody: boolean = true
  @Prop(Boolean) readonly showDel: boolean
  @Prop(Number) readonly sortIdx: number | undefined
  @State sortApi: Array<any>
  @State appInfo: any
  @Mutation deleteCp
  @Mutation setCommon
  @Mutation setPackageName
  @Mutation setPackageInfo

  dailogStatu () {
    this.dialogVisible = true
    this.setCommon({ flag: true, index: this.sortIdx })
  }

  hasNotApp () {
    return this.sortApi.every((item, idx) => {
      return !(DOWNLOAD_COMP.indexOf(item.type) > -1 && this.appInfo.packageName)
    })
  }

  onRemove (index) {
    let flag = false
    this.deleteCp(index)
    this.dialogVisible = false
    this.$message({
      message: '该模块已删除 !',
      type: 'success'
    })
    this.setCommon({ flag: false, index: 0 })
    if (this.hasNotApp() && this.appInfo.packageName) {
      this.setPackageName('')
      this.setPackageInfo({
        packageName: '',
        name: '',
        icon: '',
        versionCode: '',
        id: '',
        status: ''
      })
    }
  }
}
</script>

<style lang="scss">
.delete-compontent-box {
  .el-icon-close_bg_blue {
    z-index: 999;
  }
  .el-dialog__body {
    padding: 0;
  }
  .dialog-message {
    font-size: 16px;
  }
}
</style>
