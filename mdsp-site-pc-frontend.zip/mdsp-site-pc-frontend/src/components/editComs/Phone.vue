<template>
  <div class="btn-edit ui-edit"
    :data-code="comData.code"
    v-if="sortIdx === currentIndex">
    <el-form class="edit-form" ref="form" label-width="80px">
      <div class="form-group">
        <h3 class="form-group__title">文字样式</h3>
        <el-form-item label="文字">
          <el-input size="large" v-model="comData.content.buttonText" placeholder="输入按钮文案"></el-input>
        </el-form-item>
        <el-form-item label="号码">
          <el-input size="large" type="number" v-model="comData.content.phone" placeholder="输入电话号码"></el-input>
        </el-form-item>
        <div class="form-row">
          <el-form-item label="字号">
            <el-input type="number"
              v-model="comData.attr.style['fontSize']"
              class="cui-input-box"
              size="small">
            </el-input><span> px</span>
          </el-form-item>
          <el-form-item label="颜色">
            <el-color-picker
              @active-change=" (value) => setStyle(value, 'color')"
              v-model="comData.attr.style['color']"
              show-alpha>
            </el-color-picker>
          </el-form-item>
        </div>
      </div>
      <div class="form-group">
        <h3 class="form-group__title">按钮样式</h3>
        <div class="form-row">
          <el-form-item label="背景颜色">
            <el-color-picker
              @active-change=" (value) => setStyle(value, 'backgroundColor')"
              v-model="comData.attr.style['backgroundColor']"
              show-alpha>
            </el-color-picker>
          </el-form-item>
          <el-form-item label="圆角">
            <el-input type="number" v-model="comData.attr.style['borderRadius']"
              class="cui-input-box"
              size="small">
            </el-input><span> px</span>
          </el-form-item>
          <el-form-item label="固定浮在底部">
            <el-switch v-model="comData.attr.bottom.status">
            </el-switch>
          </el-form-item>
        </div>
      </div>
      <div class="form-group">
        <h3 class="form-group__title">组件边距</h3>
        <div class="form-row">
          <el-form-item v-for="(modSt, idx) in styleOpt.module" :key="idx" :label="modSt.label">
            <el-input
              type="number"
              v-model="comData.attr.module[modSt.name]"
              class="cui-input-box"
              size="small">
            </el-input><span> px</span>
          </el-form-item>
        </div>
      </div>
    </el-form>
  </div>
</template>

<script lang="ts">
import { Vue, Component, Prop, Watch } from 'vue-property-decorator'
import { State, Action, Getter, Mutation } from 'vuex-class'
import { deepCopy } from '@/utils/index.ts'
import { STYLE_MODULE } from '@/enums/index.ts'

@Component
export default class DlBtnEdit extends Vue {
  @Prop(Object) comContent: any
  @Prop(Object) oStyle: any
  @Prop(Number) sortIdx: number | undefined
  @Prop(Number) currentIndex: number | undefined
  @State sortApi: Array<any>
  @State editIndex: number
  @State editShow: boolean
  @Mutation setApiItem
  comData: any = deepCopy(this.comContent, [])
  styleOpt: Object = {
    module: STYLE_MODULE
  }
  setStyle (value, style) {
    this.$set(this.comData.attr.style, style, value)
  }
  @Watch('comData', { deep: true })
  onComDataChanged (newVal: Array<any>, oldVal: Array<any>) {
    this.$store.commit('setApiItem', newVal)
  }
}
</script>

<style lang="scss" scoped>
</style>
