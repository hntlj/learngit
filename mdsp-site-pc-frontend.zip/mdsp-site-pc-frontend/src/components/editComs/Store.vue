<template>
  <div class="btn-edit ui-edit"
    :data-code="comData.code"
    v-if="sortIdx === currentIndex">
    <el-form class="edit-form" ref="form" label-width="80px">
      <div class="form-group">
        <h3 class="form-group__title">商店样式</h3>
        <el-form-item label="包名">
          <el-input
            size="large"
            :value="appInfo.packageName"
            @input="setPackageName"
            @blur="onChangePackage"
            placeholder="com.xunmeng.pinduoduo">
          </el-input>
        </el-form-item>
        <el-form-item label="deeplink">
          <el-input size="large" v-model="comData.content.deeplink" placeholder="填写deeplink地址（选填）"></el-input>
        </el-form-item>
      </div>
      <div class="form-group">
        <h3 class="form-group__title">按钮设置</h3>
        <el-form-item label="按钮文案">
          <el-input size="large" v-model="comData.content.buttonText" placeholder="输入按钮文案"></el-input>
        </el-form-item>
        <div class="form-row">
          <el-form-item label="文字颜色">
            <el-color-picker
              @active-change=" (value) => setStyle(value, 'color')"
              v-model="comData.attr.style['color']"
              show-alpha>
            </el-color-picker>
          </el-form-item>
          <el-form-item label="背景颜色">
            <el-color-picker
              @active-change=" (value) => setStyle(value, 'backgroundColor')"
              v-model="comData.attr.style['backgroundColor']"
              show-alpha>
            </el-color-picker>
          </el-form-item>
          <el-form-item label="固定浮在底部">
            <el-switch v-model="comData.attr.bottom.status">
            </el-switch>
          </el-form-item>
        </div>
      </div>
    </el-form>
  </div>
</template>

<script lang="ts">
import { Vue, Component, Prop, Watch } from 'vue-property-decorator'
import { State, Action, Getter, Mutation } from 'vuex-class'
import { deepCopy } from '@/utils/index.ts'
import { STYLE_MODULE } from '@/enums/index.ts'
@Component({
  name: 'EditStore'
})
export default class DlBtnEdit extends Vue {
  @Prop(Object) comContent: any
  @Prop(Object) oStyle: any
  @Prop(Number) sortIdx: number | undefined
  @Prop(Number) currentIndex: number | undefined
  @State sortApi: Array<any>
  @State editIndex: number
  @State editShow: boolean
  @State appInfo: any
  @Mutation setApiItem
  @Mutation setPackageName
  @Action getPackageInfo
  comData: any = deepCopy(this.comContent, [])
  onChangePackage () {
    this.getPackageInfo(this.appInfo.packageName)
  }
  setStyle (value, style) {
    this.$set(this.comData.attr.style, style, value)
  }
  @Watch('comData', { deep: true })
  onComDataChanged (newVal: Array<any>, oldVal: Array<any>) {
    this.$store.commit('setApiItem', newVal)
  }
}
</script>

<style lang="scss" scoped>
</style>
