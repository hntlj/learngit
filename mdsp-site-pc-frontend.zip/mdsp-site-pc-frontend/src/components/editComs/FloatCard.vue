<template>
  <div class="btn-edit ui-edit"
    :data-code="comData.code"
    v-if="sortIdx === currentIndex">
    <el-form class="edit-form" ref="form" label-width="80px">
      <div class="form-group">
        <h3 class="form-group__title">浮层卡片</h3>
        <el-form-item label="包名">
          <el-input
            size="large"
            :value="appInfo.packageName"
            @input="setPackageName"
            @blur="onChangePackage"
            placeholder="com.xunmeng.pinduoduo">
          </el-input>
        </el-form-item>
       <el-form-item label="deeplink">
          <el-input size="large" v-model="comData.content.deeplink" placeholder="填写deeplink地址（选填）"></el-input>
        </el-form-item>
        <el-form-item label="APP信息">
          <el-input
            size="large"
            type="textarea"
            :rows="3"
            v-model="comData.content.appDesc"
            minlength=20
            maxlength=120
            placeholder="输入APP信息，字数在20-120之间">
          </el-input>
        </el-form-item>
      </div>
      <div class="form-group">
        <h3 class="form-group__title">背景图</h3>
        <el-upload
          class="file-uploader"
          action="/common/upload"
          :show-file-list="false"
          :on-success="handleImgSuccess"
          :before-upload="beforeImgUpload()">
          <div class="file-uploader__btn">
            <i class="el-icon-plus"></i><span> 添加图片</span>
          </div>
        </el-upload>
        <div class="img-tip">图片要求：支持 jpg、png、jpeg 格式，小于300K。</div>
        <div class="img-wrap" v-if="comData.content.backgroundImage">
          <img :src="getUrl(comData.content.backgroundImage)">
        </div>
      </div>
      <div class="form-group">
        <h3 class="form-group__title">按钮设置</h3>
        <el-form-item label="按钮文案">
          <el-input size="large" v-model="comData.content.buttonText" placeholder="输入按钮文案"></el-input>
        </el-form-item>
        <div class="form-row">
          <el-form-item label="文字颜色">
            <el-color-picker
              @active-change=" (value) => setStyle(value, 'color')"
              v-model="comData.attr.style['color']"
              show-alpha>
            </el-color-picker>
          </el-form-item>
          <el-form-item label="背景颜色">
            <el-color-picker
              @active-change=" (value) => setStyle(value, 'backgroundColor')"
              v-model="comData.attr.style['backgroundColor']"
              show-alpha>
            </el-color-picker>
          </el-form-item>
        </div>
      </div>
    </el-form>
  </div>
</template>

<script lang="ts">
import { Vue, Component, Prop, Watch } from 'vue-property-decorator'
import { State, Action, Getter, Mutation } from 'vuex-class'
import { deepCopy } from '@/utils/index.ts'
import { STYLE_MODULE, HOST } from '@/enums/index.ts'
import BeforeUpload from '@/mixins/beforeUpload.ts'

@Component({
  name: 'EditFloatCard',
  mixins: [BeforeUpload]
})
export default class DlBtnEdit extends Vue {
  @Prop(Object) comContent: any
  @Prop(Object) oStyle: any
  @Prop(Number) sortIdx: number | undefined
  @Prop(Number) currentIndex: number | undefined
  @State sortApi: Array<any>
  @State editIndex: number
  @State editShow: boolean
  @State appInfo: any
  @Mutation setApiItem
  @Mutation setPackageName
  @Action getPackageInfo
  comData: any = deepCopy(this.comContent, [])
  setStyle (value, style) {
    this.$set(this.comData.attr.style, style, value)
  }
  handleImgSuccess(res, file) {
    const url = `http://${HOST}/upload/${res.value[0].url}`
    this.$set(this.comData.content, 'backgroundImage', `url(${url})`)
  }
  getUrl (str) {
    return str.match(/url\((.*)\)/)[1]
  }
  onChangePackage () {
    this.getPackageInfo(this.appInfo.packageName)
  }
  @Watch('comData', { deep: true })
  onComDataChanged (newVal: Array<any>, oldVal: Array<any>) {
    this.$store.commit('setApiItem', newVal)
  }
}
</script>

<style lang="scss" scoped>
.file-uploader {
  font-size: 16px;
  color: $blue;
  border: 1px solid $blue;
  margin: 10px 160px;
  text-align: center;
  line-height: 36px;
  .file-uploader__btn {
    padding: 0 10px;
  }
}
.img-tip, .video-tip {
  font-size: 12px;
  line-height: 20px;
  color: $gray;
  margin: 0 30px;
}
.form-group {
  margin: 0 10px;
  .img-wrap {
    background-color: #f0eeef;
    margin: 10px 0;
    text-align: center;
    position: relative;
    img{
      width: 80%;
      display: block;
      margin: 0 auto;
    }
  }
}
</style>
