<template>
  <div class="site-content" :style="sortApi[0] && sortApi[0].attr.style">
    <div class="app-top" ref="appTop">
      <SiteHeader
        v-if="sortApi[0]"
        :content="sortApi[0].content"
        @click.native="getIndex(0)">
      </SiteHeader>
    </div>
    <Draggable
      :group="sortOption.group"
      :sort="sortOption.sort"
      :animation="sortOption.animation"
      @sort="onSort"
      @add="onAdd"
      ref="appSort"
      class="app-sort">
      <div v-for="(appUi,index) in sortApi" :key="appUi.code">
        <component
          v-if="!appUi.attr.bottom.status && !(appUi.attr.top && appUi.attr.top.status)"
          :is="appUi.type"
          :content="appUi.content"
          :attrStyle="addUnitPx(appUi.attr.style)"
          :attrModule="addUnitPx(appUi.attr.module)"
          :sortIdx="index"
          @click.native="getIndex(index)"
          :key="appUi.content.code">
        </component>
        <div class="com-empty" v-if="sortApi.length < 2">
          <img src="~assets/img/layout-tip.png" alt="">
          <p>请从左侧拖进组件，制作落地页</p>
        </div>
      </div>
    </Draggable>
    <div class="app-bottom" ref="appBottom">
      <div v-for="(appUi,index) in sortApi" :key="appUi.code">
        <component
          v-if="appUi.attr.bottom.status"
          :is="appUi.type"
          :content="appUi.content"
          :attrStyle="addUnitPx(appUi.attr.style)"
          :attrModule="addUnitPx(appUi.attr.module)"
          :sortIdx="index"
          @click.native="getIndex(index)"
          :key="appUi.content.code">
        </component>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { Vue, Component, Watch } from 'vue-property-decorator'
import { State, Mutation, Action } from 'vuex-class'
import Draggable from 'vuedraggable'
import SiteComs from '@/components/siteComs/index.ts'
import { deepCopy } from '@/utils/index.ts'
import { STYLE_PX, COM_DEFAULT_DATA } from '@/enums/index.ts'
@Component({
  name: 'ComSorter',
  components: {
    Draggable, ...SiteComs
  }
})

export default class Sort extends Vue {
  sortOption: any = {
    group: {
      name: 'components',
      pull: true,
      put: true
    },
    sort: true,
    animation: 300
  }
  @State sortApi: Array<any>
  @State editIndex: number
  @Action sortCp
  @Action addCp
  @Mutation setCommon
  created () {
    if (!this.sortApi.length) {
      this.addCp(COM_DEFAULT_DATA['SiteHeader'])
    }
    this.$nextTick(() => {
      this.getIndex(0)
    })
  }
  mounted () {
    this.initBottomHei(this.sortApi, true)
  }
  initBottomHei (newVal, isFirst = false) {
    let hasBottomEle: boolean = false
    let preBottomHei: number = this.$refs.appBottom['offsetHeight']
    let bottomHei: number = 0
    for (let i = 0; i < newVal.length; i++) {
      if (newVal[i].attr.bottom.status) {
        hasBottomEle = true
        break
      }
    }
    if (hasBottomEle) {
      this.$nextTick(() => {
        bottomHei = this.$refs.appBottom['offsetHeight']
        if (bottomHei !== preBottomHei || isFirst) {
          this.$refs.appSort['$el']['style']['padding-bottom'] = bottomHei + 'px'
        }
      })
    }
  }
  onSort (res) {
    if (res.from === res.to) {
      this.sortCp(res)
    }
  }
  onAdd (res) {
    this.addCp(res)
    this.getIndex(res.oldIndex)
    this.getIndex(res.newIndex)
  }
  getIndex (index) {
    this.setCommon({ index: index, flag: true })
  }
  addUnitPx (obj) {
    let temp: any = deepCopy(obj, [])
    const deepCircle = (target: any): any => {
      for (let key in target) {
        if (typeof target[key] === 'object') {
          deepCircle(target[key])
        } else {
          if (STYLE_PX.indexOf(key) > -1 && target[key]) {
            target[key] = target[key].replace(/px/g, '') + 'px'
          }
        }
      }
      return target
    }
    return deepCircle(temp)
  }

  @Watch('sortApi', { deep: true })
  onSortApiChanged (newVal: Array<any>, oldVal: Array<any>) {
    this.initBottomHei(newVal)
  }
}
</script>

<style lang="scss">
.site-content {
  overflow-y: auto;
  height: 100%;
  background-position:center;
  background-repeat: no-repeat;
  background-size: cover;
  &::-webkit-scrollbar {
    display: none;
  }
  .app-top {
    z-index: 1111;
    width: 100%;
    height: 40px;
    background-color: #333;
    color: #fff;
    position: absolute;
    top: 0;
  }
  .app-sort {
    padding-top: 40px;
    min-height: 600px;
    .com-empty {
      width: 100%;
      position: absolute;
      left: 0;
      top: 50%;
      transform: translateY(-50%);
      display: flex;
      justify-content: center;
      flex-direction: column;
      align-items: center;
      img {
        width: 260px;
      }
      p {
        width: 100%;
        text-align: center;
        color: #ccc;
      }
    }
  }
  .app-bottom {
    z-index: 999;
    width: 100%;
    position: absolute;
    bottom: 0;
  }
  .remove-component {
    position: absolute;
    right: 0;
    top: 0;
  }

  .com-sort {
    position: relative;
  }
  .com-sort_active {
    border: 1px solid $blue;
  }
}
</style>
