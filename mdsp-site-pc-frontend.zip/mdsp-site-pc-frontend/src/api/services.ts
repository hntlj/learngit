// declare namespace Ajax {
//   // axios 返回数据
//   export interface AxiosResponse {
//     data: AjaxResponse
//   }
//   // 请求接口数据
//   export interface AjaxResponse {
//     code: number,
//     value: any,
//     message: string,
//     redirect: string
//   }
// }

// interface AjaxResponse {
//   code: number,
//   value: any,
//   message: string,
//   redirect: string
// }

import axios from 'axios'
import qs from 'qs'
// import { Message } from 'element-ui'
const ERROR_MSG = '服务器错误，请稍候再试'

import {
  isFormData,
  isArrayBuffer,
  isStream,
  isFile,
  isBlob,
  isURLSearchParams,
  isObject,
  isUndefined
} from 'axios/lib/utils'

function setContentTypeIfUnset (headers: any, value: any): void {
  if (!isUndefined(headers) && isUndefined(headers['Content-Type'])) {
    headers['Content-Type'] = value
  }
}

const service = axios.create({
  baseURL: '',
  timeout: 60000,
  headers: { 'Cache-Control': 'no-cache' },
  transformRequest: [function transformRequest (data, headers) {
    /* 把类似content-type这种改成Content-Type */
    let keys = Object.keys(headers)
    let normalizedName = 'Content-Type'
    keys.forEach(name => {
      if (name !== normalizedName && name.toUpperCase() === normalizedName.toUpperCase()) {
        headers[normalizedName] = headers[name]
        delete headers[name]
      }
    })
    if (isFormData(data) ||
      isArrayBuffer(data) ||
      isStream(data) ||
      isFile(data) ||
      isBlob(data)
    ) {
      return data
    }
    if (isURLSearchParams(data)) {
      setContentTypeIfUnset(headers, 'application/x-www-form-urlencoded;charset=utf-8')
      return data.toString()
    }
    /* 这里是重点，其他的其实可以照着axios的源码抄 */
    /* 这里就是用来解决POST提交json数据的时候是直接把整个json放在request payload中提交过去的情况
     * 这里简单处理下，把 {name: 'admin', pwd: 123}这种转换成name=admin&pwd=123就可以通过
     * x-www-form-urlencoded这种方式提交
     * */
    if (isObject(data)) {
      if (data._json) {
        setContentTypeIfUnset(headers, 'application/json;charset=utf-8')
        return JSON.stringify(data)
      }
      setContentTypeIfUnset(headers, 'application/x-www-form-urlencoded;charset=utf-8')
      let keys2 = Object.keys(data)
      /* 这里就是把json变成url形式，并进行encode */
      return keys2.map(name => `${encodeURIComponent(name)}=${encodeURIComponent(data[name])}`).join('&')
    }
    return data
  }]
})

// const showMessage = (message, type = 'error') => {
//   Message({
//     showClose: true,
//     type: type,
//     duration: 3000,
//     message
//   })
// }

service.interceptors.response.use(res => {
  let data = res.data
  if (data.model) {
    data = data.model
  }
  if (data && data.code === 198001) {
    if (~data.message.indexOf('登录')) {
      window.location.href = '/uc/login'
      return
    }
  }
  if (data && data.code === 198000) {
    if (~data.message.indexOf('授权')) {
      window.location.href = '/logout'
      return
    }
  }
  if (data && data.code === 198004) {
    if (~data.message.indexOf('登录')) {
      window.location.href = '/uc/login'
      return
    }
  }
  if (data.code !== 200) {
    // showMessage(`${data.message || ERROR_MSG}`)
    return Promise.reject(new Error(data.message || ERROR_MSG))
  } else {
    return data
  }
}, error => {
  let message = error.message || ERROR_MSG
  if (error.response && error.response.status === 403) {
    message = '您没有该权限'
  }
  // showMessage(message)
  return Promise.reject(message)
})

service['export'] = (url, { params }) => {
  const { pageSize, pageNumber, ...args } = params
  const exportUrl = url + '?' + qs.stringify(args)
  window.open(exportUrl)
}

export default service
