import { RootStateTypes } from './types'
import { ActionTree } from 'vuex'
import { COM_DEFAULT_DATA } from '@/enums/index.ts'
import { deepCopy } from '@/utils/index.ts'
import { getAppDetail } from '@/api/index.ts'

const actions: ActionTree<RootStateTypes, any> = {
  sortCp ({ state, commit }, res: any) {
    let Target: any = state.sortApi[res.oldIndex]
    let aIndex: number = res.newIndex
    state.sortApi.splice(res.oldIndex, 1)
    state.sortApi.splice(res.newIndex, 0, Target)
    commit('setCommon', { flag: true, index: aIndex })
  },
  addCp ({ state, commit }, res: any) {
    let cmType = res.item ? res.item.getAttribute('type') : res.type
    let aIndex = res.newIndex
    let componentData = deepCopy(COM_DEFAULT_DATA[cmType])
    componentData.code = cmType + Date.now()
    state.sortApi.splice(res.newIndex, 0, componentData)
    res.item && res.item.remove()
    commit('setCommon', { flag: true, index: aIndex })
    // commit('setEditIndex', aIndex - 1)
  },
  getPackageInfo ({ state, commit }, packageName) {
    getAppDetail({ packageName }).then((res: any) => {
      commit('setPackageInfo', res.value)
    })
  }
}

export default actions
