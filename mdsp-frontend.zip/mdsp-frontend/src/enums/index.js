export const HOST = 'mzdsp.meizu.com'
export const AGENT_HOST = 'mzagent.meizu.com'
export const BANK_INFO = {
  company: '珠海市魅族通讯设备有限公司',
  bank: '中国工商银行珠海明珠支行',
  cardNo: '2002 0246 0910 0123 176'
}
export const USER_TYPE = {
  0: { agent: false, desc: '普通广告主' },
  1: { agent: true, desc: '一级代理' },
  2: { agent: true, desc: '二级代理' },
  3: { agent: true, desc: '一级代理下的二级代理' },
  4: { agent: false, desc: '一级代理下的广告主' },
  5: { agent: false, desc: '二级代理下的广告主' }
}
export const CLIENT_TYPE = {
  SPONSOR: 0,
  AGENT: 2,
  FIRST_AGENT: 1
}
export const AGENT_STATUS = {
  '-1': { name: '已解绑', value: -1 },
  1: { name: '已授权', value: 1 }
}
export const AUTHEN__STATUS = {
  0: { name: '审核中', value: 0 },
  1: { name: '已认证', value: 1 },
  2: { name: '认证失败', value: 2 },
  3: { name: '更新资质', value: 3 }
}
export const USER_STATUS = {
  NONE: -1,
  VERIFYING: 0,
  VERIFYED: 1,
  REJECT: 2,
  CHECKING: 3
}
export const ACCOUNT_STATUS = {
  '-1': { name: '未认证', value: -1 },
  0: { name: '审核中', value: 0 },
  1: { name: '已认证', value: 1 },
  2: { name: '认证失败', value: 2 },
  3: { name: '审核通过，更新资质中', value: 3 }
}
export const PROMOTION_TARGET = {
  1: { name: '应用下载', desc: '以增加 Android 应用下载量为目标的推广方式，覆盖应用商店、信息流、视频流等流量场景。', value: 1 },
  2: { name: '网页推广', desc: '以增加网页访问量为目标的推广方式，覆盖信息流、浏览器、视频等流量场景。', value: 2 }
}

export const CUSTOMER_TYPE = {
  1: { name: '二级代理', desc: '', value: 1 },
  2: { name: '广告主', desc: '', value: 2 }
}

export const CHANNEL_TYPE = {
  1: { name: '商店', desc: '', value: 1 },
  2: { name: '非商店', desc: '', value: 2 }
}

export const STAT_TYPE = {
  1: { name: '汇总统计', desc: '', value: 1 },
  2: { name: '分日统计', desc: '', value: 2 }
}

export const SLOT_BUNDLE = {
  1: { name: '移动Banner', size: '984x420', desc: '覆盖如应用商店、视频等各移动应用的横幅', value: 1 },
  2: { name: '信息流', size: '大图、小图、三图', desc: '覆盖资讯、浏览器等Feed流的原生资源', value: 2 },
  3: { name: '商店搜索', size: '原生广告', desc: '魅族应用商店搜索模块', value: 3 },
  4: { name: '商店原生', size: '原生广告', desc: '包含应用商店原生资源位', value: 4 },
  5: { name: '福利广告', size: '原生广告', desc: '包含应用商店趣福利、红包活动等资源', value: 5 }
}

export const ACTIVE_SLOT_BUNDLE = {
  8: { name: 'push通知', size: '文字、图文', desc: '系统通知栏的推送资源', value: 8 },
  9: { name: '桌面通知', size: '文字、图标', desc: '系统桌面的应用描述', value: 9 }
}
// 计费方式0:CPM(展示计费) 1:CPC(点击计费) 2:CPD(下载计费) 3:CPT 4:CPI
export const BID_TYPE = {
  CPM: 0,
  CPC: 1,
  CPD: 2,
  CPT: 3,
  CPI: 4
}
// 优化目标
export const OCPC_TYPE = {
  CPM: 0,
  CLICK: 1,
  INSTALL: 2,
  ACTIVE: 3
}
// 规格ID
export const SPEC_TYPE = {
  main_img: 1,
  icon_img: 2,
  muti_img: 3
}
// 计划状态
export const PLAN_STATUS = {
  0: { name: '启动', value: 0 },
  1: { name: '暂停', value: 1 },
  2: { name: '余额不足', value: 2 },
  3: { name: '预算不足', value: 3 },
  999: { name: '删除', value: 999 },
  1111: { name: '', value: 1111 }
}
// 单元状态
export const UNIT_STATUS = {
  0: { name: '投放中', value: 0 },
  1: { name: '暂停', value: 1 },
  999: { name: '删除', value: 999 },
  1111: { name: '', value: 1111 }
}
// 创意状态
export const IDEA_STATUS = {
  '-1': { name: '提交中 ', value: -1 },
  0: { name: '启动', value: 0 },
  1: { name: '暂停', value: 1 },
  2: { name: '审核中', value: 2 },
  3: { name: '审核拒绝', value: 3 },
  999: { name: '删除', value: 999 },
  1111: { name: '', value: 1111 }
}
// 拉活状态
export const ACTIVE_STATUS = {
  0: { name: '未通过', value: 0 },
  1: { name: '审核中', value: 1 },
  2: { name: '已排期', value: 2 },
  3: { name: '投放中', value: 3 },
  4: { name: '已结束', value: 4 },
  5: { name: '已取消', value: 5 }
}
// 拉活类型
export const ACTIVE_TYPE = {
  8: { name: 'push通知', value: 8 },
  9: { name: '桌面通知', value: 9 }
}
export const TAG_TYPE = {
  sexTag: 1002,
  ageTag: 1001,
  cityTag: 1007,
  interestTag: 1006,
  netTag: 102,
  installTag: 100,
  crowdTag: 103
}
export const TEMPLATE_STYLE = {
  1: { name: '浮层样式', code: 'fullpage', value: 1 },
  2: { name: '短图文样式', code: 'longpage', value: 2 },
  3: { name: '长图文样式', code: 'newlongpage', value: 3 },
  4: { name: '移动建站', code: 'site', value: 4 }
}
export const MONEY_TYPE = {
  1: { name: '广告主线下充值', value: 1 },
  3: { name: '消耗返点充值', value: 3 },
  4: { name: '转账充值', value: 4 },
  5: { name: '转账返点', value: 5 },
  7: { name: '扣款', value: 7 },
  8: { name: '广告主线上充值', value: 8 },
  9: { name: '广告主线上返点充值', value: 9 }
}
export const FINANCILA_TYPE = {
  1: { name: '转出', value: 1 },
  2: { name: '转入', value: 2 }
}
export const INVOICE_STATUS = {
  0: { name: '审核中', value: 0 },
  1: { name: '审核通过', value: 1 },
  2: { name: '审核不通过', value: 2 }
}
export const INVOICE_TYPE = {
  1: { name: '增值税普通发票', value: 1 },
  2: { name: '增值税专用发票', value: 2 }
}
export const TRANSCATION_STATUS = {
  0: { name: '审核中', value: 0 },
  1: { name: '转账成功', value: 1 },
  2: { name: '审核不通过', value: 2 },
  3: { name: '未支付', value: 3 }
}
export const NOTIFY_TYPE = {
  100: { value: 100, name: '系统消息', subTypes: [1] },
  101: { value: 101, name: '账户消息', subTypes: [2, 3, 4, 15, 16] },
  102: { value: 102, name: '审核消息', subTypes: [5, 6] },
  103: { value: 103, name: '财务消息', subTypes: [7, 8, 9, 10, 17, 18] }
}
export const STAT_INDICATOR = {
  exposure: { key: 'exposure', type: 'number', name: '曝光量' },
  click: { key: 'click', type: 'number', name: '点击量' },
  clickRate: { key: 'clickRate', type: 'rate', name: '点击率' },
  downloadRate: { key: 'downloadRate', type: 'rate', name: '下载率' },
  download: { key: 'download', type: 'number', name: '下载量' },
  clickPrice: {
    key: 'clickPrice',
    type: 'price',
    name: '点击单价（元）',
    fat: 'cost/click'
  },
  downloadPrice: {
    key: 'downloadPrice',
    type: 'price',
    name: '下载单价（元）',
    fat: 'cost/download'
  },
  cost: { key: 'cost', type: 'price', name: '消费（元）' },
  exposurePrice: {
    key: 'exposurePrice',
    type: 'number',
    name: '千次曝光消费（元）',
    fat: 'cost/exposure*1000'
  }
}
// export const STAT_BASE_INDICATOR = {
//   exposure: { key: 'exposure', type: 'number', name: '曝光量' },
//   click: { key: 'click', type: 'number', name: '点击量' },
//   clickRate: { key: 'clickRate', type: 'rate', name: '点击率' },
// }
export const SITE_STAT_INDICATOR = {
  exposure: { key: 'exposure', type: 'number', name: '曝光量' },
  download: { key: 'download', type: 'number', name: '下载量' },
  open: { key: 'open', type: 'number', name: '打开量' },
  form: { key: 'form', type: 'number', name: '表单提交量' },
  call: { key: 'call', type: 'number', name: '电话拨打量' },
  consult: { key: 'consult', type: 'number', name: '在线咨询量' }
}
export const LANDINGPAGE_TYPE = {
  1: { name: '应用下载落地页', value: 1 }
}
export const LANDINGPAGE_STATUS = {
  0: { name: '未发布', label: '未发布', value: 0 },
  1: { name: '已发布', label: '已发布', value: 1 }
}
export const LANDINGPAGE_TEMPLATE = {
  1: { name: '浮层样式', value: 1, code: 'fullpage' },
  2: { name: '短图文样式', value: 2, code: 'longpage' },
  3: { name: '长图文样式', value: 3, code: 'newlongpage' },
  4: { name: '移动建站', value: 4, code: 'site' }
}
export const LANDINGPAGE_BTNSTYLE = {
  1: { name: '应用商店样式', value: 1 },
  2: { name: '透明浮沉样式', value: 2 }
}
export const MAX_DATE = '2100-01-01'
export const MAX_BUDGET = 21474836
export const PAGE_SIZE = 10
export const PAGE_SIZES = [10, 20, 50, 100]
// 人群包
export const CROWD_STATUS = {
  0: { name: '校验中', label: '校验中', value: 0 },
  1: { name: '未通过', label: '未通过', value: 1 },
  2: { name: '已完成', label: '已完成', value: 2 },
  3: { name: '计算中', label: '计算中', value: 3 },
  4: { name: '计算失败', label: '计算失败', value: 4 }
}
// 渠道包
export const CHANNEL_STATUS = {
  0: { name: '校验中', label: '校验中', value: 0 },
  1: { name: '通过', label: '通过', value: 1 },
  2: { name: '未通过', label: '未通过', value: 2 },
  3: { name: '删除', label: '删除', value: 3 }
}
export const CROWD_TYPE = {
  0: { name: '上传', label: '上传', value: 0 },
  1: { name: '扩展', label: '扩展', value: 1 }
}
export const BATCH_STATUS = [
  { name: '启动', value: 0 },
  { name: '暂停', value: 1 },
  { name: '删除', value: 999 }
]
export const ISSUE_TYPES = [
  { label: '行业资质', value: 1 },
  { label: '财务充值', value: 2 },
  { label: '广告投放', value: 3 },
  { label: '数据报表', value: 4 },
  { label: '工具辅助', value: 5 },
  { label: '交互体验', value: 6 },
  { label: '其他', value: 7 }
]
export const ACTION_BUTTON = [
  { name: '查看详情', value: 'VIEW_DETAIL' },
  { name: '立即下载', value: 'DOWNLOAD' },
  { name: '立即打开', value: 'OPEN' }
]
