import Vue from 'vue'
import Router from 'vue-router'
import { USER_STATUS } from '@/enums'
/**
 * Views
 */
// 首页
import Index from './views/Index'
// 帮助
import Help from './views/Help'
// 工具箱
const ToolkitContainer = () => import(/* webpackChunkName: "toolkit" */ './views/toolkit/Container')
const ToolkitMenu = () => import(/* webpackChunkName: "toolkit" */ './views/toolkit/Menu')
const MessageSetting = () => import(/* webpackChunkName: "toolkit" */ './views/toolkit/MessageSetting')
const Log = () => import(/* webpackChunkName: "toolkit" */ './views/toolkit/Log')
const Keyword = () => import(/* webpackChunkName: "toolkit" */ './views/toolkit/Keyword')
const DynamicPack = () => import(/* webpackChunkName: "toolkit" */ './views/toolkit/DynamicPack')
const LandingPage = () => import(/* webpackChunkName: "toolkit" */ './views/toolkit/LandingPage')
const LandingPageEdit = () => import(/* webpackChunkName: "toolkit" */ './views/toolkit/LandingPageEdit')
const UserInfo = () => import(/* webpackChunkName: "toolkit" */ './views/toolkit/UserInfo')
const UserInfoEdit = () => import(/* webpackChunkName: "toolkit" */ './views/toolkit/UserInfoEdit')
const SelectType = () => import(/* webpackChunkName: "toolkit" */ './views/toolkit/SelectType')
const CrowdPack = () => import(/* webpackChunkName: "toolkit" */ './views/toolkit/CrowdPack')
const AppPack = () => import(/* webpackChunkName: "toolkit" */ './views/toolkit/AppPack')
const PushBlacklist = () => import(/* webpackChunkName: "toolkit" */ './views/toolkit/PushBlacklist')
// 财务管理
const FinancialContainer = () => import(/* webpackChunkName: "financial" */ './views/financial/Container')
const Recharge = () => import(/* webpackChunkName: "financial" */ './views/financial/Recharge')
const Transaction = () => import(/* webpackChunkName: "financial" */ './views/financial/Transaction')
const FinancialDetails = () => import(/* webpackChunkName: "financial" */ './views/financial/FinancialDetails')
const rechargeFinish = () => import(/* webpackChunkName: "financial" */ './views/financial/rechargeFinish')
const invoiceList = () => import(/* webpackChunkName: "financial" */ './views/financial/invoiceList')
// 数据分析
const AnalysisContainer = () => import(/* webpackChunkName: "analysis" */ './views/analysis/Container')
const KeywordData = () => import(/* webpackChunkName: "analysis" */ './views/analysis/KeywordData')
const AssetData = () => import(/* webpackChunkName: "analysis" */ './views/analysis/AssetData')
const UnitData = () => import(/* webpackChunkName: "analysis" */ './views/analysis/UnitData')
const PlanData = () => import(/* webpackChunkName: "analysis" */ './views/analysis/PlanData')
const AccountData = () => import(/* webpackChunkName: "analysis" */ './views/analysis/AccountData')
const SiteData = () => import(/* webpackChunkName: "analysis" */ './views/analysis/SiteData')
const PushData = () => import(/* webpackChunkName: "analysis" */ './views/analysis/PushData')
// 代理商系统
const AgentContainer = () => import(/* webpackChunkName: "agent" */'./views/agent/Container')
const Client = () => import(/* webpackChunkName: "agent" */'./views/agent/Client')
const DailyStat = () => import(/* webpackChunkName: "agent" */'./views/agent/DailyStat')
const ClientStat = () => import(/* webpackChunkName: "agent" */'./views/agent/ClientStat')
const Register = () => import(/* webpackChunkName: "agent" */'./views/agent/Register')
const AgentRecharge = () => import(/* webpackChunkName: "agent" */'./views/agent/Recharge')

// 推广管理
const PromotionContainer = () => import(/* webpackChunkName: "promotion" */ './views/promotion/Container')
const AdPlan = () => import(/* webpackChunkName: "promotion" */ './views/promotion/AdPlan')
const AdUnit = () => import(/* webpackChunkName: "promotion" */ './views/promotion/AdUnit')
const AdAsset = () => import(/* webpackChunkName: "promotion" */ './views/promotion/AdAsset')
const AdActive = () => import(/* webpackChunkName: "promotion" */ './views/promotion/AdActive')
const AdEdit = () => import(/* webpackChunkName: "promotion" */ './views/promotion/AdEdit')
const AdEditPlan = () => import(/* webpackChunkName: "promotion" */ './views/promotion/adedit/PlanEdit')
const AdEditUnit = () => import(/* webpackChunkName: "promotion" */ './views/promotion/adedit/UnitEdit')
const AdEditIdea = () => import(/* webpackChunkName: "promotion" */ './views/promotion/adedit/IdeaEdit')
const AdEditActive = () => import(/* webpackChunkName: "promotion" */ './views/promotion/adedit/ActiveEdit')
Vue.use(Router)

const router = new Router({
  routes: [
    {
      path: '/',
      name: 'Index',
      component: Index,
      meta: {
        title: '首页'
      }
    },
    {
      path: '/toolkit',
      component: ToolkitContainer,
      children: [
        {
          path: 'Menu',
          name: 'ToolkitMenu',
          component: ToolkitMenu
        },
        {
          path: 'MessageSetting',
          name: 'MessageSetting',
          component: MessageSetting,
          meta: {
            title: '消息设置'
          }
        },
        {
          path: 'Log',
          name: 'Log',
          component: Log,
          meta: {
            title: '操作日志'
          }
        },
        {
          path: 'Keyword',
          name: 'Keyword',
          component: Keyword,
          meta: {
            title: '关键词包'
          }
        },
        {
          path: 'DynamicPack',
          name: 'DynamicPack',
          component: DynamicPack,
          meta: {
            title: '动态词包'
          }
        },
        {
          path: 'LandingPage',
          name: 'LandingPage',
          component: LandingPage,
          meta: {
            title: '落地页模板'
          }
        },
        {
          path: 'LandingPage/Edit',
          name: 'LandingPageEdit',
          component: LandingPageEdit,
          meta: {
            title: '落地页模板'
          }
        },
        {
          path: 'UserInfo',
          name: 'UserInfo',
          component: UserInfo,
          meta: {
            title: '用户信息'
          }
        },
        {
          path: 'UserInfo/Edit',
          name: 'UserInfoEdit',
          component: UserInfoEdit,
          meta: {
            title: '修改用户信息'
          }
        },
        {
          path: 'SelectType',
          name: 'SelectType',
          component: SelectType
        },
        {
          path: 'CrowdPack',
          name: 'CrowdPack',
          component: CrowdPack,
          meta: {
            title: '人群包管理'
          }
        },
        {
          path: 'AppPack',
          name: 'AppPack',
          component: AppPack,
          meta: {
            title: '应用渠道包管理'
          }
        },
        {
          path: 'PushBlacklist',
          name: 'PushBlacklist',
          component: PushBlacklist,
          meta: {
            title: '应用拉活黑名单'
          }
        },
        {
          path: '',
          redirect: 'Menu'
        }
      ]
    },
    {
      path: '/promotion/AdEdit',
      name: 'AdEdit',
      component: AdEdit,
      meta: {
        title: '新建广告'
      },
      children: [
        {
          path: 'PlanEdit',
          name: 'AdEditPlan',
          component: AdEditPlan
        },
        {
          path: 'UnitEdit',
          name: 'AdEditUnit',
          component: AdEditUnit
        },
        {
          path: 'IdeaEdit',
          name: 'AdEditIdea',
          component: AdEditIdea
        },
        {
          path: 'ActiveEdit',
          name: 'AdEditActive',
          component: AdEditActive
        }
      ]
    },
    {
      path: '/promotion',
      component: PromotionContainer,
      meta: {
        title: '推广管理'
      },
      children: [
        {
          path: 'AdPlan',
          name: 'AdPlan',
          component: AdPlan
        },
        {
          path: 'AdUnit',
          name: 'AdUnit',
          component: AdUnit
        },
        {
          path: 'AdIdea',
          name: 'AdAsset',
          component: AdAsset
        },
        {
          path: 'AdActive',
          name: 'AdActive',
          component: AdActive
        },
        {
          path: '',
          redirect: 'AdPlan'
        }
      ]
    },
    {
      path: '/financial',
      component: FinancialContainer,
      children: [
        {
          path: 'Recharge',
          name: 'Recharge',
          component: Recharge,
          meta: {
            title: '充值'
          }
        },
        {
          path: 'Transaction',
          name: 'Transaction',
          component: Transaction,
          meta: {
            title: '交易申请记录'
          }
        },
        {
          path: 'FinancialDetails',
          name: 'FinancialDetails',
          component: FinancialDetails,
          meta: {
            title: '财务明细'
          }
        },
        {
          path: 'rechargeFinish',
          name: 'rechargeFinish',
          component: rechargeFinish,
          meta: {
            title: '充值完成'
          }
        },
        {
          path: 'invoiceList',
          name: 'invoiceList',
          component: invoiceList,
          meta: {
            title: '发票申请记录'
          }
        },
        {
          path: '',
          redirect: 'Recharge'
        }
      ]
    },
    {
      path: '/analysis',
      component: AnalysisContainer,
      children: [
        {
          path: 'AssetData',
          name: 'AssetData',
          component: AssetData,
          meta: {
            title: '广告创意数据'
          }
        },
        {
          path: 'PushData',
          name: 'PushtData',
          component: PushData,
          meta: {
            title: '应用拉活数据'
          }
        },
        {
          path: 'KeywordData',
          name: 'KeywordData',
          component: KeywordData,
          meta: {
            title: '关键词数据'
          }
        },
        {
          path: 'PlanData',
          name: 'PlanData',
          component: PlanData,
          meta: {
            title: '广告计划数据'
          }
        },
        {
          path: 'AccountData',
          name: 'AccountData',
          component: AccountData,
          meta: {
            title: '账号数据'
          }
        },
        {
          path: 'UnitData',
          name: 'UnitData',
          component: UnitData,
          meta: {
            title: '广告单元数据'
          }
        },
        {
          path: 'SiteData',
          name: 'SiteData',
          component: SiteData,
          meta: {
            title: '站点数据'
          }
        },
        {
          path: '',
          redirect: 'AccountData'
        }
      ]
    },
    {
      path: '/LoginTip/:tipType',
      // name: 'LoginTip',
      component: Index
    },
    // 代理商系统
    {
      path: '/',
      component: AgentContainer,
      children: [
        {
          path: 'Client',
          name: 'Client',
          component: Client,
          meta: {
            title: '广告主管理',
            agent: true
          }
        },
        {
          path: 'Client/LoginTip/:tipType',
          name: 'LoginTip',
          component: Client
        },
        {
          path: 'UserInfoAdd/:agent_sponsor_id',
          name: 'UserInfoAdd',
          component: UserInfoEdit,
          meta: {
            title: '新增客户',
            agent: true
          }
        },
        {
          path: 'DailyStat',
          name: 'DailyStat',
          component: DailyStat,
          meta: {
            title: '每日数据',
            agent: true
          }
        },
        {
          path: 'ClientStat',
          name: 'ClientStat',
          component: ClientStat,
          meta: {
            title: '客户数据',
            agent: true
          }
        },
        {
          path: 'AgentRecharge',
          name: 'AgentRecharge',
          component: AgentRecharge,
          meta: {
            title: '充值',
            agent: true
          }
        },
        {
          path: 'AgentTransaction',
          name: 'AgentTransaction',
          component: Transaction,
          meta: {
            title: '交易明细',
            agent: true
          }
        },
        {
          path: 'AgentMessageSetting',
          name: 'AgentMessageSetting',
          component: MessageSetting,
          meta: {
            title: '消息设置',
            agent: true
          }
        },
        {
          path: 'AgentRegister',
          name: 'AgentRegister',
          component: Register,
          meta: {
            title: '代理商注册',
            agent: true
          }
        }
      ]
    },
    {
      path: '/help',
      name: 'Help',
      component: Help,
      meta: {
        title: '帮助'
      }
    }
  ]
})
router.beforeEach((to, from, next) => {
  const whiteList = ['UserInfoEdit', 'AgentRegister', 'SelectType']
  if (router.app.$store && [USER_STATUS.NONE, USER_STATUS.VERIFYING, USER_STATUS.REJECT].indexOf(router.app.$store.state.userInfo.status) !== -1) {
    if (to.name === 'UserInfo' && [USER_STATUS.VERIFYING, USER_STATUS.REJECT].indexOf(router.app.$store.state.userInfo.status) !== -1) {
      next()
    } else if (to.name === 'Help') {
      next()
    } else if (whiteList.indexOf(to.name) === -1 && to.path !== '/toolkit/UserInfo') {
      let registerPath = router.app.$store.state.userInfo.isSponsor ? 'UserInfo' : 'AgentRegister'
      next({ name: registerPath })
    } else {
      next()
    }
  } else {
    const route = [...to.matched].reverse().find(v => v.meta && v.meta.title)
    if (route) {
      document.title = route.meta.title + ' - ' + '魅族营销平台'
    }
    next()
  }
})

export default router
