<template>
  <div class="home-container">
    <home-aside :nav-list="navList" module="analysis"></home-aside>
    <main class="home-main">
      <router-view/>
    </main>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import HomeAside from '@/components/Aside'
export default {
  data () {
    return {}
  },
  computed: {
    ...mapGetters(['userInfo']),
    navList () {
      let navListArr = [
        { name: 'AccountData', title: '账户数据', icon: 'transaction' },
        { name: 'PlanData', title: '广告计划数据', icon: 'plan' },
        { name: 'UnitData', title: '广告单元数据', icon: 'unit' },
        { name: 'AssetData', title: '广告创意数据', icon: 'asset' },
        { name: 'KeywordData', title: '关键词数据', icon: 'keyword' },
        { name: 'SiteData', title: '站点数据', icon: 'landingpage' }
      ]
      if (this.userInfo.whiteList && this.userInfo.whiteList['push_sponsor']) {
        navListArr.push({ name: 'PushData', title: '应用拉活数据', icon: 'push' })
      }
      return navListArr
    }
  },
  components: {
    HomeAside
  }
}
</script>

<style lang="scss">
.customCols {
  .el-checkbox {
    margin-top: 10px;
  }
  .el-checkbox+.el-checkbox {
    margin-left: 0;
  }
  .el-checkbox:not(:last-child) {
    margin-right: 30px;
  }
}
</style>
