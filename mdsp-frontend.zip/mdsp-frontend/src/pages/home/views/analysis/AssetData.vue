<script>
import utils from '@/utils'
import statDataMixin from '@/mixins/statData'
import { getUnitList, getIdeaList, getStatIdeaList, exportStatIdeaList, getStatIdeaSummary } from '@/api'
export default {
  mixins: [statDataMixin],
  data () {
    return {
      unitList: [],
      ideaList: [],
      getStatList: getStatIdeaList,
      getStatSummary: getStatIdeaSummary,
      exportStatList: exportStatIdeaList,
      baseIndCols: ['planId', 'unitId', 'id'],
      defaultBaseIndCols: ['planId', 'unitId', 'id'],
      baseStateIndicator: [{ key: 'planId', type: 'number', name: '计划id' }, { key: 'unitId', type: 'number', name: '单元id' }, { key: 'id', type: 'number', name: '创意id' }],
      customColumns: [
        { prop: 'planId', label: '计划id' },
        { prop: 'planName', label: '计划名称' },
        { prop: 'unitId', label: '单元id' },
        { prop: 'unitName', label: '单元名称' },
        { prop: 'id', label: '创意id' },
        { prop: 'name', label: '创意名称' }
      ]
    }
  },
  computed: {
    searchOptions () {
      return [
        { type: 'select', key: 'planId', label: '广告计划', options: this.planList, filterable: true },
        { type: 'select', key: 'unitId', label: '广告单元', options: this.unitList, filterable: true },
        { type: 'select', key: 'ideaId', label: '广告创意', options: this.ideaList, filterable: true },
        { type: 'daterange', key: 'Time', label: '选择日期', default: [new Date(), new Date()] }
      ]
    }
  },
  methods: {
    fetchUnitList () {
      const date = new Date()
      getUnitList({
        pageNumber: 1,
        pageSize: 9999,
        startTime: utils.formatDate(date),
        endTime: utils.formatDate(date),
        planId: this.formData.planId
      }).then(res => {
        if (res.code === 200 && res.value) {
          this.unitList = (res.value.data || []).map(({unitName: label, unitId: value}) => ({label, value}))
        }
      })
    },
    fetchIdeaList () {
      const date = new Date()
      getIdeaList({
        pageNumber: 1,
        pageSize: 9999,
        startTime: utils.formatDate(date),
        endTime: utils.formatDate(date),
        unitId: this.formData.unitId
      }).then(res => {
        if (res.code === 200 && res.value) {
          this.ideaList = (res.value.data || []).map(({name: label, ideaId: value}) => ({label, value}))
        }
      })
    }
  },
  watch: {
    'formData.planId' (val) {
      this.fetchUnitList()
    },
    'formData.unitId' (val) {
      this.fetchIdeaList()
    }
  }
}
</script>
