<script>
import statDataMixin from '@/mixins/statData'
import { getStatPlanList, exportStatPlanList, getStatPlanSummary } from '@/api'
export default {
  mixins: [statDataMixin],
  data () {
    return {
      getStatList: getStatPlanList,
      getStatSummary: getStatPlanSummary,
      exportStatList: exportStatPlanList,
      baseIndCols: ['id'],
      defaultBaseIndCols: ['id'],
      baseStateIndicator: [{ key: 'id', type: 'number', name: '计划id' }],
      customColumns: [
        { prop: 'id', label: '计划id' },
        { prop: 'name', label: '计划名称' }
      ]
    }
  }
}
</script>
