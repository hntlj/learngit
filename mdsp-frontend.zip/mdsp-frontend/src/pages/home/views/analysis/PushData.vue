<script>
import statDataMixin from '@/mixins/statData'
import { filters } from '@/utils/filters'
import { ACTIVE_TYPE } from '@/enums'
import { getStatPushList, exportStatPushList, getStatPushSummary } from '@/api'
export default {
  mixins: [statDataMixin],
  data () {
    return {
      indicatorList: [
        { key: 'exposure', type: 'number', name: '曝光量' },
        { key: 'click', type: 'number', name: '点击量' },
        { key: 'clickRate', type: 'rate', name: '点击率' },
        { key: 'clickPrice', type: 'price', name: '点击单价（元）', fat: 'cost/click' }
      ],
      getStatList: getStatPushList,
      getStatSummary: getStatPushSummary,
      exportStatList: exportStatPushList,
      customColumns: [
        { prop: 'name', label: '广告名称' }
      ],
      columns: [
        { prop: 'exposure', label: '曝光量', sortable: 'custom', formatter: row => filters.number(row.exposure) },
        { prop: 'click', label: '点击量', sortable: 'custom', formatter: row => filters.number(row.click) },
        { prop: 'clickRate', label: '点击率', sortable: 'custom', formatter: this.formatterClickRate },
        { prop: 'clickPrice', label: '点击单价（元）', sortable: 'custom', formatter: this.formatterClickRrice }
      ],
      tableColumnObj: {
        click: 0,
        clickPrice: 0,
        clickRate: 0,
        exposure: 0,
        id: 0,
        name: '合计',
        statTime: ''
      },
      showFilterNoCost: false
    }
  },
  computed: {
    searchOptions () {
      return [
        { type: 'text', key: 'pushId', placeholder: '广告 ID' },
        { type: 'text', key: 'name', placeholder: '广告名称' },
        { type: 'select', key: 'type', label: '广告计划', options: Object.values(ACTIVE_TYPE).map(({value, name: label}) => ({value, label})) },
        { type: 'daterange', key: 'Time', label: '选择日期', default: [new Date(), new Date()] }
      ]
    }
  },
  methods: {
    formatterClickRate (row) {
      return row.name === '合计' || !row.name ? '-' : row.clickRate + '%'
    },
    formatterClickRrice (row) {
      return row.name === '合计' || !row.name ? '-' : filters.currency(row.clickPrice)
    }
  },
  watch: {}
}
</script>
