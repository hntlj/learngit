<script>
import statDataMixin from '@/mixins/statData'
import { getStatAccountList, exportStatAccountList, getStatAccountSummary } from '@/api'
export default {
  mixins: [statDataMixin],
  data () {
    return {
      getStatList: getStatAccountList,
      getStatSummary: getStatAccountSummary,
      exportStatList: exportStatAccountList
    //   customColumns: [
    //     { prop: 'name', label: '计划名称' }
    //   ]
    }
  },
  computed: {
    searchOptions () {
      return [
        { type: 'daterange', key: 'Time', label: '选择日期', default: [new Date(), new Date()] }
      ]
    }
  }
}
</script>
