<script>
import utils from '@/utils'
import statDataMixin from '@/mixins/statData'
import { getUnitList, getStatUnitList, exportStatUnitList, getSlotBundleList, getStatUnitSummary } from '@/api'
export default {
  mixins: [statDataMixin],
  data () {
    return {
      unitList: [],
      slotBundleList: [],
      getStatList: getStatUnitList,
      getStatSummary: getStatUnitSummary,
      exportStatList: exportStatUnitList,
      baseIndCols: ['planId', 'id'],
      defaultBaseIndCols: ['planId', 'id'],
      baseStateIndicator: [{ key: 'planId', type: 'number', name: '计划id' }, { key: 'id', type: 'number', name: '单元id' }],
      customColumns: [
        { prop: 'planId', label: '计划id' },
        { prop: 'planName', label: '计划名称' },
        { prop: 'id', label: '单元id' },
        { prop: 'name', label: '单元名称' }
      ]
    }
  },
  computed: {
    searchOptions () {
      return [
        { type: 'select', key: 'planId', label: '广告计划', options: this.planList, filterable: true },
        { type: 'select', key: 'unitId', label: '广告单元', options: this.unitList, filterable: true },
        { type: 'select', key: 'slotBundleId', label: '广告类型', options: this.slotBundleList, filterable: true },
        { type: 'daterange', key: 'Time', label: '选择日期', default: [new Date(), new Date()] }
      ]
    }
  },
  methods: {
    fetchUnitList () {
      const date = new Date()
      getUnitList({
        pageNumber: 1,
        pageSize: 9999,
        startTime: utils.formatDate(date),
        endTime: utils.formatDate(date),
        planId: this.formData.planId
      }).then(res => {
        if (res.code === 200 && res.value) {
          this.unitList = (res.value.data || []).map(({unitName: label, unitId: value}) => ({label, value}))
        }
      })
    },
    fetchSlotBundleList () {
      getSlotBundleList({
      }).then(res => {
        if (res.code === 200 && res.value) {
          this.slotBundleList = (res.value || []).map(({name: label, id: value}) => ({label, value}))
        }
      })
    }
  },
  watch: {
    'formData.planId' (val) {
      this.fetchUnitList()
      this.fetchSlotBundleList()
    }
  }
}
</script>
