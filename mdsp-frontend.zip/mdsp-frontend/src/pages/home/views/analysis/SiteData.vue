<template>
  <div class="pd24">
    <div class="home-card pd24">
      <div class="home-card__main" style="margin-bottom:-36px">
        <super-form class="home-searchform" label-width="0px" :form-list="searchOptions" v-model="formData"></super-form>
      </div>
    </div>
    <div class="home-card mt24 pd24">
      <div class="home-card__header">
        <el-popover placement="bottom-start" width="300" trigger="click">
          <el-checkbox :indeterminate="isIndeterminate" v-model="selectAll" @change="onSelectAllChanged">全选</el-checkbox>
          <el-checkbox-group v-model="indCols" class="customCols" @change="onIndColsChanged">
            <el-checkbox v-for="ind in indicatorList" :key="ind.key" :label="ind.key">{{ ind.name }}</el-checkbox>
          </el-checkbox-group>
          <el-button plain slot="reference">自定义列 <i class="el-icon-arrow-down"></i></el-button>
        </el-popover>
        <el-button type="primary" class="pull-right" style="width: 130px" @click="onExport">下载报表</el-button>
      </div>
      <div class="home-card__main">
        <el-table class="table-border" :data="dataList" :default-sort="defaultSort" v-loading="fetching" @sort-change="onSortChange">
          <el-table-column align="center" v-for="col in tableColumn" :key="col.prop"
            :prop="col.prop"
            :sortable="col.sortable"
            :label="col.label"
            :formatter="col.formatter">
          </el-table-column>
        </el-table>
      </div>
      <div class="home-card__footer">
        <el-pagination class="pull-right"
          v-if="dataListTotal > defaultPageSize"
          background
          :page-size="PAGE_SIZE"
          :page-sizes="PAGE_SIZES"
          :current-page="formData.pageNumber"
          :total="dataListTotal"
          @size-change="onSizeChange"
          @current-change="onPageChanged"
          layout="total, sizes, prev, pager, next, jumper">
        </el-pagination>
      </div>
    </div>
    <el-dialog custom-class="dialog-preview" title="效果预览" :visible.sync="showPreview">
      <div class="preview-wrapper" v-loading="previewLoading">
        <iframe ref="iframe" :src="previewUrl" @load="onPageLoad" v-show="!previewLoading"></iframe>
      </div>
      <div slot="footer" v-if="isPublish">
        <el-button @click="showPreview = false">取消</el-button>
        <el-button type="primary" @click="onPublish(landingPage)" v-show="showPublish">发布</el-button>
      </div>
    </el-dialog>
    <el-dialog title="效果预览" :visible.sync="showPreviewSite" width="800px">
      <div class="site-preview-box">
        <div class="site-iframe">
          <iframe :src="siteUrl"></iframe>
        </div>
        <div class="site-qrcode">
          <p class="site-qrcode__title">预览二维码</p>
          <div class="site-qrcode__img" ref="qrcode"></div>
          <p class="site-qrcode__tip">链接及二维码有时效限制, 请勿用于广告投放!</p>
        </div>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button @click="showPreviewSite = false">取 消</el-button>
        <el-button type="primary" @click="onPublishSite(landingPage)" v-show="showPublishSite">发布</el-button>
      </div>
    </el-dialog>
    <el-dialog class="tip-dialog" title="提示" :visible.sync="showUpdateTip" width="30%">
      <P class="tip-dialog__title">该落地页已关联以下创意，请解除关联后再次操作!</P>
      <el-table :data="ideasData">
        <el-table-column property="id" label="创意ID"></el-table-column>
        <el-table-column property="name" label="创意名称"></el-table-column>
      </el-table>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="showUpdateTip = false">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { filters } from '@/utils/filters'
import utils from '@/utils'
import templatePageMixin from '@/mixins/templatePage'
import Storage from '@/utils/storage'
import { LANDINGPAGE_TEMPLATE, PAGE_SIZE, PAGE_SIZES, HOST, SITE_STAT_INDICATOR } from '@/enums'
import { getAppDetail, getLandingPageDailyList, exportStatLandpage } from '@/api'
import sortable from '@/mixins/sortable'
import SuperForm from '@/components/SuperForm'
const DEFAULT_DEMENSION = Object.keys(SITE_STAT_INDICATOR)
export default {
  mixins: [templatePageMixin, sortable],
  data () {
    const lastWeek = new Date().getTime() - 86400000 * 6
    return {
      PAGE_SIZE,
      PAGE_SIZES,
      defaultPageSize: PAGE_SIZE,
      fetching: false,
      formData: null,
      searchOptions: [
        { type: 'hidden', key: 'pageNumber', default: 1 },
        { type: 'hidden', key: 'pageSize', default: PAGE_SIZE },
        { type: 'text', key: 'name', placeholder: '站点名称' },
        { type: 'text', key: 'ideaName', placeholder: '创意名称' },
        { type: 'daterange', key: 'Time', label: '选择日期', default: [lastWeek, new Date()] }
      ],
      dataList: [],
      dataListTotal: 0,
      previewUrl: 'auto:blank',
      landingPage: null,
      showPreview: false,
      showPreviewSite: false,
      previewLoading: true,
      isPublish: false,
      showPublish: false,
      showPublishSite: false,
      showUpdateTip: false,
      isPublishing: false,
      siteUrl: '',
      title: '移动建站',
      ideasData: [],
      indicatorList: SITE_STAT_INDICATOR,
      isIndeterminate: false,
      selectAll: true,
      indCols: [...DEFAULT_DEMENSION]
    }
  },
  computed: {
    ...mapGetters(['userInfo']),
    indicatorStorageKey () {
      return `${this.userInfo.uid}_site_indicators`
    },
    tableColumn () {
      const cols = [
        { prop: 'createTime', label: '日期', sortable: 'custom', formatter: ({createTime}) => utils.formatDate(createTime) },
        { prop: 'name', label: '站点名称' },
        { prop: 'ideaName', label: '创意名称' },
        { prop: 'exposure', label: '曝光量', formatter: ({exposure}) => { return filters.number(exposure) }, sortable: true },
        { prop: 'download', label: '下载量', formatter: ({download}) => { return filters.number(download) }, sortable: true },
        { prop: 'open', label: '打开量', formatter: ({open}) => { return filters.number(open) }, sortable: true },
        { prop: 'form', label: '表单提交量', formatter: ({form}) => { return filters.number(form) }, sortable: true },
        { prop: 'call', label: '电话拨打量', formatter: ({call}) => { return filters.number(call) }, sortable: true },
        { prop: 'consult', label: '在线咨询量', formatter: ({consult}) => { return filters.number(consult) }, sortable: true }
      ]
      return cols.filter(col => ['createTime', 'name', 'ideaName', ...this.indCols].indexOf(col.prop) !== -1)
    }
  },
  methods: {
    onPreview (landingPage, isPublish) {
      const code = LANDINGPAGE_TEMPLATE[landingPage.templateStyle].code
      this.landingPage = landingPage
      if (code === 'site') {
        this.siteUrl = landingPage.url
        this.showPreviewSite = true
        let myImage = new Image(160, 160)
        myImage.src = `http://${HOST}/console/mdsp/app/getQRCode?lpId=${landingPage.id}`
        this.$nextTick(() => {
          this.$refs.qrcode['innerHTML'] = ''
          this.$refs.qrcode['appendChild'](myImage)
        })
        this.showPublishSite = isPublish
      } else {
        this.previewUrl = `/template-pages/views/${code}.html?v=${new Date().getTime()}`
        this.showPreview = true
        this.isPublish = isPublish
        this.showPublish = false
      }
    },
    onPageLoad () {
      this.previewLoading = false
      const { type, templateStyle: tplType, name, packageName: pkgName, styleModel } = this.landingPage
      getAppDetail({packageName: pkgName}).then(res => {
        if (res.code === 200 && res.value) {
          const appInfo = res.value
          this.$nextTick(() => {
            this.renderPage(tplType, appInfo, {
              type,
              tplType,
              name,
              pkgName,
              config: {
                [tplType]: JSON.parse(styleModel)
              }
            })
          })
          this.showPublish = true
        }
      })
    },
    onEdit (landingPage, action) {
      window.open(`http://${HOST}/site-pc/index.html#/?id=${landingPage.id}&action=${action}`, '_blank')
    },
    onSizeChange (currSize) {
      this.formData.pageSize = currSize
      this.fetchLandingPageList()
    },
    onPageChanged (currPage) {
      this.formData.pageNumber = currPage
      this.fetchLandingPageList()
    },
    fetchLandingPageList () {
      this.fetching = true
      getLandingPageDailyList({
        ...this.formData,
        desc: (this.order === 'descending') * 1,
        orderBy: this.orderBy,
        queryType: 0
      }).then(res => {
        if (res.code === 200) {
          this.dataList = res.value.data
          this.dataListTotal = res.value.total
        }
      }).finally(() => {
        this.fetching = false
      })
    },
    onSelectAllChanged (value) {
      this.indCols = value ? [...DEFAULT_DEMENSION] : []
      this.isIndeterminate = false
    },
    onIndColsChanged (value) {
      const checkCount = value.length
      this.selectAll = checkCount === DEFAULT_DEMENSION.length
      this.isIndeterminate = checkCount > 0 && checkCount < DEFAULT_DEMENSION.length
      if (Storage.supportStorage) {
        Storage.set(`${this.userInfo.uid}_site_indicators`, value.length > 0 ? value : DEFAULT_DEMENSION)
      }
    },
    onExport () {
      exportStatLandpage(this.formData)
    }
  },
  watch: {
    formData (val) {
      this.throttleFetchLandingPageList()
    }
  },
  created () {
    const indCols = Storage.get(this.indicatorStorageKey)
    this.throttleFetchLandingPageList = utils.debounce(this.fetchLandingPageList)
    this.fetchList = this.throttleFetchLandingPageList
    if (indCols) {
      this.indCols = indCols
    }
  },
  components: {
    SuperForm
  }
}
</script>

<style lang="scss">
.site-preview-box {
  display: flex;
  justify-content: space-around;
  .site-iframe {
    box-sizing: border-box;
    width: 300px;
    height: 600px;
    padding: 32px 8px 55px 8px;
    background: url('~assets/img/preview/wrapper.png') no-repeat;
    background-size: contain;
    iframe {
      width: 100%;
      height: 100%;
    }
  }
  .site-qrcode {
    text-align: center;
    padding-top: 200px;
    &__title {
      line-height: 50px;
      font-size: 20px;
    }
    &__img {
      width: 160px;
      height: 160px;
      margin: 0 auto;
      img {
        display: block;
      }
    }
    &__tip {
      line-height: 40px;
    }
  }
}
.tip-dialog {
  &__title{
    margin-bottom: 20px;
    text-align: center;
  }
}
</style>
