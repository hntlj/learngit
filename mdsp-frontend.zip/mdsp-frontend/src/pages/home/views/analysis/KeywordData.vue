<template>
  <div class="pd24">
    <div class="home-card pd24">
      <div class="home-card__main" style="margin-bottom:-36px">
        <super-form class="home-searchform" label-width="0px" :form-list="searchOptions" v-model="formData"></super-form>
      </div>
    </div>
    <div class="home-card mt24 pd24">
      <div class="home-card__header">
        <el-popover placement="bottom-start" width="300" trigger="click">
          <el-checkbox :indeterminate="isIndeterminate" v-model="selectAll" @change="onSelectAllChanged">全选</el-checkbox>
          <el-checkbox-group v-model="indCols" class="customCols" @change="onIndColsChanged">
            <el-checkbox v-for="ind in indicatorList" :key="ind.key" :label="ind.key">{{ ind.name }}</el-checkbox>
          </el-checkbox-group>
          <el-button plain slot="reference">自定义列 <i class="el-icon-arrow-down"></i></el-button>
        </el-popover>
        <el-button type="primary" class="pull-right" style="width: 130px" @click="onExport">下载报表</el-button>
      </div>
      <div class="home-card__main">
        <el-table class="table-border" :data="computedDataList" :default-sort="defaultSort" v-loading="fetching" @sort-change="onSortChange">
          <el-table-column header-align="center" align="center" v-for="col in tableColumn" :key="col.prop"
            :prop="col.prop"
            :label="col.label"
            :sortable="col.sortable"
            :formatter="col.formatter">
          </el-table-column>
        </el-table>
      </div>
      <div class="home-card__footer">
        <el-pagination class="pull-right"
          v-if="dataListTotal > PAGE_SIZE"
          background
          layout="prev, pager, next"
          :current-page="page"
          :total="dataListTotal"
          @current-change="onPageChanged">
        </el-pagination>
      </div>
    </div>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import utils from '@/utils'
import { filters } from '@/utils/filters'
import Storage from '@/utils/storage'
import { STAT_INDICATOR } from '@/enums'
import { getAppList, getIdeaList, getUnitList, getPlanList, getStatKeywordList2, exportStatKeywordList2 } from '@/api'
import SuperForm from '@/components/SuperForm'
const PAGE_SIZE = 10
const DEFAULT_DEMENSION = Object.keys(STAT_INDICATOR)
export default {
  data () {
    return {
      formData: {
        planId: '',
        unitId: '',
        pageNumber: 1,
        pageSize: 9999,
        startTime: '',
        endTime: ''
      },
      planList: [],
      unitList: [],
      ideaList: [],
      dataList: [],
      dataListTotal: 0,
      appList: [],
      indCols: [...DEFAULT_DEMENSION],
      selectAll: true,
      isIndeterminate: false,
      fetching: true,
      page: 1,
      order: 'descending',
      orderBy: 'statDate',
      PAGE_SIZE
    }
  },
  computed: {
    ...mapGetters(['userInfo']),
    searchOptions () {
      return [
        { type: 'hidden', key: 'pageNumber', default: 1 },
        { type: 'hidden', key: 'pageSize', default: 9999 },
        { type: 'text', key: 'kw', label: '关键词', default: '', placeholder: '关键词' },
        { type: 'select', key: 'appName', label: '应用名称', options: this.appList, filterable: true },
        { type: 'select', key: 'planId', label: '计划名称', options: this.planList, filterable: true },
        { type: 'select', key: 'unitId', label: '单元名称', options: this.unitList, filterable: true },
        { type: 'select', key: 'ideaId', label: '创意名称', options: this.ideaList, filterable: true },
        { type: 'daterange', key: 'Time', label: '选择日期', default: [new Date(), new Date()] }
      ]
    },
    tableColumn () {
      const cols = [
        { prop: 'statDate', label: '日期', sortable: 'custom', formatter: row => utils.formatDate(row.statDate) },
        { prop: 'kw', label: '关键词' },
        { prop: 'planName', label: '计划名称' },
        { prop: 'ideaName', label: '创意名称' },
        { prop: 'appName', label: '应用名称' },
        { prop: 'exposure', label: '曝光量', sortable: 'custom', formatter: row => filters.number(row.exposure) },
        { prop: 'click', label: '点击量', sortable: 'custom', formatter: row => filters.number(row.click) },
        { prop: 'clickRate', label: '点击率', sortable: 'custom', formatter: row => row.clickRate + '%' },
        { prop: 'downloadRate', label: '下载率', sortable: 'custom', formatter: row => row.downloadRate + '%' },
        { prop: 'download', label: '下载量', sortable: 'custom', formatter: row => filters.number(row.download) },
        { prop: 'clickPrice', label: '点击单价（元）', sortable: 'custom', formatter: row => filters.currency(row.clickPrice, row) },
        { prop: 'downloadPrice', label: '下载单价（元）', sortable: 'custom', formatter: row => filters.currency(row.downloadPrice) },
        { prop: 'cost', label: '消费（元）', sortable: 'custom', formatter: row => filters.currency(row.cost) }
      ]
      return cols.filter(col => ['statDate', 'planName', 'ideaName', 'appName', 'kw', ...this.indCols].indexOf(col.prop) !== -1)
    },
    computedDataList () {
      const start = (this.page - 1) * PAGE_SIZE
      const end = start + PAGE_SIZE
      return this.dataList.slice().sort((a, b) => {
        const isAsc = this.order === 'ascending'
        if (isAsc) {
          return a[this.orderBy] - b[this.orderBy]
        } else {
          return b[this.orderBy] - a[this.orderBy]
        }
      }).slice(start, end)
    },
    defaultSort () {
      return {
        prop: this.orderBy,
        order: this.order
      }
    },
    indicatorStorageKey () {
      return `${this.userInfo.uid}_indicators`
    },
    indicatorList () {
      let all = Object.values(STAT_INDICATOR)
      all.pop()
      return all
    }
  },
  methods: {
    onExport () {
      exportStatKeywordList2(this.formData)
    },
    onSortChange ({column, prop, order}) {
      this.order = order || 'descending'
      this.orderBy = prop || 'exposure'
    },
    onSelectAllChanged (value) {
      this.indCols = value ? [...DEFAULT_DEMENSION] : []
      this.isIndeterminate = false
    },
    onIndColsChanged (value) {
      const checkCount = value.length
      this.selectAll = checkCount === DEFAULT_DEMENSION.length
      this.isIndeterminate = checkCount > 0 && checkCount < DEFAULT_DEMENSION.length
      if (Storage.supportStorage) {
        Storage.set(`${this.userInfo.uid}_indicators`, value.length > 0 ? value : DEFAULT_DEMENSION)
      }
    },
    onPageChanged (page) {
      this.page = page
    },
    fetchAppList () {
      getAppList().then(res => {
        if (res.code === 200) {
          // this.appList = (res.value || []).map(({appName: label, appId: value}) => ({label, value}))
          this.appList = (res.value || []).map(({appName: label, appName: value}, idx) => ({label, value, idx}))
        }
      })
    },
    fetchDataList () {
      this.fetching = true
      this.page = 1
      getStatKeywordList2(this.formData).then(res => {
        if (res.code === 200) {
          this.dataListTotal = res.value.total
          this.dataList = (res.value.data || []).map(item => {
            item.clickRate = item.expoCount !== 0 ? Math.round(item.clickCount / item.expoCount * 10000) / 100 : 0
            item.downloadRate = item.expoCount !== 0 ? Math.round(item.downloadCount / item.expoCount * 10000) / 100 : 0
            item.clickPrice = item.clickCount ? item.cost / item.clickCount : 0
            item.downloadPrice = item.downloadCount ? item.cost / item.downloadCount : 0
            item.download = item.downloadCount
            item.click = item.clickCount
            item.exposure = item.expoCount
            return item
          })
        }
      }).finally(() => {
        this.fetching = false
      })
    },
    fetchIdeaList () {
      const date = new Date()
      getIdeaList({
        pageNumber: 1,
        pageSize: 9999,
        startTime: utils.formatDate(date),
        endTime: utils.formatDate(date),
        unitId: this.formData.unitId
      }).then(res => {
        if (res.code === 200 && res.value) {
          this.ideaList = (res.value.data || []).map(({name: label, ideaId: value}) => ({label, value}))
        }
      })
    },
    fetchUnitList () {
      const date = new Date()
      getUnitList({
        pageNumber: 1,
        pageSize: 9999,
        startTime: utils.formatDate(date),
        endTime: utils.formatDate(date),
        planId: this.formData.planId
      }).then(res => {
        if (res.code === 200 && res.value) {
          this.unitList = (res.value.data || []).map(({unitName: label, unitId: value}) => ({label, value}))
        }
      })
    },
    fetchPlanList () {
      const date = new Date()
      getPlanList({
        pageNumber: 1,
        pageSize: 9999,
        startTime: utils.formatDate(date),
        endTime: utils.formatDate(date)
      }).then(res => {
        if (res.code === 200 && res.value) {
          this.planList = (res.value.data || []).map(({planName: label, planId: value}) => ({label, value}))
        }
      })
    }
  },
  watch: {
    formData (val) {
      this.debounceFetchDataList()
    },
    'formData.planId' (val) {
      this.fetchUnitList()
    },
    'formData.unitId' (val) {
      this.fetchIdeaList()
    }
  },
  created () {
    const indCols = Storage.get(this.indicatorStorageKey)
    this.debounceFetchDataList = utils.debounce(this.fetchDataList)
    this.fetchAppList()
    this.fetchPlanList()
    this.fetchUnitList()
    this.fetchIdeaList()
    if (indCols) {
      this.indCols = indCols
    }
  },
  components: {
    SuperForm
  }
}
</script>
