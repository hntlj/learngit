<template>
  <div class="pd24">
    <div class="home-card pd24">
      <div class="home-card__header line">
        <h2>每日数据</h2>
      </div>
      <div class="home-card__main">
        <super-form class="home-searchform" label-width="0px" :form-list="searchOptions" v-model="formData" v-if="showSuperForm"></super-form>
        <div class="home-card mt24 pd24">
          <div class="home-card__main">
            <div>
              <el-select v-model="dataInd[0]">
              <el-option v-for="ind in indicatorList" :key="ind.key" :value="ind.key" :label="ind.name" v-if="ind.key !== dataInd[1]"></el-option>
            </el-select>
            <el-select v-model="dataInd[1]" class="pull-right">
              <el-option v-for="ind in indicatorList" :key="ind.key" :value="ind.key" :label="ind.name" v-if="ind.key !== dataInd[0]"></el-option>
            </el-select>
            </div>
            <line-chart v-loading="fetching" :hour="isHour" :data="charData" :ind="multiInd" :times="timeRange"></line-chart>
          </div>
        </div>
        <div class="home-card mt24 pd24">
          <div class="home-card__header">
            <el-popover placement="bottom-start" width="300" trigger="click">
              <el-checkbox :indeterminate="isIndeterminate" v-model="selectAll" @change="onSelectAllChanged">全选</el-checkbox>
              <el-checkbox-group v-model="indCols" class="customCols" @change="onIndColsChanged">
                <el-checkbox v-for="ind in indicatorList" :key="ind.key" :label="ind.key">{{ ind.name }}</el-checkbox>
              </el-checkbox-group>
              <el-button plain slot="reference">自定义列 <i class="el-icon-arrow-down"></i></el-button>
            </el-popover>
            <el-button type="primary" class="pull-right" style="width: 130px" @click="onExport">导出报表</el-button>
          </div>
          <div class="home-card__main">
            <el-table class="table-border" :data="computedDataList" v-loading="fetching" :default-sort="defaultSort" @sort-change="onSortChange" :row-class-name="summaryRowIndex">
              <el-table-column header-align="center" :align="col.align || 'center'" v-for="col in tableColumn" :key="col.prop"
                :prop="col.prop"
                :label="col.label"
                :sortable="col.sortable"
                :formatter="col.formatter">
              </el-table-column>
            </el-table>
          </div>
        </div>
      </div>
      <div class="home-card__footer">
        <el-pagination class="pull-right"
          v-if="dataListTotal > defaultPageSize"
          background
          :page-size="PAGE_SIZE"
          :page-sizes="PAGE_SIZES"
          :current-page="formData.pageNumber"
          :total="dataListTotal"
          @size-change="onSizeChange"
          @current-change="onPageChanged"
          layout="total, sizes, prev, pager, next, jumper">
        </el-pagination>
      </div>
    </div>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import utils from '@/utils'
import { filters } from '@/utils/filters'
import { PROMOTION_TARGET, STAT_INDICATOR, CUSTOMER_TYPE, CHANNEL_TYPE, PAGE_SIZE, PAGE_SIZES } from '@/enums'
import { getAgentDailyStat, exportAgentDailyStat, getAgentDailyGraphStat, getAgentDailyStatSum } from '@/api'
import SuperForm from '@/components/SuperForm'
import LineChart from '@/components/LineChart'
import sortable from '@/mixins/sortable'
const DEFAULT_DEMENSION = Object.keys(STAT_INDICATOR)
export default {
  mixins: [sortable],
  data () {
    return {
      formData: {
        startTime: '',
        endTime: ''
      },
      fetching: false,
      dataListTotal: 0,
      dataList: [],
      chartDataList: [],
      selectAll: true,
      isIndeterminate: false,
      indicatorList: Object.values(STAT_INDICATOR),
      dataInd: DEFAULT_DEMENSION.slice(0, 2),
      indCols: [...DEFAULT_DEMENSION],
      customColumns: [],
      columns: [
        { prop: 'statDate', label: '时间', sortable: 'custom', formatter: row => row.statDate === '总计' ? row.statDate : utils.formatDate(row.statDate) },
        { prop: 'exposure', label: '曝光量', sortable: 'custom', formatter: row => filters.number(row.exposure) },
        { prop: 'click', label: '点击量', sortable: 'custom' },
        { prop: 'download', label: '下载量', sortable: 'custom' },
        { prop: 'clickRate', label: '点击率', sortable: 'custom', formatter: row => row.clickRate + '%' },
        { prop: 'downloadRate', label: '下载率', sortable: 'custom', formatter: row => row.downloadRate + '%' },
        { prop: 'clickPrice', label: '点击单价（元）', sortable: 'custom', formatter: row => filters.currency(row.clickPrice) },
        { prop: 'downloadPrice', label: '下载单价（元）', sortable: 'custom', formatter: row => filters.currency(row.downloadPrice) },
        { prop: 'exposurePrice', label: '千次曝光消费（元）', sortable: 'custom', formatter: row => filters.currency(row.exposurePrice) },
        { prop: 'cost', label: '消费（元）', sortable: 'custom' }
      ],
      tableColumnObj: {
        click: 0,
        clickPrice: 0,
        clickRate: 0,
        cost: 0,
        download: 0,
        downloadRate: 0,
        downloadPrice: 0,
        exposure: 0,
        exposurePrice: '',
        statDate: '总计'
      },
      getStatSummary: null,
      page: 1,
      order: 'descending',
      orderBy: 'statDate',
      defaultPageSize: PAGE_SIZE,
      PAGE_SIZE,
      PAGE_SIZES,
      showChart: false
    }
  },
  computed: {
    ...mapGetters(['slotBundle', 'userInfo']),
    searchOptions () {
      const date = new Date()
      date.setTime(date.getTime() - 3600 * 1000 * 24 * 6)
      if (this.userInfo.agentType === 2) {
        delete CUSTOMER_TYPE[1]
      }
      return [
        { type: 'hidden', key: 'pageNumber', default: 1 },
        { type: 'hidden', key: 'pageSize', default: PAGE_SIZE },
        { type: 'select', key: 'customerType', label: '客户类型', options: Object.values(CUSTOMER_TYPE).map(({ value, name: label }) => ({ value, label })), withoutAll: Object.values(CUSTOMER_TYPE).length < 2, default: Object.values(CUSTOMER_TYPE).length < 2 ? 2 : '' },
        { type: 'select', key: 'promotionTarget', label: '推广目的', options: Object.values(PROMOTION_TARGET).map(({ value, name: label }) => ({ value, label })) },
        { type: 'select', key: 'slotBundleId', label: '广告类型', options: this.slotBundle ? Object.values(this.slotBundle).map(({value, name: label}) => ({value, label})) : [] },
        { type: 'select', key: 'rebateType', label: '返点类型', options: Object.values(CHANNEL_TYPE).map(({ value, name: label }) => ({ value, label })) },
        { type: 'daterange', key: 'Time', label: '选择日期', default: [date, new Date()] }
      ]
    },
    showSuperForm () {
      return this.userInfo.hasOwnProperty('agentType')
    },
    computedDataList () {
      let filterDataList = this.dataList.slice().sort((a, b) => {
        const isAsc = this.order === 'ascending'
        if (isAsc) {
          return a[this.orderBy] - b[this.orderBy]
        } else {
          return b[this.orderBy] - a[this.orderBy]
        }
      })
      filterDataList.unshift(this.tableColumnObj)
      return filterDataList
    },
    defaultSort () {
      return {
        prop: this.orderBy,
        order: this.order
      }
    },
    isHour () {
      return this.formData.startTime === this.formData.endTime
    },
    multiInd () {
      return this.dataInd.map(ind => STAT_INDICATOR[ind])
    },
    timeRange () {
      let range = []
      if (this.isHour) {
        for (let i = 0; i <= 24; i++) {
          range.push(('0' + i).slice(-2) + ':00')
        }
      } else {
        let start = new Date(this.formData.startTime).getTime()
        let end = new Date(this.formData.endTime).getTime()
        while (start <= end) {
          range.push(utils.formatDate(start))
          start += 86400000
        }
      }
      return range
    },
    charData () {
      const data1 = this._formatData(this.dataInd[0])
      const data2 = this._formatData(this.dataInd[1])
      return [data1, data2]
    },
    tableColumn () {
      const customColumnsNames = this.customColumns.map(col => col.prop)
      const cols = [
        ...this.customColumns,
        ...this.columns
      ]
      return cols.filter(col => ['statDate', ...customColumnsNames, ...this.indCols].indexOf(col.prop) !== -1)
    }
  },
  methods: {
    onEnter (agent) {

    },
    onExport () {
      exportAgentDailyStat(this.formData)
    },
    onSortChange ({column, prop, order}) {
      // this.order = order || 'ascending'
      // this.orderBy = prop || 'statDate'
      this.order = order || 'ascending'
      this.orderBy = prop || 'statDate'
      if (this.formData) {
        this.formData.pageNumber = 1
      }
      this.fetchList()
    },
    onSizeChange (currSize) {
      this.formData.pageSize = currSize
      this.debounceFetchStatData()
    },
    onPageChanged (currPage) {
      this.formData.pageNumber = currPage
      this.debounceFetchStatData()
    },
    onSelectAllChanged (value) {
      this.indCols = value ? [...DEFAULT_DEMENSION] : []
      this.isIndeterminate = false
    },
    onIndColsChanged (value) {
      const checkCount = value.length
      this.selectAll = checkCount === DEFAULT_DEMENSION.length
      this.isIndeterminate = checkCount > 0 && checkCount < DEFAULT_DEMENSION.length
      if (Storage.supportStorage) {
        Storage.set(`${this.userInfo.uid}_indicators`, value.length > 0 ? value : DEFAULT_DEMENSION)
      }
    },
    computeItemData (obj) {
      obj.clickRate = obj.exposure !== 0 ? Math.round(obj.click / obj.exposure * 10000) / 100 : 0
      obj.downloadRate = obj.exposure !== 0 ? Math.round(obj.download / obj.exposure * 10000) / 100 : 0
      obj.clickPrice = obj.click ? Number((obj.cost / obj.click).toFixed(2)) : 0
      obj.downloadPrice = obj.download ? Number((obj.cost / obj.download).toFixed(2)) : 0
      obj.exposurePrice = obj.exposure ? Number(((obj.cost / obj.exposure) * 1000).toFixed(2)) : 0
    },
    fetchStatData () {
      this.fetching = true
      Promise.all([getAgentDailyStat({
        ...this.formData,
        desc: (this.order === 'descending') * 1,
        orderBy: this.orderBy === 'exposurePrice' ? 'thousandExposureCost' : this.orderBy
      }), getAgentDailyStatSum(this.formData)]).then(([day, sumDay]) => {
        if (sumDay.code === 200 && sumDay.value) {
          let sumDayVal = sumDay.value
          this.computeItemData(sumDayVal)
          this.tableColumnObj = { ...sumDay.value, statDate: '总计' }
        }
        if (day.code === 200 && day.value) {
          this.dataListTotal = day.value.total
          this.dataList = [...day.value.data].map(item => {
            this.computeItemData(item)
            return item
          })
        }
      }).finally(() => {
        setTimeout(() => {
          this.fetching = false
        }, 300)
      })
      getAgentDailyGraphStat({
        ...this.formData
      }).then(res => {
        if (res.code === 200 && res.value) {
          this.chartDataList = res.value.data.map(item => {
            this.computeItemData(item)
            return item
          })
          this.showChart = true
        }
      })
    },
    summaryRowIndex ({row, rowIndex}) {
      if (rowIndex === 0) {
        return 'summary-row'
      }
      return ''
    },
    _formatData (ind) {
      const result = new Array(this.timeRange.length).fill(0)
      if (STAT_INDICATOR[ind].type === 'rate') {
        const key = ind.replace('Rate', '')
        const exposureSum = this._formatData('exposure')
        const keySum = this._formatData(key)
        this.chartDataList.forEach(data => {
          let idx
          if (this.isHour) {
            idx = utils.formatDate(data.statDate, 'H')
          } else {
            idx = this.timeRange.indexOf(utils.formatDate(data.statDate))
          }
          result[idx] = exposureSum[idx] !== 0 ? Math.round(keySum[idx] / exposureSum[idx] * 10000) / 100 : 0
        })
      } else if (STAT_INDICATOR[ind].fat) {
        let fat = STAT_INDICATOR[ind].fat
        let fatk = ['/', '*', '+', '-']
        let mathIndexs = []
        // 解析格式化规则
        fat && fatk.map(it => {
          let idx = fat.indexOf(it)
          if (idx > -1) {
            mathIndexs.push({
              idx: idx,
              key: it
            })
          }
        })
        mathIndexs.sort((a, b) => a.idx - b.idx)
        let vaus = new Array(mathIndexs.length + 1).fill(0)
        let start = 0
        // 通过规则获取对应的数集合
        vaus.map((it, id) => {
          let key = fat.slice(start, typeof mathIndexs[id] !== 'undefined' ? mathIndexs[id].idx : fat.length)
          // 判断拿到的key是否是数字
          vaus[id] = /^\d+$/.test(key) ? key : this._formatData(key)
          start = mathIndexs[id] ? (mathIndexs[id].idx + 1) : 0
        })
        this.chartDataList.forEach(data => {
          let idx
          if (this.isHour) {
            idx = utils.formatDate(data.statDate, 'H')
          } else {
            idx = this.timeRange.indexOf(utils.formatDate(data.statDate))
          }
          result[idx] = mathIndexs.reduce((total, val, ind) => {
            let value = 0
            let num = typeof vaus[ind + 1] === 'object' ? parseInt(vaus[ind + 1][idx]) : parseInt(vaus[ind + 1])
            if (num === 0) {
              return 0
            }
            switch (val.key) {
              case '/':
                value = total / num
                break
              case '*':
                value = total * num
                break
              case '+':
                value = total + num
                break
              case '-':
                value = total - num
                break
            }
            return value
          }, vaus[0][idx]).toFixed(2)
        })
      } else {
        this.chartDataList.forEach(data => {
          let idx
          if (this.isHour) {
            idx = utils.formatDate(data.statDate, 'H')
          } else {
            idx = this.timeRange.indexOf(utils.formatDate(data.statDate))
          }
          result[idx] = Number(((result[idx] || 0) + data[ind]).toFixed(2))
        })
      }
      return result
    }
  },
  watch: {
    formData (val) {
      this.debounceFetchStatData()
    }
  },
  created () {
    this.debounceFetchStatData = utils.debounce(this.fetchStatData)
    this.fetchList = this.debounceFetchStatData
    this.$store.dispatch('getSlotBundleList')
  },
  components: {
    SuperForm,
    LineChart
  }
}
</script>
