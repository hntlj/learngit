<template>
  <div class="pd24">
    <div class="home-card pd24">
      <div class="home-card__header line">
        <h2>代理商注册<small>抱歉，您的账号暂时还没有开通代理商权限，请填写以下信息</small></h2>
      </div>
      <el-alert show-icon title="已成功提交审核，等待审核中" type="success" v-if="isVerifying"></el-alert>

      <div class="home-card__main">
        <div class="mt24">
          <el-form label-position="left" label-width="150px" ref="form_1" :model="formData" :rules="rules" :disabled="isVerifying">
            <el-form-item label="公司名称" prop="name">
              <el-input class="w640" v-model="formData.name" :maxlength="60"></el-input>
            </el-form-item>
            <el-form-item label="联系人" prop="contact">
              <el-input class="w640" v-model="formData.contact" :maxlength="25"></el-input>
            </el-form-item>
            <el-form-item label="联系电话" prop="phone">
              <el-input class="w640" v-model="formData.phone" :maxlength="25"></el-input>
            </el-form-item>
            <el-form-item label="联系邮箱" prop="email">
              <el-input class="w640" v-model="formData.email" :maxlength="125"></el-input>
            </el-form-item>
            <el-form-item label="联系地址" prop="address">
              <el-input class="w640" v-model="formData.address" :maxlength="125"></el-input>
            </el-form-item>
            <el-form-item>
              <el-checkbox v-model="check">我已阅读并接受 <a href="/views/agreement.html" target="_blank">《魅族广告投放平台合作协议》</a></el-checkbox>
            </el-form-item>
          </el-form>
        </div>
      </div>
      <div class="home-card__footer mt24" style="padding-left: 150px">
        <el-button type="primary" class="w160" @click="onSave" :disabled="!check || isVerifying">保存</el-button>
      </div>
    </div>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import validateMixin from '@/mixins/validate'
import { updateAgent } from '@/api'
import { USER_STATUS } from '@/enums'
import { phoneValidator } from '@/validators/user'
export default {
  mixins: [validateMixin],
  data () {
    return {
      check: false,
      formData: {
        name: '',
        contact: '',
        phone: '',
        email: '',
        address: ''
      },
      rules: {
        name: [{ required: true, message: '请输入公司名称', trigger: 'change' }],
        contact: [{ required: true, message: '请输入联系人', trigger: 'change' }],
        phone: [
          { required: true, message: '请输入联系电话', trigger: 'change' },
          { validator: phoneValidator.bind(this, '联系电话'), trigger: 'change' }
        ],
        email: [
          { required: true, message: '请输入联系邮箱', trigger: 'change' },
          { type: 'email', message: '邮箱格式不正确', trigger: 'blur' }
        ],
        address: [{ required: true, message: '请输入联系地址', trigger: 'change' }]
      },
      USER_STATUS
    }
  },
  computed: {
    ...mapGetters(['userInfo']),
    isVerifying () {
      return this.userInfo.status === USER_STATUS.VERIFYING
    }
  },
  methods: {
    async onSave () {
      const valid = await this.validate()
      if (valid) {
        updateAgent(this.formData).then(res => {
          if (res.code === 200) {
            this.$store.dispatch('getUserInfo', false)
            this.$message.success('保存成功')
          }
        }).catch(error => {
          this.$message.error(error.message)
        })
      }
    }
  },
  created () {
    const { name, contact, phone, email, address } = this.userInfo
    this.formData = { name, contact, phone, email, address }
    if (this.userInfo.status === USER_STATUS.VERIFYING) {
      this.check = true
    }
  }
}
</script>
