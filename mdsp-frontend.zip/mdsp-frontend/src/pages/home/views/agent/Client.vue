<template>
  <div class="pd24">
    <div class="home-card pd24">
      <div class="home-card__header line">
        <!-- @click="$router.push({ name: 'UserInfoAdd', params: { agent_sponsor_id : -1 }})" -->
        <h2>{{title}}</h2>
          <el-button v-if="clientType === CLIENT_TYPE.SPONSOR" type="primary" class="pull-right" style="width: 130px" @click="showSelectType=true">新增客户</el-button>
          <el-button v-if="clientType === CLIENT_TYPE.AGENT" type="primary" class="pull-right" style="width: 130px" @click="agentDialogVisible=true">新增二级代理</el-button>
      </div>
      <div class="home-card__main">
        <el-button type="primary" class="pull-right" style="width: 130px" @click="onExport">导出报表</el-button>
        <super-form ref="form" class="home-searchform" label-width="0px" :form-list="searchOptions" v-model="formData" v-if="showSuperForm" :change-from-list="isChanged" ></super-form>
        <el-table class="table-border" :data="dataList" v-loading="fetching" :default-sort="defaultSort" @sort-change="onSortChange">
          <el-table-column header-align="center" :align="col.align || 'center'" v-for="col in tableColumn" :key="col.prop"
            :sortable="col.sortable"
            :prop="col.prop"
            :label="col.label"
            :formatter="col.formatter">
          </el-table-column>
          <el-table-column
            v-if="clientType === CLIENT_TYPE.SPONSOR"
            fixed="right"
            label="操作"
            width="150">
            <template slot-scope="scope">
              <el-button type="text" size="small" v-if="scope.row.status === 1 && clientType === CLIENT_TYPE.SPONSOR && (scope.row.sponsorStatus === 1 || scope.row.sponsorStatus === 3)"  @click="onEnter(scope.row.uid)">进入账户</el-button>
              <el-button type="text" size="small" v-if="scope.row.status === 1 && clientType === CLIENT_TYPE.SPONSOR && (scope.row.sponsorStatus === 1 || scope.row.sponsorStatus === 2)"  @click="$router.push({ name: 'UserInfoAdd', params: { agent_sponsor_id : scope.row.uid, type: scope.row.identityType || 0 }})">编辑</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="home-card__footer">
        <el-pagination class="pull-right"
          v-if="dataListTotal > defaultPageSize"
          background
          layout="total, sizes, prev, pager, next, jumper"
          :page-size="PAGE_SIZE"
          :page-sizes="PAGE_SIZES"
          :current-page="formData.pageNumber"
          :total="dataListTotal"
          @size-change="onSizeChange"
          @current-change="onPageChanged">
        </el-pagination>
      </div>
      <second-agent-dialog
        :agent-dialog-visible="agentDialogVisible"
        @close="closeDialog">
      </second-agent-dialog>
    </div>
    <el-dialog
      title="提示"
      :visible.sync="showLoginTip"
      width="30%"
      top="35vh"
      center>
      <span>{{loginTipTxt}}</span>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="onLoginOut">确 定</el-button>
      </span>
    </el-dialog>
    <el-dialog
      title="请选择主体类型"
      :visible.sync="showSelectType"
      width="50%"
      top="35vh"
      center>
      <div class="select-content">
        <div class="type-title">请选择主体类型</div>
        <div class="type-list">
            <div class="type-item" v-for="(item, index) in accountType" :key="index" @click="jumpUrl(item.type)">{{item.title}}</div>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="showSelectType=false">取 消</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import utils from '@/utils'
import { filters } from '@/utils/filters'
import { CLIENT_TYPE, AGENT_STATUS, AUTHEN__STATUS, PAGE_SIZE, PAGE_SIZES, HOST } from '@/enums'
import { getAgentList, exportAgentList } from '@/api'
import SuperForm from '@/components/SuperForm'
import SecondAgentDialog from '@/components/home/agent/secondAgentDialog'
import sortable from '@/mixins/sortable'
const STATUS_OPTIONS = Object.values(AGENT_STATUS).map(({name: label, value}) => ({label, value}))
const AUTHEN_OPTIONS = Object.values(AUTHEN__STATUS).map(({name: label, value}) => ({label, value}))
export default {
  mixins: [sortable],
  data () {
    return {
      fetching: false,
      formData: null,
      dataListTotal: 0,
      dataList: [],
      column: [
        { prop: 'name', label: '客户名称', sortable: true },
        { prop: 'uid', label: '客户ID', sortable: true },
        { prop: 'status', label: '客户状态', sortable: true, formatter: row => AGENT_STATUS[row.status].name },
        { prop: 'bindTime', label: '更新时间', sortable: true, formatter: row => utils.formatDate(row.bindTime) },
        { prop: 'deposit', label: '当前余额', sortable: true, formatter: row => filters.currency(row.deposit) }
      ],
      agentDialogVisible: false,
      client: {
        sponsorId: ''
      },
      orderBy: 'bindTime',
      title: '',
      CLIENT_TYPE,
      defaultPageSize: PAGE_SIZE,
      PAGE_SIZE,
      PAGE_SIZES,
      showLoginTip: false,
      loginTipTxt: '',
      isChanged: true,
      showSelectType: false,
      accountType: [{title: '企业', type: 0}, {title: '个人', type: 1}]
    }
  },
  computed: {
    ...mapGetters(['slotBundle', 'userInfo']),
    clientType () {
      return Number(this.$route.query.clientType) || CLIENT_TYPE.SPONSOR
    },
    searchOptions () {
      let arr = [
        { type: 'hidden', key: 'pageNumber', default: 1 },
        { type: 'hidden', key: 'pageSize', default: PAGE_SIZE },
        { type: 'text', key: 'name', placeholder: '客户名称/客户ID' },
        { type: 'select', key: 'status', label: '客户状态', options: STATUS_OPTIONS },
        { type: 'daterange', key: 'Time', label: '绑定时间', default: [this.userInfo.createTime, new Date()] }
      ]
      if (this.clientType === 0) {
        arr.splice(4, 0, { type: 'select', key: 'sponsorStatus', label: '认证状态', options: AUTHEN_OPTIONS })
      }
      return arr
    },
    tableColumn () {
      return this.column.filter(({prop}) => this.clientType === CLIENT_TYPE.SPONSOR || prop !== 'posterNum')
    },
    showSuperForm () {
      return this.userInfo.hasOwnProperty('createTime')
    }
  },
  methods: {
    onExport () {
      exportAgentList({
        ...this.formData,
        desc: (this.order === 'descending') * 1,
        orderBy: this.orderBy,
        clientType: this.clientType
      })
    },
    onSizeChange (currSize) {
      this.formData.pageSize = currSize
      this.debounceFetchAgentList()
    },
    onPageChanged (currPage) {
      this.formData.pageNumber = currPage
      this.debounceFetchAgentList()
    },
    onEnter (uid) {
      utils.newTab({ href: `http://${HOST}/sponsor/forward?id=${uid}` })
    },
    fetchAgentList () {
      this.fetching = true
      getAgentList({
        ...this.formData,
        desc: (this.order === 'descending') * 1,
        orderBy: this.orderBy,
        clientType: this.clientType
      }).then(res => {
        if (res.code === 200 && res.value) {
          this.dataListTotal = res.value.total
          this.dataList = res.value.data
          if (this.clientType === 0 && this.column.length !== 6) {
            this.column.push({ prop: 'sponsorStatus', label: '认证状态', sortable: true, formatter: row => AUTHEN__STATUS[row.sponsorStatus].name })
          } else if (this.clientType === 2 && this.column.length !== 5) {
            this.column.pop()
          }
        }
      }).finally(() => {
        setTimeout(() => {
          this.fetching = false
        }, 300)
      })
    },
    initTitle (clientType) {
      if (typeof clientType === 'string') {
        clientType = Number(clientType)
      }
      if (clientType === 0) {
        this.title = '广告主管理'
      } else if (clientType === 2) {
        this.title = '代理管理'
      }
    },
    closeDialog (refresh) {
      if (refresh) this.debounceFetchAgentList()
      this.agentDialogVisible = false
    },
    onLoginOut () {
      window.location.href = '/logout'
    },
    jumpUrl (type) {
      // this.$router.push({ name: 'UserInfoAdd', query: { agent_sponsor_id : -1, type: type }})
      this.$router.push({name: 'UserInfoAdd', params: { agent_sponsor_id: -1, type: type }})
    }
  },
  watch: {
    formData (val) {
      this.debounceFetchAgentList()
    },
    '$route.query.clientType' (val) {
      this.$refs.form.$emit('refresh')
      this.debounceFetchAgentList()
      this.initTitle(val)
    }
  },
  created () {
    this.debounceFetchAgentList = utils.debounce(this.fetchAgentList)
    this.fetchList = this.debounceFetchAgentList
    if (this.$route.path.indexOf('/LoginTip') > -1) {
      let tipInfo = {
        'sponsorDisable': '该账号已经成为广告主，无法登录代理商平台。',
        'invalidAgent': '该账号是无效账号，无法登录代理商平台。'
      }
      this.loginTipTxt = tipInfo[this.$route.params.tipType]
      if (this.loginTipTxt) this.showLoginTip = true
    }
  },
  mounted () {
    this.$store.dispatch('getSlotBundleList')
    this.initTitle(this.$route.query.clientType)
  },
  components: {
    SuperForm,
    SecondAgentDialog
  }
}
</script>
<style lang="scss">
.select-content{
  margin: 0 auto;
  background: #fff;
  height: 300px;
  padding: 0 13%;
  box-sizing: border-box;
  text-align: center;
  .type-title{
      font-weight: bold;
      padding: 30px 0 80px 0;
  }
  .type-list{
      width: 100%;
      display: flex;
      justify-content: space-between;
      align-items: center;
      .type-item {
          background: #f5f5f5;
          height: 130px;
          width: 220px;
          text-align: center;
          line-height: 130px;
          cursor: pointer;
          border: 1px solid gray(.1);
      }
      .type-item:hover {
          opacity: 0.6;
      }
  }
}
</style>
