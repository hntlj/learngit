<template>
  <div>
    <div class="mg24">
      <div class="home-card home-consume">
        <div class="home-consume__btn">
          <a href="javascript:;" @click="onRecharge" :class="{disabled: userInfo.agentType === 2}">上传充值凭证</a>
          <p class="info" v-if="userInfo.agentType === 2">温馨提示：您暂时没有充值权限。</p>
        </div>
        <div class="home-consume__wrap">
          <div class="stat">
            <i class="consume-icon-balance"></i>
            <p><small>总余额（元）</small><b :title="account.deposit">{{account.deposit | currency}}</b></p>
          </div>
          <div class="stat">
            <i class="consume-icon-rebate"></i>
            <p><small>返点余额（元）</small><b :title="account.rebate">{{account.rebate | currency}}</b></p>
          </div>
        </div>
      </div>
    </div>
    <div class="mg24">
      <div class="home-card pd24">
        <div class="home-card__main">
          <super-form class="home-searchform" label-width="0px" :form-list="searchOptions" v-model="formData"></super-form>
          <el-table class="table-border" :data="dataList" v-loading="fetching">
            <el-table-column header-align="center" :align="col.align || 'center'" v-for="col in tableColumn" :key="col.prop"
              :prop="col.prop"
              :label="col.label"
              :formatter="col.formatter">
            </el-table-column>
            <el-table-column
              fixed="right"
              label="操作"
              width="150">
              <template slot-scope="scope" v-if="scope.row.status !== 999">
                <el-button type="text" size="small" @click="onTransfer(scope.row)">转账</el-button>
                <el-button type="text" size="small" @click="onTransaction(scope.row.name)">交易明细</el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <div class="home-card__footer">
          <el-pagination class="pull-right"
            v-if="dataListTotal > PAGE_SIZE"
            background
            layout="prev, pager, next"
            :page-size="PAGE_SIZE"
            :current-page="formData.pageNumber"
            :total="dataListTotal"
            @current-change="onPageChanged">
          </el-pagination>
        </div>
      </div>
    </div>
    <recharge-dialog :dialog-visible="dialogVisible" @close="dialogVisible=false"></recharge-dialog>
    <el-dialog title="转账" :visible.sync="transferDialog" width="460px">
      <el-form label-width="120px" ref="form_2" :model="transferForm" :rules="transferFormRules">
        <el-form-item label="转账类型" prop="type">
          <el-radio v-model="transferForm.type" :label="4">充值</el-radio>
          <el-radio v-model="transferForm.type" :label="5">返点</el-radio>
        </el-form-item>
        <el-form-item label="转账金额" prop="money">
          <el-input v-model.number="transferForm.money">
            <template slot="append">元</template>
          </el-input>
        </el-form-item>
        <el-form-item label="备注">
          <el-input v-model="transferForm.remark" type="textarea"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer">
        <el-button @click="transferDialog=false">取消</el-button>
        <el-button type="primary" @click="onConfirm">保存</el-button>
      </div>
    </el-dialog>
    <confirmation-dialog
      :confirmation-dialog-visible="confirmationDialogVisible"
      :confirmation-title="confirmationTitle"
      :confirmation-info="confirmationInfo"
      @close="confirmationDialogVisible=false"
      @confirmHandle="debounceTransfer">
    </confirmation-dialog>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import validateMixin from '@/mixins/validate'
import SuperForm from '@/components/SuperForm'
import RechargeDialog from '@/components/home/financial/RechargeDialog'
import ConfirmationDialog from '@/components/ConfirmationDialog'
import { getAgentAccount, getAgentAccountList, transferRecharge } from '@/api'
import utils from '@/utils'
import { filters } from '@/utils/filters'
const PAGE_SIZE = 10
export default {
  mixins: [validateMixin],
  data () {
    const moneyValidator = (rule, value, callback) => {
      if (isNaN(value)) {
        return callback(new Error('转账金额必须是数字'))
      } else {
        const max = this.transferForm.type === 4 ? this.account.deposit : this.account.rebate
        if (value > max) {
          return callback(new Error(`转账金额不能大于账户余额：${max}`))
        }
      }
      callback()
    }
    return {
      account: {
        deposit: 0,
        rebate: 0
      },
      dataList: [],
      dataListTotal: 0,
      fetching: false,
      tableColumn: [
        { prop: 'name', label: '客户名称' },
        { prop: 'uid', label: '客户ID' },
        { prop: 'deposit', label: '余额', formatter: row => filters.currency(row.deposit) }
      ],
      formData: null,
      dialogVisible: false,
      transferForm: {
        uid: '',
        type: 4,
        money: '',
        remark: ''
      },
      transferFormRules: {
        money: [
          { required: true, message: '请输入转账金额', trigger: 'change' },
          { validator: moneyValidator.bind(this), trigger: 'change' }
        ]
      },
      transferDialog: false,
      PAGE_SIZE,
      confirmationDialogVisible: false,
      confirmationTitle: '请确认您的转账信息',
      confirmationInfo: []
    }
  },
  computed: {
    ...mapGetters(['userInfo']),
    searchOptions () {
      const CLIENT_TYPE = this.userInfo.agentType === 1 ? [{value: 0, label: '广告主'}, {value: 1, label: '二级代理商'}] : [{value: 0, label: '广告主'}]
      return [
        { type: 'hidden', key: 'pageNumber', default: 1 },
        { type: 'hidden', key: 'pageSize', default: PAGE_SIZE },
        { type: 'select', key: 'clientType', label: '客户类型', options: CLIENT_TYPE, default: 0, withoutAll: true },
        { type: 'text', key: 'clientName', label: '客户名称', placeholder: '客户名称' }
      ]
    }
  },
  methods: {
    onRecharge () {
      if (this.userInfo.agentType !== 2) {
        this.dialogVisible = true
      }
    },
    onTransfer (item) {
      this.transferDialog = true
      this.transferForm = {
        uid: item.uid,
        type: 4,
        money: '',
        remark: '',
        flyme: item.flyme
      }
    },
    onTransaction (name) {
      this.$router.push({ name: 'AgentTransaction', query: { name } })
    },
    onPageChanged (currPage) {
      this.formData.pageNumber = currPage
      this.debounceFetchAgentAccountList()
    },
    fetchAgentAccount () {
      getAgentAccount().then(res => {
        if (res.code === 200) {
          this.account = res.value
        }
      })
    },
    fetchAgentAccountList () {
      getAgentAccountList(this.formData).then(res => {
        if (res.code === 200) {
          this.dataList = res.value.data || []
          this.dataListTotal = res.value.total
        }
      })
    },
    async onConfirm () {
      const valid = await this.$refs.form_2.validate()
      if (valid) {
        let type = ''
        if (this.transferForm.type === 4) {
          type = '充值'
        } else if (this.transferForm.type === 5) {
          type = '返点'
        }
        this.confirmationInfo = [
          {
            label: '转入方名称',
            value: this.transferForm.flyme
          }, {
            label: '转入方账户ID',
            value: this.transferForm.uid
          }, {
            label: `${type}转账金额`,
            value: this.transferForm.money
          }
        ]
        this.confirmationDialogVisible = true
      }
    },
    transfer () {
      let flowId = String(new Date().getTime()) +
                  String(this.userInfo.uid) +
                  'ad' + 0
      transferRecharge({
        ...this.transferForm, flowId
      }).then(res => {
        if (res.code === 200) {
          this.fetchAgentAccount()
          this.debounceFetchAgentAccountList()
          this.transferDialog = false
          this.$message.success('转账成功')
        }
      }).catch(error => {
        this.$message.error(error.message)
      })
    },
    debounceTransfer () {}
  },
  watch: {
    formData () {
      this.debounceFetchAgentAccountList()
    }
  },
  created () {
    this.fetchAgentAccount()
    this.debounceFetchAgentAccountList = utils.debounce(this.fetchAgentAccountList)
    this.debounceTransfer = utils.debounce(this.transfer)
  },
  components: {
    SuperForm,
    RechargeDialog,
    ConfirmationDialog
  }
}
</script>
<style lang="scss">
.btn {
  padding: 16px 36px;
}
</style>
