<template>
  <div class="home-container">
    <el-aside class="home-aside">
      <div class="inset-shadow pm-nav">
        <div class="pm-subnav expand" v-for="(menu, idx) in menus" :key="idx">
          <router-link class="pm-subnav__title" :to="{ name: menu.code, query: menu.query }" active-class="act">
            <i :class="`menu-icon-${menu.icon}`"></i>
            <span>{{menu.name}}</span>
          </router-link>
          <div class="pm-subnav__content">
            <template v-if="menu.code === 'Client'">
              <router-link class="pm-subnav-item" :to="{ name: 'Client', query: { clientType: CLIENT_TYPE.SPONSOR }}" exact>广告主管理</router-link>
              <router-link v-if="userInfo.agentType === CLIENT_TYPE.FIRST_AGENT" class="pm-subnav-item" :to="{ name: 'Client', query: { clientType: CLIENT_TYPE.AGENT }}" exact>代理管理</router-link>
            </template>
            <template v-if="menu.code === 'DailyStat'">
              <router-link class="pm-subnav-item" :to="{ name: 'DailyStat' }" exact>每日数据</router-link>
              <router-link class="pm-subnav-item" :to="{ name: 'ClientStat' }" exact>客户数据</router-link>
            </template>
            <template v-if="menu.code === 'AgentRecharge'">
              <router-link class="pm-subnav-item" :to="{ name: 'AgentRecharge'}" exact>充值</router-link>
              <router-link class="pm-subnav-item" :to="{ name: 'AgentTransaction'}" exact>交易申请记录</router-link>
            </template>
          </div>
        </div>
      </div>
    </el-aside>
    <main class="home-main">
      <router-view/>
    </main>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { CLIENT_TYPE } from '@/enums'
import HomeAside from '@/components/Aside'
export default {
  data () {
    return {
      menus: [
        { name: '客户管理', icon: 'userinfo', code: 'Client', query: { clientType: CLIENT_TYPE.SPONSOR } },
        { name: '数据分析', icon: 'unit', code: 'DailyStat' },
        { name: '财务管理', icon: 'recharge', code: 'AgentRecharge' },
        { name: '消息设置', icon: 'messagesetting', code: 'AgentMessageSetting' }
      ],
      CLIENT_TYPE
    }
  },
  computed: {
    ...mapGetters(['userInfo']),
    navList () {
      return [
        { name: 'Client', title: '用户管理' }
      ]
    }
  },
  components: {
    HomeAside
  }
}
</script>

<style lang="scss">
</style>
