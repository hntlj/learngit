<template>
  <div class="home-container tools-wrap">
    <div class="tools" v-for="(tool, idx) in tools" :key="idx">
      <h3 class="tools__title">{{tool.title}}</h3>
      <div class="tools-group">
        <div class="tools-group__list"
          v-for="(item, index) in tool.list"
          :key="index"
          @click="selectMenu(item.name)">
          <i :class="`menu-icon-toolkit-${item.icon || item.name.toLowerCase()}`"></i>
          <span>{{item.title}}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
export default {
  data () {
    return {
      tools: [
        {
          title: '账户辅助',
          list: [
            { name: 'UserInfo', title: '用户信息' },
            { name: 'Log', title: '操作日志' },
            { name: 'MessageSetting', title: '消息设置' }
          ]
        }, {
          title: '定向辅助',
          list: [
            { name: 'Keyword', title: '关键词包' },
            { name: 'CrowdPack', title: '人群包管理' }
          ]
        }, {
          title: '创意辅助',
          list: [
            { name: 'LandingPage', title: '移动建站' },
            { name: 'DynamicPack', title: '动态词包' }
          ]
        }
      ]
    }
  },
  computed: {
    ...mapGetters(['userInfo'])
  },
  methods: {
    selectMenu (name) {
      this.$router.push(`../toolkit/${name}`)
    },
    updateTools (whiteList) {
      if (whiteList && !whiteList.tx_game) {
        this.tools[1].list.push({ name: 'AppPack', title: '应用渠道包管理' })
      }
      if (whiteList && whiteList.push_sponsor) {
        this.tools[1].list.push({ name: 'PushBlackList', title: '应用拉活黑名单' })
      }
    }
  },
  watch: {
    'userInfo.whiteList': {
      handler (whiteList) {
        this.updateTools(whiteList)
      },
      deep: true
    }
  },
  created () {
    const whiteList = this.userInfo.whiteList
    this.updateTools(whiteList)
  },
  components: {}
}
</script>

<style lang="scss">
.tools-wrap {
  padding: 0 100px;
  .tools {
    margin-bottom: 20px;
    &__title {
      line-height: 36px;
      font-size: 30px;
      font-weight: bold;
      padding: 40px 0 24px 0;
    }
    &-group {
      display: flex;
      flex-wrap: wrap;
      &__list {
        background: #fff;
        width: 340px;
        height: 145px;
        padding-top: 6px;
        margin-right: 30px;
        border-radius: 3px;
        cursor: pointer;
        border: 2px solid rgba(0,0,0,0.10);
        font-size: 16px;
        font-weight: bold;
        display: flex;
        align-items: center;
        flex-direction: column;
      }
    }
  }
}
</style>
