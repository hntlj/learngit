<!--
 * @Date: 2020-04-27 16:34:08
 * @LastEditors: PoloHuang
 * @LastEditTime: 2020-05-19 11:49:03
 -->
<template>
    <div class="select-type">
        <div class="select-content">
            <div class="type-title">请选择主体类型</div>
            <div class="type-list">
                <div class="type-item" v-for="(item, index) in accountType" :key="index" @click="jumpUrl(item.type)">{{item.title}}</div>
            </div>
        </div>
    </div>
</template>
<script>
export default {
  data () {
    return {
      accountType: [{title: '企业', type: 0}, {title: '个人', type: 1}]
    }
  },
  methods: {
    jumpUrl (params) {
      this.$router.push({name: 'UserInfoEdit', query: { type: params }})
    }
  }
}
</script>
<style lang="scss">
.select-type{
    width: 100%;
    .select-content{
        width: 50%;
        margin: 200px auto 0;
        background: #fff;
        height: 300px;
        padding: 0 13%;
        box-sizing: border-box;
        text-align: center;
        .type-title{
            font-weight: bold;
            padding: 30px 0 80px 0;
        }
        .type-list{
            width: 100%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            .type-item {
                background: #f5f5f5;
                height: 100px;
                width: 150px;
                text-align: center;
                line-height: 100px;
                cursor: pointer;
                border: 1px solid gray(.1);
            }
            .type-item:hover {
                opacity: 0.6;
            }
        }
    }
}
</style>
