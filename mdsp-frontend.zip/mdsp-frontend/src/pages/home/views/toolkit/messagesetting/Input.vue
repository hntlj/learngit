<template lang="html">
  <div class="msgsetting-input">
    <div class="el-form-item" :class="{'is-error': errMessage && editing}">
      <div class="msgsetting-input__text" v-if="!editing" @click="$emit('focus')">
        <span>{{ value }}</span><i class="el-icon-close" v-show="showDelete" @click.stop="onRemove"></i>
      </div>
      <div class="el-form-item__content" v-else>
        <el-input v-model="val" autofocus>
          <el-button @click="onSave" type="text" slot="append" class="msgsetting-input__btn" :disabled="!val">确定</el-button>
        </el-input>
        <div class="el-form-item__error" v-html="errMessage"></div>
      </div>
    </div>
  </div>
</template>

<script>
const telReg = new RegExp('^(13|14|15|17|18|19)[0-9]{9}$')
const emailReg = new RegExp('^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(.[a-zA-Z0-9_-]+)+$')
export default {
  props: {
    value: String,
    rule: Object,
    type: String,
    editing: Boolean,
    showDelete: Boolean
  },
  data () {
    return {
      edit: false,
      val: this.value,
      errMessage: ''
    }
  },
  methods: {
    onSave () {
      if (!this.errMessage) {
        this.$emit('save', this.val)
      }
    },
    onRemove () {
      this.$confirm(`确定删除${this.type === 'tel' ? '手机号码' : '邮箱'} ${this.value}吗？`, '', {
        type: 'warning'
      }).then(() => {
        this.$emit('remove')
      })
    }
  },
  watch: {
    editing (val) {
      this.edit = val
      if (val) {
        this.val = this.value
      }
    },
    val (value) {
      const pattern = this.type === 'tel' ? telReg : emailReg
      if (value && !pattern.test(value)) {
        this.errMessage = `${this.type === 'tel' ? '手机号码' : '邮箱'}格式不正确`
      } else {
        this.errMessage = ''
      }
    }
  }
}
</script>

<style lang="scss">
.msgsetting-input {
  display: inline-block;
  vertical-align: top;
  margin-right: 24px;

  &__text {
    position: relative;
    border: 1px solid #ddd;
    border-radius: 4px;
    padding: 10px 45px 10px 15px;
    font-size: 14px;
    line-height: 16px;

    .el-icon-close {
      position: absolute;
      right: 15px;
      border-radius: 4px;
      background-color: #ccc;
      color: #fff;
      font-size: 9px;
      padding: 2px;
      cursor: pointer;
    }
  }
  .el-input-group__append {
    background: #fff !important;
  }
  &__btn {
    color: $blue !important;
    &.is-disabled span {
      color: gray(.3)
    }
  }
  .errorTip {
    font-size: 12px;
    padding-top: 6px;
  }
}
</style>
