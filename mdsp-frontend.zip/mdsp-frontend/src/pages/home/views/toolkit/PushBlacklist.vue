<template>
  <div class="pd24">
    <div class="home-card pd24 mh600">
      <div class="home-card__header line">
        <h2><back :title="title"></back></h2>
        <el-button class="pull-right crowd-upload-btn" style="width: 160px" @click="onEdit(null, 'create', $event)">新建黑名单</el-button>
      </div>
      <div class="home-card__main">
        <super-form class="home-searchform" label-width="0px" :form-list="searchOptions" v-model="searchFormData"></super-form>
        <el-table class="table-border" :data="dataList" v-loading="fetching">
          <el-table-column header-align="center" align="center" v-for="col in tableColumn" :key="col.id"
            :prop="col.prop" :sortable="col.sortable"
            :label="col.label">
            <template slot-scope="scope">
              <span v-if="col.prop === 'name'" v-html="col.formatter(scope.row)"></span>
              <span v-else>{{ col.formatter ? col.formatter(scope.row) : scope.row[col.prop] }}</span>
            </template>
          </el-table-column>
          <el-table-column width="400px" align="center" label="操作">
            <template slot-scope="scope">
              <el-button @click="onEdit(scope.row, 'detail', $event)" type="text">查看</el-button>
              <el-button @click="onEdit(scope.row, 'update', $event)" type="text">修改</el-button>
              <el-button @click="onDelete(scope.row, $event)" type="text" class="color-red">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="home-card__footer">
        <el-pagination class="pull-right"
          v-if="dataListTotal > defaultPageSize"
          background
          :page-size="PAGE_SIZE"
          :page-sizes="PAGE_SIZES"
          :current-page="searchFormData.pageNumber"
          :total="dataListTotal"
          @size-change="onSizeChange"
          @current-change="onPageChanged"
          layout="total, sizes, prev, pager, next, jumper">
        </el-pagination>
      </div>
    </div>
    <el-dialog class="tip-dialog" title="提示" :visible.sync="showUpdateTip" width="30%">
      <P class="tip-dialog__title">该黑名单已关联以下广告，不支持删除!</P>
      <el-table :data="ideasData">
        <el-table-column property="id" label="广告ID" width="150"></el-table-column>
        <el-table-column property="name" label="广告名称"></el-table-column>
      </el-table>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="showUpdateTip = false">确 定</el-button>
      </span>
    </el-dialog>
    <blacklist-creator @refetch="fetchBlacklistList" :blacklist.sync="currentBlacklist" :operType.sync="operType"></blacklist-creator>
  </div>
</template>

<script>
import utils from '@/utils'
import { getBlacklistList, destroyBlacklist } from '@/api'
import { PAGE_SIZE, PAGE_SIZES } from '@/enums'
import SuperForm from '@/components/SuperForm'
import BlacklistCreator from '@/components/home/toolkit/PushBlacklistCreator'
import Back from '@/components/home/toolkit/Back'
export default {
  data () {
    return {
      fetching: false,
      searchFormData: null,
      dataList: [],
      dataListTotal: 0,
      searchOptions: [
        { type: 'hidden', key: 'pageNumber', default: 1 },
        { type: 'hidden', key: 'pageSize', default: PAGE_SIZE },
        { type: 'text', key: 'name', placeholder: '黑名单名称' }
      ],
      tableColumn: [
        { prop: 'name', label: '黑名单名称', formatter: row => row.name },
        { prop: 'size', label: 'imei数量', formatter: row => row.size },
        { prop: 'date', label: '创建时间', formatter: row => utils.formatDate(row.createdTime, 'yyyy-MM-dd HH:mm:ss') },
        { prop: 'date', label: '更新时间', formatter: row => utils.formatDate(row.updatedTime, 'yyyy-MM-dd HH:mm:ss') }
      ],
      page: 1,
      PAGE_SIZE,
      PAGE_SIZES,
      defaultPageSize: PAGE_SIZE,
      currentBlacklist: null,
      operType: '',
      title: '应用拉活黑名单',
      ideasData: [],
      showUpdateTip: false
    }
  },
  computed: {},
  methods: {
    onEdit (bl, type) {
      this.currentBlacklist = bl || {}
      this.operType = type
    },
    onDelete (bl) {
      this.$confirm(`是否删除黑名单：${bl.name}？`, '', {
        type: 'warning'
      }).then(() => {
        destroyBlacklist(bl.id).then(res => {
          if (res.code === 200) {
            this.$message.success('删除成功!')
            if (this.dataList.length === 1 && this.searchFormData.pageNumber > 1) {
              this.onPageChanged(--this.searchFormData.pageNumber)
            } else {
              this.fetchBlacklistList()
            }
          }
        }).catch(error => {
          if (typeof error.value === 'object') {
            this.ideasData = error.value
            this.showUpdateTip = true
          } else {
            this.$message.error(error.message)
          }
        })
      })
    },
    onSizeChange (currSize) {
      this.searchFormData.pageSize = currSize
      this.fetchBlacklistList()
    },
    onPageChanged (currPage) {
      this.searchFormData.pageNumber = currPage
      this.fetchBlacklistList()
    },
    fetchBlacklistList () {
      this.fetching = true
      getBlacklistList({ ...this.searchFormData }).then(res => {
        this.dataList = res.value.data || []
        this.dataListTotal = res.value.total
      }).finally(() => {
        setTimeout(() => {
          this.fetching = false
        }, 300)
      })
    }
  },
  watch: {
    searchFormData (val) {
      this.debounceFetchBlacklistList()
    }
  },
  created () {
    this.debounceFetchBlacklistList = utils.debounce(this.fetchBlacklistList)
  },
  components: {
    SuperForm,
    Back,
    BlacklistCreator
  }
}
</script>

<style lang="scss" scoped>
.tip-dialog {
  &__title{
    margin-bottom: 20px;
    text-align: center;
  }
}
</style>
