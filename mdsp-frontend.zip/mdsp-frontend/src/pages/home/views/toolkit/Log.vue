<template>
  <div class="pd24">
    <div class="home-card pd24">
      <div class="home-card__header line">
        <h2><back :title="title"></back></h2>
      </div>
      <div class="home-card__main">
        <super-form class="home-searchform" label-width="0px" :form-list="searchOptions" v-model="formData">
          <div>
            <el-form-item label="操作项" label-width="100px">
              <el-radio v-model="customOperateTypes" :label="false">全部选项</el-radio>
              <el-radio v-model="customOperateTypes" :label="true">自定义</el-radio>
              <keep-alive>
                <div v-if="customOperateTypes">
                  <el-checkbox :indeterminate="isIndeterminate" v-model="selectAll" @change="onSelectAllChanged">全选</el-checkbox>
                  <el-checkbox-group v-model="checkedOperateTypes" @change="onOperateTypesChanged">
                    <p v-for="(group, idx) in operateTypes" :key="idx">
                      <span class="checkbox-title">{{ group.label }}</span>
                      <el-checkbox v-for="ot in group.value" :key="ot.type" :label="ot.type">{{ ot.name }}</el-checkbox>
                    </p>
                  </el-checkbox-group>
                </div>
              </keep-alive>
            </el-form-item>
          </div>
        </super-form>
        <el-table class="table-border" :data="dataList" v-loading="fetching">
          <el-table-column header-align="center" align="center" v-for="col in tableColumn" :key="col.prop"
            :prop="col.prop"
            :label="col.label">
            <template slot-scope="scope">
              <el-popover v-if="showTimeGrid(scope.row, col.prop)"
                placement="top-start"
                width="1200"
                trigger="hover">
                <el-time-grid read-only v-model="scope.row[col.prop]"></el-time-grid>
                <a href="javascript:;" slot="reference">分时段</a>
              </el-popover>
              <span v-else>{{col.formatter ? col.formatter(scope.row) : scope.row[col.prop]}}</span>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="home-card__footer">
        <el-pagination class="pull-right"
          v-if="dataListTotal > defaultPageSize"
          background
          :page-size="PAGE_SIZE"
          :page-sizes="PAGE_SIZES"
          :current-page="formData.pageNumber"
          :total="dataListTotal"
          @size-change="onSizeChange"
          @current-change="onPageChanged"
          layout="total, sizes, prev, pager, next, jumper">
        </el-pagination>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import utils from '@/utils'
import Storage from '@/utils/storage'
import { getLogList, getLogTypeList } from '@/api'
import SuperForm from '@/components/SuperForm'
import { MAX_BUDGET, PAGE_SIZE, PAGE_SIZES } from '@/enums'
import Back from '@/components/home/toolkit/Back'
export default {
  data () {
    return {
      fetching: false,
      formData: null,
      dataList: [],
      dataListTotal: 0,
      tableColumn: [
        { prop: 'operateTime', label: '操作时间', formatter: row => utils.formatDate(row.operateTime, 'yyyy-MM-dd HH:mm:ss') },
        { prop: 'parentOperateTypeName', label: '层级' },
        { prop: 'planName', label: '计划名称' },
        { prop: 'unitName', label: '单元名称' },
        { prop: 'ideaName', label: '创意名称' },
        { prop: 'operateTypeName', label: '操作项' },
        { prop: 'oldValue', label: '操作前', formatter: row => row.operateTypeName === '修改每日预算' ? this.formatBudget(row.oldValue) : row.oldValue },
        { prop: 'newValue', label: '操作后', formatter: row => row.operateTypeName === '修改每日预算' ? this.formatBudget(row.newValue) : row.newValue },
        { prop: 'operatorName', label: '操作人' }
      ],
      customOperateTypes: false,
      checkedOperateTypes: [],
      selectAll: true,
      isIndeterminate: false,
      operateTypes: [],
      PAGE_SIZE,
      PAGE_SIZES,
      defaultPageSize: PAGE_SIZE,
      title: '操作日志'
    }
  },
  computed: {
    ...mapGetters(['planList']),
    searchOptions () {
      return [
        { type: 'hidden', key: 'pageNumber', default: 1 },
        { type: 'hidden', key: 'pageSize', default: PAGE_SIZE },
        { type: 'select', key: 'planId', label: '广告计划', options: this.planList },
        { type: 'daterange', key: 'Time', label: '选择日期', default: [new Date(), new Date()] }
      ]
    },
    allOperateTypesValue () {
      return this.operateTypes.reduce((c, a) => c.concat(a.value), []).map(o => o.type)
    }
  },
  methods: {
    onPageChanged (currPage) {
      this.formData.pageNumber = currPage
      this.debounceFetchLogList()
    },
    onSizeChange (currSize) {
      this.formData.pageSize = currSize
      this.debounceFetchLogList()
    },
    onOperateTypesChanged (value) {
      const checkCount = value.length
      this.selectAll = checkCount === this.allOperateTypesValue.length
      this.isIndeterminate = checkCount > 0 && checkCount < this.allOperateTypesValue.length
      this.debounceFetchLogList()
    },
    onSelectAllChanged (value) {
      this.checkedOperateTypes = value ? this.allOperateTypesValue : []
      this.onOperateTypesChanged(this.checkedOperateTypes)
      this.isIndeterminate = false
    },
    fetchLogTypes () {
      getLogTypeList().then(res => {
        if (res.code === 200) {
          const data = res.value
          this.operateTypes = Object.keys(data).map(key => {
            return {
              label: key,
              value: data[key]
            }
          })
        }
      }).then(() => {
        this.checkedOperateTypes = [...Storage.get('oprTypes')] || [...this.allOperateTypesValue]
        this.fetchLogList()
      })
    },
    fetchLogList () {
      this.fetching = true
      const operateTypes = this.customOperateTypes ? this.checkedOperateTypes.join(',') : this.allOperateTypesValue.join(',')
      if (!operateTypes) {
        this.dataList = []
        this.dataListTotal = 0
        this.fetching = false
        return
      }
      getLogList({...this.formData, operateTypes}).then(res => {
        if (res.code === 200) {
          this.dataListTotal = res.value.total
          this.dataList = res.value.data || []
        }
      }).finally(() => {
        setTimeout(() => {
          this.fetching = false
        }, 300)
      })
    },
    showTimeGrid (row, prop) {
      if (~row.operateTypeName.indexOf('投放时间段') && ~['newValue', 'oldValue'].indexOf(prop)) {
        if (row[prop] !== '全时间段') {
          return true
        }
      }
      return false
    },
    formatBudget (value) {
      value = Number(value)
      return (isNaN(value) || value >= MAX_BUDGET) ? '不限额' : value
    }
  },
  watch: {
    customOperateTypes (val) {
      this.debounceFetchLogList()
    },
    checkedOperateTypes (val) {
      Storage.set('oprTypes', this.checkedOperateTypes)
    },
    formData (val) {
      this.operateTypes.length > 0 && this.debounceFetchLogList()
    }
  },
  created () {
    this.$store.dispatch('getAllPlanList')
    this.debounceFetchLogList = utils.debounce(this.fetchLogList)
    this.debounceFetchLogList()
    this.fetchLogTypes()
  },
  components: {
    SuperForm, Back
  }
}
</script>
<style lang="scss">
span.checkbox-title {
  display: inline-block;
  font-size: 14px;
  margin-right: 20px;
  width: 60px;
}
</style>
