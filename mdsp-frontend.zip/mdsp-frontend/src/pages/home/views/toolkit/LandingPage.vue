<template>
  <div class="pd24">
    <div class="home-card pd24 mh600">
      <div class="home-card__header line">
        <h2>
          <back :title="title"></back>
        </h2>
        <el-button type="primary" class="pull-right" style="width: 160px" @click="onEdit({id:''}, 'new')">新增站点</el-button>
      </div>
      <div class="home-card__main">
        <super-form class="home-searchform" label-width="0px" :form-list="searchOptions" v-model="formData"></super-form>
        <el-table class="table-border" :data="dataList" :default-sort="defaultSort" v-loading="fetching" @sort-change="onSortChange">
          <el-table-column align="center" v-for="col in tableColumn" :key="col.prop"
            :prop="col.prop"
            :sortable="col.sortable"
            :label="col.label"
            :formatter="col.formatter">
          </el-table-column>
          <el-table-column width="400px" align="center" label="操作">
            <template slot-scope="scope">
              <el-button type="text" @click="onPreview(scope.row)">预览</el-button>
              <el-button v-if="scope.row.status === 0" type="text" @click="onPreview(scope.row, true)">发布</el-button>
              <el-button v-if="scope.row.status === 1" type="text" @click="onDisable(scope.row)">下线</el-button>
              <el-button v-if="scope.row.status === 0 && scope.row.templateStyle === 4" type="text" @click="onEdit(scope.row, 'edit')">编辑</el-button>
              <el-button v-if="scope.row.templateStyle === 4" type="text" @click="onEdit(scope.row, 'copy')">复制</el-button>
              <el-button v-if="scope.row.status === 0" type="text" class="color-red" @click="onDelete(scope.row)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="home-card__footer">
        <el-pagination class="pull-right"
          v-if="dataListTotal > defaultPageSize"
          background
          :page-size="PAGE_SIZE"
          :page-sizes="PAGE_SIZES"
          :current-page="formData.pageNumber"
          :total="dataListTotal"
          @size-change="onSizeChange"
          @current-change="onPageChanged"
          layout="total, sizes, prev, pager, next, jumper">
        </el-pagination>
      </div>
    </div>
    <el-dialog custom-class="dialog-preview" title="效果预览" :visible.sync="showPreview">
      <div class="preview-wrapper" v-loading="previewLoading">
        <iframe ref="iframe" :src="previewUrl" @load="onPageLoad" v-show="!previewLoading"></iframe>
      </div>
      <div slot="footer" v-if="isPublish">
        <el-button @click="showPreview = false">取消</el-button>
        <el-button type="primary" @click="onPublish(landingPage)" v-show="showPublish">发布</el-button>
      </div>
    </el-dialog>
    <el-dialog title="效果预览" :visible.sync="showPreviewSite" width="800px">
      <div class="site-preview-box">
        <div class="site-iframe">
          <iframe :src="siteUrl"></iframe>
        </div>
        <div class="site-qrcode">
          <p class="site-qrcode__title">预览二维码</p>
          <div class="site-qrcode__img" ref="qrcode"></div>
          <p class="site-qrcode__tip">链接及二维码有时效限制, 请勿用于广告投放!</p>
        </div>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button @click="showPreviewSite = false">取 消</el-button>
        <el-button type="primary" @click="onPublishSite(landingPage)" v-show="showPublishSite">发布</el-button>
      </div>
    </el-dialog>
    <el-dialog class="tip-dialog" title="提示" :visible.sync="showUpdateTip" width="30%">
      <P class="tip-dialog__title">该落地页已关联以下创意，请解除关联后再次操作!</P>
      <el-table :data="ideasData">
        <el-table-column property="id" label="创意ID"></el-table-column>
        <el-table-column property="name" label="创意名称"></el-table-column>
      </el-table>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="showUpdateTip = false">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
// import { filters } from '@/utils/filters'
import utils from '@/utils'
import templatePageMixin from '@/mixins/templatePage'
import { TEMPLATE_STYLE, LANDINGPAGE_TEMPLATE, LANDINGPAGE_STATUS, PAGE_SIZE, PAGE_SIZES, HOST } from '@/enums'
import { getAppDetail, getLandingPageList, updateLandingPageStatus, postLandingPage } from '@/api'
import sortable from '@/mixins/sortable'
import SuperForm from '@/components/SuperForm'
import Back from '@/components/home/toolkit/Back'
export default {
  mixins: [templatePageMixin, sortable],
  data () {
    const lastWeek = new Date().getTime() - 86400000 * 6
    return {
      PAGE_SIZE,
      PAGE_SIZES,
      defaultPageSize: PAGE_SIZE,
      fetching: false,
      formData: null,
      searchOptions: [
        { type: 'hidden', key: 'pageNumber', default: 1 },
        { type: 'hidden', key: 'pageSize', default: PAGE_SIZE },
        { type: 'text', key: 'name', placeholder: '站点名称' },
        { type: 'select', key: 'status', label: '状态', options: LANDINGPAGE_STATUS },
        { type: 'daterange', key: 'Time', label: '选择日期', default: [lastWeek, new Date()] }
      ],
      tableColumn: [
        { prop: 'name', label: '站点名称' },
        { prop: 'id', label: '站点ID' },
        { prop: 'templateStyle', label: '站点（落地页）类型', formatter: row => TEMPLATE_STYLE[row.templateStyle].name },
        { prop: 'updateTime', label: '更新时间', formatter: row => utils.formatDate(row.updateTime) },
        { prop: 'status', label: '状态', formatter: row => LANDINGPAGE_STATUS[row.status].name }
        // { prop: 'exposure', label: '展现量', formatter: ({exposure}) => { return filters.number(exposure) }, sortable: true },
        // { prop: 'download', label: '下载量', formatter: ({download}) => { return filters.number(download) }, sortable: true },
        // { prop: 'open', label: '打开量', formatter: ({open}) => { return filters.number(open) }, sortable: true },
        // { prop: 'form', label: '表单提交量', formatter: ({form}) => { return filters.number(form) }, sortable: true },
        // { prop: 'call', label: '电话拨打量', formatter: ({call}) => { return filters.number(call) }, sortable: true },
        // { prop: 'consult', label: '在线咨询量', formatter: ({consult}) => { return filters.number(consult) }, sortable: true }
      ],
      // defaultSort: {
      //   prop: 'exposure',
      //   order: 'descending'
      // },
      dataList: [],
      dataListTotal: 0,
      previewUrl: 'auto:blank',
      landingPage: null,
      showPreview: false,
      showPreviewSite: false,
      previewLoading: true,
      isPublish: false,
      showPublish: false,
      showPublishSite: false,
      showUpdateTip: false,
      isPublishing: false,
      siteUrl: '',
      title: '移动建站',
      ideasData: []
    }
  },
  methods: {
    onPreview (landingPage, isPublish) {
      const code = LANDINGPAGE_TEMPLATE[landingPage.templateStyle].code
      this.landingPage = landingPage
      if (code === 'site') {
        this.siteUrl = `${landingPage.url}?t=` + new Date().getTime()
        this.showPreviewSite = true
        let myImage = new Image(160, 160)
        myImage.src = `http://${HOST}/console/mdsp/app/getQRCode?lpId=${landingPage.id}`
        this.$nextTick(() => {
          this.$refs.qrcode['innerHTML'] = ''
          this.$refs.qrcode['appendChild'](myImage)
        })
        this.showPublishSite = isPublish
      } else {
        this.previewUrl = `/template-pages/views/${code}.html?v=${new Date().getTime()}`
        this.showPreview = true
        this.isPublish = isPublish
        this.showPublish = false
      }
    },
    onPageLoad () {
      this.previewLoading = false
      const { type, templateStyle: tplType, name, packageName: pkgName, styleModel } = this.landingPage
      getAppDetail({packageName: pkgName}).then(res => {
        if (res.code === 200 && res.value) {
          const appInfo = res.value
          this.$nextTick(() => {
            this.renderPage(tplType, appInfo, {
              type,
              tplType,
              name,
              pkgName,
              config: {
                [tplType]: JSON.parse(styleModel)
              }
            })
          })
          this.showPublish = true
        }
      })
    },
    onEdit (landingPage, action) {
      window.open(`http://${HOST}/site-pc/index.html#/?id=${landingPage.id}&action=${action}`, '_blank')
    },
    onDisable (landingPage) {
      updateLandingPageStatus(landingPage.id, 0).then(res => {
        if (res.code === 200) {
          this.$message.success('下线成功')
          this.fetchLandingPageList()
        }
      }).catch(error => {
        if (typeof error.value === 'object') {
          this.ideasData = error.value
          this.showUpdateTip = true
        } else {
          this.$message.error(error.message)
        }
      })
    },
    onDelete (landingPage) {
      this.$confirm(`确定要删除落地页“${landingPage.name}”？`, '', {
        type: 'warning'
      }).then(() => {
        updateLandingPageStatus(landingPage.id, 2).then(res => {
          if (res.code === 200) {
            this.$message.success('删除成功')
            if (this.dataList.length === 1 && this.formData.pageNumber > 1) {
              this.onPageChanged(--this.formData.pageNumber)
            } else {
              this.fetchLandingPageList()
            }
          }
        })
      })
    },
    onPublishSite (landingPage) {
      if (this.isPublishing) return
      this.isPublishing = true
      updateLandingPageStatus(landingPage.id, 1).then(res => {
        if (res.code === 200) {
          this.$message.success('发布成功')
          this.showPreviewSite = false
          this.fetchLandingPageList()
        }
      }).catch(error => {
        this.$message.error(`发布落地页错误[${error.message}]，请重试!`)
      }).finally(() => {
        this.isPublishing = false
      })
    },
    onPublish (landingPage) {
      if (this.isPublishing) return
      const { id, type, templateStyle, name, packageName } = landingPage
      let localImgs = []
      let styleModel = JSON.parse(landingPage.styleModel)
      if (templateStyle === 1) {
        localImgs.push(styleModel.bgImage)
      } else {
        if (styleModel.topImage) {
          localImgs.push(styleModel.topImage)
        }
        localImgs = localImgs.concat(styleModel.content.filter(({img}) => img).map(({img}) => img))
      }
      const doc = this._getIframeDoc()
      const html = ('<!DOCTYPE html>' + doc.getElementsByTagName('html')[0].outerHTML)
        .replace(/http:\/\/dsp\.meizu\.com\/upload\//g, '/upload/')
        .replace(/\.\.\/(css|js)/g, '/ad-static/landpage/$1')
        .replace(/\$\{__cls-invisibility__\}/g, 'invisibility')
      let params = { id, type, templateStyle, name, packageName, html }
      params = {
        ...params,
        status: 1,
        styleModel: JSON.stringify(styleModel),
        localImgs: localImgs.filter(img => img.indexOf('/upload/') === 0).join(',')
      }
      this.isPublishing = true
      postLandingPage(params).then(res => {
        if (res.code === 200) {
          this.$message.success('发布成功')
          this.showPreview = false
          this.fetchLandingPageList()
        }
      }).catch(error => {
        this.$message.error(`发布落地页错误[${error.message}]，请重试!`)
      }).finally(() => {
        this.isPublishing = false
      })
    },
    onSizeChange (currSize) {
      this.formData.pageSize = currSize
      this.fetchLandingPageList()
    },
    onPageChanged (currPage) {
      this.formData.pageNumber = currPage
      this.fetchLandingPageList()
    },
    fetchLandingPageList () {
      this.fetching = true
      getLandingPageList({
        ...this.formData,
        desc: (this.order === 'descending') * 1,
        orderBy: this.orderBy,
        queryType: 1
      }).then(res => {
        if (res.code === 200) {
          this.dataList = res.value.data
          this.dataListTotal = res.value.total
        }
      }).finally(() => {
        this.fetching = false
      })
    }
  },
  watch: {
    formData (val) {
      this.throttleFetchLandingPageList()
    }
  },
  created () {
    this.throttleFetchLandingPageList = utils.debounce(this.fetchLandingPageList)
    this.fetchList = this.throttleFetchLandingPageList
  },
  components: {
    SuperForm, Back
  }
}
</script>

<style lang="scss">
.site-preview-box {
  display: flex;
  justify-content: space-around;
  .site-iframe {
    box-sizing: border-box;
    width: 300px;
    height: 600px;
    padding: 32px 8px 55px 8px;
    background: url('~assets/img/preview/wrapper.png') no-repeat;
    background-size: contain;
    iframe {
      width: 100%;
      height: 100%;
    }
  }
  .site-qrcode {
    text-align: center;
    padding-top: 200px;
    &__title {
      line-height: 50px;
      font-size: 20px;
    }
    &__img {
      width: 160px;
      height: 160px;
      margin: 0 auto;
      img {
        display: block;
      }
    }
    &__tip {
      line-height: 40px;
    }
  }
}
.tip-dialog {
  &__title{
    margin-bottom: 20px;
    text-align: center;
  }
}
</style>
