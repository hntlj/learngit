<template>
  <div class="pd24">
    <div class="home-card pd24">
      <div class="home-card__header line">
        <h2>{{ title }}落地页模板</h2>
      </div>
      <div class="home-card__main">
        <div class="mt24" style="position: relative">
          <el-form label-position="left" label-width="120px" ref="form_1" :model="formData" :rules="rules">
            <el-form-item label="落地页类型" prop="type" key="type">
              <el-select v-model="formData.type">
                <el-option v-for="item in LANDINGPAGE_TYPE" :key="item.value" :label="item.name" :value="item.value"></el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="模板类型" prop="templateStyle" key="templateStyle">
              <el-radio-group v-model="formData.templateStyle">
                <el-radio v-for="item in LANDINGPAGE_TEMPLATE" :key="item.value" :label="item.value">{{ item.name }}</el-radio>
              </el-radio-group>
            </el-form-item>
            <el-form-item label="落地页名称" prop="name" key="name">
              <el-input v-model="formData.name" class="w640" placeholder="请输入名称，3-15字" :maxlength="15"></el-input>
            </el-form-item>
            <el-form-item label="应用包名" prop="packageName" key="packageName" required>
              <el-input v-model="formData.packageName" style="width: 580px" placeholder="请输入应用包名，例如 com.meizu.media.music"></el-input>
              <img v-if="appInfo" class="el-form-item__icon" :src="appInfo.icon"> {{ appInfo && appInfo.name }}
            </el-form-item>
            <!-- 短图文样式 -->
            <template v-if="formData.templateStyle === 2">
              <el-form-item label="顶部图片" :prop="`styleModel[${formData.templateStyle}].topImage`" :key="`styleModel[${formData.templateStyle}].topImage`" :rules="pageRules.topImage">
                <image-upload :width="1080" :height="460" v-model="formData.styleModel[formData.templateStyle].topImage" @input="onRenderPage()" />
              </el-form-item>
              <el-form-item label="宣传标题" :prop="`styleModel[${formData.templateStyle}].title`" :key="`styleModel[${formData.templateStyle}].title`" :rules="pageRules.title">
                <el-input v-model="formData.styleModel[formData.templateStyle].title" class="w640" placeholder="请输入宣传标题，6-20 字" @input="onRenderPage()" :maxlength="20"></el-input>
              </el-form-item>
            </template>
            <!-- 浮层样式 -->
            <template v-if="formData.templateStyle === 1">
              <el-form-item label="宣传图片" :prop="`styleModel[${formData.templateStyle}].bgImage`" :key="`styleModel[${formData.templateStyle}].bgImage`" :rules="pageRules.bgImage">
                <image-upload :width="1080" :height="1920" v-model="formData.styleModel[formData.templateStyle].bgImage" @input="onRenderPage()" />
              </el-form-item>
              <el-form-item label="宣传文案" :prop="`styleModel[${formData.templateStyle}].content`" :key="`styleModel[${formData.templateStyle}].content`" :rules="pageRules.content">
                <el-input type="textarea" v-model="formData.styleModel[formData.templateStyle].content" class="w640" placeholder="请输入宣传文案，20-120 字" @input="onRenderPage()" :maxlength="120"></el-input>
              </el-form-item>
            </template>
            <template v-else>
              <el-form-item label="宣传图文" prop="content">
                <rich-content v-model="formData.styleModel[formData.templateStyle].content" :limit-img="LIMIT_IMG[formData.templateStyle]" :template="formData.templateStyle" :limit-text="LIMIT_TEXT[formData.templateStyle]" @input="onRenderPage()" @valid="onRichContentValid" />
              </el-form-item>
            </template>
            <!-- 长图文样式 -->
            <template v-if="formData.templateStyle === 3">
              <el-form-item label="按钮样式" :prop="`styleModel[${formData.templateStyle}].btnStyle`" :key="`styleModel[${formData.templateStyle}].btnStyle`">
                <el-radio-group v-model="formData.styleModel[formData.templateStyle].btnStyle" @change="onRenderPage()">
                  <el-radio v-for="item in LANDINGPAGE_BTNSTYLE" :key="item.value" :label="item.value">{{ item.name }}</el-radio>
                </el-radio-group>
              </el-form-item>
            </template>
            <el-form-item label="按钮文字" :prop="`styleModel[${formData.templateStyle}].installText`" :rules="pageRules.installText">
              <el-input v-model="formData.styleModel[formData.templateStyle].installText" class="w640" placeholder="请输入按钮文字，2-4 字" @input="onRenderPage()" :maxlength="4"></el-input>
            </el-form-item>
            <el-form-item label="按钮颜色" prop="installBgColor">
              <el-popover
                ref="popovercolor"
                placement="top"
                width="220"
                trigger="click"
                class="popover-color">
                <sketch-picker v-model="formData.styleModel[formData.templateStyle].installBgColor" @input="onRenderPage()"></sketch-picker>
              </el-popover>
              <div class="installbg-color" v-popover:popovercolor :style="{backgroundColor: formData.styleModel[formData.templateStyle].installBgColor.hex}"></div>
            </el-form-item>
            <template v-if="formData.templateStyle === 3 && formData.styleModel[formData.templateStyle].btnStyle === 2">
              <el-form-item label="浮沉颜色" prop="layerBgColor">
                <el-popover
                  ref="popoverlayercolor"
                  placement="top"
                  width="220"
                  trigger="click"
                  class="popover-color">
                  <sketch-picker v-model="formData.styleModel[formData.templateStyle].layerBgColor" @input="onRenderPage()"></sketch-picker>
                </el-popover>
                <div class="installbg-color" v-popover:popoverlayercolor :style="{backgroundColor: formData.styleModel[formData.templateStyle].layerBgColor.hex}"></div>
              </el-form-item>
            </template>
          </el-form>
          <div class="dialog-preview landingpage-preview">
            <div class="preview-wrapper">
              <iframe ref="iframe" :src="iframeUrl" @load="previewLoading = false" v-show="!previewLoading"></iframe>
            </div>
          </div>
        </div>
      </div>
      <div class="home-card__footer mt24">
        <el-button class="normal w160" @click="$router.push({name: 'LandingPage'})">取消</el-button>
        <el-button type="primary" class="w160" @click="onSave" :disabled="updateLoading" :loading="updateLoading">保存</el-button>
        <!-- <el-button v-if="formData.id" type="primary" class="w160" @click="onPublish" :disabled="publishLoading" :loading="publishLoading">发布</el-button> -->
      </div>
    </div>
  </div>
</template>
<script>
import { Sketch } from 'vue-color'
import utils from '@/utils'
import validateMixin from '@/mixins/validate'
import templatePageMixin from '@/mixins/templatePage'
import { LANDINGPAGE_TYPE, LANDINGPAGE_TEMPLATE, LANDINGPAGE_BTNSTYLE } from '@/enums'
import ImageUpload from '@/components/home/ImageUpload'
import RichContent from './landingpage/RichContent'
import { getAppDetail, getLandingPageDetail, postLandingPage } from '@/api'
const defaultColor = {
  hex: '#3A75FF',
  a: 1
}
export default {
  mixins: [validateMixin, templatePageMixin],
  props: {
    id: Number
  },
  data () {
    const onValidApp = (rule, value, callback) => {
      if (!value) {
        return callback(new Error('请输入应用包名'))
      }
      if (this.appInfo.packageName === value) {
        return callback()
      }
      getAppDetail({ packageName: value }).then(res => {
        if (res.code === 200 && res.value) {
          this.appInfo = res.value
          this.onRenderPage()
          callback()
        } else {
          callback(new Error('应用中心没有找到该应用,请检查您输入的包名'))
        }
      })
    }
    return {
      appInfo: {},
      formData: {
        id: this.$route.query.id,
        type: LANDINGPAGE_TYPE[1].value,
        templateStyle: LANDINGPAGE_TEMPLATE[1].value,
        name: '',
        packageName: '',
        styleModel: {
          1: {
            bgImage: '',
            content: '',
            installText: '安装',
            installBgColor: defaultColor
          },
          2: {
            topImage: '',
            title: '',
            content: [],
            installText: '安装',
            installBgColor: defaultColor
          },
          3: {
            topImage: '',
            title: '',
            content: [],
            btnStyle: LANDINGPAGE_BTNSTYLE[2].value,
            installText: '安装',
            installBgColor: defaultColor,
            layerBgColor: '#fff',
            floatAlpha: 1
          }
        }
      },
      colors: defaultColor,
      layerColors: { hex: '#fff', a: 0.5 },
      rules: {
        name: [
          { required: true, message: '请输入落地页名称', trigger: 'change' },
          { min: 3, max: 15, message: '长度在 3-15 个字符', trigger: 'blur' }
        ],
        packageName: [{ validator: utils.debounce(onValidApp), trigger: 'change' }]
      },
      pageRules: {
        bgImage: [{ required: true, message: '请上传宣传图片', trigger: 'change' }],
        topImage: [{ required: true, message: '请上传顶部图片', trigger: 'change' }],
        content: [
          { required: true, message: '请输入宣传文案', trigger: 'change' },
          { min: 20, max: 120, message: '长度在 20-120 个字符', trigger: 'change' }
        ],
        title: [
          { required: true, message: '请输入宣传标题', trigger: 'change' },
          { min: 6, max: 20, message: '长度在 6-20 个字符', trigger: 'blur' }
        ],
        installText: [
          { required: true, message: '请输入按钮文字', trigger: 'change' },
          { min: 2, max: 4, message: '长度在 2 到 4 个字符', trigger: 'blur' }
        ]
      },
      richContentValid: false,
      LANDINGPAGE_TYPE: Object.values(LANDINGPAGE_TYPE),
      LANDINGPAGE_TEMPLATE: Object.values(LANDINGPAGE_TEMPLATE),
      LANDINGPAGE_BTNSTYLE: Object.values(LANDINGPAGE_BTNSTYLE),
      LIMIT_IMG: {
        2: 8,
        3: 2
      },
      LIMIT_TEXT: {
        2: 8,
        3: 2
      },
      previewLoading: true,
      updateLoading: false,
      publishLoading: false
    }
  },
  computed: {
    iframeForm () {
      const { type, templateStyle: tplType, name, packageName: pkgName, styleModel: config } = this.formData
      return { type, tplType, name, pkgName, config }
    },
    iframeUrl () {
      const code = LANDINGPAGE_TEMPLATE[this.formData.templateStyle].code
      return `/template-pages/views/${code}.html`
    },
    isCopy () {
      return this.$route.query.copy
    },
    title () {
      if (this.isCopy) {
        return '复制'
      } else if (this.formData.id) {
        return '编辑'
      }
      return '新建'
    }
  },
  methods: {
    async onPublish () {
      const valid = await this.validate()
      if (valid && !this.richContentValid && !this.updateLoading) {
        this.publishLoading = true
        const doc = this._getIframeDoc()
        const html = ('<!DOCTYPE html>' + doc.getElementsByTagName('html')[0].outerHTML)
          .replace(/http:\/\/dsp\.meizu\.com\/upload\//g, '/upload/')
          .replace(/\.\.\/(css|js)/g, '/ad-static/landpage/$1')
          .replace(/\$\{__cls-invisibility__\}/g, 'invisibility')
        const params = this._formatForm()
        params.status = 1 // 发布
        params['html'] = html
        postLandingPage(params).then(res => {
          if (res.code === 200) {
            this.$message.success('发布成功')
            this.$router.push({name: 'LandingPage'})
          }
        }).catch(error => {
          this.$message.error(`发布落地页错误[${error.message}]，请重试!`)
        }).finally(() => {
          this.publishLoading = false
        })
      }
    },
    async onSave () {
      const valid = await this.validate()
      if (valid && !this.richContentValid && !this.updateLoading) {
        this.updateLoading = true
        postLandingPage(this._formatForm()).then(res => {
          if (res.code === 200) {
            this.$message.success('保存成功')
            this.$router.push({name: 'LandingPage'})
          }
        }).catch(error => {
          this.$message.error(`保存落地页错误[${error.message}]，请重试!`)
        }).finally(() => {
          this.updateLoading = false
        })
      }
    },
    onRenderPage () {
      this.renderPage(this.formData.templateStyle, this.appInfo, this.iframeForm)
      this.validate()
    },
    onRichContentValid (isValid) {
      this.richContentValid = isValid
    },
    fetchPageDetail (id) {
      getLandingPageDetail({ lp_id: id }).then(res => {
        if (res.code === 200) {
          this.formData = this._syncForm(res.value)
          this.$nextTick(() => {
            this.$refs.form_1.validate()
          })
        }
      })
    },
    _formatForm () {
      let localImgs = []
      const status = 0
      const html = ''
      let { id, type, templateStyle, name, packageName, styleModel } = this.formData
      styleModel = {...styleModel[templateStyle]}
      styleModel.installBgColor = styleModel.installBgColor.hex
      if (templateStyle === 3 && styleModel.btnStyle === 2) {
        styleModel.layerBgColor = styleModel.layerBgColor.hex
      }
      if (templateStyle === 1) {
        localImgs.push(styleModel.bgImage)
      } else {
        if (styleModel.topImage) {
          localImgs.push(styleModel.topImage)
        }
        localImgs = localImgs.concat(styleModel.content.filter(({img}) => img).map(({img}) => img))
      }
      return {
        id,
        type,
        templateStyle,
        name,
        packageName,
        styleModel: JSON.stringify(styleModel),
        localImgs: localImgs.filter(img => img.indexOf('/upload/') === 0).join(','),
        status,
        html
      }
    },
    _syncForm (data) {
      const { id, type, templateStyle, name, packageName, styleModel } = data
      const _styleModel = JSON.parse(styleModel)
      const formData = {
        ...this.formData,
        id: this.isCopy ? '' : id,
        type,
        templateStyle,
        name,
        packageName,
        styleModel: {
          ...this.formData.styleModel,
          [templateStyle]: {
            ..._styleModel,
            installBgColor: {
              hex: _styleModel.installBgColor
            }
          }
        }
      }
      if (templateStyle === 3) {
        formData.styleModel[templateStyle].layerBgColor = {
          hex: _styleModel.layerBgColor || '#fff'
        }
      }
      return formData
    }
  },
  watch: {
    '$route.query.id': {
      handler: function (id) {
        id && this.fetchPageDetail(id)
      },
      immediate: true
    }
  },
  components: {
    ImageUpload,
    RichContent,
    SketchPicker: Sketch
  }
}
</script>
<style lang="scss">
.installbg-color {
  width: 64px;
  height: 32px;
  border: 2px solid #f1f1f1;
  border-radius: 3px;
}
.vc-sketch {
  box-shadow: none;
}
.landingpage-preview {
  position: absolute;
  top: 0;
  left: 881px;
}
</style>
