<!--
 * @Date: 2019-09-29 15:07:44
 * @LastEditors: PoloHuang
 * @LastEditTime: 2019-10-18 10:32:54
 -->
<template>
  <div class="pd24">
    <div class="home-card pd24 mh600">
      <div class="home-card__header line">
        <h2><back :title="title"></back></h2>
        <el-button class="pull-right crowd-upload-btn" @click="showUploadDialog = true" style="margin-left: 30px;">导入词包</el-button>
        <el-button class="pull-right crowd-upload-btn" style="width: 160px" @click="onEdit(null, 'add', $event)">新建词包</el-button>
      </div>
      <div class="home-card__main">
        <super-form class="home-searchform" label-width="0px" :form-list="searchOptions" v-model="searchFormData"></super-form>
        <el-table class="table-border" :data="dataList" v-loading="fetching">
          <el-table-column header-align="center" align="center" v-for="col in tableColumn" :key="col.prop"
            :prop="col.prop" :sortable="col.sortable"
            :label="col.label">
            <template slot-scope="scope">
              <span v-if="col.prop === 'name'" v-html="col.formatter(scope.row)"></span>
              <span v-else>{{ col.formatter ? col.formatter(scope.row) : scope.row[col.prop] }}</span>
            </template>
          </el-table-column>
          <el-table-column width="400px" align="center" label="操作">
            <template slot-scope="scope">
              <el-button @click="onEdit(scope.row, 'view', $event)" type="text">查看</el-button>
              <el-button @click="onEdit(scope.row, 'update', $event)" type="text">修改</el-button>
              <el-button @click="onExport(scope.row)" type="text">导出</el-button>
              <el-button @click="onDelete(scope.row, $event)" type="text" class="color-red">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="home-card__footer">
        <el-pagination class="pull-right"
          v-if="dataListTotal > defaultPageSize"
          background
          :page-size="PAGE_SIZE"
          :page-sizes="PAGE_SIZES"
          :current-page="searchFormData.pageNumber"
          :total="dataListTotal"
          @size-change="onSizeChange"
          @current-change="onPageChanged"
          layout="total, sizes, prev, pager, next, jumper">
        </el-pagination>
      </div>
    </div>
    <el-dialog title="导入词包" :visible.sync="showUploadDialog" v-loading="uploadLoading">
      <el-form label-width="120px" ref="form_upload" :model="uploadFormData" :rules="rules">
        <el-form-item label="词包名称" prop="packageName" key="packageName">
          <el-input v-model="uploadFormData.packageName"></el-input>
        </el-form-item>
        <el-form-item label="上传文件">
          <el-upload
            class="avatar-uploader"
            ref="keywordUpload"
            action="/console/mdsp/kw/manage/add"
            :data="uploadFormData"
            :on-change="handleChange"
            :on-remove="handleRemove"
            :on-success="uploadSubmitSucc"
            :on-error="uploadSubmitError"
            :auto-upload="false">
            <el-button slot="trigger" size="small">选择文件</el-button>
          </el-upload>
        </el-form-item>
      </el-form>
      <div class="keyword-tip-img">
        <div class="keyword-tip-icon">
          <el-tooltip placement="bottom" effect="light">
            <div slot="content"><img src="~assets/img/tiprule.png" /></div>
            <i class="el-icon-question"></i>
          </el-tooltip>
        </div>
        说明：<br/>
        1、文件格式：*.txt(UTF-8编码)文档中，一行一个关键词<br/>
        2、文件大小：单个文件内关键词数量上限是50个<br/>
        3、一个关键词的字符不能超过20，且字之间不能加空格<br/>
        4、词包名称不能重复，否则无法区分词包<br/>
        5、文件上传过程中，请勿关闭页面窗口，否则会导致文件上传失败
      </div>
      <div slot="footer">
        <el-button @click="showUploadDialog = false">取消</el-button>
        <el-button type="primary" @click="submitUpload">上传</el-button>
      </div>
    </el-dialog>
    <keyword-creator @refetch="fetchKeywordList" :keywordPackage.sync="currKeyword" :operType.sync="operType"></keyword-creator>
  </div>
</template>

<script>
// import { mapGetters } from 'vuex'
import utils from '@/utils'
import { getKeywordPackageList, destroyKeyword, exportKeyword } from '@/api'
import SuperForm from '@/components/SuperForm'
import KeywordCreator from '@/components/home/KeywordCreator'
import { PAGE_SIZE, PAGE_SIZES } from '@/enums'
import Back from '@/components/home/toolkit/Back'
export default {
  data () {
    const lastMonth = new Date().getTime() - 86400000 * 30
    return {
      fetching: false,
      searchFormData: null,
      dataList: [],
      dataListTotal: 0,
      searchOptions: [
        { type: 'hidden', key: 'pageNumber', default: 1 },
        { type: 'hidden', key: 'pageSize', default: PAGE_SIZE },
        { type: 'text', key: 'packageName', placeholder: '词包名称' },
        { type: 'daterange', key: 'Time', label: '选择日期', default: [lastMonth, new Date()] }
      ],
      tableColumn: [
        { prop: 'kwPackageName', label: '词包名称', formatter: row => row.kwPackageName },
        { prop: 'keywordCount', label: '关键词数量', formatter: row => row.keywordCount },
        { prop: 'date', label: '更新时间', formatter: row => utils.formatDate(row.updateTime, 'yyyy-MM-dd HH:mm:ss') }
      ],
      page: 1,
      PAGE_SIZE,
      PAGE_SIZES,
      defaultPageSize: PAGE_SIZE,
      currKeyword: null,
      operType: '',
      uploadFormData: {
        packageName: ''
      },
      rules: {
        packageName: [
          { required: true, message: '请输入词名称', trigger: 'change' }
        ],
        file: [
          { required: true, message: '请上传文件', trigger: 'change' }
        ]
      },
      showUploadDialog: false,
      uploadLoading: false,
      title: '关键词包'
    }
  },
  computed: {},
  methods: {
    onEdit (kw, type) {
      this.currKeyword = kw || {}
      this.operType = type
    },
    onDelete (kw) {
      this.$confirm(`是否删除词包：${kw.kwPackageName}？`, '', {
        type: 'warning'
      }).then(() => {
        destroyKeyword(kw.kwPackageName).then(res => {
          if (res.code === 200) {
            this.$message.success('删除成功')
            if (this.dataList.length === 1 && this.searchFormData.pageNumber > 1) {
              this.onPageChanged(--this.searchFormData.pageNumber)
            } else {
              this.fetchKeywordList()
            }
          }
        }).catch(error => {
          this.$message.error(error.message)
        })
      })
    },
    onExport (kw) {
      exportKeyword({packageName: kw.kwPackageName})
    },
    onSizeChange (currSize) {
      this.searchFormData.pageSize = currSize
      this.fetchKeywordList()
    },
    onPageChanged (currPage) {
      this.searchFormData.pageNumber = currPage
      this.fetchKeywordList()
    },
    fetchKeywordList () {
      this.fetching = true
      getKeywordPackageList({ ...this.searchFormData }).then(res => {
        if (res.code === 200) {
          this.dataList = res.value.data
          this.dataListTotal = res.value.total
        }
      }).finally(() => {
        setTimeout(() => {
          this.fetching = false
        }, 300)
      })
    },
    exportToText () {
      window.open(`/console/mdsp/kwpackage/list/export`)
    },
    handleRemove (file) {
      this.hasUploadFile = false
    },
    handleChange (file, fileList) {
      if (fileList.length === 0) {
        this.hasUploadFile = false
        return false
      }
      const isText = file.raw.type === 'text/plain'
      const isLt50M = file.size / 1024 / 1024 < 50
      if (!isText) {
        this.$message.error('上传文件格式必须为.txt格式!')
      }
      if (!isLt50M) {
        this.$message.error('上传文件大小不能超过 50MB!')
      }
      if (!isText || !isLt50M) {
        this.$refs.keywordUpload.clearFiles()
      } else {
        if (fileList.length > 1) {
          fileList.shift()
        }
      }
      this.hasUploadFile = isText && isLt50M
    },
    submitUpload () {
      this.$refs['form_upload'].validate((valid) => {
        if (!this.hasUploadFile) {
          this.$message.error('请上传文件!')
        } else {
          if (valid) {
            this.uploadLoading = true
            this.$refs.keywordUpload.submit()
          }
        }
        this.showUploadDialog = true
      })
    },
    uploadSubmitSucc (res) {
      this.uploadLoading = false
      if (res.code === 200) {
        this.fetchKeywordList()
        this.$message.success('上传成功!')
        this.showUploadDialog = false
      } else {
        this.$message.error(res.message)
        this.$refs.keywordUpload.clearFiles()
        this.hasUploadFile = false
      }
    },
    uploadSubmitError (res) {
      this.uploadLoading = false
    }
  },
  watch: {
    searchFormData (val) {
      // this.dataListTotal === 0 && this.fetchKeywordList()
      this.throttleFetchKeywordList()
    },
    showUploadDialog (val) {
      if (!val) {
        this.$refs.keywordUpload.clearFiles()
        this.uploadFormData = {
          packageName: ''
        }
      }
    }
  },
  created () {
    this.throttleFetchKeywordList = utils.debounce(this.fetchKeywordList)
  },
  components: {
    SuperForm,
    KeywordCreator,
    Back
  }
}
</script>

<style lang="scss">
.keyword-tip-img {
  position: relative;
  line-height: 25px;
  background: #f0f0f0;
  padding: 10px 20px;
  width: 500px;
  margin: 30px 0 50px 30px;
  .keyword-tip-icon{
    position: absolute;
    right: 160px;
    top: 28px;
  }
}
</style>
