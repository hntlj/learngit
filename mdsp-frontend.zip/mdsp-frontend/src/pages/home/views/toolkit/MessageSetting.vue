<template>
  <div class="pd24">
    <div class="home-card pd24">
      <div class="home-card__header line">
        <h2><back :title="title"></back></h2>
      </div>
      <div class="home-card__main">
        <div class="msgsetting">
          <div class="msgsetting__header"><span>手机号码</span></div>
          <div class="msgsetting__main">
            <ms-input v-for="(tel, idx) in formData.tels" :key="idx"
              type="tel" :value="tel" :editing="editingIndex.tels === idx" :show-delete="formData.tels.length > 1"
              @focus="onFocus('tels', idx, $event)"
              @save="onSave('tels', idx, $event)"
              @remove="onRemove('tels', idx, $event)" />
            <template v-if="formData.tels.length < 5">
              <ms-input v-if="adding.tels" :value="adding.telsVal" editing @save="onSave('tels', formData.tels.length, $event)" type="tel"/>
              <el-button v-else plain class="normal" @click="onAdd('tels', $event)">添加手机号</el-button>
              <span></span>
            </template>
          </div>
          <div class="msgsetting__header"><span>邮箱</span></div>
          <div class="msgsetting__main">
            <ms-input v-for="(email, idx) in formData.emails" :key="idx"
              type="email" :value="email" :editing="editingIndex.emails === idx" :show-delete="formData.emails.length > 1"
              @focus="onFocus('emails', idx, $event)"
              @save="onSave('emails', idx, $event)"
              @remove="onRemove('emails', idx, $event)" />
            <template v-if="formData.emails.length < 5">
              <ms-input v-if="adding.emails" :value="adding.emailsVal" editing @save="onSave('emails', formData.emails.length, $event)" type="email"/>
              <el-button v-else plain class="normal" @click="onAdd('emails', $event)">添加邮箱</el-button>
              <span></span>
            </template>
          </div>
        </div>
      </div>
    </div>

    <div class="home-card pd24 mt24">
      <div class="home-card__header">
        <h2>消息订阅</h2>
      </div>
      <div class="home-card__main">
        <table class="msgsetting__table">
          <thead>
            <tr>
              <th width="150">消息类型</th>
              <th width="450">消息种类</th>
              <th>站内信</th>
              <th>邮箱</th>
              <th>手机短信</th>
            </tr>
          </thead>
          <tbody>
            <template v-for="(row, idx) in config">
              <template v-for="(subRow, subIdx) in row.msgTypes">
                <tr :key="idx + '-' + subIdx">
                  <td v-if="subIdx === 0" :rowspan="row.msgTypes.length">{{ row.notifyType }}</td>
                  <td>{{ subRow.desc }}</td>
                  <td><el-checkbox checked disabled></el-checkbox></td>
                  <td><el-checkbox-group v-model="formData.settings[subRow.key]" @change="submit"><el-checkbox label="3">&nbsp;</el-checkbox></el-checkbox-group></td>
                  <td><el-checkbox-group v-model="formData.settings[subRow.key]" @change="submit"><el-checkbox label="2">&nbsp;</el-checkbox></el-checkbox-group></td>
                </tr>
              </template>
            </template>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { getNotifySetting, updateNotifySetting } from '@/api'
import Input from './messagesetting/Input'
import Back from '@/components/home/toolkit/Back'
export default {
  data () {
    return {
      formData: {
        tels: [],
        emails: [],
        settings: {}
      },
      editingIndex: {
        tels: -1,
        emails: -1
      },
      adding: {
        tels: false,
        telsVal: '',
        emails: false,
        emailsVal: ''
      },
      title: '联系方式'
    }
  },
  computed: {
    ...mapGetters(['isSponsor', 'userInfo']),
    config () {
      if (this.isSponsor) {
        return [
          { notifyType: '账号信息', msgTypes: [{desc: '广告计划达到日限额', key: '2'}, {desc: '广告单元投放到期', key: '4'}, {desc: '推广应用下架', key: '15'}, {desc: '自定义人群包到期', key: '16'}] },
          { notifyType: '审核信息', msgTypes: [{desc: '广告创意审核不通过', key: '6'}] },
          { notifyType: '财务信息', msgTypes: [{desc: '账户余额为 0', key: '7'}, {desc: '账户余额低于 200', key: '8'}, {desc: '账户资金到账', key: '9'}, {desc: '充值审核不通过', key: '10'}, {desc: '账户余额小于两日总消耗', key: '17'}] }
        ]
      } else {
        return [{ notifyType: '财务信息', msgTypes: [{desc: '账户资金到账', key: '9'}, {desc: '充值审核不通过', key: '10'}] }]
      }
    }
  },
  methods: {
    onFocus (key, idx) {
      this.adding[key] = false
      this.adding[key + 'Val'] = ''
      this.editingIndex[key] = idx
    },
    onAdd (key) {
      this.adding[key] = true
      this.editingIndex[key] = -1
    },
    onRemove (key, idx) {
      this.formData[key].splice(idx, 1)
      this.submit()
    },
    onSave (key, idx, value) {
      if (!value) {
        return
      }
      if (key === 'tels' || key === 'emails') {
        const index = this.formData[key].indexOf(value)
        if (index !== idx && index !== -1) {
          return this.$message.error(`${key === 'tels' ? '手机号码' : '邮箱'}已存在`)
        }
        const isAdd = this.formData[key].length === idx
        this.$confirm(`确定要${isAdd ? '添加' : '修改'}${key === 'tels' ? '手机号' : '邮箱'} ${value} 吗？`, '', {
          type: 'warning'
        }).then(() => {
          this.formData[key][idx] = value
          this.submit()
        })
      }
    },
    submit () {
      const params = {
        phones: this.formData.tels.join(','),
        emails: this.formData.emails.join(','),
        settings: this.formatSettingsString(this.formData.settings)
      }
      updateNotifySetting(this.isSponsor, params).then(res => {
        if (res.code === 200) {
          this.$message.success('更新成功')
        }
      }).catch(error => {
        this.$message.error(error.message)
      }).finally(() => {
        this.editingIndex = {
          tels: -1,
          emails: -1
        }
        this.adding = {
          tels: false,
          telsVal: '',
          emails: false,
          emailsVal: ''
        }
        this.fetchNotifySetting()
      })
    },
    fetchNotifySetting () {
      getNotifySetting(this.isSponsor).then(res => {
        if (res.code === 200) {
          const { phones, emails, settings } = res.value
          const settingsJson = settings ? JSON.parse(settings) : {}
          let formatSettings = {}
          Object.keys(settingsJson).forEach(key => {
            formatSettings[key] = settingsJson[key].split(',')
          })
          this.formData = {
            tels: phones.split(','),
            emails: emails.split(','),
            settings: formatSettings
          }
        }
      })
    },
    isCheck (key, value) {
      return this.formData.settings[key].indexOf(value) > -1
    },
    formatSettingsString (settings) {
      let ret = { ...settings }
      for (let key in ret) {
        ret[key] = ret[key].join(',')
      }
      return JSON.stringify(ret)
    }
  },
  watch: {
    isSponsor () {
      this.fetchNotifySetting()
    }
  },
  created () {
    this.fetchNotifySetting()
  },
  components: {
    'ms-input': Input,
    Back
  }
}
</script>

<style lang="scss">
.msgsetting {
  &__header {
    padding: 18px 0;
  }
  .el-button {
    padding: 11px 15px;
  }

  &__table {
    width: 100%;
    text-align: center;
    border-collapse: collapse;
    border-radius: 4px;
    border-style: hidden;
    box-shadow: 0 0 0 1px gray(.1);
    tr {
      border: 1px solid gray(.1);
    }
    td {
      vertical-align: middle;
    }
    thead tr {
      line-height: 65px;
      background-color: #f3f3f3;
      font-size: 12px;
      font-weight: 700;
      color: gray(.6);
    }
    tbody {
      font-size: 14px;
      tr {
        line-height: 48px;
      }
      td[rowspan] {
        // border-right: 1px solid #000;
        position: relative;
        &:after {
          content: '';
          position: absolute;
          height: 100%;
          width: 1px;
          top: 0;
          right: 0;
          background: gray(.1)
        }
      }
    }
  }
}
</style>
