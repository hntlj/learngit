<template>
  <div class="pd24">
    <div class="home-card pd24 mh600">
      <div class="home-card__header line">
        <h2><back :title="title"></back></h2>
      </div>
      <div class="home-card__main" style="position: relative;">
        <super-form class="home-searchform" label-width="0px" :form-list="searchOptions" v-model="searchFormData"></super-form>
        <el-button type="primary" class="pull-right crowd-upload-btn" @click="showUploadDialog = true">上传应用渠道包</el-button>
        <el-table class="table-border" :data="dataList" :row-class-name="tableRowClassName">
          <el-table-column align="center" v-for="col in tableColumn" :key="col.prop"
            :prop="col.prop"
            :sortable="col.sortable"
            :label="col.label"
            :formatter="col.formatter">
          </el-table-column>
          <el-table-column width="300px" align="center" label="操作">
            <template slot-scope="scope">
              <el-button v-if="scope.row.status === 2" type="text" @click="onUpdate(scope.row)">修改</el-button>
              <el-button v-if="scope.row.status !== 3" type="text" :disabled="scope.row.status === 0" @click="onDelete(scope.row)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="home-card__footer">
        <el-pagination class="pull-right"
          v-if="dataListTotal > defaultPageSize"
          background
          :page-size="PAGE_SIZE"
          :page-sizes="PAGE_SIZES"
          :current-page="formData.pageNumber"
          :total="dataListTotal"
          @size-change="onSizeChange"
          @current-change="onPageChanged"
          layout="total, sizes, prev, pager, next, jumper">
        </el-pagination>
      </div>
      <div class="upload-tip">
          说明：为保障推广效果，平台建议上传最新版本
        </div>
    </div>
    <el-dialog title="上传应用渠道包" :visible.sync="showUploadDialog">
      <el-form label-width="150px" ref="form_update" :model="formData" :rules="rules">
        <el-form-item label="应用渠道包名称" prop="channelPackageName" key="channelPackageName">
          <el-input v-model="formData.channelPackageName"></el-input>
        </el-form-item>
        <el-form-item label="包名" prop="appPackageName" key="appPackageName">
          <el-input v-model="formData.appPackageName"></el-input>
        </el-form-item>
        <el-form-item label="上传文件">
          <el-upload
            class="avatar-uploader"
            ref="crowdUpload"
            action="/common/channel/package/upload"
            :on-change="handleChange"
            :on-remove="handleRemove"
            :on-success="uploadSubmitSucc"
            :on-error="uploadSubmitError"
            :file-list="filePathArr"
            :auto-upload="true">
            <el-button slot="trigger" size="small">选择文件</el-button>
          </el-upload>
        </el-form-item>
        <div class="upload-tip">
          说明：<br/>
          1、应用渠道包名称不能重复，否则无法区分<br/>
          2、为保障推广效果，平台建议上传最新应用版本<br/>
          3、文件格式： *.apk，文件大小2G以内<br/>
          4、文件上传过程中，请勿关闭页面窗口，否则会导致文件上传失败
        </div>
      </el-form>
      <div slot="footer">
        <el-button @click="showUploadDialog = false">取消</el-button>
        <el-button type="primary" @click="submitUpload" :disabled="uploading">上传</el-button>
      </div>
    </el-dialog>
    <el-dialog
      title="该应用渠道包已经关联以下广告单位，请解决关联后再次操作"
      :visible.sync="showRelationDialog"
      width="30%">
      <el-table class="table-border" :data="relationList" :row-class-name="tableRowClassName">
        <el-table-column align="center" v-for="col in relationtableColumn" :key="col.prop"
          :prop="col.prop"
          :sortable="col.sortable"
          :label="col.label"
          :formatter="col.formatter">
        </el-table-column>
      </el-table>
      <div slot="footer">
        <el-button type="primary" @click="showRelationDialog = false">确定</el-button>
      </div>
    </el-dialog>
    <el-dialog
      title="删除提示"
      :visible.sync="showDeleteDialog"
      width="30%">
      <span>确定删除 {{selectedCrowdName}}？</span>
      <span slot="footer" class="dialog-footer">
        <el-button @click="showDeleteDialog = false">取 消</el-button>
        <el-button type="primary" @click="deleteAppChannel">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import utils from '@/utils'
import { CHANNEL_STATUS, PAGE_SIZE, PAGE_SIZES } from '@/enums'
import { getAppChannelList, addChannelPackage, updateChannelPackage, deleteAppChannel } from '@/api'
import SuperForm from '@/components/SuperForm'
import Back from '@/components/home/toolkit/Back'
export default {
  data () {
    return {
      PAGE_SIZE,
      PAGE_SIZES,
      defaultPageSize: PAGE_SIZE,
      searchFormData: null,
      formData: {
        id: '',
        channelPackageName: '',
        appPackageName: '',
        filePath: ''
      },
      rules: {
        channelPackageName: [
          { required: true, message: '请输入应用渠道包名称', trigger: 'change' }
        ],
        appPackageName: [
          { required: true, message: '请输入包名', trigger: 'change' }
        ],
        filePath: [
          { required: true, message: '请上传文件', trigger: 'change' }
        ]
      },
      searchOptions: [
        { type: 'hidden', key: 'pageNumber', default: 1 },
        { type: 'hidden', key: 'pageSize', default: PAGE_SIZE },
        { type: 'text', key: 'channelPackageName', placeholder: '输入应用渠道包名称' },
        { type: 'text', key: 'appPackageName', placeholder: '输入应用包名' },
        { type: 'select', key: 'status', label: '状态', options: CHANNEL_STATUS }
      ],
      tableColumn: [
        { prop: 'id', label: '应用渠道包ID' },
        { prop: 'appChannelName', label: '应用渠道包名称' },
        { prop: 'appPackageName', label: '包名' },
        { prop: 'appChannelVersion', label: '渠道包版本号' },
        { prop: 'appMeizuVersion', label: '魅族官方包版本号' },
        { prop: 'status', label: '状态', formatter: row => CHANNEL_STATUS[row.status].name },
        { prop: 'remark', label: '备注' }
      ],
      relationtableColumn: [
        { prop: 'unitId', label: '单元ID' },
        { prop: 'unitName', label: '单元名称' }
      ],
      dataList: [],
      relationList: [],
      dataListTotal: 0,
      selectedCrowdName: '',
      selectedCrowdId: '',
      showUploadDialog: false,
      showDeleteDialog: false,
      hasUploadFile: false,
      showRelationDialog: false,
      uploading: false,
      title: '应用渠道包管理',
      filePathArr: []
    }
  },
  methods: {
    tableRowClassName ({row, rowIndex}) {
      if (!row.valid) {
        return 'gray-row'
      }
      return ''
    },
    onSizeChange (currSize) {
      this.searchFormData.pageSize = currSize
      this.fetchDataList()
    },
    onPageChanged (currPage) {
      this.searchFormData.pageNumber = currPage
      this.fetchDataList()
    },
    fetchDataList () {
      this.fetching = true
      getAppChannelList({
        ...this.searchFormData
      }).then(res => {
        if (res.code === 200) {
          this.dataList = res.value.data
          this.dataListTotal = res.value.total
        }
      }).finally(() => {
        this.fetching = false
      })
    },
    handleRemove (file) {
      this.hasUploadFile = false
      this.uploading = true
    },
    // 上传文件
    handleChange (file, fileList) {
      if (fileList.length === 0) {
        this.hasUploadFile = false
        return false
      }
      const isText = file.raw.type === 'application/vnd.android.package-archive'
      if (!isText) {
        this.$message.error('上传文件格式必须为.apk格式!')
      }
      if (!isText) {
        this.$refs.crowdUpload.clearFiles()
      } else {
        if (fileList.length > 1) {
          fileList.shift()
        }
      }
      this.hasUploadFile = isText
    },
    // 上传按钮
    addChannelPackage () {
      let postFunc = this.formData.id ? updateChannelPackage : addChannelPackage
      postFunc({
        ...this.formData
      }).then(res => {
        if (res.code === 200) {
          this.$message.success('上传成功!')
          this.showUploadDialog = false
          this.fetchDataList()
        }
      }).catch((err) => {
        this.$message.error(err.message)
      }).finally(() => {
      })
    },
    submitUpload () {
      this.$refs['form_update'].validate((valid) => {
        if (!this.hasUploadFile) {
          this.$message.error('请上传文件!')
        } else {
          if (valid) {
            this.addChannelPackage()
          }
        }
        this.showUploadDialog = true
      })
    },
    uploadSubmitSucc (res) {
      this.uploading = false
      if (res.code === 200) {
        this.formData.filePath = res.value[0].url
      } else {
        this.$message.error(res.message)
        this.$refs.crowdUpload.clearFiles()
        this.hasUploadFile = false
      }
    },
    uploadSubmitError (res) {
      this.uploading = false
    },
    // 修改
    onUpdate (row) {
      this.formData.channelPackageName = row.appChannelName
      this.formData.appPackageName = row.appPackageName
      this.formData.id = row.id
      this.formData.filePath = row.filePath
      this.filePathArr.push({name: row.filePath, url: row.filePath})
      this.hasUploadFile = true
      this.showUploadDialog = true
    },
    // 删除
    onDelete (row) {
      this.selectedCrowdName = row.appChannelName
      this.selectedCrowdId = row.id
      this.showDeleteDialog = true
    },
    deleteAppChannel () {
      deleteAppChannel({
        id: this.selectedCrowdId
      }).then(res => {
        if (res.code === 200) {
          this.fetchDataList()
          this.$message.success('删除成功')
          if (this.dataList.length === 1 && this.searchFormData.pageNumber > 1) {
            this.onPageChanged(--this.searchFormData.pageNumber)
          } else {
            this.fetchDataList()
          }
        }
      }).catch(error => {
        if (error.value.length > 0) {
          this.relationList = error.value
          this.showRelationDialog = true
        } else {
          this.$message.error(`删除错误[${error.message}]，请重试!`)
        }
      }).finally(() => {
        this.showDeleteDialog = false
      })
    }
  },
  watch: {
    searchFormData (val) {
      this.throttleFetchCrowdList()
    },
    showUploadDialog (val) {
      this.uploading = val && !this.formData.filePath
      if (!val) {
        this.$refs.crowdUpload.clearFiles()
        this.formData = {
          channelPackageName: '',
          appPackageName: '',
          id: '',
          filePath: ''
        }
        this.filePathArr = []
      }
    }
  },
  created () {
    this.throttleFetchCrowdList = utils.debounce(this.fetchDataList)
    this.fetchList = this.throttleFetchCrowdList
  },
  components: {
    SuperForm, Back
  }
}
</script>

<style lang="scss" scoped>
.home-card__main {
  .crowd-upload-btn {
    width: 160px;
    position: absolute;
    top: 0px;
    right: 0px;
  }
}
.gray, .gray-row {
  color: #c1c1c1;
}

.upload-tip {
  line-height:25px;
  background:#ebebeb;
  padding:10px 20px;
}
</style>
