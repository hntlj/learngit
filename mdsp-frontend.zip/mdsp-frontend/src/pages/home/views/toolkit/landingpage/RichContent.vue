<template>
  <div class="richcontent">
    <div class="richcontent-main">
      <transition-group name="list" tag="div">
        <!-- <div v-for="(item, idx) in content" :key="item.img || item.text" style="margin-bottom: 24px"> -->
        <div v-for="(item, idx) in content" :key="idx+'-'" style="margin-bottom: 24px">
          <a href="javascript:;" @click="onRemove(idx, $event)"><i class="el-icon-delete color-red"></i></a>
          <div v-if="typeof item.img !== 'undefined'">
            <image-upload v-if="template === 2" :width="1080" :height="460" v-model="item.img" @input="onChange" />
            <image-upload v-else :width="1080" :min-height="460" v-model="item.img" @input="onChange" />
            <el-form-item style="display: inline-block;vertical-align:top">
              <el-checkbox v-model="item.clickInstall">添加下载链接</el-checkbox>
              <div class="el-form-item__tip">添加下载链接后，点击图片可下载对应应用</div>
            </el-form-item>
          </div>
          <div v-if="typeof item.text !== 'undefined'">
            <el-form-item :class="{'is-error': isTextError(item.text)}">
              <el-input class="w640" type="textarea" :rows="3" v-model="item.text" placeholder="请输入宣传文案，10-100 字"></el-input>
              <div class="el-form-item__error" v-if="isTextError(item.text)">长度在 10-100 个字符</div>
            </el-form-item>
          </div>
        </div>
      </transition-group>
    </div>
    <div class="richcontent-footer">
      <el-button @click="onAddImg" v-if="imgs < limitImg">添加宣传图片（{{ limitImg - imgs}}）</el-button>
      <el-button @click="onAddText" v-if="texts < limitText">添加宣传文案（{{ limitText - texts}}）</el-button>
    </div>
  </div>
</template>
<script>
import ImageUpload from '@/components/home/ImageUpload'
export default {
  props: {
    value: Array,
    limitImg: Number,
    limitText: Number,
    template: Number
  },
  data () {
    return {
      content: this.value
    }
  },
  computed: {
    imgs () {
      return this.content.filter(({img}) => typeof img !== 'undefined').length
    },
    texts () {
      return this.content.filter(({text}) => typeof text !== 'undefined').length
    }
  },
  methods: {
    onChange () {
      this.$emit('input', this.content)
    },
    onRemove (idx) {
      this.content.splice(idx, 1)
    },
    onAddImg () {
      this.content.push({
        img: '',
        clickInstall: false
      })
    },
    onAddText () {
      this.content.push({
        text: ''
      })
    },
    isTextError (text) {
      const result = text.length < 10 || text.length > 100
      this.$emit('valid', result)
      return result
    }
  },
  watch: {
    value: {
      handler: function (value) {
        this.content = value
      },
      deep: true
    },
    content: {
      handler: function (value) {
        this.$emit('input', this.content)
      },
      deep: true
    }
  },
  components: {
    ImageUpload
  }
}
</script>

<style lang="scss">
.list-enter-active, .list-leave-active {
  transition: all .2s;
}

.list-enter, .list-leave-to {
  opacity: 0;
  transform: translateX(30px);
}
</style>
