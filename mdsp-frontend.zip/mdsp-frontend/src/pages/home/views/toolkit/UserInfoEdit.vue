<template>
  <div class="pd24">
    <div class="home-card pd24">
      <div class="home-card__header">
        <h2><i class="el-icon-arrow-left" @click="toBack" style="cursor:pointer;"></i> {{ title }}</h2>&nbsp;&nbsp;&nbsp;&nbsp;
        <h2 v-if="userProfile.status == 2" style="color: #ccc;">拒绝原因:（<h2 style="color: red;">{{ userProfile.remark }}</h2>）</h2>
      </div>
      <div class="home-card__main home-userinfo-edit">
        <template v-if="userProfile">
          <el-popover ref="popover1" placement="bottom" trigger="hover">
            <div class="example">
              <img src="~assets/img/userinfo/license.jpg" alt="">
            </div>
          </el-popover>
          <el-popover ref="popover2" placement="bottom" trigger="hover">
            <div class="example">
              <img src="~assets/img/userinfo/id1.png" alt="">
            </div>
          </el-popover>
          <el-popover ref="popover3" placement="bottom" trigger="hover">
            <div class="example">
              <img src="~assets/img/userinfo/icp.png" alt="">
            </div>
          </el-popover>
          <el-popover ref="popover5" placement="bottom" trigger="hover">
            <div class="example">
              <img src="~assets/img/userinfo/id2.png" alt="">
            </div>
          </el-popover>
          <el-popover ref="popover4" placement="bottom" trigger="hover">
            <div class="example">
              <img src="~assets/img/userinfo/tax_file.png" alt="">
            </div>
          </el-popover>
          <div class="mt24" v-if="identityType === 0">
            <el-form label-position="left" label-width="150px" ref="form_1" :rules="rules" :model="formData">
              <div class="form-title bold">企业信息</div>
              <div class="form-classify">
                <el-form-item label="Flyme账号" v-if="isAgent" prop="flyme" :rules="{required: true, message: '请填写Flyme账号', trigger: 'change'}" style="width: 100%;">
                  <el-input class="w540" v-model="formData.flyme" :disabled="isUpdate" :maxlength="60"></el-input>
                </el-form-item>
                <el-form-item label="公司名称" prop="name">
                  <el-input class="w540" v-model="formData.name" :maxlength="60"></el-input>
                </el-form-item>
                <el-form-item label="公司行业" prop="tierOneIndustry">
                  <el-select clearable v-model="formData.tierOneIndustry" placeholder="请选择公司行业">
                    <el-option v-for="c in companyCertList" :key="c.cert1_id" :label="c.cert_name" :value="c.cert1_id"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="公司地址" prop="address">
                  <el-input class="w540" v-model="formData.address" :maxlength="125" />
                </el-form-item>
                <el-form-item label="主要产品" prop="mainProduct">
                  <el-input class="w540" v-model="formData.mainProduct" :maxlength="125" />
                </el-form-item>
                <el-form-item label="联系人" prop="contact">
                  <el-input class="w540" v-model="formData.contact" :maxlength="25" />
                </el-form-item>
                <el-form-item label="联系电话" prop="phone">
                  <el-input class="w540" v-model="formData.phone" :maxlength="25" />
                </el-form-item>
                <el-form-item label="联系邮箱" prop="email">
                  <el-input class="w540" v-model="formData.email" :maxlength="125"/>
                </el-form-item>
              </div>
              <div class="form-title bold">主体资质</div>
              <div class="form-classify">
                <el-form-item label="主体资质类型" prop="entityQualifiType">
                  <el-select v-model="formData.entityQualifiType" placeholder="请选择公司行业">
                    <el-option v-for="f in entityQualifiTypeList" :key="f.fid" :label="f.fname" :value="f.fvalue"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="主体资质编码" prop="license">
                  <el-input class="w540" v-model="formData.license" :maxlength="30"></el-input>
                </el-form-item>
                <el-form-item label="注册日期" prop="registerDate">
                  <el-date-picker
                    v-model="formData.registerDate"
                    type="date"
                    value-format="yyyy-MM-dd"
                    placeholder="选择日期">
                  </el-date-picker>
                </el-form-item>
                <el-form-item label="法人姓名" prop="corporate">
                  <el-input class="w540" v-model="formData.corporate" :maxlength="25"></el-input>
                </el-form-item>
                <el-form-item label="主体资质图片" prop="licenseFile">
                  <el-upload drag action="/common/upload" :show-file-list="false" style="display: inline-block;margin-right: 20px"
                    :on-error="onUploadError"
                    :on-success="onUploadSuccess('licenseFile')"
                    :before-upload="onUploadBefore">
                    <div v-if="formData.licenseFile" class="el-upload__preview">
                      <img :src="formData.licenseFile">
                      <span @click.stop="onRemoveImg('licenseFile', $event)"><i class="el-icon-close"></i></span>
                    </div>
                    <div class="el-upload__placeholder" v-else>
                      <i class="el-icon-uploader"></i>
                      <div class="el-upload__text"><em>点击上传图片</em></div>
                    </div>
                  </el-upload>
                  <div class="el-form-item__tip">请上传营业执照 <a href="javascript:;" v-popover:popover1>查看示例</a></div>
                </el-form-item>
                <el-form-item label="法人身份证">
                  <el-upload drag action="/common/upload" :show-file-list="false" style="display: inline-block;margin-right: 20px"
                    :on-error="onUploadError"
                    :on-success="onUploadSuccess('corporateCertFile')"
                    :before-upload="onUploadBefore">
                    <div v-if="formData.corporateCertFile" class="el-upload__preview">
                      <img :src="formData.corporateCertFile">
                      <span @click.stop="onRemoveImg('corporateCertFile', $event)"><i class="el-icon-close"></i></span>
                    </div>
                    <div class="el-upload__placeholder" v-else>
                      <i class="el-icon-uploader"></i>
                      <div class="el-upload__text"><em>点击上传图片</em></div>
                    </div>
                  </el-upload>
                  <div class="el-form-item__tip">请上传身份证正面照片 <a href="javascript:;" v-popover:popover2popover2>查看示例</a></div>
                </el-form-item>
              </div>
              <div class="form-title">
                <div><span class="bold">补充资质</span><span>如果是网址/特殊行业建议上传相关资质，以提升开户及推广效率。</span></div>
                <a class="fold-opr" @click="isFold=!isFold">{{`点击${isFold ?'展开' : '收起' }`}} <i :class="isFold ? 'el-icon-arrow-down' : 'el-icon-arrow-up'"></i></a>
              </div>
              <div class="form-classify" :class="isFold ? 'form-fold' : 'form-unfold'">
                <div class="websitForm" v-for="(website, idx) in formData.websiteInfo" :key="idx" style="padding:10px 0;overflow: hidden;">
                  <el-form-item required style="width: 100%;float: none;">
                    <el-form-item :prop="`websiteInfo[${idx}].fwebsiteUrl`" label="推广网址" :rules="{required: true, message: '请填写网址'}">
                      <el-input class="w540" v-model="website.fwebsiteUrl"></el-input>
                    </el-form-item>
                    <el-form-item :prop="`websiteInfo[${idx}].ficpNumber`" label="ICP备案号" :rules="{required: true, message: '请填写ICP备案号'}">
                      <el-input class="w540" v-model="website.ficpNumber"></el-input>
                    </el-form-item>
                    <el-form-item :prop="`websiteInfo[${idx}].ficpFile`" label="ICP备案" required :rules="{validator: onValidCertFile(idx, 'ICP备案')}">
                      <el-upload drag action="/common/upload" :show-file-list="false" style="display: inline-block;margin-right: 20px"
                        :on-error="onUploadError"
                        :on-success="onUploadSuccess('icpFile', idx)"
                        :before-upload="onUploadBefore">
                        <div v-if="website.ficpFile" class="el-upload__preview">
                          <img :src="website.ficpFile">
                        </div>
                        <div class="el-upload__placeholder" v-else>
                          <i class="el-icon-uploader"></i>
                          <div class="el-upload__text"><em>点击上传图片</em></div>
                        </div>
                      </el-upload>
                      <!-- <div class="el-form-item__tip">请上传 IPC 备案图片 <a href="javascript:;" v-popover:popover3>查看示例</a></div> -->
                    </el-form-item>
                    <el-button type="danger" plain @click="onRemoveWebsite(idx, $event)"><i class="el-icon-delete"></i> 移除该网址</el-button>
                  </el-form-item>
                </div>
                <el-button class="normal" style="margin-left: 150px" @click="onAddWebsite">添加网址</el-button>
              </div>
            </el-form>
            <el-form label-position="left" label-width="150px" ref="form_2" :rules="rules" :model="formData" :class="isFold ? 'form-hide' : ''">
              <div class="form-title bold">行业资质</div>
              <div class="certForm" v-for="(cert, idx) in formData.certificates" :key="idx">
                <el-form-item label="行业" required>
                  <el-form-item :prop="`certificates[${idx}].cert1Id`" :rules="{required: true, message: '请选择一级行业'}">
                    <el-select v-model="cert.cert1Id" placeholder="请选择一级行业" @change="onCert1IdChanged(idx, $event)">
                      <el-option v-for="c in certList1" :disabled="c.isEnable===0" :key="c.id" :label="c.name" :value="c.id"></el-option>
                    </el-select>
                  </el-form-item>
                  <el-form-item :prop="`certificates[${idx}].cert2Id`" :rules="{required: true, message: '请选择二级行业'}">
                    <el-select v-model="cert.cert2Id" placeholder="请选择二级行业">
                      <el-option v-for="c in getCertByCert1Id(formData.certificates[idx].cert1Id)" :disabled="c.isEnable===0" :key="c.id" :label="c.name" :value="c.id"></el-option>
                    </el-select>
                  </el-form-item>
                  <el-button type="danger" plain @click="onRemoveCert(idx, $event)"><i class="el-icon-delete"></i> 移除该行业</el-button>
                </el-form-item>
                <el-form-item>
                  <div class="certDesc" v-html="getCertDescByCert2Id(idx)"></div>
                </el-form-item>
                <el-form-item label="行业资质照片" :prop="`certificates[${idx}].certFile`" required :rules="{validator: onValidCertFile(idx, '行业资质')}">
                  <div class="imgList">
                    <div class="imgItem" v-for="(img, index) in cert.certFile" :key="img">
                      <img :src="img" />
                      <span @click.stop="onRemoveImg('certFile', idx, index, $event)"><i class="el-icon-close"></i></span>
                    </div>
                  </div>
                  <el-upload drag action="/common/upload" :show-file-list="false" style="display: inline-block;margin-right: 20px"
                    :on-error="onUploadError"
                    :on-success="onUploadSuccess('certFile', idx)"
                    :before-upload="onUploadBefore">
                    <div class="el-upload__placeholder">
                      <i class="el-icon-uploader"></i>
                      <div class="el-upload__text"><em>点击上传图片</em></div>
                    </div>
                  </el-upload>
                </el-form-item>
              </div>
              <el-button class="normal" style="margin-left: 150px" @click="onAddCert">添加行业</el-button>
            </el-form>
            <el-form label-position="left" label-width="150px" ref="form_3" :rules="rules" :model="formData">
              <el-form-item style="text-align:center;">
                <el-checkbox v-model="check">我已阅读并接受 <a href="/views/agreement.html" target="_blank">《魅族广告投放平台合作协议》</a></el-checkbox>
              </el-form-item>
            </el-form>
          </div>
          <div class="mt24" v-if="identityType === 1">
            <el-form label-position="left" label-width="150px" ref="form_1" :rules="rules" :model="formData">
              <div class="form-title bold">主体资质</div>
              <div class="person-flex">
                <div>
                  <el-form-item label="Flyme账号" v-if="isAgent" prop="flyme" :rules="{required: true, message: '请填写Flyme账号', trigger: 'change'}" style="width: 100%;">
                    <el-input class="w540" v-model="formData.flyme" :disabled="isUpdate" :maxlength="60"></el-input>
                  </el-form-item>
                  <el-form-item label="个人姓名" prop="name">
                    <el-input class="w540" v-model="formData.name" :maxlength="60"></el-input>
                  </el-form-item>
                  <el-form-item label="证件号码" prop="identityNumber">
                    <el-input class="w540" v-model="formData.identityNumber" :maxlength="25" />
                  </el-form-item>
                  <el-form-item label="证件有效期" prop="registerDate">
                    <el-date-picker
                      v-model="formData.registerDate"
                      type="date"
                      value-format="yyyy-MM-dd"
                      placeholder="选择日期">
                    </el-date-picker>
                  </el-form-item>
                  <el-form-item label="联系邮箱" prop="email">
                    <el-input class="w540" v-model="formData.email" :maxlength="125"/>
                  </el-form-item>
                  <el-form-item label="联系电话" prop="phone">
                    <el-input class="w540" v-model="formData.phone" :maxlength="25" />
                  </el-form-item>
                </div>

                <div>
                  <el-form-item label="身份证反面照片" prop="identityFrontUrl">
                    <el-upload drag action="/common/upload" :show-file-list="false" style="display: inline-block;margin-right: 20px"
                      :on-error="onUploadError"
                      :on-success="onUploadSuccess('identityFrontUrl')"
                      :before-upload="onUploadBefore">
                      <div v-if="formData.identityFrontUrl" class="el-upload__preview">
                        <img :src="formData.identityFrontUrl">
                        <span @click.stop="onRemoveImg('identityFrontUrl', $event)"><i class="el-icon-close"></i></span>
                      </div>
                      <div class="el-upload__placeholder" v-else>
                        <i class="el-icon-uploader"></i>
                        <div class="el-upload__text"><em>点击上传图片</em></div>
                      </div>
                    </el-upload>
                    <div class="el-form-item__tip">请上传身份证反面照片 <a href="javascript:;" v-popover:popover5>查看示例</a></div>
                  </el-form-item>

                  <el-form-item label="身份证正面照片" prop="identityBackUrl">
                    <el-upload drag action="/common/upload" :show-file-list="false" style="display: inline-block;margin-right: 20px"
                      :on-error="onUploadError"
                      :on-success="onUploadSuccess('identityBackUrl')"
                      :before-upload="onUploadBefore">
                      <div v-if="formData.identityBackUrl" class="el-upload__preview">
                        <img :src="formData.identityBackUrl">
                        <span @click.stop="onRemoveImg('identityBackUrl', $event)"><i class="el-icon-close"></i></span>
                      </div>
                      <div class="el-upload__placeholder" v-else>
                        <i class="el-icon-uploader"></i>
                        <div class="el-upload__text"><em>点击上传图片</em></div>
                      </div>
                    </el-upload>
                    <div class="el-form-item__tip">请上传身份证正面照片 <a href="javascript:;" v-popover:popover2>查看示例</a></div>
                  </el-form-item>
                </div>
              </div>
              <div class="form-title">
                <div><span class="bold">补充资质</span><span>如果是网址/特殊行业建议上传相关资质，以提升开户及推广效率。</span></div>
                <a class="fold-opr" @click="isFold=!isFold">{{`点击${isFold ?'展开' : '收起' }`}} <i :class="isFold ? 'el-icon-arrow-down' : 'el-icon-arrow-up'"></i></a>
              </div>
              <div class="form-classify" :class="isFold ? 'form-fold' : 'form-unfold'">
                <div class="websitForm" v-for="(website, idx) in formData.websiteInfo" :key="idx" style="padding:10px 0;overflow: hidden;">
                  <el-form-item required style="width: 100%;float: none;">
                    <el-form-item :prop="`websiteInfo[${idx}].fwebsiteUrl`" label="推广网址" :rules="{required: true, message: '请填写网址'}">
                      <el-input class="w540" v-model="website.fwebsiteUrl"></el-input>
                    </el-form-item>
                    <el-form-item :prop="`websiteInfo[${idx}].ficpNumber`" label="ICP备案号" :rules="{required: true, message: '请填写ICP备案号'}">
                      <el-input class="w540" v-model="website.ficpNumber"></el-input>
                    </el-form-item>
                    <el-form-item :prop="`websiteInfo[${idx}].ficpFile`" label="ICP备案" required :rules="{validator: onValidCertFile(idx, 'ICP备案')}">
                      <el-upload drag action="/common/upload" :show-file-list="false" style="display: inline-block;margin-right: 20px"
                        :on-error="onUploadError"
                        :on-success="onUploadSuccess('icpFile', idx)"
                        :before-upload="onUploadBefore">
                        <div v-if="website.ficpFile" class="el-upload__preview">
                          <img :src="website.ficpFile">
                        </div>
                        <div class="el-upload__placeholder" v-else>
                          <i class="el-icon-uploader"></i>
                          <div class="el-upload__text"><em>点击上传图片</em></div>
                        </div>
                      </el-upload>
                      <!-- <div class="el-form-item__tip">请上传 IPC 备案图片 <a href="javascript:;" v-popover:popover3>查看示例</a></div> -->
                    </el-form-item>
                    <el-button type="danger" plain @click="onRemoveWebsite(idx, $event)"><i class="el-icon-delete"></i> 移除该网址</el-button>
                  </el-form-item>
                </div>
                <el-button class="normal" style="margin-left: 150px" @click="onAddWebsite">添加网址</el-button>
              </div>
            </el-form>
            <el-form label-position="left" label-width="150px" ref="form_2" :rules="rules" :model="formData" :class="isFold ? 'form-hide' : ''">
              <div class="form-title bold">行业资质</div>
              <div class="certForm" v-for="(cert, idx) in formData.certificates" :key="idx">
                <el-form-item label="行业" required>
                  <el-form-item :prop="`certificates[${idx}].cert1Id`" :rules="{required: true, message: '请选择一级行业'}">
                    <el-select v-model="cert.cert1Id" placeholder="请选择一级行业" @change="onCert1IdChanged(idx, $event)">
                      <el-option v-for="c in certList1" :disabled="c.isEnable===0" :key="c.id" :label="c.name" :value="c.id"></el-option>
                    </el-select>
                  </el-form-item>
                  <el-form-item :prop="`certificates[${idx}].cert2Id`" :rules="{required: true, message: '请选择二级行业'}">
                    <el-select v-model="cert.cert2Id" placeholder="请选择二级行业">
                      <el-option v-for="c in getCertByCert1Id(formData.certificates[idx].cert1Id)" :disabled="c.isEnable===0" :key="c.id" :label="c.name" :value="c.id"></el-option>
                    </el-select>
                  </el-form-item>
                  <el-button type="danger" plain @click="onRemoveCert(idx, $event)"><i class="el-icon-delete"></i> 移除该行业</el-button>
                </el-form-item>
                <el-form-item>
                  <div class="certDesc" v-html="getCertDescByCert2Id(idx)"></div>
                </el-form-item>
                <el-form-item label="行业资质照片" :prop="`certificates[${idx}].certFile`" required :rules="{validator: onValidCertFile(idx, '行业资质')}">
                  <div class="imgList">
                    <div class="imgItem" v-for="(img, index) in cert.certFile" :key="img">
                      <img :src="img" />
                      <span @click.stop="onRemoveImg('certFile', idx, index, $event)"><i class="el-icon-close"></i></span>
                    </div>
                  </div>
                  <el-upload drag action="/common/upload" :show-file-list="false" style="display: inline-block;margin-right: 20px"
                    :on-error="onUploadError"
                    :on-success="onUploadSuccess('certFile', idx)"
                    :before-upload="onUploadBefore">
                    <div class="el-upload__placeholder">
                      <i class="el-icon-uploader"></i>
                      <div class="el-upload__text"><em>点击上传图片</em></div>
                    </div>
                  </el-upload>
                </el-form-item>
              </div>
              <el-button class="normal" style="margin-left: 150px" @click="onAddCert">添加行业</el-button>
            </el-form>
            <el-form label-position="left" label-width="150px" ref="form_3" :rules="rules" :model="formData">
              <el-form-item style="text-align:center;">
                <el-checkbox v-model="check">我已阅读并接受 <a href="/views/agreement.html" target="_blank">《魅族广告投放平台合作协议》</a></el-checkbox>
              </el-form-item>
            </el-form>
          </div>
        </template>
      </div>
      <div class="home-card__footer mt24" style="text-align:center;">
        <el-button class="w160" @click="toBack" v-if="isAgent">取消</el-button>
        <el-button type="primary" class="w160" @click="submit" :disabled="!check">完成并提交</el-button>
      </div>
      <el-dialog
        title="提示"
        :visible.sync="tipDialogVisible"
        width="30%"
        center>
        <p class="tip-content">
          已提交成功，账户信息正在审核中！<br/>
          如无特殊情况，我们将在24小时内反馈审核结果，您可前往帮助中心，了解更多投放相关内容。
        </p>
        <span slot="footer" class="dialog-footer">
          <!-- @click="tipDialogVisible = false"  -->
          <el-button  @click="toUserInfo">暂 不</el-button>
          <el-button type="primary" @click="toHelp">前往帮助中心</el-button>
        </span>
      </el-dialog>
    </div>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import { USER_STATUS } from '@/enums'
import { postUserProfile, getCertCategoryList, getNameAndValue } from '@/api'
import { companyNameValidator, phoneValidator, identityValidator } from '@/validators/user'
import validateMixin from '@/mixins/validate'
let MESSAGE_OBJ = {
  name: '请输入企业名称',
  registerDate: '请选择注册日期'
}
export default {
  mixins: [validateMixin],
  data () {
    return {
      stepList: ['广告主信息', '行业资质', '联系人信息'],
      formData: {},
      messageObj: {
        name: '请输入企业名称',
        registerDate: '请选择注册日期'
      },
      rules: {
        name: [
          { required: true, message: MESSAGE_OBJ.name, trigger: 'change' },
          { validator: companyNameValidator.bind(this, '企业名称'), trigger: 'change' }
        ],
        license: [
          { required: true, message: '请输入营业执照代码', trigger: 'change' },
          { max: 30, message: '营业执照代码最多30个字', trigger: 'change' }
        ],
        licenseFile: [{ required: true, message: '请上传营业执照', trigger: 'change' }],
        corporate: [{ required: true, max: 25, message: '法人代表最多25个字', trigger: 'change' }],
        taxNo: [{ max: 25, message: '税务登记证书编号最多25个字', trigger: 'change' }],
        siteUrl: [{ type: 'url', message: '网站地址格式不正确', trigger: 'blur' }],
        contact: [{ required: true, message: '请输入业务联系人', trigger: 'change' }],
        phone: [
          { required: true, message: '请输入联系电话', trigger: 'change' },
          { validator: phoneValidator.bind(this, '联系电话'), trigger: 'change' }
        ],
        email: [
          { required: true, message: '请输入联系邮箱', trigger: 'change' },
          { type: 'email', message: '邮箱格式不正确', trigger: 'blur' }
        ],
        address: [{ required: true, message: '请输入联系地址', trigger: 'change' }],
        entityQualifiType: [{ required: true, message: '请选择公司行业', trigger: 'change' }],
        registerDate: [{ required: true, message: MESSAGE_OBJ.registerDate, trigger: 'change' }],

        identityNumber: [
          { required: true, message: '请输入证件号码', trigger: 'change' },
          { validator: identityValidator.bind(this, '身份证件'), trigger: 'change' }
        ],
        identityFrontUrl: [{ required: true, message: '请上传身份证反面照片', trigger: 'change' }],
        identityBackUrl: [{ required: true, message: '请上传身份证正面照片', trigger: 'change' }]
      },
      check: false,
      tipDialogVisible: false,
      isFold: true,
      companyCertList: [],
      entityQualifiTypeList: [],
      isAgent: false,
      agentSponsorId: '',
      // type: this.$route.query.type,
      identityType: this.$route.query.type
    }
  },
  computed: {
    ...mapGetters(['userInfo', 'userProfile', 'certCategory', 'certList1', 'certList2']),
    title () {
      if (this.userInfo.status === USER_STATUS.NONE || this.isAgent) {
        const title = document.title.split(' - ')
        title[0] = '广告主资质认证'
        document.title = title.join(' - ')
        return '广告主资质认证'
      } else {
        return '修改用户信息'
      }
    },
    isUpdate () {
      let isUpdate = this.userInfo.status !== USER_STATUS.NONE
      if (this.isAgent) {
        isUpdate = Number(this.agentSponsorId) !== -1
      }
      return isUpdate
    }
  },
  methods: {
    onValidCertFile (idx, type) {
      return (rule, value, callback) => {
        if (value.length === 0) {
          return callback(new Error(`请上传${type}照片`))
        }
        callback()
      }
    },
    onNext () {
      this.validate(this.activeStep).then(isValid => {
        this.submit().then(() => {
          this.formData = this._syncForm()
          this.$router.push('/toolkit/UserInfo')
        }).catch(error => {
          this.$message.error(error.message)
        })
      }).catch(() => {
        this.$nextTick(() => {
          this.$scrollTo('.el-form-item__error', 500, {offset: -200})
        })
      })
    },
    onUploadError (key) {
      this.$message.error('图片上传失败')
    },
    onUploadSuccess (key, idx) {
      return (res, file) => {
        if (res.code === 200 && res.value.length > 0) {
          const url = '/upload/' + res.value[0].url
          if (key === 'certFile') {
            this.formData.certificates[idx].certFile.push(url)
            this.$refs.form_2.validateField(`certificates[${idx}].certFile`)
          } else if (key === 'icpFile') {
            this.formData.websiteInfo[idx].ficpFile = url
            this.$refs.form_1.validateField(`websiteInfo[${idx}].ficpFile`)
          } else {
            this.formData[key] = url
            this.$refs.form_1.validateField(key)
          }
          this.$forceUpdate()
        } else {
          this.onUploadError()
        }
      }
    },
    onUploadBefore (file) {
      const UPLOAD_LIMIT = 300
      const image = new Image()
      const isAllow = ['image/jpeg', 'image/png'].indexOf(file.type) > -1
      const isLtLimit = file.size / 1024 <= UPLOAD_LIMIT
      return new Promise((resolve, reject) => {
        image.src = URL.createObjectURL(file)
        image.onload = () => {
          let msg = ''
          if (!isAllow) {
            msg = '图片只能是 jpg,png 格式!'
            reject(new Error(msg))
          } else if (!isLtLimit) {
            msg = `图片大小不能超过 ${UPLOAD_LIMIT}KB!`
            reject(new Error(msg))
          } else {
            resolve()
          }
          if (msg) {
            this.$message.error(msg)
          }
        }
      })
    },
    onRemoveImg (key, idx, index) {
      if (key === 'certFile') {
        this.formData.certificates[idx].certFile.splice(index, 1)
      } else {
        this.formData[key] = ''
      }
    },
    onCert1IdChanged (idx) {
      this.formData.certificates[idx].cert2Id = ''
    },
    onAddCert () {
      this.formData = {
        ...this.formData,
        certificates: this.formData.certificates.concat({
          cert1Id: '',
          cert2Id: '',
          certFile: []
        })
      }
      this.$forceUpdate()
    },
    onAddWebsite () {
      this.formData = {
        ...this.formData,
        websiteInfo: this.formData.websiteInfo.concat({
          fwebsiteUrl: '',
          ficpNumber: '',
          ficpFile: ''
        })
      }
      this.$forceUpdate()
    },
    onRemoveCert (idx) {
      this.formData.certificates.splice(idx, 1)
      this.$forceUpdate()
    },
    onRemoveWebsite (idx) {
      this.formData.websiteInfo.splice(idx, 1)
      this.$forceUpdate()
    },
    async submit () {
      const valid = await this.validate()
      if (valid) {
        let isUpdate = this.isUpdate
        let params = {
          ...this._formatForm(),
          addType: this.isAgent ? 1 : 0 // addType  添加类型 0：官网，1：代理后台，2：运营后台
        }
        if (this.isAgent) {
          params = { ...params, belongAgent: this.userInfo.uid, uid: this.userProfile.uid }
        } else {
          params = { ...params, uid: this.userInfo.uid }
        }
        postUserProfile(params, isUpdate, this.identityType).then(res => {
          if (res.code === 200) {
            if (!this.isAgent) {
              if (!isUpdate || this.userProfile.status === 2) {
                this.tipDialogVisible = true
              } else if (this.userProfile.status === 1) {
                this.$message.success('提交审核成功')
                this.$store.dispatch('getUserInfo', true)
                this.$store.commit('setUserProfile', res.value)
                this.$router.push('/toolkit/UserInfo')
              }
              this.$store.dispatch('getUserInfo', true)
              this.$store.commit('setUserProfile', res.value)
            } else {
              this.$message.success('提交审核成功')
              this.$router.go(-1)
            }
          }
        }).catch(error => {
          this.$message.error(error.message)
        })
      }
    },
    getCertByCert1Id (cert1Id) {
      return this.certList2.filter(c => c.parentId === cert1Id)
    },
    getCertDescByCert2Id (idx) {
      const cert2Id = this.formData.certificates[idx].cert2Id
      if (cert2Id && this.certCategory.cert2[cert2Id]) {
        return this.certCategory.cert2[cert2Id].desc.replace(/\n/g, '<br />')
      }
      return ''
    },
    _formatForm () {
      let certificates = []
      this.formData.certificates.forEach(({cert1Id, cert2Id, certFile}) => {
        certFile.forEach(file => {
          certificates.push({cert1Id, cert2Id, certFile: file})
        })
      })
      if (this.identityType === 1) {
        this.formData.identityType = 1
        // this.formData.type = this.type
        this.formData.identityFile = [this.formData.identityBackUrl, this.formData.identityFrontUrl].filter(d => d).join(',')
      }
      return {
        ...this.formData,
        certificates: JSON.stringify(certificates),
        websiteInfo: JSON.stringify(this.formData.websiteInfo)
      }
    },
    _syncForm () {
      let { flyme, type, name, license, licenseFile, corporate, corporateCert, corporateCertFile,
        icpFile, taxNo, taxFile, siteName, siteUrl, certificates,
        contact, phone, email, address, tierOneIndustry,
        mainProduct, entityQualifiType, registerDate, websiteInfo, identityFile, identityNumber, identityTypeId, identityBackUrl, identityFrontUrl, identityType } = this.userProfile
      if (!type) type = 'COM'
      // if (!this.type) this.type = type
      if (!identityType) identityType = 0
      this.identityType = this.identityType ? this.identityType : identityType
      this.formData = { flyme, type, name, license, licenseFile, corporate, corporateCert, corporateCertFile, icpFile, taxNo, taxFile, siteName, siteUrl, contact, phone, email, address, tierOneIndustry, mainProduct, entityQualifiType, registerDate, websiteInfo, identityFile, identityNumber, identityTypeId, identityBackUrl, identityFrontUrl, identityType }
      this.formData.certificates = [...certificates]
      if (this.identityType === 1) {
        this.formData.identityBackUrl = this.formData.identityFile ? this.formData.identityFile.split(',')[0] : ''
        this.formData.identityFrontUrl = this.formData.identityFile ? this.formData.identityFile.split(',')[1] : ''
      }
    },
    _valid () {
      if (this.identityType === 1) {
        // 验证提示信息修改
        MESSAGE_OBJ = {
          name: '请输入个人姓名',
          registerDate: '请选择证件有效期'
        }
      }
    },
    toHelp () {
      this.$router.push({name: 'Help'})
    },
    toUserInfo () {
      this.$router.push({name: 'UserInfo'})
    },
    toBack () {
      this.$router.go(-1)
    },
    getCompanyCertList () {
      getCertCategoryList(1).then(res => {
        this.companyCertList = res
      })
    },
    getNameAndValueList () {
      // type 查询类型 （0，主体资质类型；1，商务部门；2，所属主体）
      getNameAndValue(0).then(res => {
        this.entityQualifiTypeList = res.value
      })
    }
  },
  watch: {
    userProfile: '_syncForm',
    type: '_valid'
  },
  created () {
    this.getCompanyCertList()
    this.getNameAndValueList()
    const current = this.$router.history.current
    if (current.meta && current.meta.agent) {
      this.isAgent = true
    }
    this.agentSponsorId = this.isAgent ? current.params.agent_sponsor_id : ''
    this.identityType = this.isAgent ? current.params.type : this.$route.query.type ? this.$route.query.type : ''
    this.$store.dispatch('getCertList')
    this.$store.dispatch('getUserInfoProfile', this.agentSponsorId)
    if (this.userProfile) {
      this._syncForm()
    }
    this._valid()
  }
}
</script>
<style lang="scss" scoped>
.home-userinfo-edit {
  .el-form-item__content img {
    width: 210px;
    height: 140px
  }
  .el-upload-dragger {
    min-width: 210px;
    min-height: 140px;
  }
}
.home-step {
  display: inline-block;
  height: 10px;
  border-bottom: 4px solid #e6e6e6;
  margin: 24px 0 34px;
  &__progress {
    float: left;
    margin-top: -14px;
    width: 0%;
    height: 4px;
    background-color: $blue;
  }
  &-item {
    display: inline-block;
    background: #fff;
    padding: 0 24px;
    &+.home-step-item {
      margin-left: 240px;
    }
    &.active {
      .home-step-item__title {
        color: $blue;
      }
      .stepno {
        background-color: $blue;
        color: #fff;
      }
    }
    &__title {
      font-size: 14px;
      line-height: 24px;
      color: gray(.4);

      .stepno {
        display: inline-block;
        margin-right: 6px;
        background-color: #e6e6e6;
        width: 24px;
        height: 24px;
        line-height: 24px;
        text-align: center;
        border-radius: 50%;
      }
    }
  }
}
.el-form {
  .form-title {
    font-size: 14px;
    margin-bottom: 20px;
    line-height: 40px;
    border-bottom: 1px solid gray(.1);
    display: flex;
    justify-content: space-between;
  }
  .person-flex{
    display: flex;
    justify-content: space-between;
    padding-right: 29%;
  }
  .bold {
    font-size: 18px;
    font-weight: bold;
    padding-right: 20px;
  }
  .fold-opr {
    cursor: pointer;
  }
  .form-classify {
    padding: 20px 0;
    overflow: hidden;
    .el-form-item {
      width: 50%;
      float: left;
    }
    .el-form-item .el-form-item {
      display: inline-block;
      margin: 20px 0;
    }
  }
  .form-fold {
    height: 0;
    overflow: hidden;
    padding: 0;
  }
}
.form-hide {
  height: 0;
  overflow: hidden;
}
.websitForm {
  .el-form-item__content {
    margin-left: 0 !important;
    .el-form-item__error {
      padding-left: 150px;
    }
  }
}
.certForm {
  margin-bottom: 24px;
  &:after {
    content: '';
    display: block;
    margin-top: 24px;
    margin-left: 150px;
    border-bottom: 1px solid gray(.1);
  }
  .el-form-item .el-form-item {
    display: inline-block;
    margin-right: 10px;
  }
}
.imgList {
  float: left;
  max-width: 100%;
}
.imgItem {
  position: relative;
  margin: 5px;
  float: left;
  background-clip: padding-box;
  border-right: 10px solid transparent;
  width: 210px;
  height: 140px;
  text-align: center;
  img {
    display: inline-block;
    border-radius: 6px;
    vertical-align: middle;
  }
  span {
    position: absolute;
    top: 9px;
    right: 9px;
    border-radius: 4px;
    background-color: gray(.2);
    color: #fff;
    line-height: 1;
    font-size: 12px;
    padding: 2px;
    cursor: pointer;
  }
}
.example img {
  width: 300px;
}
.tip-content {
  line-height: 25px;
}
</style>
