<!--
 * @Date: 2019-09-29 15:07:44
 * @LastEditors: PoloHuang
 * @LastEditTime: 2019-10-18 10:32:54
 -->
<template>
  <div class="pd24">
    <div class="home-card pd24 mh600">
      <div class="home-card__header line">
        <h2><back title="动态词包"></back></h2>
      </div>
      <div class="home-card__main">
        <super-form class="home-searchform" label-width="0px" :form-list="searchOptions" v-model="searchFormData"></super-form>
        <el-table class="table-border" :data="dataList" v-loading="fetching">
          <el-table-column header-align="center" align="center" v-for="col in tableColumn" :key="col.prop"
            :prop="col.prop" :sortable="col.sortable"
            :label="col.label">
            <template slot-scope="scope">
              <span>{{ col.formatter ? col.formatter(scope.row) : scope.row[col.prop] }}</span>
            </template>
          </el-table-column>
          <el-table-column width="400px" align="center" label="操作">
            <template slot-scope="scope">
              <el-button @click="onShow(scope.row, $event)" type="text">查看</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="home-card__footer">
        <el-pagination class="pull-right"
          v-if="dataListTotal > defaultPageSize"
          background
          :page-size="PAGE_SIZE"
          :page-sizes="PAGE_SIZES"
          :current-page="searchFormData.pageNumber"
          :total="dataListTotal"
          @size-change="onSizeChange"
          @current-change="onPageChanged"
          layout="total, sizes, prev, pager, next, jumper">
        </el-pagination>
      </div>
      <div>动态词包根据用户特征在广告展现时动态将默认词调整为替换词。</div>
    </div>

    <el-dialog title="查看词包" :visible.sync="showDialog" >
      <ul class="dialog-list" v-if="dialogData">
        <li class="dialog-list-item"><p class="label">词包名称</p><p class="text">{{dialogData.name}}</p></li>
        <li class="dialog-list-item"><p class="label">默认词</p><p class="text">{{dialogData.defaultKeyword}}</p></li>
        <li class="dialog-list-item"><p class="label">替换词</p><p class="text" v-html="dialogData.keywords.join('<br>')"></p></li>
        <li class="dialog-list-item"><p class="label">替换词数量</p><p class="text" v-text="dialogData.keywords.length"></p></li>
      </ul>
      <div slot="footer">
        <el-button @click="showDialog = false">确定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
// import { mapGetters } from 'vuex'
import utils from '@/utils'
import { getDynamicList } from '@/api'
import SuperForm from '@/components/SuperForm'
import { PAGE_SIZE, PAGE_SIZES } from '@/enums'
import Back from './Back'
export default {
  data () {
    // const lastMonth = new Date().getTime() - 86400000 * 30
    return {
      fetching: false,
      searchFormData: null,
      dataList: [],
      dataListTotal: 0,
      searchOptions: [
        { type: 'hidden', key: 'pageNumber', default: 1 },
        { type: 'hidden', key: 'pageSize', default: PAGE_SIZE },
        { type: 'text', key: 'name', placeholder: '输入词包名称' }
      ],
      tableColumn: [
        { prop: 'id', label: '词包id', formatter: row => row.id },
        { prop: 'name', label: '词包名称', formatter: row => row.name },
        { prop: 'defaultKeyword', label: '默认词', formatter: row => row.defaultKeyword },
        { prop: 'keywords', label: '替换词', formatter: row => (row.keywords || []).join('，') }
      ],
      page: 1,
      PAGE_SIZE,
      PAGE_SIZES,
      defaultPageSize: PAGE_SIZE,
      rules: {
        packageName: [
          { required: true, message: '请输入词名称', trigger: 'change' }
        ]
      },
      showDialog: false,
      dialogData: null
    }
  },
  computed: {},
  methods: {
    onShow (kw, e) {
      this.showDialog = true
      this.dialogData = kw
    },
    onSizeChange (currSize) {
      this.searchFormData.pageSize = currSize
      this.fetchDynamicList()
    },
    onPageChanged (currPage) {
      this.searchFormData.pageNumber = currPage
      this.fetchDynamicList()
    },
    fetchDynamicList () {
      this.fetching = true
      getDynamicList({ ...this.searchFormData }).then(res => {
        if (res.code === 200) {
          this.dataList = (res.value.data || []).map(it => {
            let maxLen = 0;
            // 获取最长词的长度,计算词长度差
            (it.keywords || []).map(it2 => {
              if (it2.length > maxLen) {
                maxLen = it2.length
              }
            })
            it.maxLen = maxLen
            it.diffLen = maxLen - it.name.length
            if (it.name === '日期') {
              it.keywords = [`系统时间如：${it.keywords[0]}`]
            }
            return it
          })
          this.dataListTotal = res.value.total
        }
      }).finally(() => {
        setTimeout(() => {
          this.fetching = false
        }, 300)
      })
    }
  },
  watch: {
    searchFormData (val) {
      this.throttleFetchDynamicList()
    }
  },
  created () {
    this.throttleFetchDynamicList = utils.debounce(this.fetchDynamicList)
  },
  components: {
    SuperForm,
    Back
  }
}
</script>

<style lang="scss">
.keyword-tip-img {
  position: relative;
  line-height: 25px;
  background: #f0f0f0;
  padding: 10px 20px;
  width: 500px;
  margin: 30px 0 50px 30px;
  .keyword-tip-icon{
    position: absolute;
    right: 160px;
    top: 28px;
  }
}
.textOverflow {
  width: 100%;
  overflow: hidden;
  white-space:nowrap;
  text-overflow:ellipsis;
}
.dialog-list {
  border: 1px solid #f3f3f3;
  border-bottom: 0;
}
.dialog-list-item {
  display: flex;
  padding: 12px 0;
  border-bottom: 1px solid #f3f3f3;
  text-align: center;
  font-size: 14px;
  line-height: 21px;
  overflow: hidden;
  justify-content: center;
  align-items: center;

  .label {
    width: 120px;
    flex-shrink: 0;
  }
  .text {
    width: 100%;
    flex-grow: 1;
  }
}
</style>
