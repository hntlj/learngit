<template>
  <div class="home-userinfo pd24">
    <div class="home-card pd24">
      <div class="home-card__header line">
        <h2>
          <back :title="title"></back> <small v-html="userStatus"></small>
        </h2>
        <el-button v-if="canEdit" plain class="normal pull-right" style="width:100px" @click="$router.push({name: 'UserInfoEdit'})">{{this.userProfile.status === USER_STATUS.REJECT ? '重新认证' : '修改'}}</el-button>
      </div>

      <div class="home-card__main" v-if="userProfile">
        <div class="module-title" v-text="userProfile.identityType === 0 ? '企业信息' : '个人信息'"></div>
        <el-form class="mt24" label-position="right" label-width="170px">
          <el-form-item v-for="item in companyInfo" :key="item.key" class="lh1" :label="item.label" v-show="userProfile[item.key]">
            <span v-if="item.isImg"><img :src="userProfile[item.key]" alt=""></span>
            <span v-else>{{ userProfileModifier[item.key] }}</span>
          </el-form-item>
          <div v-if="userProfile.identityType == 1">
            <el-form-item class="lh1" >
              <div style="margin:0 0 10px -130px; display:flex; color: rgba(0,0,0,.6);"><span style="padding-right: 30px;">身份证反面照片</span><img :src="userProfile.identityFrontUrl" alt=""></div>
              <div style="margin-left:-130px; display:flex; color: rgba(0,0,0,.6);"><span style="padding-right: 30px;">身份证正面照片</span><img :src="userProfile.identityBackUrl" alt=""></div>
            </el-form-item>
          </div>
        </el-form>
        <div class="module-title" v-if="userProfile.identityType == 0">主体资质</div>
        <el-form v-if="userProfile.identityType == 0" class="mt24" label-position="right" label-width="170px">
          <el-form-item v-for="item in entityQualifiInfo" :key="item.key" class="lh1" :label="item.label" v-show="userProfile[item.key]">
            <span v-if="item.isImg"><img :src="userProfile[item.key]" alt=""></span>
            <span v-else>{{ userProfileModifier[item.key] }}</span>
          </el-form-item>
        </el-form>

        <div class="module-title" v-if="userProfile.websiteInfo.length > 0">补充资质</div>
        <el-form class="mt24" label-position="right" label-width="170px" v-if="userProfile.websiteInfo.length > 0">
          <div v-for="(website, idx) in userProfile.websiteInfo" :key="idx" style="overflow:hidden;">
            <el-form-item label="推广网址"><span>{{website.fwebsiteUrl}}</span></el-form-item>
            <el-form-item label="ICP备案号"><span>{{website.ficpNumber}}</span></el-form-item>
            <el-form-item class="lh1" label="ICP备案图片"><span><img :src="website.ficpFile"></span></el-form-item>
          </div>
        </el-form>

        <div class="module-title" v-if="certCategory && userProfile.certificates.length > 0">行业资质</div>
        <el-form class="mt24" label-position="right" label-width="170px" v-if="certCategory && userProfile.certificates.length > 0">
          <div v-for="cert in userProfile.certificates" :key="'name'+cert.id">
            <el-form-item class="lh1" label="行业"><span>{{getCertName(cert.cert1Id, cert.cert2Id)}}</span></el-form-item>
            <el-form-item class="lh1" label="行业资质照片"><span v-for="(img, idx) in cert.certFile" :key="idx" ><img :src="img"> </span></el-form-item>
          </div>
        </el-form>
      </div>
    </div>
    <div class="home-card pd24 mt24" v-if="typeof agency.status !== 'undefined' && agency.status !== -1">
      <div class="home-card__header line">
        <h2>代理商信息</h2>
      </div>
      <div class="home-card__main">
        <div class="angencyinfo">
          <img src="~assets/img/portal.png" alt="" class="angencyinfo__img">
          <div class="angencyinfo__main">
            <div class="middleWrap">
              <h4>{{ agency.name }}</h4>
              <p>{{['正在申请为您的广告代理商', '已经成为您的广告代理商', '您已拒绝' + agency.name + '成为您的广告代理商'][agency.status]}}</p>
            </div>
            <div class="angencyinfo__btn" v-if="agency.status === 0">
              <el-button size="small" type="primary" @click="showAudit=true">授权代理商</el-button>
              <el-button size="small" @click="onReject">拒绝</el-button>
            </div>
          </div>
          <div class="angencyinfo__footer mt24">
            * 如要解除绑定，请发送邮件到 <a href="mailto://ad@meizu.com">ad@meizu.com</a> 申请
          </div>
        </div>
      </div>
    </div>
    <el-dialog :title="`您确认要授权 “${agency.name}” 成为代理商吗？`" :visible.sync="showAudit" width="500px">
      <dl class="audit-desc">
        <dt>授权后，代理商将获得以下权限：</dt>
        <dd>1.有权登录您的帐户，并查看您账户内的所有信息；</dd>
        <dd>2.有权使用您账户内的余额，并拥有充值、转账等其他财物功能；</dd>
        <dd>3.有权帮您操作投放广告，并查看广告投放的数据；</dd>
        <dd style="margin-top:10px">每个帐号只能授权一个代理商；</dd>
        <dd>同意授权后，若要解除绑定，请发送邮件到<a href="mailto:ad@meizu.com">ad@meizu.com</a>申请。</dd>
      </dl>
      <span slot="footer" class="dialog-footer">
        <el-button @click="showAudit = false">取消</el-button>
        <el-button type="primary" @click="onAudit(1)" :loading="processing" :disabled="processing">确定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { getUserAgency, auditUserAgent, getCertCategoryList, getNameAndValue } from '@/api'
import { USER_STATUS, ACCOUNT_STATUS } from '@/enums'
import Back from '@/components/home/toolkit/Back'
export default {
  data () {
    return {
      agency: {},
      companyInfo: [
        { label: '公司名称', key: 'name', isImg: false },
        { label: '公司行业', key: 'tierOneIndustry', isImg: false },
        { label: '公司地址', key: 'address', isImg: false },
        { label: '主要产品', key: 'mainProduct', isImg: false },
        { label: '联系人', key: 'contact', isImg: false },
        { label: '联系电话', key: 'phone', isImg: false },
        { label: '联系邮箱', key: 'email', isImg: false }
      ],
      entityQualifiInfo: [
        { label: '主体资质类型', key: 'entityQualifiType', isImg: false },
        { label: '主体资质编码', key: 'license', isImg: false },
        { label: '注册日期', key: 'registerDate', isImg: false },
        { label: '法人姓名', key: 'corporate', isImg: false },
        { label: '主体资质图片', key: 'licenseFile', isImg: true },
        { label: '法人身份证', key: 'corporateCertFile', isImg: true }
      ],
      ACCOUNT_STATUS,
      USER_STATUS,
      showAudit: false,
      processing: false,
      modifierObj: {
        tierOneIndustry: '',
        entityQualifiType: ''
      },
      title: '账号信息'
    }
  },
  computed: {
    ...mapGetters(['userInfo', 'userProfile', 'certCategory']),
    canEdit () {
      const { NONE, VERIFYING, CHECKING } = USER_STATUS
      return this.userProfile && [NONE, VERIFYING, CHECKING].indexOf(this.userProfile.status) === -1
    },
    userStatus () {
      if (this.userProfile && this.userProfile.status !== USER_STATUS.VERIFYED) {
        let statusText = ACCOUNT_STATUS[this.userProfile.status].name
        let remark = this.userProfile.remark ? ` （<span class="color-red">拒绝原因：${this.userProfile.remark}</span>）` : ''
        return statusText + remark
      }
      return ''
    },
    userProfileModifier () {
      return {
        ...this.userProfile,
        tierOneIndustry: this.modifierObj.tierOneIndustry,
        entityQualifiType: this.modifierObj.entityQualifiType
      }
    }
  },
  methods: {
    async onAudit (status) {
      this.processing = true
      try {
        const res = await auditUserAgent({
          id: this.agency.id,
          status
        })
        if (res.code === 200) {
          let message = '操作成功'
          if (status === 1) {
            message = '授权' + message
          } else if (status === 2) {
            message = '拒绝' + message
          }
          this.$message.success(message)
          this.fetchUserAgency()
          this.showAudit = false
        }
      } catch (error) {
        this.$message.error(error.message)
      } finally {
        this.processing = false
      }
    },
    onReject () {
      this.$confirm(`您确认要拒绝 “${this.agency.name}” 成为代理商吗？`, '', {
        type: 'warning'
      }).then(() => {
        this.onAudit(2)
      })
    },
    fetchUserAgency () {
      getUserAgency().then(res => {
        this.agency = res.value || {}
      })
    },
    getCertName (cert1Id, cert2Id) {
      return this.certCategory.cert1[cert1Id].name + ' - ' + this.certCategory.cert2[cert2Id].name
    },
    getCompanyCertList () {
      getCertCategoryList(1).then(cateList => {
        cateList.forEach(cate => {
          if (cate.cert1_id === this.userProfile.tierOneIndustry) {
            this.modifierObj.tierOneIndustry = cate.cert_name
          }
        })
      })
    },
    getNameAndValueList () {
      // type 查询类型 （0，主体资质类型；1，商务部门；2，所属主体）
      getNameAndValue(0).then(res => {
        res.value && res.value.forEach(item => {
          if (item.fid === this.userProfile.entityQualifiType) {
            this.modifierObj.entityQualifiType = item.fname
          }
        })
      })
    }
  },
  mounted () {
    this.$store.dispatch('getCertList')
    this.$store.dispatch('getUserInfoProfile')
    this.fetchUserAgency()
  },
  watch: {
    userProfile (val, oldVal) {
      if (val.identityType === 1) {
        this.companyInfo.splice(0, 1, { label: '个人姓名', key: 'name', isImg: false }, { label: '证件号码', key: 'identityNumber', isImg: false }, { label: '证件有效期', key: 'registerDate', isImg: false })
        val.identityBackUrl = val.identityFile.split(',')[0]
        val.identityFrontUrl = val.identityFile.split(',')[1]
      }
      this.getCompanyCertList()
      this.getNameAndValueList()
    }
  },
  components: {
    Back
  }
}
</script>

<style lang="scss">
.home-userinfo {
  .el-form {
    overflow: hidden;
    &:not(:last-child) {
      padding-bottom: 24px;
      margin-bottom: 24px;
      border-bottom: 1px solid gray(.1);
    }
    .el-form-item {
      width: 50%;
      float: left;
    }
  }
  .module-title {
    line-height: 30px;
    font-weight: bold;
  }
  .el-form-item__label {
    color: gray(.6)
  }
  .el-form-item__content img {
    width: 210px;
    height: 140px;
    margin-right: 10px;
  }
}
.angencyinfo {
  overflow: hidden;
  &__img {
    float: left;
    display: block;
    width: 90px;
    height: 90px;
  }
  &__main {
    height: 90px;
    margin-left: 114px;
    h4 {
      font-size: 24px;
      line-height: 31px;
    }
    p {
      color: gray(.4);
      font-size: 16px;
      line-height: 21px;
    }
  }
  &__btn {
    margin-top: 10px;
  }
  &__footer {
    font-size: 16px;
    line-height: 21px;
    color: gray(.4);
  }
}
.audit-desc {
  line-height: 1.5;
  dt {
    font-size: 16px;
    font-weight: 700;
    margin-bottom: 20px;
  }
}
</style>
