<template>
  <div class="pd24">
    <div class="home-card pd24 mh600">
      <div class="home-card__header line">
        <h2><back :title="title"></back></h2>
      </div>
      <div class="home-card__main" style="position: relative;">
        <super-form class="home-searchform" label-width="0px" :form-list="searchOptions" v-model="searchFormData"></super-form>
        <el-button type="primary" class="pull-right crowd-upload-btn" @click="showUploadDialog = true">上传人群</el-button>
        <el-popover class="tab-tip" trigger="hover" placement="top" :diabled="true" style="right: 694px;">
          <p class="refusal-reason">上传数量：上传文件中的人群数量。</p>
          <div slot="reference">
            <i class="el-icon-question"></i>
          </div>
        </el-popover>
        <el-popover class="tab-tip" trigger="hover" placement="top" :diabled="true" style="right: 513px;">
          <p class="refusal-reason">有效覆盖数：覆盖魅族用户的数量。</p>
          <div slot="reference">
            <i class="el-icon-question"></i>
          </div>
        </el-popover>
        <el-popover class="tab-tip" trigger="hover" placement="top" :diabled="true" style="right: 342px;">
          <p class="refusal-reason">有效期：人群包的有效时间，当人群包过期后无法再使用，下方人群包变灰表示即已过期，请在过期前及时更新，以免影响投放。</p>
          <div slot="reference">
            <i class="el-icon-question"></i>
          </div>
        </el-popover>
        <el-table class="table-border" :data="dataList" :row-class-name="tableRowClassName">
          <el-table-column align="center" v-for="col in tableColumn" :key="col.prop"
            :prop="col.prop"
            :sortable="col.sortable"
            :label="col.label"
            :formatter="col.formatter">
          </el-table-column>
          <el-table-column width="300px" align="center" label="操作">
            <template slot-scope="scope">
              <el-button v-if="scope.row.status === 2 && scope.row.coverNum >= 3000" type="text" @click="onExtend(scope.row)">扩展</el-button>
              <el-button v-if="scope.row.status === 2" type="text" @click="onUpdate(scope.row)">更新</el-button>
              <el-button type="text" @click="onDelete(scope.row)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="home-card__footer">
        <el-pagination class="pull-right"
          v-if="dataListTotal > defaultPageSize"
          background
          :page-size="PAGE_SIZE"
          :page-sizes="PAGE_SIZES"
          :current-page="formData.pageNumber"
          :total="dataListTotal"
          @size-change="onSizeChange"
          @current-change="onPageChanged"
          layout="total, sizes, prev, pager, next, jumper">
        </el-pagination>
      </div>
    </div>
    <el-dialog title="上传人群" :visible.sync="showUploadDialog">
      <el-form label-width="120px" ref="form_update" :model="formData" :rules="rules">
        <el-form-item label="人群类型" prop="crowdType" key="crowdType">
          <el-radio-group v-model="formData.crowdType">
            <el-radio label="IMEI">IMEI</el-radio>
            <el-radio label="IMEI-MD5">IMEI-MD5</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="人群名称" prop="crowdName" key="crowdName">
          <el-input v-model="formData.crowdName"></el-input>
        </el-form-item>
        <el-form-item label="上传文件">
          <el-upload
            class="avatar-uploader"
            ref="crowdUpload"
            action="/console/mdsp/crowd/add"
            :data="formData"
            :on-change="handleChange"
            :on-remove="handleRemove"
            :on-success="uploadSubmitSucc"
            :on-error="uploadSubmitError"
            :auto-upload="false">
            <el-button slot="trigger" size="small">选择文件</el-button>
          </el-upload>
        </el-form-item>
        <div class="upload-tip">
          说明：<br/>
          1、文件大小：单个文件不超过50M<br/>
          2、文件格式： *.txt（UTF-8编码）文档中，一行一个号码<br/>
          3、人群包名称不能重复，否则无法区分人群包<br/>
          4、人群包上传后需要进行校验，校验通过前广告按无此定向投放<br/>
          5、文件上传过程需要一定时间，请勿关闭页面窗口，否则会导致文件上传失败
        </div>
      </el-form>
      <div slot="footer">
        <el-button @click="showUploadDialog = false">取消</el-button>
        <el-button type="primary" @click="submitUpload" :disabled="uploading">上传</el-button>
      </div>
    </el-dialog>
    <el-dialog title="扩展人群" :visible.sync="showExtendDialog" v-loading="extendLoading">
      <el-form label-width="120px" ref="form_extend" :model="extendFormData" :rules="extendRules">
        <el-form-item label="人群名称" prop="crowdName" key="crowdName">
          <el-input v-model="extendFormData.crowdName"></el-input>
        </el-form-item>
        <el-form-item label="种子人群数">
          <div>{{extendFormData.coverNum}}</div>
          <p class="gray">目前系统支持的扩展门槛为3000人，即大于等于3000人的种子群才能被扩展</p>
        </el-form-item>
        <el-form-item label="扩展方式">
          <div>Lookalike</div>
        </el-form-item>
        <el-form-item label="数据计算">
          <el-radio-group v-model="extendFormData.inclusive">
            <el-radio :label="1">包含种子人群</el-radio>
            <el-radio :label="0">不包含种子人群</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="输出人群数">
          <div style="display: flex;">
            <div class="block" style="width: 90%;">
              <el-slider
                :min="10"
                :max="3000"
                v-model="extendFormData.targetSize"
                show-input>
              </el-slider>
            </div>
            <span style="margin-left: 10px;"> 万 </span>
          </div>
          <p class="gray">输出人群数越大，则与种子用户相似度越低，一般扩展量级建议3-5倍</p>
        </el-form-item>
      </el-form>
      <div slot="footer">
        <el-button @click="showExtendDialog = false">取消</el-button>
        <el-button type="primary" @click="submitExtend">扩展</el-button>
      </div>
    </el-dialog>
    <el-dialog
      title="更新提示"
      :visible.sync="showUpdateDialog"
      width="30%">
      <span>确定更新 {{selectedCrowdName}}？</span>
      <span slot="footer" class="dialog-footer">
        <el-button @click="showUpdateDialog = false">取 消</el-button>
        <el-button type="primary" @click="updateCrowd">确 定</el-button>
      </span>
    </el-dialog>
    <el-dialog
      title="删除提示"
      :visible.sync="showDeleteDialog"
      width="30%">
      <span>确定删除 {{selectedCrowdName}}？</span>
      <span slot="footer" class="dialog-footer">
        <el-button @click="showDeleteDialog = false">取 消</el-button>
        <el-button type="primary" @click="deleteCrowd">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import utils from '@/utils'
import { CROWD_TYPE, CROWD_STATUS, PAGE_SIZE, PAGE_SIZES } from '@/enums'
import { getCrowdList, extendCrowd, updateCrowdValidTime, deleteCrowd } from '@/api'
import SuperForm from '@/components/SuperForm'
import Back from '@/components/home/toolkit/Back'
export default {
  data () {
    return {
      PAGE_SIZE,
      PAGE_SIZES,
      defaultPageSize: PAGE_SIZE,
      searchFormData: null,
      formData: {
        crowdType: '',
        crowdName: ''
      },
      extendFormData: {
        crowdName: '',
        seedCrowdId: '',
        coverNum: 0,
        inclusive: 1,
        targetSize: 10
      },
      rules: {
        crowdType: [
          { required: true, message: '请选择人群类型', trigger: 'change' }
        ],
        crowdName: [
          { required: true, message: '请输入人群名称', trigger: 'change' }
        ],
        file: [
          { required: true, message: '请上传文件', trigger: 'change' }
        ]
      },
      extendRules: {
        crowdName: [
          { required: true, message: '请输入扩展人群名称', trigger: 'change' }
        ]
      },
      searchOptions: [
        { type: 'hidden', key: 'pageNumber', default: 1 },
        { type: 'hidden', key: 'pageSize', default: PAGE_SIZE },
        { type: 'text', key: 'crowdName', placeholder: '输入人群名称' },
        { type: 'select', key: 'status', label: '数据状态', options: CROWD_STATUS },
        { type: 'select', key: 'type', label: '类别', options: CROWD_TYPE }
      ],
      tableColumn: [
        { prop: 'crowdId', label: '人群ID' },
        { prop: 'crowdName', label: '人群名称' },
        { prop: 'status', label: '数据状态', formatter: row => CROWD_STATUS[row.status].name },
        { prop: 'type', label: '类别', formatter: row => CROWD_TYPE[row.type].name },
        { prop: 'uploadNum', label: '上传数量' },
        { prop: 'coverNum', label: '有效覆盖数' },
        { prop: 'validTime', label: '有效期至' }
      ],
      dataList: [],
      dataListTotal: 0,
      selectedCrowdName: '',
      selectedCrowdId: '',
      showUploadDialog: false,
      showExtendDialog: false,
      showUpdateDialog: false,
      showDeleteDialog: false,
      hasUploadFile: false,
      uploading: false,
      extendLoading: false,
      title: '人群包管理'
    }
  },
  methods: {
    tableRowClassName ({row, rowIndex}) {
      if (!row.valid) {
        return 'gray-row'
      }
      return ''
    },
    onSizeChange (currSize) {
      this.searchFormData.pageSize = currSize
      this.fetchDataList()
    },
    onPageChanged (currPage) {
      this.searchFormData.pageNumber = currPage
      this.fetchDataList()
    },
    fetchDataList () {
      this.fetching = true
      getCrowdList({
        ...this.searchFormData
      }).then(res => {
        if (res.code === 200) {
          this.dataList = res.value.data
          this.dataListTotal = res.value.total
        }
      }).finally(() => {
        this.fetching = false
      })
    },
    handleRemove (file) {
      this.hasUploadFile = false
    },
    handleChange (file, fileList) {
      if (fileList.length === 0) {
        this.hasUploadFile = false
        return false
      }
      const isText = file.raw.type === 'text/plain'
      const isLt50M = file.size / 1024 / 1024 < 50
      if (!isText) {
        this.$message.error('上传文件格式必须为.txt格式!')
      }
      if (!isLt50M) {
        this.$message.error('上传文件大小不能超过 50MB!')
      }
      if (!isText || !isLt50M) {
        this.$refs.crowdUpload.clearFiles()
      } else {
        if (fileList.length > 1) {
          fileList.shift()
        }
      }
      this.hasUploadFile = isText && isLt50M
    },
    submitUpload () {
      this.$refs['form_update'].validate((valid) => {
        if (!this.hasUploadFile) {
          this.$message.error('请上传文件!')
        } else {
          if (valid) {
            this.uploading = true
            this.$refs.crowdUpload.submit()
          }
        }
        this.showUploadDialog = true
      })
    },
    uploadSubmitSucc (res) {
      this.uploading = false
      if (res.code === 200) {
        this.fetchDataList()
        this.$message.success('上传成功!')
        this.showUploadDialog = false
      } else {
        this.$message.error(res.message)
        this.$refs.crowdUpload.clearFiles()
        this.hasUploadFile = false
      }
    },
    uploadSubmitError (res) {
      this.uploading = false
    },
    onExtend (row) {
      this.extendFormData = {
        crowdName: '',
        seedCrowdId: row.crowdId,
        coverNum: row.coverNum,
        inclusive: 1,
        targetSize: 10
      }
      this.showExtendDialog = true
    },
    submitExtend () {
      this.$refs['form_extend'].validate((valid) => {
        if (valid) {
          this.extendLoading = true
          extendCrowd(this.extendFormData).then(res => {
            if (res.code === 200) {
              this.fetchDataList()
              this.$message.success('扩展成功')
              this.showExtendDialog = false
            }
          }).catch(error => {
            this.$message.error(`扩展错误[${error.message}]，请重试!`)
          }).finally(() => {
            this.extendLoading = false
          })
        }
      })
    },
    onUpdate (row) {
      this.selectedCrowdName = row.crowdName
      this.selectedCrowdId = row.crowdId
      this.showUpdateDialog = true
    },
    updateCrowd () {
      updateCrowdValidTime({
        crowdId: this.selectedCrowdId
      }).then(res => {
        if (res.code === 200) {
          this.fetchDataList()
          this.$message.success('更新成功')
          this.showUpdateDialog = false
        }
      }).catch(error => {
        this.$message.error(`更新错误[${error.message}]，请重试!`)
      }).finally(() => {})
    },
    onDelete (row) {
      this.selectedCrowdName = row.crowdName
      this.selectedCrowdId = row.crowdId
      this.showDeleteDialog = true
    },
    deleteCrowd () {
      deleteCrowd({
        crowdId: this.selectedCrowdId
      }).then(res => {
        if (res.code === 200) {
          this.fetchDataList()
          this.$message.success('更新成功')
          this.showDeleteDialog = false
          if (this.dataList.length === 1 && this.searchFormData.pageNumber > 1) {
            this.onPageChanged(--this.searchFormData.pageNumber)
          } else {
            this.fetchDataList()
          }
        }
      }).catch(error => {
        this.$message.error(`删除错误[${error.message}]，请重试!`)
      }).finally(() => {})
    }
  },
  watch: {
    searchFormData (val) {
      this.throttleFetchCrowdList()
    },
    showUploadDialog (val) {
      this.uploading = !val
      if (!val) {
        this.$refs.crowdUpload.clearFiles()
        this.formData = {
          crowdType: '',
          crowdName: ''
        }
      }
    }
  },
  created () {
    this.throttleFetchCrowdList = utils.debounce(this.fetchDataList)
    this.fetchList = this.throttleFetchCrowdList
  },
  components: {
    SuperForm, Back
  }
}
</script>

<style lang="scss" scoped>
.home-card__main {
  .crowd-upload-btn {
    width: 160px;
    position: absolute;
    top: 0px;
    right: 0px;
  }
  .tab-tip {
    position: absolute;
    top: 97px;
    // left: 828px;
    z-index: 9;
    cursor: pointer;
  }
}
.gray, .gray-row {
  color: #c1c1c1;
}

.upload-tip {
  line-height:25px;
  background:#ebebeb;
  padding:10px 20px;
}
</style>
