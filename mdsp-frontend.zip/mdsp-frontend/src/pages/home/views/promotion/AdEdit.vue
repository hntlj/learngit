<template lang="html">
  <div class="home-adedit home-container">
    <adedit-aside />

    <main class="home-main">
      <router-view />
    </main>
  </div>
</template>

<script>
import AdeditAside from './adedit/Aside'
export default {
  beforeRouteLeave (to, from, next) {
    if (!to.query.complete) {
      this.$confirm('若离开当前页面，所输入的内容将不会被保留', '', {
        confirmButtonText: '离开',
        cancelButtonText: '取消',
        customClass: 'leaveConfirm'
      }).then(() => {
        this.$store.commit('clearAdEdit')
        next()
      })
    } else {
      next()
    }
  },
  components: {
    AdeditAside
  }
}
</script>

<style lang="scss">
.home-adedit {

  &__tab.el-menu{
    width: 100% !important;
    padding-left: 36px;
    border-bottom: 0;
    background: #FCFCFC;
    box-shadow: 0 1px 0 0 rgba(0,0,0,.1);

    .el-menu-item {
      font-size: 16px;
      margin-right: 60px;
      padding: 0;
      &:not(.is-disabled) {
        &:hover,&:focus,&.is-active {
          color: $blue;
          background-color: transparent;
        }
      }
    }
  }
  .el-form {
    margin-bottom: 38px;
  }
  .icon-question {
    display: inline-block;
    vertical-align: middle;
    margin-left: 4px;
    margin-top: -2px;
    width: 12px;
    height: 12px;
    background-image: url('~assets/img/element-icon.png');
    background-position: 0 0;
    background-size: 18px 42px;
  }
  .el-radio__input.is-checked+.el-radio__label .icon-question {
    background-position: 0  -12px;
  }
}
.leaveConfirm {
  .el-message-box__btns .el-button--primary {
    background-color: #DF3737;
    border-color: #DF3737;
  }
}
</style>
