<template>
  <div>
    <div class="home-promotion__header inset-shadow">
      <h1 class="home-promotion__header--title">应用拉活广告</h1>
      <small class="home-promotion__header--subtitle" v-if="editDisable">（{{activeIdea.pushAdName}}）</small>
    </div>
    <el-card class="form-container" style="min-width:1100px;position: relative;">
      <preview :sb="activeIdea.resourceType" style="margin-top:24px"/>
      <h3 class="form-title">广告资源</h3>
      <el-form>
        <el-form-item prop="slotBundle">
          <p class="form-row">
            <span class="form-col w200 color-gray">名称</span>
            <span class="form-col w200 color-gray">创意规格</span>
            <span class="form-col color-gray">资源描述</span>
          </p>
          <p class="form-row" :class="{'color-blue': activeIdea.resourceType === slot.value}"
            v-for="slot in ACTIVE_SLOT_BUNDLE" :key="slot.value">
            <span class="form-col w200"><el-radio v-model="activeIdea.resourceType" :label="slot.value" :disabled="editDisable">{{slot.name}}</el-radio></span>
            <span class="form-col w200">{{slot.size}}</span>
            <span class="form-col">{{slot.desc}}</span>
          </p>
        </el-form-item>
      </el-form>
      <el-form style="padding-top: 100px;">
        <h3 class="form-title">应用设置</h3>
        <el-form label-width="130px" label-position="left" :model="activeIdea" :rules="rules" ref="form2_1">
          <el-form-item prop="appPackageName" label="应用包名" :rules="{ validator: onValidApp(), trigger: 'blur' }">
            <el-input
              class="form-input--large"
              style="width:580px"
              v-model="activeIdea.appPackageName"
              :disabled="editDisable"
              placeholder="请输入应用包名"></el-input>
            <img v-if="activeIdea.appInfo" class="el-form-item__icon" :src="activeIdea.appInfo.icon"> {{ activeIdea.appInfo && activeIdea.appInfo.name }}
          </el-form-item>
          <el-form-item prop="deepLink" label="Deeplink">
            <el-popover class="deeplink-tip" trigger="hover" placement="top" :diabled="true">
              <p class="refusal-reason">填写应用直达链接，指定点击广告可直达的应用内详情页。</p>
              <div slot="reference" class="name-wrapper">
                <p style="white-space: nowrap;"><i class="el-icon-question"></i></p>
              </div>
            </el-popover>
            <el-input class="form-input--large" :maxlength="1000" v-model="activeIdea.deepLink" :disabled="editDisable" placeholder="选填"></el-input>
          </el-form-item>
        </el-form>
      </el-form>
      <el-form>
        <h3 class="form-title">定向设置</h3>
        <el-form label-width="130px" label-position="left" :model="activeIdea" :rules="rules" ref="form3_1">
          <el-form-item label="投放时间" required v-if="!editDisable">
            <div style="height: 60px;">
              <el-col :span="4">
                <el-form-item prop="pushDate">
                  <el-date-picker
                    v-model="activeIdea.pushDate"
                    align="right"
                    type="date"
                    placeholder="选择日期"
                    value-format="yyyy-MM-dd"
                    :picker-options="pickerOptions">
                  </el-date-picker>
                </el-form-item>
              </el-col>
              <el-col :span="4">
                <el-form-item prop="pushDateTime">
                  <el-select v-model="activeIdea.pushDateTime" placeholder="请选择具体时间">
                    <el-option
                      v-for="item in pushConfigTime"
                      :key="item"
                      :label="item"
                      :value="item">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </div>
            <p class="el-form-item__tip">平台的审核时间是 <span class="color-red">周一至周五</span></p>
            <p class="el-form-item__tip" v-if="pushLimitTime">广告需要审核/排期，在 <span class="color-red">{{pushLimitTime}}</span> 以后订单将不能修改/提交。</p>
          </el-form-item>
          <el-form-item label="投放时间" v-else>
            <el-date-picker
              v-model="activeIdea.pushDate"
              align="right"
              type="datetime"
              placeholder="选择日期"
              value-format="yyyy-MM-dd HH:mm:ss"
              :disabled="editDisable"
              :picker-options="pickerOptions">
            </el-date-picker>
          </el-form-item>
          <el-form-item label="投放人群">
            <el-radio-group v-model="activeIdea.pushCrowdSubDateType" :disabled="editDisable">
              <el-radio :label="0">不限定</el-radio>
              <el-radio :label="1">定向用户</el-radio>
            </el-radio-group>
            <div class="target-group" v-if="activeIdea.pushCrowdSubDateType === 1">
              <div class="target-group__title">定向用户</div>
              <el-radio-group v-model="activeIdea.pushCrowdSubDate">
                <el-radio
                  v-for="(item, idx) in targetUser"
                  :key="idx"
                  v-show="item.dayTarget !== 0"
                  :disabled="editDisable"
                  :label="item.dayTarget">{{formatTargetUser(item.dayTarget)}}</el-radio>
              </el-radio-group>
            </div>
            <p class="el-form-item__tip" v-if="activeIdea.crowdCount >= 0">根据定向条件约覆盖 {{activeIdea.crowdCount}} 人。</p>
          </el-form-item>
          <el-form-item label="投放用户数量" v-if="this.action !== 'edit'" prop="pushCrowdCount"
            :rules="[
              { required: true, message: '请输入投放用户数量', trigger: 'blur' },
              { validator: onValidCrowdCount(), trigger: 'blur' }
            ]">
            <el-input type="number" style="width:180px"
              v-model="activeIdea.pushCrowdCount"
              :disabled="editDisable || !activeIdea.crowdCount"
              placeholder=""></el-input> 人
            <p class="el-form-item__tip">投放用户数量必须小于等于覆盖人群数量。当定向人群数量为 0 时，请重新选择投放人群。</P>
          </el-form-item>
          <el-form-item label="投放用户数量" v-if="this.action === 'edit'">
            <el-input type="number" style="width:180px"
              v-model="activeIdea.pushCrowdCount"
              :disabled="editDisable || !activeIdea.crowdCount"
              placeholder=""></el-input> 人
          </el-form-item>
          <el-form-item label="投放黑名单">
            <el-select v-model="activeIdea.blackImeiCrowd" :disabled="editDisable" clearable placeholder="选择黑名单">
              <el-option
                v-for="item in blacklistData"
                :key="item.id"
                :label="item.name"
                :value="item.id">
              </el-option>
            </el-select>
            <p class="el-form-item__tip">选填，不填则不过滤。</p>
          </el-form-item>
        </el-form>
      </el-form>
      <el-form>
        <h3 class="form-title">计费设置</h3>
        <el-form label-width="130px" label-position="left">
          <el-form-item label="计费类型">
            点击（CPC）
          </el-form-item>
          <el-form-item label="单价" v-show="activeIdea.price">
            {{activeIdea.price}} 元
          </el-form-item>
          <div class="cost-tip" v-show="activeIdea.pushCrowdCount">根据选择的投放人群及单价，本次投放预计消耗金额 {{costNum}} 元</div>
        </el-form>
      </el-form>
      <el-form>
        <h3 class="form-title">创意素材</h3>
        <el-form label-width="130px" label-position="left" v-if="showSource" :model="activeIdea" :rules="rules" ref="form4_1">
          <el-form-item label="创意样式" v-if="activeIdea.resourceType === 8">安卓原生</el-form-item>
          <el-form-item label="标题" prop="titlePush" v-if="activeIdea.resourceType === 8">
            <el-input class="form-input--large" v-model="activeIdea.titlePush" :disabled="action==='view'" placeholder="32个字符以内"></el-input>
          </el-form-item>
          <el-form-item label="创意标题" prop="titleDesktop" v-if="activeIdea.resourceType === 9">
            <el-input class="form-input--large" v-model="activeIdea.titleDesktop" :disabled="action==='view'" placeholder="5个字符以内"></el-input>
          </el-form-item>
          <el-form-item label="内容" prop="content" v-if="activeIdea.resourceType === 8">
            <el-input class="form-input--large" v-model="activeIdea.content" :disabled="action==='view'" placeholder="100个字符以内"></el-input>
          </el-form-item>
          <el-form-item label="小图标" v-if="activeIdea.resourceType === 9">
            <div>默认图标</div>
            <el-radio-group v-model="activeIdea.image" class="push-icons" :disabled="action==='view'">
              <el-radio v-for="(icon, idx) in pushIcons" :label="icon" :key="idx"><i :class="icon"></i></el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item label="展开方式" v-if="activeIdea.resourceType === 8">
            <el-radio-group v-model="expandType" @change="onExpandTypeChanged" :disabled="action==='view'">
              <el-radio-button label="text">文本</el-radio-button>
              <el-radio-button ref="expandImgBtn" label="img">大图</el-radio-button>
            </el-radio-group>
          </el-form-item>
          <el-form-item v-if="activeIdea.resourceType === 8">
            <el-input
              v-if="expandType === 'text'"
              type="textarea"
              placeholder="100个字符以内"
              v-model="activeIdea.expandContent"
              maxlength="100"
              show-word-limit
              :autosize="{ minRows: 4}"
              style="width: 400px;"
              :disabled="action==='view'">
            </el-input>
            <div v-if="expandType === 'img'">
              <el-upload drag action="/common/upload" :show-file-list="false" style="display: inline-block;margin-right: 20px"
                :on-error="onUploadError"
                :on-success="onUploadSuccess"
                :before-upload="onUploadBefore"
                :disabled="action==='view'">
                <div v-if="activeIdea.expandImage" class="el-upload__preview">
                  <img :src="activeIdea.expandImage">
                  <span @click.stop="onRemoveImg" v-if="action!=='view'"><i class="el-icon-close"></i></span>
                </div>
                <div class="el-upload__placeholder" v-else>
                  <i class="el-icon-uploader"></i>
                  <div class="el-upload__text"><em>点击上传图片</em></div>
                </div>
              </el-upload>
              <div class="el-form-item__tip assets-imgs-tip">建议图片尺寸为700x400，格式为 jpg、png、jpeg 并且大小在 200KB 以内。</div>
            </div>
          </el-form-item>
        </el-form>
      </el-form>
      <el-form>
        <h3 class="form-title">广告名称</h3>
        <el-form label-width="130px" label-position="left" :model="activeIdea" :rules="rules" ref="form5_1">
          <el-form-item label="广告名称" prop="pushAdName">
            <el-input class="form-input--large" v-model="activeIdea.pushAdName" :disabled="editDisable" placeholder="输入广告名称"></el-input>
          </el-form-item>
        </el-form>
      </el-form>
      <el-row v-if="action !== 'view'">
        <el-col :span="16">
          <el-button type="primary" @click="onCancel">取消</el-button>
          <el-button type="success" @click="onSubmit">确定</el-button>
        </el-col>
      </el-row>
    </el-card>
    <el-dialog class="detail-dialog" :visible.sync="showDetail" title="投放详情" width="700px">
      <el-form label-width="180px">
        <el-form-item class="font-bold" label="推广目标">应用拉活</el-form-item>
        <el-form-item class="font-bold" label="广告资源">{{resourceTypeName}}</el-form-item>
        <el-form-item class="font-bold" label="应用设置"></el-form-item>
        <el-form-item label="应用包名">{{activeIdea.appPackageName}}</el-form-item>
        <el-form-item label="deeplink">{{activeIdea.deepLink}}</el-form-item>
        <el-form-item class="font-bold" label="定向设置"></el-form-item>
        <el-form-item label="投放日期">{{pushDateNormal}}</el-form-item>
        <el-form-item label="投放人群">{{formatTargetUserComp}}</el-form-item>
        <el-form-item label="投放用户数量">{{activeIdea.pushCrowdCount}} 人</el-form-item>
        <el-form-item label="投放黑名单">{{getBlacklistName}}</el-form-item>
        <el-form-item class="font-bold" label="计费设置"></el-form-item>
        <el-form-item label="计费类型">cpc</el-form-item>
        <el-form-item label="单价">{{activeIdea.price}}元</el-form-item>
        <el-form-item class="font-bold" label="创意素材"></el-form-item>
        <el-form-item label="创意样式" v-if="activeIdea.resourceType === 8">安卓原生</el-form-item>
        <el-form-item label="标题">{{ideaTitle}}</el-form-item>
        <el-form-item label="内容" v-if="activeIdea.resourceType === 8">{{activeIdea.content}}</el-form-item>
        <el-form-item label="展开方式" v-if="activeIdea.resourceType === 8 && activeIdea.expandContent">{{activeIdea.expandContent}}</el-form-item>
        <el-form-item label="展开方式" v-if="activeIdea.resourceType === 8 && activeIdea.expandImage"><img height="100" :src="activeIdea.expandImage"></el-form-item>
        <el-form-item label="小图标" v-if="activeIdea.resourceType === 9"><i :class="activeIdea.image"></i></el-form-item>
        <el-form-item class="font-bold" label="广告名称">{{activeIdea.pushAdName}}</el-form-item>
      </el-form>
      <div class="detail-dialog__tip">预计投放人数 {{activeIdea.pushCrowdCount}} 人，消耗账户金额 {{costNum}} 元，实际扣费金额在订单结束后按实际消耗扣取。</div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="showDetail = false">取消</el-button>
        <el-button type="primary" @click="onSave">提交</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import { ACTIVE_SLOT_BUNDLE } from '@/enums'
import utils from '@/utils'
import {
  getAppDetail, getPushConfigPrice, getPushConfig, getPushCrowdIdAndCount, createPush, getPushDetail, updatePush, getBlacklistList
} from '@/api'
import { schemaValidator, crowdCountValidator } from '@/validators/idea'
import validateMixin from '@/mixins/validate'
import Preview from './Preview'
export default {
  mixins: [validateMixin],
  data () {
    const onValidApp = function (form, rule, value, callback) {
      value = form.appPackageName
      if (!value) {
        form.appInfo = null
        return callback(new Error('请输入应用包名'))
      }
      if (form.appInfo && form.appInfo.packageName.toUpperCase() === value.toUpperCase()) {
        callback()
      } else {
        getAppDetail({ packageName: value }).then(res => {
          if (res.code === 200 && res.value) {
            form.appInfo = res.value
            form.appId = form.appInfo.id
            this.getPushCrowdIdAndCount(res.value.packageName, this.pushDateNormal, this.pushCrowdSubDateNormal)
            callback()
          } else {
            form.appInfo = null
            form.appId = ''
            callback(new Error('应用中心没有找到该应用,请检查您输入的包名'))
          }
        })
      }
    }
    return {
      ACTIVE_SLOT_BUNDLE,
      showDetail: false,
      activeIdea: {
        id: '',
        resourceType: '',
        appId: '',
        appPackageName: '',
        deepLink: '',
        pushDate: '',
        pushDateTime: '',
        pushCrowdSubDate: -1,
        pushCrowdSubDateType: '',
        pushCrowdCount: '',
        feeType: '',
        price: '',
        transferRatio: 100,
        pushStyle: '',
        titlePush: '',
        titleDesktop: '',
        content: '',
        image: 'push_icon1',
        pushAdName: '',
        crowdId: '',
        crowdCount: '',
        originCrowdCount: '',
        originDuplicateCrowdCount: '',
        appInfo: null,
        expandContent: '',
        expandImage: '',
        blackImeiCrowd: ''
      },
      pushConfigTime: [],
      targetUser: [],
      advanceTime: '',
      pickerOptions: {
        disabledDate (time) {
          return time.getTime() < Date.now()
        }
      },
      onValidApp: () => onValidApp.bind(this, this.activeIdea),
      onValidCrowdCount: () => crowdCountValidator.bind(this, this.activeIdea),
      rules: {
        deepLink: [{ validator: schemaValidator.bind(this), trigger: 'change' }],
        pushDate: [{ type: 'string', required: true, message: '请选择日期', trigger: 'change' }],
        pushDateTime: [{ required: true, message: '请选择具体时间', trigger: 'change' }],
        titlePush: [
          { required: true, message: '请输入标题', trigger: 'blur' },
          { max: 32, message: '长度在32个字符以内', trigger: 'blur' }
        ],
        titleDesktop: [
          { required: true, message: '请输入标题', trigger: 'blur' },
          { max: 5, message: '长度在5个字符以内', trigger: 'blur' }
        ],
        content: [
          { required: true, message: '请输入内容', trigger: 'blur' },
          { max: 100, message: '长度在100个字符以内', trigger: 'blur' }
        ],
        pushAdName: [{ required: true, message: '请输入广告名称', trigger: 'blur' }]
      },
      pushIcons: ['push_icon1', 'push_icon2', 'push_icon3', 'push_icon4', 'push_icon5'],
      fetching: false,
      pushId: '',
      action: '',
      getCrowdId: false,
      expandType: 'text',
      showSource: true,
      blacklistData: []
    }
  },
  computed: {
    ...mapGetters(['userInfo', 'slotBundle']),
    pushLimitTime () {
      if (!this.advanceTime || !this.pushDateNormal) return 0
      return utils.formatDate(new Date(this.pushDateNormal) - (this.advanceTime.split(':')[0]) * 1000 * 60 * 60, 'yyyy-MM-dd HH:mm:ss')
    },
    pushDateNormal () {
      let res = ''
      if (this.activeIdea.pushDate && this.activeIdea.pushDateTime) {
        res = this.activeIdea.pushDate + ' ' + this.activeIdea.pushDateTime
      }
      if (this.pushId) {
        res = this.activeIdea.pushDate
      }
      return res
    },
    pushCrowdSubDateNormal () {
      let res = ''
      if (this.activeIdea.pushCrowdSubDateType === 0) {
        res = 0
      } else if (!isNaN(this.activeIdea.pushCrowdSubDate)) {
        res = this.activeIdea.pushCrowdSubDate
      }
      return res
    },
    costNum () {
      return (this.activeIdea.pushCrowdCount * this.activeIdea.price * this.activeIdea.transferRatio / 100).toFixed(2)
    },
    formatTargetUserComp () {
      const dayTarget = this.pushCrowdSubDateNormal
      let desStr = ''
      if (dayTarget === -1) {
        desStr = '未激活用户'
      } else if (dayTarget === 0) {
        desStr = '不限定'
      } else {
        desStr = `近 ${dayTarget} 天沉默用户`
      }
      return desStr
    },
    ideaTitle () {
      if (this.activeIdea.resourceType === 8) {
        return this.activeIdea.titlePush
      } else if (this.activeIdea.resourceType === 9) {
        return this.activeIdea.titleDesktop
      }
    },
    resourceTypeName () {
      if (this.activeIdea.resourceType === 8) {
        return 'push推送'
      } else if (this.activeIdea.resourceType === 9) {
        return '桌面通知'
      }
    },
    editDisable () {
      return !!this.pushId
    },
    getBlacklistName () {
      let name = ''
      this.blacklistData.every(item => {
        if (item.id === this.activeIdea.blackImeiCrowd) {
          name = item.name
          return false
        }
        return true
      })
      return name
    }
  },
  methods: {
    getPushConfigPriceData (resourceType) {
      getPushConfigPrice({
        resourceType
      }).then(res => {
        this.targetUser = res
        if (this.activeIdea.pushCrowdSubDateType === '') {
          this.activeIdea.pushCrowdSubDateType = 0
        }
        res.every((item, idx) => {
          if (item.dayTarget !== 0 && this.action === 'new') {
            this.activeIdea.pushCrowdSubDate = item.dayTarget
            return false
          } else {
            return true
          }
        })
        if ((this.pushCrowdSubDateNormal || this.pushCrowdSubDateNormal === 0) && this.action === 'new') {
          this.targetUser.every((item, idx) => {
            if (item.dayTarget === this.pushCrowdSubDateNormal) {
              this.activeIdea.price = item.price
              return false
            } else {
              return true
            }
          })
        }
      })
    },
    getPushConfigData (resourceType, pushDate) {
      if (!resourceType || !pushDate) return
      getPushConfig({
        resourceType,
        pushDate
      }).then(res => {
        this.pushConfigTime = res.pushDate.split(',')
        this.advanceTime = String(res.advanceDate)
        this.activeIdea.pushDateTime = ''
        this.activeIdea.transferRatio = Number(res.transferRatio)
      })
    },
    getPushCrowdIdAndCount (appPackageName, pushDate, pushCrowdSubDate) {
      if (this.action !== 'new') return
      if (!appPackageName || !pushDate) {
        this.activeIdea.crowdId = ''
        this.activeIdea.crowdCount = ''
        this.activeIdea.originCrowdCount = ''
        this.activeIdea.originDuplicateCrowdCount = ''
      }
      if (pushDate) {
        pushDate = pushDate.replace(/(\S+)00:00$/, '$100')
      }
      if (this.getCrowdId && this.editDisable) return
      if (!appPackageName || !pushDate || (!pushCrowdSubDate && pushCrowdSubDate !== 0)) return
      this.getCrowdId = true
      getPushCrowdIdAndCount({
        appPackageName, pushDate, pushCrowdSubDate, resourceType: this.activeIdea.resourceType
      }).then(res => {
        this.activeIdea.crowdId = Number(res.originCrowdId)
        this.activeIdea.crowdCount = Number(res.originDuplicateCrowdCount)
        this.activeIdea.originDuplicateCrowdCount = Number(res.originDuplicateCrowdCount)
        this.activeIdea.originCrowdCount = Number(res.originCrowdCount)
      }).catch(error => {
        this.$message.error(error.message)
      })
    },
    formatTargetUser (dayTarget) {
      let desStr = ''
      if (dayTarget === -1) {
        desStr = '未激活用户'
      } else if (dayTarget !== 0) {
        desStr = `近${dayTarget}天沉默用户`
      }
      return desStr
    },
    async onSubmit () {
      const valid = await this.validate()
      if (valid) {
        this.showDetail = true
      } else {
        return Promise.reject(new Error('error.message'))
      }
    },
    _formatForm () {
      const activeIdea = this.activeIdea
      let pushStyle = ''
      let title = ''
      if (activeIdea.resourceType === 8) {
        pushStyle = 1
        title = activeIdea.titlePush
        activeIdea.image = ''
      } else if (activeIdea.resourceType === 9) {
        pushStyle = 0
        title = activeIdea.titleDesktop
      }
      let fromatIdea = {
        id: activeIdea.id,
        resourceType: activeIdea.resourceType,
        appId: activeIdea.appId,
        appPackageName: activeIdea.appPackageName,
        deepLink: activeIdea.deepLink,
        pushDate: this.pushDateNormal,
        pushCrowdSubDate: this.pushCrowdSubDateNormal,
        pushCrowdCount: activeIdea.pushCrowdCount,
        feeType: 0,
        price: activeIdea.price,
        transferRatio: activeIdea.transferRatio,
        pushStyle,
        title,
        content: activeIdea.content,
        image: activeIdea.image,
        pushAdName: activeIdea.pushAdName,
        crowdId: activeIdea.crowdId,
        originCrowdCount: activeIdea.originCrowdCount,
        originDuplicateCrowdCount: activeIdea.originDuplicateCrowdCount,
        expandContent: activeIdea.expandContent,
        expandImage: activeIdea.expandImage,
        blackImeiCrowd: activeIdea.blackImeiCrowd
      }
      return fromatIdea
    },
    onSave () {
      let formatForm = this._formatForm()
      if (this.fetching) return
      this.fetching = true
      if (this.action === 'new') {
        createPush(formatForm).then(res => {
          if (res.code === 200) {
            this.$message.success('提交成功')
            this.showDetail = false
            setTimeout(() => {
              this.$router.push({name: 'AdActive', query: { complete: true }})
            }, 2000)
          }
        }).catch(error => {
          this.$message.error(error.message)
        }).finally(() => {
          this.fetching = false
        })
      } else if (this.action === 'edit') {
        updatePush(formatForm).then(res => {
          if (res.code === 200) {
            this.$message.success('提交成功')
            this.showDetail = false
            setTimeout(() => {
              this.$router.push({name: 'AdActive', query: { complete: true }})
            }, 2000)
          }
        }).catch(error => {
          this.$message.error(error.message)
        }).finally(() => {
          this.fetching = false
        })
      }
    },
    onCancel () {
      this.$router.push({ name: 'AdActive' })
    },
    fetchPushDetail () {
      let pushId = this.$route.query.pushId
      if (pushId) {
        getPushDetail(pushId).then(res => {
          const pushDetail = res.value
          for (let key in pushDetail) {
            this.activeIdea[key] = pushDetail[key]
          }
          if (pushDetail.expandImage) {
            this.expandType = 'img'
          }
          this.activeIdea.pushCrowdCount = pushDetail.pushCrowdCount
          if (pushDetail.resourceType === 8) {
            this.activeIdea.titlePush = pushDetail.title
          } else if (pushDetail.resourceType === 9) {
            this.activeIdea.titleDesktop = pushDetail.title
          }
          this.activeIdea.pushDate = utils.formatDate(pushDetail.pushDate, 'yyyy-MM-dd HH:mm:ss')
          if (pushDetail.pushCrowdSubDate === 0) {
            this.activeIdea.pushCrowdSubDateType = 0
          } else {
            this.activeIdea.pushCrowdSubDateType = 1
          }
          this.activeIdea.crowdId = Number(res.originCrowdId)
          this.activeIdea.crowdCount = Number(res.originDuplicateCrowdCount)
          this.activeIdea.originDuplicateCrowdCount = Number(res.originDuplicateCrowdCount)
          this.activeIdea.originCrowdCount = Number(res.originCrowdCount)
        })
      }
    },
    onExpandTypeChanged () {
      if (this.expandType === 'text') {
        this.activeIdea.expandImage = ''
      } else if (this.expandType === 'img') {
        this.activeIdea.expandContent = ''
      }
    },
    onUploadError (err) {
      this.$message.error(err || '文件上传失败')
    },
    onUploadSuccess (res) {
      if (res.code === 200 && res.value.length > 0) {
        const url = '/upload/' + res.value[0].url
        this.activeIdea.expandImage = url
      } else {
        this.onUploadError(res.message)
      }
    },
    onUploadBefore (file) {
      const UPLOAD_LIMIT = 200
      const image = new Image()
      const isAllow = ['image/jpeg', 'image/png'].indexOf(file.type) > -1
      const isLtLimit = file.size / 1024 <= UPLOAD_LIMIT
      const limitSize = '700x400'
      return new Promise((resolve, reject) => {
        image.src = URL.createObjectURL(file)
        image.onload = () => {
          const size = `${image.width}x${image.height}`
          let msg = ''
          if (!isAllow) {
            msg = '图片只能是 jpg, png, jpeg 格式!'
            reject(new Error(msg))
          } else if (!isLtLimit) {
            msg = `图片大小不能超过 ${UPLOAD_LIMIT}KB!`
            reject(new Error(msg))
          } else if (size !== limitSize) {
            msg = `图片尺寸必须为${limitSize}`
            reject(new Error(msg))
          } else {
            resolve()
          }
          if (msg) {
            this.$message.error(msg)
          }
        }
      })
    },
    onRemoveImg () {
      this.activeIdea.expandImage = ''
    }
  },
  watch: {
    'activeIdea.resourceType' (val) {
      if (!val) return
      this.showSource = false
      this.getPushConfigPriceData(val)
      this.getPushConfigData(val, this.activeIdea.pushDate)
      this.$nextTick(() => {
        this.showSource = true
      })
    },
    'activeIdea.pushDate' (val) {
      this.getPushConfigData(this.activeIdea.resourceType, val)
    },
    'pushDateNormal' (val) {
      this.getPushCrowdIdAndCount(this.activeIdea.appPackageName, val, this.pushCrowdSubDateNormal)
    },
    'pushCrowdSubDateNormal' (val) {
      this.getPushCrowdIdAndCount(this.activeIdea.appPackageName, this.pushDateNormal, val)
      if ((val || val === 0) && this.action === 'new') {
        this.targetUser.every((item, idx) => {
          if (item.dayTarget === val) {
            this.activeIdea.price = item.price
            return false
          } else {
            return true
          }
        })
      }
    },
    '$route.query.pushId' (val) {
      this.pushId = val
      this.fetchPushDetail()
    },
    '$route.query.action' (val) {
      this.action = val
    },
    userInfo (val) {
      if (val.hasOwnProperty('status')) {
        this.$store.dispatch('getSlotBundleList')
      }
    }
  },
  created () {
    this.pushId = this.$route.query.pushId
    this.action = this.$route.query.action
    if (this.action === 'new') {
      this.activeIdea.resourceType = 8
    }
    this.fetchPushDetail()
    if (this.userInfo.hasOwnProperty('status')) {
      this.$store.dispatch('getSlotBundleList')
    }
    getBlacklistList({ pageNumber: 1, pageSize: 9999, name: '' }).then(res => {
      this.blacklistData = res.value.data || []
    })
  },
  components: {
    Preview
  }
}
</script>
<style lang="scss" scoped>
.deeplink-tip {
  display: inline-block;
  margin-left: -65px;
  margin-right: 47px;
  cursor: pointer;
}
.color-red {
  color: red;
}
.cost-tip {
  font-weight: 600;
}
.target-group {
  margin: 10px 0;
  width: 350px;
  border: 1px solid #eee;
  &__title {
    border-bottom: 1px solid #eee;
    text-align: center;
  }
  label {
    display: block;
    line-height: 35px;
    padding-left: 100px;
  }
  .el-radio+.el-radio {
    margin-left: 0;
  }
}
i[class^="push_icon"] {
  display: inline-block;
  vertical-align: middle;
  width: 22px;
  height: 22px;
  background-repeat:  no-repeat;
}
.push_icon {
  &1 {
    background-image: url('~assets/img/push-icon/push_icon1.png');
  }
  &2 {
    background-image: url('~assets/img/push-icon/push_icon2.png');
  }
  &3 {
    background-image: url('~assets/img/push-icon/push_icon3.png');
  }
  &4 {
    background-image: url('~assets/img/push-icon/push_icon4.png');
  }
  &5 {
    background-image: url('~assets/img/push-icon/push_icon5.png');
  }
}
.detail-dialog {
  .el-form-item {
    margin-bottom: 10px;
    word-wrap: break-word;
  }
  .font-bold {
    .el-form-item__label {
      font-weight: 600;
    }
  }
  &__tip {
    font-weight: 600;
    text-align: center;
    border-top: 1px solid #999;
    padding-top: 20px;
  }
}
</style>
