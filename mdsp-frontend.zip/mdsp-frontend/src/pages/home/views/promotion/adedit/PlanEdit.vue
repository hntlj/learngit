<template>
  <div>
    <div class="home-promotion__header inset-shadow">
      <h1 class="home-promotion__header--title">广告计划</h1>
      <small class="home-promotion__header--subtitle" v-if="plan && plan.planName">（{{ plan.planName }}）</small>
    </div>
    <el-menu class="home-adedit__tab" :default-active="tab+''" mode="horizontal" @select="toggleTab">
      <el-menu-item index="0">{{form.planId ? '修改' : '新建'}}计划</el-menu-item>
      <el-menu-item index="1">使用已有计划</el-menu-item>
    </el-menu>

    <el-card class="form-container" style="min-width:1100px;" v-loading="loading">
      <template v-if="!tab">
        <h3 class="form-title">推广目标</h3>
        <el-form ref="form1" :model="form" :rules="rules">
          <el-form-item prop="promotionTarget">
            <p class="form-row" v-for="pt in Object.values(PROMOTION_TARGET)" :key="pt.value">
              <el-radio v-model="form.promotionTarget" :label="pt.value" :disabled="!!form.planId">{{ pt.name }}</el-radio>
              <span class="form-tip">{{ pt.desc }}</span>
            </p>
          </el-form-item>
        </el-form>

        <h3 class="form-title">计划设置</h3>
        <el-form label-width="106px" label-position="left" :model="form" :rules="rules" ref="form2">
          <el-form-item label="预算" prop="budget" class="budget-error">
            <el-radio v-model="form.budgetFlag" :label="true">不限额</el-radio>
            <el-radio v-model="form.budgetFlag" :label="false">限额</el-radio>
            <el-input class="form-input--small" style="margin-left:24px;" v-model="form.budget" placeholder="预算金额" :disabled="form.budgetFlag"></el-input>
            <span class="form-input-append">元 / 天</span>
            <span class="form-warn" style="margin-left:60px;"><i class="el-icon-warning"></i>（由于用户行为和数据传输原因，实际消耗和预算可能存在一定的误差）</span>
          </el-form-item>
          <el-form-item label="计划名称" prop="planName" >
            <el-input class="form-input--medium" v-model="form.planName" placeholder="输入计划名称" :maxLength="30"></el-input>
          </el-form-item>
        </el-form>
      </template>
      <template v-else>
        <el-form label-width="0px" label-position="left" :model="form2" ref="form3">
          <el-form-item prop="planId" :rules="[{ required: true, message: '请选择广告计划' }]">
            <el-select v-model="form2.planId" placeholder="请选择已有计划" style="width:732px">
              <el-option v-for="plan in planList" :key="plan.id" :label="plan.name" :value="plan.id"></el-option>
            </el-select>
          </el-form-item>
        </el-form>
        <h3 class="form-title">推广目标</h3>
        <el-form label-width="0px" label-position="left">
          <el-input v-if="!plan.promotionTarget" value="未选择计划" disabled style="width:732px"></el-input>
          <el-form-item v-else :label="PROMOTION_TARGET[plan.promotionTarget].name" label-width="106px">
            <span class="form-tip" style="margin-left:0">{{ PROMOTION_TARGET[plan.promotionTarget].desc }}</span>
          </el-form-item>
        </el-form>
        <h3 class="form-title">计划设置</h3>
        <el-form label-width="106px" label-position="left">
          <el-form-item label="预算">
            <el-input :value="budgetText" disabled class="form-input--large"></el-input>
          </el-form-item>
        </el-form>
      </template>
      <el-row>
        <el-col :span="16">
          <el-button v-if="!tab" type="success" :loading="fetching" @click="onSave">保存</el-button>
          <el-button type="primary" class="el-button--submit" @click="onNext" :loading="fetching" :disabled="nextDisable && !!tab">{{ !tab ? '保存并' : '' }}下一步</el-button>
        </el-col>
        <el-col :span="8">
          <el-button @click="onCancel" class="pull-right">取消</el-button>
        </el-col>
      </el-row>
    </el-card>
  </div>
</template>
<script>
import { MAX_BUDGET, PROMOTION_TARGET } from '@/enums'
import { postPlan, getPlanDetail, getAllPlanList } from '@/api'
import validateMixin from '@/mixins/validate'
import utils from '@/utils'
export default {
  mixins: [validateMixin],
  data () {
    const onValidBudget = (rules, value, callback) => {
      if (!this.form.budgetFlag) {
        let tip = ''
        const sum = this.plan.cost + this.plan.configCost
        if (!utils.validateNum(value, 2)) {
          return callback(new Error('请输入正确金额，仅支持 2 位小数'))
        }
        if (value < 200) {
          tip = '200元'
        } else if (value < sum) {
          tip = '当前消耗'
        }
        const temp = sum < 200 ? 200 : sum
        if (value < temp) {
          return callback(new Error(`预算金额不能小于${tip}`))
        }
      }
      callback()
    }
    return {
      tab: 0,
      planList: [],
      form: {
        planId: '',
        promotionTarget: '',
        planName: '',
        budgetFlag: true,
        budget: ''
      },
      rules: {
        promotionTarget: [{ required: true, message: '请选择推广目的', trigger: 'blur' }],
        budget: [{ validator: onValidBudget, trigger: 'change' }],
        planName: [{ required: true, message: '请输入计划名称', trigger: 'blur' }]
      },
      form2: {
        planId: ''
      },
      plan1: {},
      plan2: {},
      fetching: false,
      PROMOTION_TARGET,
      nextDisable: true,
      loading: false
    }
  },
  computed: {
    plan () {
      return this.tab ? this.plan2 : this.plan1
    },
    budgetText () {
      const budget = this.plan.budget
      if (!budget) {
        return '未选择计划'
      }
      return budget >= MAX_BUDGET ? '不限额' : `限额 ${budget} 元 / 天`
    }
  },
  methods: {
    toggleTab () {
      this.tab = !this.tab * 1
      this.elForms.forEach(form => form.clearValidate())
    },
    setPlan (plan) {
      if (this.tab) {
        this.plan2 = plan
      } else {
        this.plan1 = plan
      }
    },
    onCancel () {
      this.$router.push({ name: 'AdPlan' })
    },
    onSave () {
      this.submit().then(plan => {
        this.setPlan(plan)
        this.$router.push({ name: 'AdEditPlan', query: { planId: plan.planId, s: 2 } })
      }).catch(_ => {})
    },
    onNext () {
      if (!this.tab) {
        this.submit().then(plan => {
          this.setPlan(plan)
          this.goToUnit()
        }).catch(_ => {})
      } else {
        this.validate().then(valid => {
          if (valid) {
            this.goToUnit()
          }
        })
      }
    },
    goToUnit () {
      this.$store.commit('setAdEditPlan', this.plan)
      this.$router.push({ name: 'AdEditUnit', query: { planId: this.plan.planId, unitId: this.$route.query.unitId, s: 1 } })
    },
    async submit () {
      const valid = await this.validate()
      if (valid) {
        this.fetching = true
        return this.savePlan()
      }
    },
    fetchPlanList () {
      getAllPlanList().then(planList => {
        this.planList = planList
      }).catch(error => {
        this.$message.error(error.message)
      })
    },
    fetchPlanDetail (planId) {
      return getPlanDetail(planId).then(plan => {
        this.setPlan(plan)
        this.loading = false
        this.nextDisable = false
        return plan
      }).catch(error => {
        this.$message.error(error.message)
      })
    },
    savePlan () {
      return postPlan(this._formatForm()).then(plan => {
        this.form.planId = plan.planId
        this.$message.success('保存成功')
        return plan
      }).catch(error => {
        this.$message.error(error.message)
        return Promise.reject(new Error(error.message))
      }).finally(() => {
        this.fetching = false
      })
    },
    init () {
      this.form.planId = this.$route.query.planId
      if (this.form.planId) {
        this.fetchPlanDetail(this.form.planId).then(plan => {
          this.plan1 = plan
          this.form = this._syncForm(plan)
        })
      } else {
        this.plan1 = {}
        this.elForms.forEach(form => form.resetFields())
      }
    },
    _formatForm () {
      let { planId, promotionTarget, planName, budgetFlag, budget } = this.form
      budget = budgetFlag ? MAX_BUDGET : budget
      return { planId, promotionTarget, planName, budget }
    },
    _syncForm (plan) {
      let { planId, promotionTarget, planName, budget } = plan
      let budgetFlag = budget >= MAX_BUDGET
      budget = budgetFlag ? '' : budget
      return { planId, promotionTarget, planName, budgetFlag, budget }
    }
  },
  watch: {
    // 'form2.planId': 'fetchPlanDetail',
    'form2.planId' (val) {
      // this.plan.planId = val
      this.loading = true
      this.nextDisable = true
      this.fetchPlanDetail(val)
    },
    'form.promotionTarget' (val) {
      if (val) {
        this.setStep(2)
      } else {
        this.setStep(1)
      }
    },
    '$route.query.planId' () {
      this.init()
    },
    'form.budgetFlag' (val) {
      if (val) this.form.budget = ''
    }
  },
  mounted () {
    this.init()
    this.fetchPlanList()
  }
}
</script>
<style lang="scss">
.budget-error .el-form-item__error {
  left: 220px;
}
</style>
