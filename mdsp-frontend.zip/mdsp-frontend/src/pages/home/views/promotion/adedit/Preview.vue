<template>
  <div class="preview-wrap" :class="previewClass"></div>
</template>
<script>
import { mapGetters } from 'vuex'
export default {
  props: {
    assetType: String,
    sb: [Number, String]
  },
  computed: {
    ...mapGetters(['slotBundle']),
    previewClass () {
      if (!this.slotBundle || !this.sb) {
        return ''
      }
      let value = ''
      if (this.sb === 8 || this.sb === 9) {
        value = this.sb
      } else {
        value = this.slotBundle[Number(this.sb)].value
      }
      const imgClassMap = new Map([
        [1, 'banner_img'],
        [2, () => {
          if (['muti_img', 'main_img', 'icon_img', 'video_cover'].indexOf(this.assetType) > -1) {
            return this.assetType
          }
          return 'main_img'
        }],
        [3, 'search_img'],
        [4, 'appstore_img'],
        [5, 'welfare_img'],
        [6, () => {
          if (this.assetType === 'main_img') {
            return 'media_one'
          } else {
            return 'media_three'
          }
        }],
        [7, 'screen_img'],
        [8, 'push_img'],
        [9, 'desktop_img']
      ])
      let imgClass = imgClassMap.get(value)
      if (typeof imgClass === 'function') {
        imgClass = imgClassMap.get(value).call(this)
      }
      return imgClass
    }
  }
}
</script>
<style lang="scss">
.preview-wrap {
  position: absolute;
  top: 24px;
  left: 881px;
  width: 160px;
  height: 310px;
  background: url('~assets/img/preview/wrap.png') no-repeat;

  &:after {
    content: '';
    display: block;
    width: 154px;
    height: 276px;
    margin: 17px 3px;
  }

  &.muti_img:after {
    background: url('~assets/img/preview/multi_img.png') no-repeat;
  }
  &.main_img:after {
    background: url('~assets/img/preview/main_img.png') no-repeat;
  }
  &.icon_img:after {
    background: url('~assets/img/preview/icon_img.png') no-repeat;
  }
  &.banner_img:after {
    background: url('~assets/img/preview/banner.png') no-repeat;
  }
  &.welfare_img:after {
    background: url('~assets/img/preview/welfare.png') no-repeat;
  }
  &.search_img:after {
    background: url('~assets/img/preview/search.png') no-repeat;
  }
  &.appstore_img:after {
    background: url('~assets/img/preview/appstore.png') no-repeat;
  }
  &.screen_img:after {
    background: url('~assets/img/preview/screen.png') no-repeat;
  }
  &.video_cover:after {
    background: url('~assets/img/preview/video_img.png') no-repeat;
  }
  &.media_one:after {
    background: url('~assets/img/preview/media1.png') no-repeat;
  }
  &.media_three:after {
    background: url('~assets/img/preview/media3.png') no-repeat;
  }
  &.push_img:after {
    background: url('~assets/img/preview/push.png') no-repeat;
  }
  &.desktop_img:after {
    background: url('~assets/img/preview/desktop.png') no-repeat;
  }
}
</style>
