<template>
  <div>
    <div class="home-promotion__header inset-shadow">
      <h1 class="home-promotion__header--title">广告单元</h1>
      <small class="home-promotion__header--subtitle" v-if="plan && plan.planName">（{{ title }}）</small>
    </div>
    <el-card class="form-container" style="min-width:1100px;position: relative;">
      <preview :sb="form.slotBundle" style="margin-top:24px"/>
      <h3 class="form-title">广告类型</h3>
      <el-form :model="form" ref="form1" :rules="rules">
        <el-form-item prop="slotBundle">
          <p class="form-row">
            <span class="form-col w200 color-gray">名称</span>
            <span class="form-col w200 color-gray">创意规格</span>
            <span class="form-col color-gray">资源描述</span>
          </p>
          <p class="form-row" :class="{'color-blue': form.slotBundle === slot.id}"
            v-for="slot in slotBundleList" :key="slot.value"
            v-if="((slot.value < 3 || slot.value ===7 ) || plan.promotionTarget === 1) && (!form.unitId || slot.id === form.slotBundle)">
            <span class="form-col w200"><el-radio v-model="form.slotBundle" :label="slot.id">{{slot.name}}</el-radio></span>
            <span class="form-col w200">{{slot.size}}</span>
            <span class="form-col">{{slot.desc}}</span>
          </p>
        </el-form-item>
      </el-form>
      <el-form ref="form3" :model="form" :rules="rules" label-width="136px" label-position="left" v-if="plan.promotionTarget === 1">
        <h3 class="form-title">应用设置</h3>
        <el-form-item prop="packageName" label="应用包名">
          <el-autocomplete
            class="inline-input"
            v-model="form.packageName"
            :fetch-suggestions="querySearch"
            placeholder="请输入应用包名"
            @blur = 'handlePackageNameBlur'
            :disabled="isComplete || unit.isComplete"
          ></el-autocomplete>
          <img v-if="appInfo" class="el-form-item__icon" :src="appInfo.icon"> {{ appInfo && appInfo.name }}
          <el-popover class="game-tip" trigger="hover" placement="top" :diabled="true"  v-if="appInfo && appInfo.categoryId === 2">
            <p class="refusal-reason">游戏广告带来的用户付费收入，分成比例为 9：1。联系对接商务了解更多，联系邮箱：ad@meizu.com</p>
            <div slot="reference">
              <span class="money-icon">￥</span>
            </div>
          </el-popover>
        </el-form-item>
        <el-form-item v-if="!userInfo.whiteList.tx_game" label="应用渠道包">
          <el-select v-model="form.channelPackageId" @change="getDownloadUrl">
            <el-option :label="`选择应用渠道包`" :value='this.defaultId'></el-option>
            <el-option v-for="opt in dataList" :label="opt.appChannelName" :value="opt.id" :key="opt.id || opt.appId"></el-option>
          </el-select>
          <div>选填，不填则默认下载魅族官方包</div>
        </el-form-item>
        <el-form-item v-if="userInfo.whiteList.tx_game" prop="downloadUrl" label="下载地址">
          <el-input class="form-input--large" placeholder="输入下载地址" v-model="form.downloadUrl"></el-input>
        </el-form-item>
        <el-form-item v-if="userInfo.whiteList.tx_game" prop="txTrackParam" label="上报参数">
          <el-input type="textarea"
            :rows="4"
            class="form-input--large"
            placeholder="一行一个。示例：gid=10086"
            v-model="form.txTrackParam"></el-input>
        </el-form-item>
      </el-form>
      <h3 class="form-title">定向设置
        <!-- <small v-if="showTarget">当前覆盖人群约 <em class="color-blue">{{coverCount}}</em></small> -->
      </h3>
      <el-form label-width="106px" label-position="left" v-if="tagList">
        <el-form-item label="投放日期">
          <el-radio v-model="form.dateRangeFlag" :label="true">从今天开始长期投放</el-radio>
          <el-radio v-model="form.dateRangeFlag" :label="false">设置开始和结束时间</el-radio>
          <el-date-picker style="margin-left:24px;"
            v-model="form.dateRange"
            :disabled="form.dateRangeFlag"
            type="daterange"
            range-separator="-"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            :picker-options="pickerOptions">
          </el-date-picker>
        </el-form-item>
        <el-form-item label="投放时段" style="margin-bottom:22px;">
          <el-radio v-model="form.timeSegFlag" :label="false">全时段</el-radio>
          <el-radio v-model="form.timeSegFlag" :label="true">分时段</el-radio>
          <el-time-grid v-if="form.timeSegFlag" v-model="form.timeSeg"></el-time-grid>
        </el-form-item>
        <el-form-item label="自定义人群" style="margin-bottom:22px;" v-if="form.slotBundle == 4 && userInfo.whiteList.mstore_crowd">
          <el-radio v-model="form.crowdFlag" :label="false">不限定</el-radio>
          <el-radio v-model="form.crowdFlag" :label="true">自定义人群</el-radio>
          <el-tree-transfer v-show="form.crowdFlag" label="定向人群列表" ref="tree-transfer3" :deepth="1" :data-list="tagList[TAG_TYPE.crowdTag]" :default-checked-keys="form.defaultCrowds" @change="onCrowdTagChange"></el-tree-transfer>
        </el-form-item>
        <template v-if="showTarget">
          <el-form-item label="性别" style="margin-bottom:22px;">
            <el-radio-group v-model="target[TAG_TYPE.sexTag]">
              <el-radio :label="null">不限定</el-radio>
              <el-radio v-for="item in tagList[TAG_TYPE.sexTag]" :key="item.value" :label="item">{{item.name}}</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item label="年龄" style="margin-bottom:22px;">
            <el-radio v-model="form.ageFlag" :label="false">不限定</el-radio>
            <el-radio v-model="form.ageFlag" :label="true">特定年龄</el-radio>
            <div class="form-item__content">
              <el-checkbox-group v-show="form.ageFlag" v-model="target[TAG_TYPE.ageTag]">
                <el-checkbox v-for="item in tagList[TAG_TYPE.ageTag]" :key="item.value" :label="item">{{item.name}}</el-checkbox>
              </el-checkbox-group>
            </div>
          </el-form-item>
          <el-form-item label="地域" style="margin-bottom:22px;">
            <el-radio v-model="form.cityFlag" :label="false">不限定</el-radio>
            <el-radio v-model="form.cityFlag" :label="true">特定地域</el-radio>
            <el-tree-transfer v-show="form.cityFlag" label="地域列表" ref="tree-transfer1" :deepth="2" :data-list="tagList[TAG_TYPE.cityTag]" :default-checked-keys="form.defaultCities" @change="onCityTagChange"></el-tree-transfer>
          </el-form-item>
          <el-form-item label="网络" style="margin-bottom:22px;">
            <el-radio-group v-model="target[TAG_TYPE.netTag]">
              <el-radio :label="null">不限定</el-radio>
              <el-radio v-for="item in tagList[TAG_TYPE.netTag]" :key="item.value" :label="item">{{item.name}}</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item label="自定义人群" style="margin-bottom:22px;">
            <el-radio v-model="form.crowdFlag" :label="false">不限定</el-radio>
            <el-radio v-model="form.crowdFlag" :label="true">自定义人群</el-radio>
            <el-tree-transfer v-show="form.crowdFlag" label="定向人群列表" ref="tree-transfer3" :deepth="1" :data-list="tagList[TAG_TYPE.crowdTag]" :default-checked-keys="form.defaultCrowds" @change="onCrowdTagChange"></el-tree-transfer>
          </el-form-item>
          <el-form-item label="兴趣" style="margin-bottom:22px;">
            <el-radio v-model="form.interestFlag" :label="false">不限定</el-radio>
            <el-radio v-model="form.interestFlag" :label="true">特定兴趣</el-radio>
            <el-tree-transfer v-show="form.interestFlag" label="兴趣列表" ref="tree-transfer2" :deepth="3" :data-list="tagList[TAG_TYPE.interestTag]" :default-checked-keys="form.defaultInterest" @change="onInterestTagChange"></el-tree-transfer>
          </el-form-item>
          <el-form-item label="应用安装" style="margin-bottom:22px;" v-if="plan.promotionTarget === 1">
            <el-tooltip content="指定投放目标群体为已安装或未安装投放应用" placement="bottom" effect="light"
              style="margin-left: -42px; margin-right: 24px;">
              <i class="el-icon-question"></i>
            </el-tooltip>
            <el-radio-group v-model="target[TAG_TYPE.installTag]">
              <el-radio :label="null">不限定</el-radio>
              <el-radio v-for="item in tagList[TAG_TYPE.installTag]" :key="item.value" :label="item">{{item.name}}</el-radio>
            </el-radio-group>
          </el-form-item>
        </template>
      </el-form>
      <h3 class="form-title">单元名称
        <el-form ref="form2" :model="form" :rules="rules" style="display:inline-block;">
          <el-form-item prop="unitName" class="unitName-error">
            <el-input class="form-input--large" style="margin-left:18px;" placeholder="输入单元名称" v-model="form.unitName"></el-input>
          </el-form-item>
        </el-form>
      </h3>
      <el-row>
        <el-col :span="16">
          <el-button type="success" :loading="fetching" @click="onSave">保存</el-button>
          <el-button type="primary" class="el-button--submit" @click="onNext" :loading="fetching">保存并下一步</el-button>
        </el-col>
        <el-col :span="8">
          <el-button @click="onCancel" class="pull-right">取消</el-button>
        </el-col>
      </el-row>
    </el-card>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import { getPlanDetail, getUnitDetail, postUnit, getUnitTagList, getUnitTargetingCount, getAppDetail, getAppChannelList } from '@/api'
import validateMixin from '@/mixins/validate'
import { SLOT_BUNDLE, TAG_TYPE } from '@/enums'
import utils from '@/utils'
import storage from '@/utils/storage'
import Preview from './Preview'
const TEN_YEARS = 86400 * 3650 * 1000
export default {
  mixins: [validateMixin],
  data () {
    let recentPackageNames = storage.get('recentPackageNames')
    return {
      SLOT_BUNDLE,
      TAG_TYPE,
      form: {
        unitId: this.$route.query.unitId || '',
        planId: this.$route.query.planId,
        slotBundle: '',
        unitName: '',
        ageFlag: false,
        cityFlag: false,
        defaultCities: [],
        crowdFlag: false,
        defaultCrowds: [],
        interestFlag: false,
        defaultInterest: [],
        timeSegFlag: false,
        timeSeg: '',
        dateRangeFlag: true,
        dateRange: [],
        packageName: '',
        downloadUrl: '',
        txTrackParam: '',
        channelPackageId: ''
      },
      pickerOptions: {
        disabledDate (time) {
          return time.getTime() > Date.now() + TEN_YEARS || time.getTime() < Date.now() - 86400000
        }
      },
      target: {
        [TAG_TYPE.sexTag]: null,
        [TAG_TYPE.ageTag]: [],
        [TAG_TYPE.cityTag]: [],
        [TAG_TYPE.interestTag]: [],
        [TAG_TYPE.netTag]: null,
        [TAG_TYPE.installTag]: null,
        [TAG_TYPE.crowdTag]: []
      },
      targetCoverParams: {
        sex_tag: '',
        age_tag: '',
        city_tag: ''
      },
      coverCount: '--',
      rules: {
        slotBundle: [{ required: true, message: '请选择广告类型', trigger: 'change' }],
        unitName: [{ required: true, message: '请输入单元名称', trigger: 'change' }],
        packageName: [{ required: true, message: '请输入正确的应用包名', trigger: 'change' }]
      },
      fetching: false,
      recentPackageNames: recentPackageNames ? JSON.parse(recentPackageNames) : [],
      appInfo: null,
      isComplete: false,
      searchFormData: {
        channelPackageName: '',
        appPackageName: '',
        status: 1,
        pageNumber: '',
        pageSize: ''
      },
      dataList: [],
      defaultId: 0
    }
  },
  computed: {
    ...mapGetters(['userInfo', 'adEdit', 'tagList', 'slotBundle']),
    plan () {
      return this.adEdit.plan
    },
    unit () {
      return this.adEdit.unit
    },
    title () {
      const planName = this.plan.planName
      const unitName = (this.unit && this.unit.unitName) || ''
      if (unitName) {
        return [planName, unitName].join(' - ')
      }
      return planName
    },
    slotBundleList () {
      return Object.values(this.slotBundle || []).sort((a, b) => a.value > b.value)
    },
    showTarget () {
      const slotBundleId = this.form.slotBundle
      return slotBundleId && this.slotBundle && this.slotBundle[slotBundleId] && (this.slotBundle[slotBundleId].value < 3 || this.slotBundle[slotBundleId].value === 7)
    }
  },
  methods: {
    querySearch (queryString, cb) {
      let recentPackageNames = this.recentPackageNames
      let results = queryString ? recentPackageNames.filter(this.createFilter(queryString)) : recentPackageNames
      cb(results)
    },
    createFilter (queryString) {
      return (recentPackageNames) => {
        return (recentPackageNames.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0)
      }
    },
    handlePackageNameBlur () {
      setTimeout(() => {
        if (!this.form.packageName) {
          this.appInfo = null
          return
        }
        this.getAppDetailFn()
      }, 200)
    },
    onSave () {
      this.submit().then(unit => {
        this.$store.commit('setAdEditUnit', unit)
        this.$router.push({ name: 'AdEditUnit', query: { planId: this.plan.planId, unitId: this.unit.unitId, s: this.$route.query.s } })
      }).catch(error => {
        this.$message.error(error)
      })
    },
    onNext () {
      this.submit().then(unit => {
        this.$store.commit('setAdEditUnit', unit)
        this.$router.push({ name: 'AdEditIdea', query: { planId: this.plan.planId, unitId: this.unit.unitId, s: 1 } })
      }).catch(_ => {})
    },
    onCancel () {
      this.$router.push('/')
    },
    onCityTagChange (value) {
      this.target[TAG_TYPE.cityTag] = value
    },
    onInterestTagChange (value) {
      this.target[TAG_TYPE.interestTag] = value
    },
    onCrowdTagChange (value) {
      this.target[TAG_TYPE.crowdTag] = value
    },
    async submit () {
      const valid = await this.validate()
      if (valid) {
        this.fetching = true
        return this.saveUnit()
      }
    },
    handleClear (ref) {
      this.$refs[ref].handleClear()
    },
    saveUnit () {
      return postUnit(this._formatForm()).then(unit => {
        this.form.unitId = unit.unitId
        this.$message.success('保存成功')
        return unit
      }).catch(error => {
        this.$message.error(error.message)
        return Promise.reject(new Error(error.message))
      }).finally(() => {
        this.fetching = false
      })
    },
    fetchPlanDetail () {
      if (!this.plan || this.plan.planId !== this.$route.query.planId) {
        getPlanDetail(this.$route.query.planId).then(plan => {
          this.$store.commit('setAdEditPlan', plan)
        })
      }
    },
    fetchUnitDetail () {
      if (!this.unit || this.unit.unitId !== this.$route.query.unitId) {
        getUnitDetail(this.$route.query.unitId).then(unit => {
          const target = {
            [TAG_TYPE.sexTag]: null,
            [TAG_TYPE.ageTag]: [],
            [TAG_TYPE.cityTag]: [],
            [TAG_TYPE.interestTag]: [],
            [TAG_TYPE.netTag]: null,
            [TAG_TYPE.installTag]: null,
            [TAG_TYPE.crowdTag]: []
          }
          this.$store.commit('setAdEditUnit', unit)
          this.form = this._syncForm(unit)
          this.isComplete = unit.isComplete
          unit.unitTargeting.forEach(({type, content: value}) => {
            if (value) {
              if (type === TAG_TYPE.sexTag) {
                target[type] = this.tagList[type].filter(o => value === o.value)[0]
              } else if (type === TAG_TYPE.ageTag) {
                target[type] = this.tagList[type].filter(o => ~value.indexOf(o.value))
                this.form.ageFlag = true
              } else if (type === TAG_TYPE.cityTag) {
                const allCity = this.tagList[type].reduce((c, a, i) => c.concat(a.children.map(child => ({ id: child.tagId, name: child.label, value: child.value, treeId: child.id }))), [])
                target[type] = allCity.filter(o => ~value.split(',').indexOf(o.name))
                this.form.cityFlag = true
                this.form.defaultCities = target[type].map(tag => tag.treeId)
              } else if (type === TAG_TYPE.interestTag) {
                const allInterest = this.tagList[type].reduce((c, a, i) => c.concat(a.children.reduce((cc, aa) => cc.concat(aa.children.map(child => ({ id: child.tagId, value: child.value, treeId: child.id }))), [])), [])
                target[type] = allInterest.filter(o => ~value.split(',').indexOf(o.value))
                this.form.interestFlag = true
                this.form.defaultInterest = target[type].map(tag => tag.treeId)
              } else if (type === TAG_TYPE.netTag) {
                target[type] = this.tagList[type].filter(o => value === o.value)[0]
              } else if (type === TAG_TYPE.installTag) {
                target[type] = this.tagList[type].filter(o => value === o.value)[0]
              } else if (type === TAG_TYPE.crowdTag) {
                const allCrowd = this.tagList[type].map(list => ({ id: list.id, value: list.value, name: list.label }))
                target[type] = allCrowd.filter(o => ~value.split(',').indexOf(o.value))
                this.form.crowdFlag = true
                this.form.defaultCrowds = target[type].map(tag => tag.id)
              }
            }
          })
          this.target = target
          if (unit.packageName) {
            this.getAppDetailFn()
          }
        })
      }
    },
    getAppChannelList () {
      const data = utils.deepCopy(this.searchFormData)
      data.appPackageName = this.form.packageName
      getAppChannelList({
        ...data
      }).then(res => {
        if (res.code === 200) {
          this.dataList = res.value.data
        }
      }).finally(() => {
        this.fetching = false
      })
    },
    getDownloadUrl (e) {
      if (e) {
        this.form.downloadUrl = this.dataList.find(item => item.id === e).downloadUrl
      } else {
        this.form.downloadUrl = ''
      }
    },
    fetchTagList () {
      return new Promise((resolve) => {
        getUnitTagList().then(tagList => {
          this.$store.commit('setTagList', tagList)
          resolve()
        })
      })
    },
    fetchTargetCount (params) {
      getUnitTargetingCount(params).then(count => {
        this.coverCount = count
      })
    },
    _formatForm () {
      const reg = /0{42}/
      const planId = this.plan.planId
      let unitTargeting = ''
      let { unitId, unitName, slotBundle, timeSeg, timeSegFlag, dateRangeFlag, dateRange, packageName, downloadUrl, txTrackParam, channelPackageId } = this.form
      let [startTime, endTime] = dateRangeFlag ? [-1, -1] : dateRange.map(d => utils.formatDate(d))
      if (slotBundle < 3 || slotBundle === 7 || slotBundle === 4) {
        unitTargeting = JSON.stringify(this._formatTarget())
      }
      timeSeg = timeSegFlag && !reg.test(timeSeg) ? timeSeg : -1
      return { planId, unitId, unitName, slotBundle, unitTargeting, timeSeg, startTime, endTime, packageName, downloadUrl, txTrackParam, channelPackageId }
    },
    _formatTarget () {
      return Object.keys(this.target).map(type => {
        const value = this.target[type] ? this.target[type].map ? this.target[type].reduce((c, a) => c.concat(a.value), []) : [this.target[type].value] : ['']
        return {
          type,
          value: value.join ? value.join(',') : value
        }
      })
    },
    _syncForm (unit) {
      let { planId, unitId, unitName, slotBundle, timeSeg, startTime, endTime, packageName, downloadUrl, txTrackParam, channelPackageId } = unit
      let [timeSegFlag, ageFlag, cityFlag, crowdFlag, interestFlag, dateRangeFlag] = [!!timeSeg, false, false, false, false, !startTime && !endTime]
      let dateRange = [startTime || '', endTime || '']
      if (txTrackParam) txTrackParam = txTrackParam.replace(/,/g, '\n')
      return { planId, unitId, unitName, slotBundle, timeSeg, timeSegFlag, ageFlag, cityFlag, crowdFlag, interestFlag, dateRangeFlag, dateRange, packageName, downloadUrl, txTrackParam, channelPackageId }
    },
    getAppDetailFn () {
      this.getAppChannelList() // 根据包名请求渠道包
      getAppDetail({ packageName: this.form.packageName }).then(res => {
        if (res.code === 200 && res.value) {
          this.appInfo = res.value
          this.form.packageName = res.value.packageName
          let packageNames = storage.get('recentPackageNames')
          if (packageNames) {
            packageNames = JSON.parse(packageNames)
          } else {
            packageNames = []
          }
          if (packageNames.length) {
            for (let i = packageNames.length - 1; i >= 0; i--) {
              if (packageNames[i].value === this.form.packageName) return
            }
          }
          packageNames.unshift({ value: this.form.packageName })
          packageNames = packageNames.slice(0, 5)
          storage.set('recentPackageNames', JSON.stringify(packageNames))
          this.recentPackageNames = packageNames
        } else {
          this.appInfo = null
          this.form.packageName = ''
          this.$message.error('请输入正确的应用包名')
        }
      })
    }
  },
  watch: {
    'form.slotBundle' (value) {
      if (value) {
        this.setStep(3)
      } else {
        this.setStep(1)
      }
    },
    target: {
      handler: function (value, oldValue) {
        if (value) {
          const params = {
            sex_tag: value[TAG_TYPE.sexTag] ? value[TAG_TYPE.sexTag].id : '',
            age_tag: value[TAG_TYPE.ageTag].map(tag => tag.id).join(','),
            city_tag: value[TAG_TYPE.cityTag].map(tag => tag.id).join(','),
            interest_tag: value[TAG_TYPE.interestTag].map(tag => tag.value).join(','),
            net_tag: value[TAG_TYPE.netTag] ? value[TAG_TYPE.netTag].id : '',
            install_tag: value[TAG_TYPE.installTag] ? value[TAG_TYPE.installTag].id : '',
            crowd_tag: value[TAG_TYPE.crowdTag].map(tag => tag.id).join(',')
          }
          if (JSON.stringify(this.targetCoverParams) !== JSON.stringify(params)) {
            this.targetCoverParams = params
          }
        }
      },
      deep: true
    },
    targetCoverParams: 'fetchTargetCount',
    'form.ageFlag' (val) {
      if (!val) {
        this.target[TAG_TYPE.ageTag] = []
      }
    },
    'form.cityFlag' (val) {
      if (!val) {
        this.target[TAG_TYPE.cityTag] = []
        this.handleClear('tree-transfer1')
      }
    },
    'form.interestFlag' (val) {
      if (!val) {
        this.target[TAG_TYPE.interestTag] = []
        this.handleClear('tree-transfer2')
      }
    },
    'form.crowdFlag' (val) {
      if (!val) {
        this.target[TAG_TYPE.crowdTag] = []
        this.handleClear('tree-transfer3')
      }
    }
  },
  created () {
    this.$store.dispatch('getSlotBundleList')
    this.fetchPlanDetail()
    this.fetchTagList().then(() => {
      this.fetchUnitDetail()
    })
  },
  components: {
    Preview
  }
}
</script>
<style lang="scss">
.unitName-error .el-form-item__error {
  margin-left: 18px;
}
.game-tip {
  display: inline-block;
  .money-icon {
    font-size: 20px;
    color: gold;
    vertical-align: middle;
    cursor: pointer;
  }
}
</style>
