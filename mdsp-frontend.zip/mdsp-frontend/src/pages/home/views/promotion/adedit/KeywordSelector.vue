<template>
  <div class="keyword-selector">
    <span class="keyword" v-for="kw in value" :key="kw.id">{{ kw.name }} <i class="el-icon-close" @click="onRemovePackage(kw)"></i></span>
    <el-button plain @click="selectVisible = true">使用现有词包</el-button>
    <el-button plain @click="currKeyword = {}">新建词包</el-button>
    <el-dialog :visible.sync="selectVisible" width="462px">
      <div class="keyword-box">
        <h3>已有词包</h3>
        <div class="keyword-package">
          <el-checkbox-group v-model="checked">
            <el-checkbox v-for="keyword in keywordList" :key="keyword.id" :label="keyword" :title="keyword.keywords">{{ keyword.name }}</el-checkbox>
          </el-checkbox-group>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="onCancel">取消</el-button>
        <el-button type="primary" @click="onSelect">保存</el-button>
      </span>
    </el-dialog>
    <keyword-creator @refetch="fetchKeywordList" :keyword.sync="currKeyword"></keyword-creator>
  </div>
</template>
<script>
import { getKeywordList } from '@/api'
import KeywordCreator from '@/components/home/KeywordCreator'
export default {
  props: {
    value: Array,
    packageId: Array
  },
  data () {
    return {
      selectVisible: false,
      createVisible: false,
      keywordList: [],
      checked: [],
      tmpChecked: [],
      currKeyword: null
    }
  },
  methods: {
    onSelect () {
      this.$emit('input', this.checked)
      this.selectVisible = false
    },
    onCancel () {
      this.checked = []
      this.selectVisible = false
    },
    onRemovePackage (kw) {
      const index = this.checked.indexOf(kw)
      if (index > -1) {
        this.checked.splice(index, 1)
        this.$emit('input', this.checked)
      }
    },
    fetchKeywordList (newValue) {
      this.tmpChecked.push(newValue)
      getKeywordList({
        pageNumber: 1,
        pageSize: 9999
      }).then(res => {
        if (res.code === 200) {
          this.keywordList = res.value.data.map(({ id, name, keywords }) => {
            return {
              id,
              name,
              keywords: keywords.map(kw => kw.keyword).join('、')
            }
          })
          var checkedIds = this.checked.map(kw => kw.id)
          this.checked = this.keywordList.filter(kw => ~this.packageId.indexOf(kw.id) || ~this.tmpChecked.indexOf(kw.id) || ~checkedIds.indexOf(kw.id))
          this.$emit('input', this.checked)
        }
      })
    }
  },
  watch: {
    packageId (val) {
      this.checked = this.keywordList.filter(kw => ~val.indexOf(kw.id))
      this.$emit('input', this.checked)
    }
  },
  created () {
    this.fetchKeywordList()
  },
  components: {
    KeywordCreator
  }
}
</script>
<style lang="scss">
.keyword-selector {
  max-width: 640px;
  margin-bottom: -24px;
  .el-dialog__body {
    overflow: hidden;
  }
  .keyword {
    display: inline-block;
    margin-bottom: 24px;
    margin-right: 24px;
    background: #eee;
    border: 1px solid #ddd;
    border-radius: 4px;
    padding: 0 12px;
    .el-icon-close {
      cursor: pointer;
      margin-left: 24px;
      display: inline-block;
      text-align: center;
      border-radius: 4px;
      width: 16px;
      height: 16px;
      font-size: 12px;
      line-height: 16px;
      color: #fff;
      background-color: #ccc;
    }
    &-box {
      h3 {
        font-size: 18px;
        line-height: 1;
        margin-bottom: 24px;
      }
    }
    &-package {
      border: 1px solid #ccc;
      border-radius: 4px;
      padding: 16px;
      max-height: 300px;
      overflow: auto;
      .el-checkbox {
        display: block;
        width: 200px;
      }
      .el-checkbox+.el-checkbox {
        margin-left: 0;
      }
    }
  }
}
</style>
