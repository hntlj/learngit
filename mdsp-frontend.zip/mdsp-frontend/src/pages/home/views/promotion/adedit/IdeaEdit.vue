<template>
  <div>
    <div class="home-promotion__header inset-shadow">
      <h1 class="home-promotion__header--title">广告创意</h1>
      <small class="home-promotion__header--subtitle" v-if="plan.planName">（{{ title }}）</small>
    </div>
    <el-tabs type="card" class="adedit-tabs" v-model="activeTab" @tab-click="handlerTabClick">
      <el-tab-pane v-for="(idea, idx) in ideaList" :key="idx" :name="`tab${idx+1}`">
        <span slot="label" :index="idx"><span>{{ idea.name || '创意' }}</span> <i class="el-icon-circle-close" v-if="ideaList.length > 1" @click.stop="onRemove(idx)"></i></span>
        <el-card class="form-container" style="min-width:1100px;position: relative;overflow: visible;">
          <preview :sb="unit.slotBundle" :asset-type="currSpec && currSpec.key" style="margin-top:24px"/>
          <el-form label-width="126px" label-position="left" :model="idea" :ref="`form_${idx}`">
            <el-form-item label="创意样式">
              <el-radio-group v-if="assetList.length > 1" v-model="idea.specIdx" @change="onAssetsChanged">
                <el-radio-button v-for="(asset, idx) in assetList" :key="asset.id" :label="idx">{{ asset.name }}</el-radio-button>
              </el-radio-group>
              <span v-else-if="slotBundle && slotBundle[unit.slotBundle]">{{ slotBundle[unit.slotBundle].name }}</span>
            </el-form-item>
            <template v-if="assetList.length > 0 && currSpec.assets">
              <el-form-item label="创意素材" prop="assetsImgs">
                <div>
                  <el-upload drag action="/common/upload" :show-file-list="false" style="display: inline-block;margin-right: 20px"
                    v-for="(img, _idx) in currSpec.assets" :key="_idx"
                    :on-error="onUploadError()"
                    :on-success="onUploadSuccess(_idx)"
                    :before-upload="onUploadBefore()">
                    <div v-if="idea.assetsImgs && idea.assetsImgs[currSpec.key] && idea.assetsImgs[currSpec.key][_idx]" class="el-upload__preview">
                      <img :src="currAssetsImgs(idx)[_idx]">
                      <span @click.stop="onRemoveImg(_idx, $event)"><i class="el-icon-close"></i></span>
                    </div>
                    <div class="el-upload__placeholder" v-else>
                      <i class="el-icon-uploader"></i>
                      <div class="el-upload__text"><em>点击上传{{currSpec.key === 'video_cover' ? '视频封面图' : '图片'}}</em></div>
                    </div>
                  </el-upload>
                  <div class="el-form-item__tip assets-imgs-tip">建议图片尺寸为 {{currSpec.imgWidth}}x{{currSpec.imgHeight}}，格式为 jpg、png、jpeg 并且大小在 {{imgSpace}}k 以内{{unit.slotBundle === 7 ? '，图片从底部往上75dp不要放文字与按钮，在非全面屏上会遮挡' : ''}}。</div>
                </div>
                <div v-if="currSpec.video">
                  <el-upload drag action="/common/uploadVideo" style="display: inline-block;margin-right: 20px"
                    :data="{ ideaIdentify: idea.ideaIdentify }"
                    ref="videoUpload"
                    :on-error="onUploadError()"
                    :on-success="onUploadSuccess(1, 'video')"
                    :before-upload="onUploadBefore('video')"
                    :limit="1">
                    <div v-if="idea.assetsImgs && idea.assetsImgs[currSpec.key] && idea.assetsImgs[currSpec.key][1]" class="el-upload__preview">
                      <video ref controls name="media" style="width: 180px;height: 100px;" v-if="showVideo" @playing="onVideoPlaying(idea.ideaIdentify)">
                        <source :src="currAssetsImgs(idx)[1]" type="video/mp4">
                      </video>
                      <span @click.stop="onRemoveImg(1, $event)"><i class="el-icon-close"></i></span>
                    </div>
                    <div class="el-upload__placeholder" v-else>
                      <i class="el-icon-uploader"></i>
                      <div class="el-upload__text"><em>点击上传视频</em></div>
                    </div>
                  </el-upload>
                  <div class="el-form-item__tip assets-imgs-tip">尺寸比例16:9，分辨率不小于 {{currSpec.videoWidth}}x{{currSpec.videoHeight}}，格式为MP4，50M以内，时长5-30s，建议15s以内。</div>
                </div>
              </el-form-item>
            </template>
          </el-form>
          <template v-if="currSpec">
            <el-form label-width="126px" label-position="left" :model="idea" :ref="`form2_${idx}`">
              <el-form-item label="创意标题" v-if="currSpec.titleLen && dyncCtrl.data[idx]" prop="assetsTitle" :rules="[{ required: true, message: '请输入创意标题' },{validator: (rule, value, callback) => {checkLegal(idx, 'assetsTitle', value, callback)}, trigger: 'change'},{validator: (rule, value, callback) => {checkLegal(idx, 'assetsTitle', value, callback)}, trigger: 'blur'},{max: currSpec.titleLen - dyncCtrl.data[idx].assetsTitle.diffLen, message: `创意标题不能大于${currSpec.titleLen}字`, trigger: 'change'}, {min: currSpec.titleMinLen - dyncCtrl.data[idx].assetsTitle.diffLen, message: `创意标题不能小于${currSpec.titleMinLen}字`, trigger: 'change'}]" :data-max="currSpec.titleLen - dyncCtrl.data[idx].assetsTitle.diffLen">
                <el-input :ref="`assetsTitle_${idx}`" v-if="currSpec.titleLen" v-model="checkAssetsTitle" class="form-input--large" style="width:516px;" :placeholder="`${currSpec.titleMinLen} ~ ${currSpec.titleLen} 个字以内`" @click.native="e => getCursorIndex(e.target, 'assetsTitle')" @cut.native.capture.prevent="e => false" @dragstart.native.capture.prevent="e => false"  :suffix-icon="dyncCtrl.data[idx].assetsTitle.loading ? 'el-icon-loading' : ''" />
                  <span v-text="getWordLimit(idx, 'assetsTitle', currSpec.titleLen)"></span>
                <dynamic-line @setDynamicPkg="(v) => setDynamicPkg(v, 'assetsTitle', idea)"/>
              </el-form-item>
              <el-form-item label="创意描述" v-if="currSpec.descLen && dyncCtrl.data[idx]" prop="assetsDesc" :rules="[{ required: true, message: '请输入创意描述' },{validator: (rule, value, callback) => {checkLegal(idx, 'assetsDesc', value, callback)}, trigger: 'change'}, {validator: (rule, value, callback) => {checkLegal(idx, 'assetsDesc', value, callback)}, trigger: 'blur'}, {max: currSpec.descLen - dyncCtrl.data[idx].assetsDesc.diffLen, message: `创意描述不能大于${currSpec.descLen}字`, trigger: 'change'}, {min: currSpec.descMinLen - dyncCtrl.data[idx].assetsDesc.diffLen, message: `创意描述不能小于${currSpec.descMinLen}字`, trigger: 'change'}]" :data-min="currSpec.descMinLen - dyncCtrl.data[idx].assetsDesc.diffLen">
                <el-input :ref="`assetsDesc_${idx}`" v-if="currSpec.descLen" v-model="checkAssetsDesc" class="form-input--large" style="width:516px;" :placeholder="`${currSpec.descMinLen} ~ ${currSpec.descLen} 个字以内`" @click.native="e => getCursorIndex(e.target, 'assetsDesc')" @cut.native.capture.prevent="e => false" @dragstart.native.capture.prevent="e => false" :suffix-icon="dyncCtrl.data[idx].assetsDesc.loading ? 'el-icon-loading' : ''"/>
                <span v-text="getWordLimit(idx, 'assetsDesc', currSpec.descLen)"></span>
                <dynamic-line :autoGet="false" @setDynamicPkg="(v) => setDynamicPkg(v, 'assetsDesc', idea)" />
              </el-form-item>
              <el-form-item label="行动按钮" v-if="currSpec.actionButton" prop="assetsActBtn" :rules="[{ required: !!currSpec.actionButton, message: '请选择行动按钮', trigger: 'change' }]">
                <el-select v-model="idea.assetsActBtn" @change="onAssetsChanged" placeholder="请选择行动按钮">
                  <el-option
                    v-for=" item in actionsList"
                    :key="item.value"
                    :label="item.name"
                    :value="item.value">
                  </el-option>
                </el-select>
                <p class="el-form-item__tip" v-if ="plan.promotionTarget === 1 && idea.assetsActBtn === 'VIEW_DETAIL'">用户点击查看详情会跳转落地页。</p>
              </el-form-item>
            </el-form>
          </template>
          <el-form label-width="126px" label-position="left" :model="idea" :rules="rules" :ref="`form3_${idx}`">
            <el-form-item label="优化目标" v-if="unit.slotBundle !== 7" prop="ocpcType">
              <el-radio v-if="plan.promotionTarget === 1" v-model="idea.ocpcType" :label="OCPC_TYPE.INSTALL" @change="handleBidType">下载
                <el-popover
                  placement="bottom-start"
                  width="240"
                  trigger="hover">
                  <div class="popoverRule">
                    1.暂时只支持下载类投放；<br>
                    2.根据【转化】竞价，系统会根据目标出价进行流量控制，建议出价参考以往实际转化效果；<br>
                    3.根据【转化】出价，结算方式仍是CPC结算，结算公式为: <img src="~assets/img/formula.jpg">
                  </div>
                  <i class="icon-question" slot="reference" v-show="compareSlotBundle(unit.slotBundle, 3) === 1"></i>
                </el-popover>
              </el-radio>
              <el-radio v-if="compareSlotBundle(unit.slotBundle, 3) === 1" v-model="idea.ocpcType" :label="OCPC_TYPE.CLICK" @change="handleBidType">点击</el-radio>
            </el-form-item>
            <el-form-item label="计费类型">
              <span v-if="unit.slotBundle !== 7">{{ bidTypeText }}</span>
              <el-form-item v-else prop="bidType">
                <el-radio-group v-model="idea.bidType" @change="handleBidType">
                  <el-radio :label="BID_TYPE.CPM">展示扣费(CPM)</el-radio>
                  <el-radio :label="BID_TYPE.CPC">点击扣费(CPC)</el-radio>
                </el-radio-group>
              </el-form-item>
            </el-form-item>
            <el-form-item label="创意出价" prop="bidPrice" :rules="{ validator: onValidPrice(idx), trigger: 'change' }">
              <el-input class="form-input--large" :placeholder="bidPricePlaceholder" v-model="idea.bidPrice"></el-input>
              <el-popover
                placement="top-start"
                width="100"
                trigger="hover">
                <div class="popoverRule">创意出价为平台智能匹配出价</div>
                <i class="icon-question" slot="reference"></i>
              </el-popover>
            </el-form-item>
            <el-form-item label="创意名称" prop="name" :rules="{ required: true, message: '请输入创意名称' }">
              <el-input class="form-input--large" v-model="idea.name"></el-input>
            </el-form-item>
            <el-form-item label="Deeplink" v-if="plan.promotionTarget === 2" prop="landingPage.schema">
              <el-popover class="deeplink-tip" trigger="hover" placement="top" :diabled="true">
                <p class="refusal-reason">填写应用直达链接，指定点击广告可直达的应用内详情页。</p>
                <div slot="reference" class="name-wrapper">
                  <p style="white-space: nowrap;"><i class="el-icon-question"></i></p>
                </div>
              </el-popover>
              <el-input class="form-input--large" v-model="idea.landingPage.schema" :disabled="unit.slotBundle !== 7 && currOcpcType === 2" placeholder="非必填"></el-input>
              <p v-show="currOcpcType === 2">若优化目标为下载，则不支持使用应用内打开功能</p>
            </el-form-item>
          </el-form>

          <template v-if="plan.promotionTarget === 1">
            <h3 class="form-title">应用设置</h3>
            <el-form label-width="126px" label-position="left" :model="idea" :ref="`form4_${idx}`">
              <el-form-item label="应用包名" prop="landingPage.packageName" :rules="{ validator: onValidApp(idx), trigger: 'blur' }">
                <el-input class="form-input--large" style="width:580px" v-model="idea.landingPage.packageName" placeholder="请输入应用包名" :disabled="true"></el-input>
                <img v-if="appInfo" class="el-form-item__icon" :src="appInfo.icon"> {{ appInfo && appInfo.name }}
                <el-popover class="game-tip" trigger="hover" placement="top" :disabled="true"  v-if="appInfo && appInfo.categoryId === 2">
                  <p class="refusal-reason">游戏广告带来的用户付费收入，分成比例为 9：1。联系对接商务了解更多，联系邮箱：ad@meizu.com</p>
                  <div slot="reference">
                    <span class="money-icon">￥</span>
                  </div>
                </el-popover>
              </el-form-item>
              <el-form-item label="Deeplink" prop="landingPage.schema">
                <el-popover class="deeplink-tip" trigger="hover" placement="top" :diabled="true">
                  <p class="refusal-reason">填写应用直达链接，指定点击广告可直达的应用内详情页。</p>
                  <div slot="reference" class="name-wrapper">
                    <p style="white-space: nowrap;"><i class="el-icon-question"></i></p>
                  </div>
                </el-popover>
                <el-input class="form-input--large" v-model="idea.landingPage.schema" :disabled="unit.slotBundle !== 7 && currOcpcType === 2" placeholder="非必填"></el-input>
                <p v-show="unit.slotBundle !== 7 && currOcpcType === 2">若优化目标为下载，则不支持使用应用内打开功能</p>
              </el-form-item>
              <el-form-item v-if="userInfo.whiteList" prop="downloadUrl" label="下载地址">
                <el-input class="form-input--large" :disabled="true" v-model="idea.downloadUrl"></el-input>
              </el-form-item>
            </el-form>
          </template>

          <template v-if="compareSlotBundle(unit.slotBundle, 3) === 1 || compareSlotBundle(unit.slotBundle, 7) === 0">
            <h3 class="form-title">落地页设置</h3>
            <el-form label-width="126px" label-position="left" :model="idea" :rules="rules" :ref="`form5_${idx}`">
              <template>
                <el-form-item label="落地页类型">
                  <el-radio-group v-model="idea.landingPage.lpSource" :max="1">
                    <el-radio-button :label="1">平台落地页</el-radio-button>
                    <el-radio-button :label="2">自定义</el-radio-button>
                    <el-radio-button :label="0" :disabled="lpScDefDisabled || plan.promotionTarget !== 1">商店默认</el-radio-button>
                  </el-radio-group>
                  <el-button class="el-button--preview" plain v-show="idea.landingPage.lpSource !== 0 && (idea.landingPage.lpId || idea.landingPage.cpLpUrl)" @click="onPreview">效果预览</el-button>
                </el-form-item>
                <el-form-item label="平台落地页" v-if="idea.landingPage.lpSource === 1" prop="landingPage.lpId" key="lpId">
                  <landing-page-selector v-model="idea.landingPage.lpId" :package-name="idea.landingPage.packageName" />
                  <el-button type="text" @click="onEdit({id:''}, 'new')">新建落地页
                    <el-popover
                      placement="top-start"
                      width="200"
                      trigger="hover"
                      content="可到“工具箱”-“落地页模板”编辑落地页。">
                      <i class="icon-question" slot="reference"></i>
                    </el-popover>
                  </el-button>
                </el-form-item>
                <template v-if="idea.landingPage.lpSource === 2">
                  <el-form-item label="落地页链接" prop="landingPage.cpLpUrl" key="cpLpUrl">
                    <el-input class="form-input--large" v-model="idea.landingPage.cpLpUrl" placeholder="广告目标链接，限定 https 链接"></el-input>
                  </el-form-item>
                  <el-form-item label="下载按钮位置" v-if="plan.promotionTarget === 1">
                    <el-radio v-model="idea.landingPage.btnLocation" :label="0">页面底部</el-radio>
                    <el-radio v-model="idea.landingPage.btnLocation" :label="1">页面顶部</el-radio>
                  </el-form-item>
                  <el-form-item label="按钮文案" v-if="plan.promotionTarget === 1">
                    <el-input class="form-input--medium" v-model="idea.landingPage.btnText" placeholder="2-4 个字，不填则为“ 安装 ”"></el-input>
                  </el-form-item>
                </template>
              </template>
              <!--<el-form-item label="落地页链接" v-if="plan.promotionTarget === 2" prop="landingPage.url">
                <el-input class="form-input--large" v-model="idea.landingPage.url" placeholder="广告目标链接，限定 https 链接" @input="updateStatus"></el-input>
              </el-form-item>-->
            </el-form>
            <h3 class="form-title">监控设置（非必填）<i style="font-size:20px;font-weight:700;color:rgba(0,0,0,.4)" :class="`el-icon-arrow-${showMonitor ? 'up' : 'down'}`" @click="showMonitor=!showMonitor"></i></h3>
            <el-form label-width="126px" label-position="left" :model="idea" class="animated-slide" :rules="rules" :ref="`form7_${idx}`" :class="{slide: showMonitor}">
              <el-form-item label="点击监控" prop="clickMonitorUrls">
                <el-input class="form-input--large" v-model="idea.clickMonitorUrls" placeholder="点击监控地址"></el-input>
              </el-form-item>
              <el-form-item style="margin-bottom:22px;" label="展示监控" prop="impMonitorUrls">
                <el-input class="form-input--large" v-model="idea.impMonitorUrls" placeholder="展示监控地址"></el-input>
              </el-form-item>
              <div >
                <el-checkbox-group v-model="idea.sponsorTrackParams" v-if="isShowCheck" style="padding-left:125px; display: inline-block">
                  <el-checkbox v-for="(item, index) in allSponsorParams" :label="item.name" :key="index">{{item.desc}}</el-checkbox>
                </el-checkbox-group>
                <el-tooltip v-if="isShowCheck" style="display: inline-block" placement="bottom" effect="light">
                      <div slot="content">
                        示例<br/>
                        广告主监控地址为http://meizu.com/exposure/idea/1001/<br/>
                        广告主勾选了回传参数为imei_md5，<br/>
                        则最终上报的监控地址为<br/>
                        http://meizu.com/exposure/idea/1001/?<span style="color: red;">planId=1&unitId=2&ideaId=3&imei_md5=14e1b600b1fd579f47433b88e8d85291</span><br/>
                        红字部分为广告平台添加<br/>
                        其中planId为广告计划id、unitId为广告单元id、ideaId为广告创意id、imei_md5为用户imei的md5值
                      </div>
                  <i class="el-icon-question"></i>
                </el-tooltip>
              </div>
            </el-form>
          </template>
          <template v-if="compareSlotBundle(unit.slotBundle, [3, 6]) === 0">
            <h3 class="form-title">添加关键词（可选）</h3>
            <el-form label-width="126px" label-position="left" :model="idea" :ref="`form6_${idx}`">
              <el-form-item label="添加关键词">
                <el-input class="form-input--large" style="width:350px" v-model="searchKeys.addinput" @keyup.enter.native="addSearchKey"></el-input>
                <el-button type="primary" @click="addSearchKey" >添加</el-button>
                <el-select v-model="keywordPackage" placeholder="请选择">
                  <el-option
                    v-for="keyword in keywordPackageList"
                    :key="keyword.kwPackageName"
                    :label="keyword.kwPackageName"
                    :value="keyword.kwPackageName"
                  ></el-option>
                </el-select>
                <div class="el-form-item__tip"></div>
              </el-form-item>
              <el-form-item label="已添加关键词" style="width: 770px;">
                <el-input class="form-input--large" style="width:416px" v-model="tmpseacrhkey"></el-input>
                <el-button type="primary" @click="doFilterKeys">查询</el-button>
                <el-button type="primary" style="margin-left: 20px;" @click="showAddKwPackage=true">保存为新词包</el-button>
                <template>
                  <el-table
                    :data="currKeysList"
                    @selection-change="handleKyesSelectionChange"
                    border
                    style="width: 640px;margin-top: 10px;"
                    max-height="400">
                    <el-table-column
                      type="selection"
                      width="50">
                    </el-table-column>
                    <el-table-column
                      fixed
                      prop="kw"
                      label="关键词"
                      width="180">
                    </el-table-column>
                    <el-table-column
                      label="关键词热度"
                      width="170">
                      <template slot-scope="scope">
                        <el-rate
                          v-model="scope.row.hot2"
                          disabled
                          show-score
                          allow-half
                          :score-template="`${scope.row.hot}`"
                          :max="5"
                          text-color="#ff9900"
                          :colors="['#99A9BF', '#F7BA2A', '#FF9900']">
                        </el-rate>
                      </template>
                    </el-table-column>
                    <el-table-column
                      label="精准匹配出价（元）"
                      width="130">
                      <template slot-scope="scope">
                        <el-form-item prop="price" :rules="{validator: onValidKeyPrice(idx, scope.row.price), trigger: 'blur'}">
                          <el-input type="number" v-model="scope.row.price" :placeholder="`不低于${getKwBasePrice().minPrice}`"></el-input>
                        </el-form-item>
                      </template>
                    </el-table-column>
                    <el-table-column
                      label="操作"
                      width="108">
                      <template slot-scope="scope">
                        <el-button
                          @click.native.prevent="deleteRow(scope.row)"
                          type="text"
                          size="small">
                          移除
                        </el-button>
                      </template>
                    </el-table-column>
                  </el-table>
                  <div class="el-form-item__tip">最多添加50个搜索热词</div>
                  <div style="width: 100%;margin-top: 20px">
                    <span >{{searchKeys.multipleSelection.length}}/<span :class="{ red: currKeysList.length > 50 }">{{currKeysList.length}}</span></span>
                    <div style="float: right">
                      价格：
                      <el-input
                        type="number"
                        label="属性方式："
                        style="width: 120px;margin-right: 4px;"
                        :placeholder="`不低于${getKwBasePrice().minPrice}`"
                        v-model="searchKeys.unifyP">
                      </el-input>
                      <el-button type="primary" @click="unifyPrice">统一出价</el-button>
                      <el-button @click="delKeys">删除</el-button>
                    </div>
                  </div>
                  </template>
              </el-form-item>
            </el-form>
          </template>
          <el-row>
            <el-col :span="16">
              <el-button type="success" :loading="fetching" @click="onSave">保存</el-button>
              <el-button type="primary" class="el-button--submit" :loading="fetching" @click="onComplete">完成</el-button>
            </el-col>
            <el-col :span="8">
              <el-button @click="onCancel" class="pull-right">取消</el-button>
            </el-col>
          </el-row>
        </el-card>
      </el-tab-pane>
      <el-tab-pane v-if="ideaList.length < 5">
        <span @click.stop="copyIdea" slot="label"><i class="el-icon-plus"></i>新增</span>
      </el-tab-pane>
    </el-tabs>
    <el-dialog custom-class="dialog-preview" title="效果预览" :visible.sync="showPreview">
      <div class="preview-wrapper" v-loading="previewLoading">
        <div class="video-img" v-if="previewClass"><img :src="currIdeeCoverUrl" alt=""></div>
        <iframe :class="{ 'iframe-short': previewClass }" ref="previewIframe" src="about:blank" @load="previewLoading = false" v-show="!previewLoading"></iframe>
      </div>
    </el-dialog>
    <el-dialog :visible.sync="showAddKwPackage" title="新建词包" width="500px">
      <el-form label-width="106px">
        <el-form-item label="词包名称">
          <el-input type="text" v-model="addKwPackageName"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="showAddKwPackage = false">取消</el-button>
        <el-button type="primary" @click="saveKwsToPackage" :disabled="!addKwPackageName">保存</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import { BID_TYPE, OCPC_TYPE, ACTION_BUTTON, HOST } from '@/enums'
import {
  getUnitDetail, getPlanDetail, getIdeaListByUnitId, getSpecList,
  getAdvicePrice, getBidcostFloor, getAppDetail, postIdea, getKwHot,
  getKeywordPackageList, getKeywordList, postKeyword, getAllSponsorParams, getDynamicList} from '@/api'
import utils from '@/utils'
import { schemaValidator, httpsValidator, httpValidator, bidPriceValidator, kwPriceValidator } from '@/validators/idea'
import validateMixin from '@/mixins/validate'
import Preview from './Preview'
import KeywordSelector from './KeywordSelector'
import LandingPageSelector from '@/components/home/LandingPageSelector'
import DynamicLine from '@/components/func/DynamicLine'
export default {
  mixins: [validateMixin],
  data () {
    const onValidApp = function (form, rule, value, callback) {
      if (!value) {
        form.appInfo = null
        return callback(new Error('请输入应用包名'))
      }
      if (form.appInfo && form.appInfo.packageName.toUpperCase() === value.toUpperCase()) {
        callback()
      } else {
        getAppDetail({ packageName: value }).then(res => {
          if (res.code === 200 && res.value) {
            form.appInfo = res.value
            form.landingPage.application_id = form.appInfo.id
            callback()
          } else {
            form.appInfo = null
            form.landingPage.application_id = ''
            callback(new Error('应用中心没有找到该应用,请检查您输入的包名'))
          }
        })
      }
    }
    return {
      activeTab: 'tab1',
      ideaList: [{
        status: 0,
        specIdx: 0,
        assets: '',
        assetsBak: '',
        specificationId: '',
        assetsImgs: {},
        assetsTitle: '',
        assetsDesc: '',
        assetsActBtn: '',
        keywordType: 1,
        keywords: [],
        packageId: [],
        ocpcType: '',
        bidType: 1,
        bidPrice: '',
        name: '创意',
        appInfo: null,
        landingPage: {
          application_id: 0,
          packageName: '',
          lpSource: 1,
          lpId: '',
          cpLpUrl: '',
          btnLocation: 0,
          btnText: '',
          schema: '',
          url: ''
        },
        clickMonitorUrls: '',
        impMonitorUrls: '',
        fetchUnitDetailAgain: true,
        keyWordPrices: [],
        downloadUrl: '',
        ideaIdentify: this.getRandom(),
        sponsorTrackParams: []
      }],
      ideaListCopy: [],
      rules: {
        ocpcType: [{ required: true, message: '请选择优化目标', trigger: 'change' }],
        clickMonitorUrls: [
          { validator: httpValidator.bind(this), trigger: 'change' }
        ],
        impMonitorUrls: [
          { validator: httpValidator.bind(this), trigger: 'change' }
        ],
        'landingPage.lpId': [{ required: true, message: '请选择落地页模板', trigger: 'blur' }],
        'landingPage.cpLpUrl': [
          { required: true, message: '请输入落地页链接' },
          { validator: httpsValidator.bind(this), trigger: 'change' }
        ],
        'landingPage.schema': [{ validator: schemaValidator.bind(this), trigger: 'change' }],
        'landingPage.url': [
          { required: true, message: '请输入落地页链接' },
          { validator: httpsValidator.bind(this), trigger: 'change' }
        ]
      },
      assetList: [],
      advicePrice: {
        click: 0,
        install: 0
      },
      bidPriceFloor: {
        downloadPrice: {
          floorPrice: 0.5,
          kwFloorPrice: 0.5
        },
        clickPrice: {
          floorPrice: 0.5,
          kwFloorPrice: 0.5
        },
        cpmPrice: {
          floorPrice: 0.5
        }
      },
      showMonitor: false,
      fetching: false,
      showPreview: false,
      previewLoading: true,
      onValidApp: idx => onValidApp.bind(this, this.ideaList[idx]),
      onValidPrice: idx => bidPriceValidator.bind(this, this.ideaList[idx]),
      onValidKeyPrice: (idx, val) => kwPriceValidator.bind(this, this.ideaList[idx], val),
      OCPC_TYPE,
      BID_TYPE,
      ideaNum: 0,
      currTabIndex: 0,
      searchKeys: {
        addinput: '',
        seacrhkey: '',
        tempkeys: {},
        multipleSelection: [],
        unifyP: '',
        inputlock: false
      },
      tmpseacrhkey: '',
      packageName: '',
      applicationId: '',
      appInfo: null,
      currOcpcType: '',
      keywordPackage: '',
      keywordPackageList: [],
      showAddKwPackage: false,
      addKwPackageName: '',
      allSponsorParams: [],
      isShowCheck: false,
      showVideo: false,
      videoInfo: null,
      previewClass: false,
      dyncCtrl: {
        data: [{
          assetsTitle: {
            index: 0,
            loading: false,
            diffLen: 0,
            errMsg: ''
          },
          assetsDesc: {
            index: 0,
            loading: false,
            diffLen: 0,
            errMsg: ''
          }
        }],
        dyncUseList: [],
        unDyncStrList: [],
        timer: null
      }
    }
  },
  computed: {
    ...mapGetters(['userInfo', 'adEdit', 'specList', 'slotBundle', 'landingPageList', 'accountState']),
    plan () {
      return this.adEdit.plan
    },
    unit () {
      return this.adEdit.unit
    },
    title () {
      const planName = this.plan.planName
      const unitName = (this.unit && this.unit.unitName) || ''
      if (unitName) {
        return [planName, unitName].join(' - ')
      }
      return planName
    },
    currSpec () {
      return this.assetList[this.currIdea.specIdx] || null
    },
    lpScDefDisabled () {
      return this.currSpec && this.currSpec.key === 'video_cover'
    },
    currIdea () {
      return this.ideaList[this.activeTab.slice(3) - 1]
    },
    bidTypeText () {
      return this.compareSlotBundle(this.unit.slotBundle, 3) === 1 ? '点击扣费' : '下载扣费'
    },
    currKeysList () {
      let all = (this.ideaList[this.currTabIndex].keyWordPrices || []).concat(this.searchKeys.tempkeys[this.currTabIndex] || [])
      all.map((it, idx) => {
        it.idx = idx
        it.hot = it.hot || 0
        it.hot2 = it.hot / 2
        return it
      })
      let fkey = this.searchKeys.seacrhkey
      return fkey ? all.filter(item => item.kw.indexOf(fkey) > -1) : all
    },
    bidPricePlaceholder () {
      const ocpcTypeMap = new Map([
        [OCPC_TYPE.INSTALL, this.advicePrice.install],
        [OCPC_TYPE.CLICK, this.advicePrice.click],
        [OCPC_TYPE.CPM, this.advicePrice.cpm]
      ])
      let ocpcType = this.ideaList[this.currTabIndex].ocpcType
      let price = ''
      if (this.unit.slotBundle === 7) {
        ocpcTypeMap.set(OCPC_TYPE.CLICK, this.advicePrice.cpm_click)
        ocpcType = this.ideaList[this.currTabIndex].bidType
        price = ocpcTypeMap.get(ocpcType)
        price = price === '0.00' ? ocpcType ? this.bidPriceFloor.cpcPrice.floorPrice * 1.2 : this.bidPriceFloor.cpmPrice.floorPrice * 1.2 : price
      } else {
        price = ocpcTypeMap.get(ocpcType)
        price = price === '0.00' ? ocpcType === '1' ? this.bidPriceFloor.clickPrice.floorPrice * 1.2 : this.bidPriceFloor.downloadPrice.floorPrice * 1.2 : price
      }
      return price > 0 ? `建议出价 ${price}元` : ''
    },
    imgSpace () {
      return this.unit.slotBundle === 7
        ? 200
        : this.currSpec.key && this.currSpec.key === 'video_cover' ? 100 : 300
    },
    actionsList () {
      if (this.plan.promotionTarget === 2) {
        return ACTION_BUTTON.slice(0, 1)
      }
      return ACTION_BUTTON
    },
    currIdeeCoverUrl () {
      return JSON.parse(this.currIdea.assets).video.cover_url
    },
    getWordLimit () {
      return (idx, type, len) => {
        return `${this.currIdea[type].length + this.dyncCtrl.data[idx][type].diffLen}/${len}`
      }
    },
    checkAssetsTitle: {
      get () {
        return this.currIdea['assetsTitle'] || ''
      },
      set (val) {
        this.dyncTimer(300, () => {
          this.checkDyncValue(val, 'assetsTitle')
        })
      }
    },
    checkAssetsDesc: {
      get () {
        return this.currIdea['assetsDesc'] || ''
      },
      set (val) {
        this.dyncTimer(300, () => {
          this.checkDyncValue(val, 'assetsDesc')
        })
      }
    }
  },
  methods: {
    onUploadError (res, type) {
      return (err) => {
        if (type === 'video') {
          if (this.$refs.videoUpload) {
            this.$refs.videoUpload.forEach(item => {
              item.clearFiles()
            })
          }
        }
        this.$message.error((res && res.message) || err || '文件上传失败')
      }
    },
    onUploadSuccess (idx, type) {
      return (res, file) => {
        if (res.code === 200 && res.value.length > 0) {
          const url = '/upload/' + res.value[0].url
          if (type === 'video') {
            this.showVideo = TextTrackCue
            this.videoInfo = res.value[0]
            const ideaIdentify = this.videoInfo.ideaIdentify
            let changeIdea = null
            for (let i = 0; i < this.ideaList.length; i++) {
              if (ideaIdentify === this.ideaList[i].ideaIdentify) {
                changeIdea = this.ideaList[i]
                break
              }
            }
            if (changeIdea) {
              changeIdea.assetsImgs.video_cover = changeIdea.assetsImgs.video_cover || []
              changeIdea.assetsImgs.video_cover[1] = url
              this.showVideo = false
              this.$nextTick(() => {
                this.showVideo = true
              })
            }
            const videoUpload = this.$refs.videoUpload
            if (videoUpload) {
              for (let i = 0; i < videoUpload.length; i++) {
                if (ideaIdentify === videoUpload[i].data.ideaIdentify) {
                  videoUpload[i].clearFiles()
                  break
                }
              }
            }
            this.onVideoAssetsChanged()
          } else {
            this.currIdea.assetsImgs[this.currSpec.key] = this.currIdea.assetsImgs[this.currSpec.key] || []
            this.currIdea.assetsImgs[this.currSpec.key][idx] = url
            this.onAssetsChanged()
          }
          this.$forceUpdate()
        } else {
          this.onUploadError(res, type)()
        }
      }
    },
    onUploadBefore (fileType) {
      return (file) => {
        const UPLOAD_LIMIT = this.imgSpace
        const image = new Image()
        const isAllow = ['image/jpeg', 'image/png'].indexOf(file.type) > -1
        const isLtLimit = file.size / 1024 <= UPLOAD_LIMIT
        const limitSize = `${this.currSpec.imgWidth}x${this.currSpec.imgHeight}`
        if (fileType === 'video') {
          let videoMsg = ''
          if (file.type === 'video/mp4') {
            if (file.size > 1024 * 1024 * 50) {
              videoMsg = '视频大小不能超过50M'
            }
          } else {
            videoMsg = '请上传mp4格式的视频文件'
          }
          if (videoMsg) {
            this.$message.error(videoMsg)
            return false
          } else {
            return true
          }
        } else {
          return new Promise((resolve, reject) => {
            image.src = URL.createObjectURL(file)
            image.onload = () => {
              const size = `${image.width}x${image.height}`
              let msg = ''
              if (!isAllow) {
                msg = '图片只能是 jpg, png, jpeg 格式!'
                reject(new Error(msg))
              } else if (!isLtLimit) {
                msg = `图片大小不能超过 ${UPLOAD_LIMIT}KB!`
                reject(new Error(msg))
              } else if (size !== limitSize) {
                msg = `图片尺寸必须为${limitSize}`
                reject(new Error(msg))
              } else {
                resolve()
              }
              if (msg) {
                this.$message.error(msg)
              }
            }
          })
        }
      }
    },
    onRemoveImg (idx) {
      this.currIdea.assetsImgs[this.currSpec.key][idx] = ''
      if (this.currIdea.specIdx === 3) {
        this.videoInfo = null
      }
      this.onAssetsChanged()
      this.$forceUpdate()
    },
    onSave () {
      this.submit().then(() => {
        this.fetchIdeaList()
      }).catch(err => {
        console.log(err)
      })
    },
    onComplete () {
      this.submit().then(() => {
        this.$router.push({ name: 'AdAsset', query: { unitId: this.adEdit.unit.unitId, complete: true } })
      }).catch(err => {
        console.log(err)
      })
    },
    onCancel () {
      this.$router.push({ name: 'AdAsset', query: { unitId: this.adEdit.unit.unitId } })
    },
    onPreview () {
      let videoCoverImg = ''
      this.previewClass = false
      if (this.currIdea.specIdx === 3) {
        videoCoverImg = JSON.parse(this.currIdea.assets).video.cover_url
        if (!videoCoverImg) {
          return this.$message.error('请上传视频封面图')
        }
      }
      this.showPreview = true
      this.$nextTick(() => {
        let url
        const { lpSource, btnLocation, btnText, application_id: appId, cpLpUrl, lpId } = this.currIdea.landingPage
        if (lpSource === 2) {
          url = `https://i3.mzres.com/resources/appStore/landing-page/index.html?cpUrl=${cpLpUrl}&appId=${appId}&btnLocation=${btnLocation}&btnText=${btnText}`
          url += '&t=' + Date.now()
        } else if (lpSource === 1) {
          const landingPage = this.landingPageList.filter(lp => lp.id === lpId)[0]
          url = landingPage.url + '?t=' + Date.now()
        }
        if (videoCoverImg) {
          if (lpSource === 1) {
            if (/^http:\/\/e.res.flyme.cn/.test(videoCoverImg)) {
              url += `&videoCoverImg=${videoCoverImg}`
            } else {
              url += `&videoCoverImg=http://${HOST}${videoCoverImg}`
            }
          }
          if (lpSource === 2) {
            this.previewClass = true
          }
        }
        this.$refs.previewIframe.src = url
      })
    },
    onAssetsChanged () {
      const { key, imgWidth: w, imgHeight: h } = this.currSpec
      const url = this.currIdea.assetsImgs[key] && this.currIdea.assetsImgs[key].join(';')
      const assetsActBtn = this.currIdea.assetsActBtn
      let assets = {}
      if (key === 'video_cover') {
        const assetsImgs = this.currIdea.assetsImgs
        const assetsBak = this.currIdea.assetsBak && JSON.parse(this.currIdea.assetsBak)
        assets = {
          video: {
            cover_url: assetsImgs[key] && assetsImgs[key][0],
            play_url: assetsImgs[key] && assetsImgs[key][1],
            resolution: assetsBak.video && assetsBak.video.resolution,
            duration: assetsBak.video && assetsBak.video.duration,
            videoType: assetsBak.video && assetsBak.video.videoType
          },
          title: this.currIdea.assetsTitle
        }
        if (this.currIdea.landingPage.lpSource === 0) {
          this.currIdea.landingPage.lpSource = 1
        }
      } else {
        assets = {
          [this.currSpec.key]: {url, w, h},
          title: this.currIdea.assetsTitle
        }
      }
      assets.desc = this.currIdea.assetsDesc
      assets.action_button = {
        type: assetsActBtn
          ? assetsActBtn === 'VIEW_DETAIL' ? 'VIEW_DETAIL' : 'DOWNLOAD_OR_OPEN'
          : '',
        title: assetsActBtn
          ? (ACTION_BUTTON.filter(item => item.value === assetsActBtn))[0]['name']
          : ''
      }
      this.currIdea.assets = JSON.stringify(assets)
      this.currIdea.specificationId = this.currSpec.id
      this.updateStatus()
    },
    onVideoAssetsChanged () {
      const ideaIdentify = this.videoInfo.ideaIdentify
      let changeIdea = null
      for (let i = 0; i < this.ideaList.length; i++) {
        if (ideaIdentify === this.ideaList[i].ideaIdentify) {
          changeIdea = this.ideaList[i]
          break
        }
      }
      if (changeIdea) {
        let assets = JSON.parse(changeIdea.assets)
        let assetsVideo = {
          ...assets.video,
          resolution: this.videoInfo.resolution,
          duration: this.videoInfo.duration,
          videoType: this.videoInfo.videoType,
          play_url: this.videoInfo.url
        }
        assets.video = assetsVideo
        changeIdea.assets = JSON.stringify(assets)
        changeIdea.assetsBak = changeIdea.assets
      }
    },
    updateStatus () {
      this.currIdea.status = 1
    },
    onEdit (landingPage, action) {
      window.open(`http://${HOST}/site-pc/index.html#/?id=${landingPage.id}&action=${action}`, '_blank')
    },
    onRemove (idx) {
      this.$confirm('确定要删除该广告创意吗？', '', {
        type: 'warning'
      }).then(() => {
        this.removeIdea(idx)
      })
    },
    async submit () {
      const valid = await this.validate()
      // const svalid = this.seacrhKeysValidate()
      if (valid) {
        this.fetching = true
        return this.saveIdea()
      } else {
        return Promise.reject(new Error('error.message'))
      }
    },
    saveIdea () {
      let formatForm = this._formatForm()
      let ideasArr = JSON.parse(formatForm.ideasJson)
      ideasArr = ideasArr.map(item => {
        for (let i = 0; i < this.ideaListCopy.length; i++) {
          let list = this.ideaListCopy[i]
          if (this.plan.promotionTarget === 2) {
            item.landingPage.url = item.landingPage.cpLpUrl
          }
          if (item.ideaId === list.id) {
            if (item.assets && item.assets !== list.assets) {
              item.status = 1
              return item
            }
            for (let key in item.landingPage) {
              if (key === 'application_id' || key === 'packageName' || key === 'schema') continue
              if (item.landingPage[key] !== list.landingPage[key]) {
                item.status = 1
                return item
              }
            }
          }
        }
        return item
      })
      formatForm.ideasJson = JSON.stringify(ideasArr)
      return postIdea(formatForm).then(ideaIds => {
        this.$message.success('保存成功')
        // 重置本地
        this.searchKeys.tempkeys = {}
      }).catch(error => {
        this.$message.error(error.message)
        return Promise.reject(new Error(error.message))
      }).finally(() => {
        this.fetching = false
      })
    },
    currAssetsImgs (idx) {
      let idea = this.ideaList[idx]
      return idea.assetsImgs[this.currSpec.key] || []
    },
    fetchUnitDetail () {
      getUnitDetail(this.$route.query.unitId).then(unit => {
        this.$store.commit('setAdEditUnit', unit)
        this.onUnitFetched(unit)
      }).catch(error => {
        if (this.fetchUnitDetailAgain) {
          this.this.fetchUnitDetail()
          this.fetchUnitDetailAgain = false
        } else {
          this.$message.error(error.message)
        }
      })
    },
    fetchIdeaList () {
      const unitId = this.$route.query.unitId
      getIdeaListByUnitId(unitId).then(ideaList => {
        if (ideaList.length > 0) {
          this.ideaList = ideaList.map((idea, idx) => {
            if (this.$route.query.ideaId && idea.id === parseInt(this.$route.query.ideaId)) {
              this.activeTab = `tab${idx + 1}`
              this.currTabIndex = idx
            }
            return this._syncForm(idea, this.getRandom(), idx)
          })
          if (this.$route.query.create && this.ideaList.length < 5) {
            this.copyIdea()
          }
        } else {
          // 设置默认选中
          const ctInstall = this.plan.promotionTarget === 1
          const ctClick = this.compareSlotBundle(this.unit.slotBundle, 3) === 1
          const ctCpm = this.compareSlotBundle(this.unit.slotBundle, 7) === 0
          // 只有当前创意无值，是新建状态
          if (!this.ideaList[this.currTabIndex].ocpcType) {
            if (ctInstall || ctCpm) {
              this.ideaList[this.currTabIndex].ocpcType = OCPC_TYPE.INSTALL
            } else if (ctClick) {
              this.ideaList[this.currTabIndex].ocpcType = OCPC_TYPE.CLICK
            }
          }
        }
        this.ideaNum = ideaList.length
        this.ideaListCopy = utils.deepCopy(this.ideaList, [])
      })
    },
    fetchSpecStyle (slotBundle) {
      return getSpecList(slotBundle).then(specList => {
        this.assetList = specList
        this.$store.commit('setSpecList', {
          slotBundle: slotBundle,
          specList
        })
      })
    },
    fetchAdvicePrice () {
      const unitId = this.$route.query.unitId
      getAdvicePrice(unitId).then(res => {
        if (res.code === 200) {
          this.advicePrice = res.value
        }
      })
    },
    fetchBidcostFloor (slotBundleId) {
      // slotBundleId=7开屏广告
      if (slotBundleId === 7) {
        const currTabBidType = this.ideaList[this.currTabIndex].bidType
        getBidcostFloor({slotBundleId, bidType: currTabBidType, ocpcType: currTabBidType}).then(res => {
          if (currTabBidType === 0) {
            this.bidPriceFloor.cpmPrice = res
          } else if (currTabBidType === 1) {
            this.bidPriceFloor.cpcPrice = res
          }
        })
        return
      }
      if (slotBundleId === 2) {
        this.fetchAllSponsorParams()
      }
      const bidType = this.compareSlotBundle(slotBundleId, 3) === 1 ? BID_TYPE.CPC : BID_TYPE.CPD
      const download = getBidcostFloor({slotBundleId, bidType, ocpcType: OCPC_TYPE.INSTALL})
      const click = getBidcostFloor({slotBundleId, bidType, ocpcType: OCPC_TYPE.CLICK})
      Promise.all([download, click]).then(([downloadPrice, clickPrice]) => {
        this.bidPriceFloor.downloadPrice = downloadPrice
        this.bidPriceFloor.clickPrice = clickPrice
      })
    },
    fetchAllSponsorParams () {
      getAllSponsorParams().then(res => {
        if (res.code === 200 && res.value) {
          this.allSponsorParams = res.value
          this.isShowCheck = true
        } else {
          this.$message.error(res.message)
        }
      })
    },
    fetchAppDetail () {
      if (this.unit.packageName) {
        getAppDetail({ packageName: this.unit.packageName }).then(res => {
          if (res.code === 200 && res.value) {
            this.appInfo = res.value
            this.packageName = res.value.packageName
            this.applicationId = res.value.id
            this.ideaList[0].appInfo = res.value
            this.ideaList[0].landingPage.packageName = res.value.packageName
            this.ideaList[0].landingPage.applicationId = res.value.id
          } else {
            this.$message.error(res.message)
          }
        })
      }
    },
    fetchDynamicList (name) {
      return new Promise((resolve, reject) => {
        getDynamicList({ name: name, pageNumber: 1, pageSize: 10 }).then(res => {
          if (res.code === 200) {
            const data = res.value.data || []
            data.map(it1 => {
              let maxLen = 0;
              // 获取最长词的长度,计算词长度差
              (it1.keywords || []).map(it2 => {
                if (it2.length > maxLen) {
                  maxLen = it2.length
                }
              })
              it1.maxLen = maxLen
              it1.diffLen = maxLen - it1.name.length
              return it1
            })
            resolve(data)
          }
        }).catch(e => {
          reject(e)
        })
      })
    },
    onUnitFetched (unit) {
      this.fetchAppDetail()
      this.currIdea.name = `${unit.unitName}-${this.currIdea.name}`
      if (!this.plan || unit.planId !== this.plan.planId) {
        getPlanDetail(unit.planId).then(plan => {
          this.$store.commit('setAdEditPlan', plan)
        }).catch(error => {
          this.$message.error(error.message)
        })
      }
      if (!this.specList[unit.slotBundle]) {
        this.fetchSpecStyle(unit.slotBundle).then(() => {
          this.fetchIdeaList()
        })
      } else {
        this.assetList = this.specList[unit.slotBundle]
        this.fetchIdeaList()
      }

      this.fetchBidcostFloor(unit.slotBundle)
    },
    copyIdea () {
      const ideaTemplate = {
        status: 0,
        specIdx: 0,
        assets: '',
        assetsBak: '',
        specificationId: this.assetList[0].id,
        assetsImgs: {},
        assetsTitle: '',
        assetsDesc: '',
        assetsActBtn: '',
        keywordType: 1,
        keywords: [],
        ocpcType: this.ideaList[0].ocpcType,
        bidType: this.compareSlotBundle(this.unit.slotBundle, 3) === 1 || this.unit.slotBundle === 7 ? BID_TYPE.CPC : BID_TYPE.CPD,
        bidPrice: '',
        name: this.unit.unitName + '-创意' + (this.ideaList.length + 1),
        appInfo: this.appInfo,
        landingPage: {
          application_id: this.applicationId,
          packageName: this.packageName,
          lpSource: 1,
          lpId: '',
          cpLpUrl: '',
          btnLocation: 1,
          btnText: '',
          schema: '',
          url: ''
        },
        clickMonitorUrls: '',
        impMonitorUrls: '',
        keyWordPrices: [],
        downloadUrl: this.ideaList[0].downloadUrl,
        sponsorTrackParams: [],
        ideaIdentify: this.getRandom()
      }
      this.ideaList.push(ideaTemplate)
      this.activeTab = `tab${this.ideaList.length}`
      this.currTabIndex = this.ideaList.length - 1
      this.setDyncData('', '', this.currTabIndex)
    },
    removeIdea (idx) {
      this.activeTab = 'tab1'
      this.$nextTick(() => {
        this.currTabIndex = 0
        this.ideaList.splice(idx, 1)
        this.dyncCtrl.data.splice(idx, 1)
      })
    },
    init () {
      let unit = this.unit
      if (!unit || unit.unitId !== this.$route.query.unitId) {
        this.fetchUnitDetail()
      } else {
        this.onUnitFetched(unit)
      }
    },
    _syncForm (idea, ideaIdentify, index) {
      const landingPage = JSON.parse(idea.landingPage || '{}')
      const assetsType = this.assetList.map(asset => asset.key)
      const assetsObj = JSON.parse(idea.assets || '{}')
      let assetsImgs = {}
      let specIdx = 0
      let specificationId = idea.specificationId
      let bidType
      if (this.unit.slotBundle === 7) {
        bidType = idea.bidType
        idea.ocpcType = bidType
      } else {
        bidType = this.compareSlotBundle(this.unit.slotBundle, 3) === 1 ? BID_TYPE.CPC : BID_TYPE.CPD
      }
      if (assetsObj.hasOwnProperty('video')) {
        assetsObj.video_cover = {
          url: assetsObj.video.cover_url + ';' + assetsObj.video.play_url
        }
        this.showVideo = true
      }
      let actBtn = assetsObj.action_button && assetsObj.action_button.title
      if (actBtn) {
        ACTION_BUTTON.forEach(item => {
          if (actBtn === item.name) {
            actBtn = item.value
          }
        })
      }
      if (this.plan.promotionTarget === 2) {
        landingPage.cpLpUrl = landingPage.url
      }
      assetsType.forEach((key, idx) => {
        if (assetsObj[key]) {
          assetsImgs[key] = assetsObj[key].url.split(';')
          specIdx = idx
          specificationId = this.assetList[idx].id
        } else if (assetsType.length === 1) {
          specificationId = this.assetList[0].id
        }
      })
      const ideaData = {
        id: idea.id,
        status: 0,
        specIdx: specIdx,
        assets: idea.assets || '',
        assetsBak: idea.assets || '',
        specificationId: specificationId,
        assetsImgs,
        assetsTitle: assetsObj.title || '',
        assetsDesc: assetsObj.desc || '',
        assetsActBtn: actBtn || '',
        keywordType: idea.keywordType,
        packageId: idea.packageId || [],
        keywords: [],
        ocpcType: idea.ocpcType,
        bidPrice: idea.bidPrice,
        bidType: bidType,
        name: idea.name,
        appInfo: null,
        landingPage: {
          application_id: landingPage.application_id || '',
          packageName: landingPage.packageName || landingPage.app_id || '',
          lpSource: landingPage.lpSource || landingPage.lp_source || 0,
          lpId: landingPage.lpId || landingPage.lp_id || '',
          cpLpUrl: landingPage.cpLpUrl || landingPage.cp_lp_url || '',
          btnLocation: landingPage.btnLocation || landingPage.btn_location || 0,
          btnText: landingPage.btnText || landingPage.btn_text || '',
          schema: landingPage.schema || '',
          url: landingPage.url
        },
        clickMonitorUrls: idea.clickMonitorUrls,
        impMonitorUrls: idea.impMonitorUrls,
        keyWordPrices: JSON.parse(idea.keyWordPrices) || [],
        downloadUrl: idea.downloadUrl,
        sponsorTrackParams: idea.sponsorTrackParams ? idea.sponsorTrackParams.split(',') : [],
        ideaIdentify
      }
      // 当前的词包
      const assetsTitleDyncList = utils.getExecStrs(ideaData.assetsTitle)
      const assetsDescDyncList = utils.getExecStrs(ideaData.assetsDesc)
      const dyncList = assetsTitleDyncList.concat(assetsDescDyncList)
      const dyncs = dyncList.reduce((tt, val, i) => {
        tt += (i === 0 ? '' : ',') + val.str
        return tt
      }, '')
      // 获取词包详细信息并记录
      this.fetchDynamicList(dyncs).then((val) => {
        this.dyncCtrl.dyncUseList = this.dyncCtrl.dyncUseList.concat(val)
        // 设置默认的动态词包数据
        this.setDyncData(ideaData.assetsTitle, ideaData.assetsDesc, index)
      })
      // 返回表单数据
      return ideaData
    },
    _formatForm () {
      let ideaList = this.ideaList.map((idea, index) => {
        let isCPC = this.compareSlotBundle(this.unit.slotBundle, 3) === 1
        let isSearch = this.compareSlotBundle(this.unit.slotBundle, [3, 6]) === 0
        let bidType
        if (this.unit.slotBundle === 7) {
          bidType = idea.bidType
          idea.ocpcType = bidType
        } else {
          bidType = isCPC ? BID_TYPE.CPC : BID_TYPE.CPD
        }
        let formatIdea = {
          ideaId: idea.id,
          specificationId: idea.specificationId,
          slotBundleId: this.unit.slotBundle,
          ocpcType: idea.ocpcType,
          bidType: bidType,
          bidPrice: idea.bidPrice,
          name: idea.name,
          status: idea.status || 0,
          sponsorTrackParams: idea.sponsorTrackParams ? idea.sponsorTrackParams.length > 0 ? idea.sponsorTrackParams.join(',') : '' : ''
        }
        if (isCPC || this.unit.slotBundle === 7) {
          formatIdea.assets = idea.assets
          formatIdea.clickMonitorUrls = idea.clickMonitorUrls
          formatIdea.impMonitorUrls = idea.impMonitorUrls
          formatIdea.landingPage = idea.landingPage
          formatIdea.landingPage = {
            application_id: idea.landingPage.application_id,
            lpSource: idea.landingPage.lpSource,
            schema: idea.landingPage.schema
          }
          if (idea.landingPage.lpSource === 1) {
            formatIdea.landingPage.lpId = idea.landingPage.lpId
          } else if (idea.landingPage.lpSource === 2) {
            formatIdea.landingPage = {
              ...formatIdea.landingPage,
              btnLocation: idea.landingPage.btnLocation,
              btnText: idea.landingPage.btnText,
              cpLpUrl: idea.landingPage.cpLpUrl
            }
          }
          if (this.plan.promotionTarget === 1) { // 应用下载
            formatIdea.landingPage.packageName = idea.landingPage.packageName
          }
        } else {
          /* eslint-disable */
          if (this.unit.slotBundle == 6) formatIdea.assets = idea.assets;
          formatIdea.landingPage = {
            application_id: idea.landingPage.application_id,
            packageName: idea.landingPage.packageName,
            schema: idea.landingPage.schema
          }
          /* if (this.compareSlotBundle(this.unit.slotBundle, 3) === 0) {
            formatIdea.keywordType = idea.keywordType
            formatIdea.packageId = idea.keywords.map(k => k.id).join(',')
          } */
          /* eslint-enable */
        }
        if (isSearch) {
          // 处理keyWordPrices
          let keyWordPrices = (idea.keyWordPrices || []).concat(this.searchKeys.tempkeys[index] || [])
          let fmtKeyWordPrices = {}
          keyWordPrices.map(it => {
            fmtKeyWordPrices[it.kw] = Number(it.price)
          })
          formatIdea.keyWordPrices = fmtKeyWordPrices
        }
        return formatIdea
      })
      return {
        planId: this.plan.planId,
        unitId: this.unit.unitId,
        ideasJson: JSON.stringify(ideaList)
      }
    },
    compareSlotBundle (slotBundleId, val) {
      if (!this.slotBundle || !this.slotBundle[slotBundleId]) {
        return -1
      } else {
        if (val instanceof Array) {
          let cut = 0
          val.map(it => {
            if (this.slotBundle[slotBundleId].value === it) {
              cut++
            }
          })
          if (cut > 0) {
            return 0
          }
          return -1
        }
        if (this.slotBundle[slotBundleId].value < val) {
          return 1
        } else if (this.slotBundle[slotBundleId].value === val) {
          return 0
        } else {
          return -1
        }
      }
    },
    handlerTabClick (tab, event) {
      this.currTabIndex = parseInt(tab.index || 0)
    },
    addSearchKey () {
      // 防止添加太快
      if (this.searchKeys.inputlock) {
        return
      }
      this.searchKeys.inputlock = true
      // 重置筛选
      this.searchKeys.seacrhkey = this.tmpseacrhkey = ''
      let str = this.searchKeys.addinput
      if (!str) {
        this.searchKeys.inputlock = false
        this.$message.error('请输入合法的关键词和价格！')
        return
      }
      let lastIndex = str.replace(/，/g, ',').lastIndexOf(',')
      let lastStr = lastIndex > -1 ? str.slice(lastIndex + 1) : ''
      let kw = str
      let price = 0
      // 判断是否输入了价格
      if (lastIndex > -1 && /^\d+(\.\d+)?$/.test(lastStr)) {
        kw = str.slice(0, lastIndex)
        price = lastStr
      }
      // 清除空格
      kw = kw.replace(/(^[\s\n\t]+|[\s\n\t]+$)/g, '')
      // 判断当前关键词是不是超过20个字
      if (kw.length > 20) {
        this.searchKeys.inputlock = false
        this.$message.error('关键词长度不能超过20个字哦！')
        return
      }
      // 添加默认值
      if (!(this.searchKeys.tempkeys[this.currTabIndex] instanceof Array)) {
        this.$set(this.searchKeys.tempkeys, this.currTabIndex, [])
      }
      let currTempSearchKeys = this.searchKeys.tempkeys[this.currTabIndex]
      let currSearchKeys = this.currKeysList
      // 判断是否超过50个了
      // if (currSearchKeys.length >= 50) {
      //   this.searchKeys.inputlock = false
      //   this.$message.error('关键词不能超过超过50个哦！')
      //   return
      // }
      // 判断是否已经存在了
      for (let i = 0; i < currSearchKeys.length; i++) {
        if (currSearchKeys[i].kw === kw) {
          this.searchKeys.inputlock = false
          this.$message.error('关键词已经存在！')
          return
        }
      }
      // 查询热度
      getKwHot({
        kw: kw,
        unitId: this.$route.query.unitId,
        bidType: this.ideaList[this.currTabIndex].bidType,
        ocpc: this.ideaList[this.currTabIndex].ocpcType
      }).then((val) => {
        if (price) {
          val.price = parseFloat(price)
        }
        val.tmp = 1
        val.hot = val.hot || 0
        currTempSearchKeys.push(val)
        this.searchKeys.addinput = ''
        this.searchKeys.inputlock = false
      }).catch(err => {
        this.searchKeys.inputlock = false
        console.log(err)
      })
    },
    doFilterKeys () {
      this.searchKeys.seacrhkey = this.tmpseacrhkey
    },
    saveKwsToPackage () {
      let errorMsg = ''
      if (this.currKeysList.length === 0) {
        errorMsg = '关键词不能为空'
      } else if (this.currKeysList.length > 50) {
        errorMsg = '关键词数量不能超过50个'
      }
      if (errorMsg) return this.$message.error(errorMsg)
      const keywords = this.currKeysList.map(item => item.kw)
      postKeyword({
        operType: 'add',
        packageName: this.addKwPackageName,
        keywords
      }).then(res => {
        this.showAddKwPackage = false
        this.$message.success('保存成功')
      }).catch(error => {
        this.$message.error(error.message)
      })
    },
    deleteRow (row, rp = false) {
      let idx = row.idx
      let currDataList = this.ideaList[this.currTabIndex].keyWordPrices
      // 在本地
      if (row.tmp) {
        this.searchKeys.tempkeys[this.currTabIndex].splice(idx - currDataList.length, 1)
      } else {
        currDataList.splice(idx, 1)
      }
    },
    handleKyesSelectionChange (val) {
      this.searchKeys.multipleSelection = val
    },
    unifyPrice () {
      if (this.searchKeys.multipleSelection.length < 1) {
        this.$message.error('未选中关键词！')
        return
      }
      this.searchKeys.multipleSelection.map((it, id) => {
        it.price = this.searchKeys.unifyP
      })
    },
    delKeys () {
      if (this.searchKeys.multipleSelection.length < 1) {
        this.$message.error('未选中关键词！')
        return
      }
      // 先大到小排序
      this.searchKeys.multipleSelection.sort((a, b) => b.idx - a.idx).map((it, id) => {
        this.deleteRow(it, true)
      })
    },
    seacrhKeysValidate () {
      let clist = this.currKeysList
      let kwBasePrice = this.getKwBasePrice()
      for (let i = 0; i < clist.length; i++) {
        let price = parseFloat(clist[i].price)
        if (isNaN(price) || price < kwBasePrice.minPrice) {
          this.$message.error(`关键词出价不能低于${kwBasePrice.minPrice}元`)
          return false
        } else if (price > kwBasePrice.maxPrice) {
          this.$message.error(`关键词出价不能高于${kwBasePrice.maxPrice}元`)
          return false
        }
      }
      return true
    },
    getKwBasePrice () {
      let ocpcType = this.ideaList[this.currTabIndex].ocpcType
      const minPrice = ocpcType === OCPC_TYPE.INSTALL ? this.bidPriceFloor.downloadPrice.kwFloorPrice : this.bidPriceFloor.clickPrice.kwFloorPrice
      const maxPrice = ocpcType === OCPC_TYPE.INSTALL ? 100 : 20
      return {
        minPrice,
        maxPrice
      }
    },
    handleBidType (val) {
      this.ideaList[this.currTabIndex].bidPrice = ''
      this.fetchBidcostFloor(this.unit.slotBundle)
    },
    fetchKeywordPackageList () {
      getKeywordPackageList({
        pageNumber: 1,
        pageSize: 100,
        packageName: ''
      }).then(res => {
        if (res.code === 200) {
          this.keywordPackageList = res.value.data
        }
      })
    },
    onVideoPlaying (ideaIdentify) {
      let videoType = ''
      for (let i = 0; i < this.ideaList.length; i++) {
        if (ideaIdentify === this.ideaList[i].ideaIdentify) {
          videoType = JSON.parse(this.ideaList[i].assets)['video']['videoType']
        }
      }
      if (videoType !== 'MP4_H264') {
        this.$message.error('该视频格式暂不支持预览')
      }
    },
    getRandom () {
      return Date.now() + '_' + Math.random()
    },
    setDynamicPkg (val, label, origin) {
      const dc = this.dyncCtrl.data[this.currTabIndex][label]
      const oval = origin[label] || ''
      const index = oval.length === 0 ? 0 : dc.index
      const nval = oval.slice(0, index) + `{${val.name}}` + oval.slice(index)
      const dyncList = utils.getExecStrs(nval) || []
      let currVal = oval
      // 插入之前检查是否在光标位置插入了，{手动输入{插入的词包}
      for (const it of dyncList) {
        // 标记的起始位置 == 插入的位置
        if (it.start === index) {
          currVal = nval
          // 新增词，记录新增词的长度差值
          dc.diffLen += val.diffLen - 2
          // 记录已使用的词包
          this.dyncCtrl.dyncUseList.push(val)
          break
        }
      }
      dc.index = currVal.length
      origin[label] = currVal
      this.$forceUpdate()
      // 更新值状态
      this.onAssetsChanged()
      this.$message({
        message: oval === currVal ? '不能插入，请删除不合法的输入' : '成功插入动态词',
        type: oval === currVal ? 'error' : 'success'
      })
    },
    getDiffIndex (str1, str2) {
      let index = 0
      const end = str2.length > str1.length ? str2.length : str1.length
      for (let i = 0; i < end; i++) {
        if (str1[i] !== str2[i]) {
          index = i
          break
        }
      }
      return index
    },
    // 控制光标的位置
    getCursorIndex (el, label) {
      const dyncData = this.dyncCtrl.data[this.currTabIndex]
      const index = utils.getCursortPosition(el)
      // 获取当前的词包，并且排除非法的词包
      // const dyncList = utils.getExecStrs(el.value).filter(it => this.dyncCtrl.unDyncStrList.indexOf(it.str) === -1)
      dyncData[label].index = index
      // 修复全选在点中间输入的bug
      if (!index) {
        utils.setCaretPosition(el, 0)
      }
      /* for (const it of dyncList) {
        // 不同点在区间内,注意开头是允许相等的
        if (index > it.start && index <= it.end && it.str) {
          // 强制光标移出词包内
          utils.setCaretPosition(el, el.value.length)
          dyncData[label].index = el.value.length
          break
        }
      } */
    },
    // 处理动态词包字段
    checkDyncValue (val, label) {
      // const oval = ('' + this.currIdea[label]) || ''
      const dyncList = utils.getExecStrs(val) // 新词包
      const dyncRuleList = this.dyncCtrl.dyncUseList.map(it => it.name)
      const dc = this.dyncCtrl.data[this.currTabIndex][label]
      // 清空当前非法词包
      dc.errMsg = ''
      /* 重新计算词包和长度 */
      let diffLen = 0
      let ndyncList = [] // 记录词数据
      let unDync = []
      // a.判断现有的词包是否包含在词包组里面
      for (const it of dyncList) {
        let idx = dyncRuleList.indexOf(it.str)
        if (idx > -1) {
          diffLen += this.dyncCtrl.dyncUseList[idx].diffLen - 2
        } else {
          // 有值，
          if (it.str) {
            // 已在非法词仓库里面，则不需要接口判断了
            if (this.dyncCtrl.unDyncStrList.indexOf(it.str) > -1) {
              unDync.push(it.str)
            } else {
              // 并且不在非法词列表里，则记录后请求当前的输入词是否合法
              ndyncList.push(it) // 使用倒序
            }
          } else {
            // 空词包
            unDync.push('')
          }
        }
      }
      if (unDync.length > 0) {
        dc.errMsg = `词包：{${unDync.join('},{')}}不合法，请修改！`
      }
      // b.异步检查词包
      if (ndyncList.length > 0) {
        this.checkFecthDync(ndyncList, val, label, unDync)
      }
      // 最后赋值，才能触发校验逻辑
      this.ideaList[this.currTabIndex][label] = val
      console.log('value：', val)
      // 更新长度
      dc.diffLen = diffLen
      // 记录当前的光标位置
      let el = (this.$refs[`${label}_${this.currTabIndex}`] || [{}])[0].$el
      if (el.tagName !== 'INPUT') {
        el = el.querySelector('input')
      }
      dc.index = el ? utils.getCursortPosition(el) : val.length
      // 更新值状态
      this.onAssetsChanged()
    },
    checkFecthDync (ndyncList, val, label, unDync) {
      const dc = this.dyncCtrl.data[this.currTabIndex][label]
      dc.dyncLoading = true
      let ndyncs = ndyncList.map(it => it.str)
      this.fetchDynamicList(ndyncs.join(',')).then((v) => {
        const list = v || []
        // 检查查询的词包
        ndyncList.map(it => {
          let isLegal = false
          for (const it2 of list) {
            if (it.str === it2.name) {
              // 合法的则记录当前的词包，并且计数长度
              this.dyncCtrl.dyncUseList.push(it2)
              // diffLen += it2.diffLen - 2
              isLegal = true
              break
            }
          }
          // 非法词
          if (!isLegal) {
            unDync.push(it.str)
            // 记录非法词包
            this.dyncCtrl.unDyncStrList.push(it.str)
            // 从后往前删除
            // checkVal = checkVal.slice(0, it.start) + checkVal.slice(it.end + 1)
          }
        })
        dc.dyncLoading = false
        // 更新当前的词包长度
        dc.diffLen = this.upDyncInputLenDiff(val)
        dc.errMsg = `词包：{${unDync.join('},{')}}不合法，请修改！`
        // 手动触发输入校验
        if (this.$refs['form2_' + this.currTabIndex][0]) {
          this.$refs['form2_' + this.currTabIndex][0].validateField(label)
        }
      }).catch(() => {
        dc.dyncLoading = false
        this.$message({
          message: '词包查询失败，请重试！',
          type: 'error'
        })
      })
    },
    timerClock (time, callback) {
    },
    setDyncData (title, desc, index) {
      const data = {
        assetsTitle: {
          index: title ? title.length : 0,
          loading: false,
          diffLen: title ? this.upDyncInputLenDiff(title) : 0,
          errMsg: ''
        },
        assetsDesc: {
          index: desc ? desc.length : 0,
          loading: false,
          diffLen: desc ? this.upDyncInputLenDiff(desc) : 0,
          errMsg: ''
        }
      }
      this.$set(this.dyncCtrl.data, index, data)
    },
    checkLegal (index, label, value, callback) {
      if (value && this.dyncCtrl.data[index][label].errMsg) {
        callback(new Error(this.dyncCtrl.data[index][label].errMsg))
      } else {
        callback()
      }
    },
    // 词包跟实际长度的差值
    upDyncInputLenDiff (str, label) {
      const dyncList = str.constructor === Array ? str : utils.getExecStrs(str)
      let len = 0
      dyncList.map(it => {
        for (const it2 of this.dyncCtrl.dyncUseList) {
          if (it2.name === it.str) {
            len += it2.diffLen - 2
            break
          }
        }
      })
      return label ? (this.dyncCtrl.data[this.currTabIndex][label].diffLen = len) : len
    },
    dyncTimer (time = 500, func) {
      clearTimeout(this.dyncCtrl.timer)
      this.dyncCtrl.timer = setTimeout(() => {
        func()
        clearTimeout(this.dyncCtrl.timer)
      }, time)
    }
  },
  watch: {
    '$route.query.unitId' () {
      this.init()
    },
    ideaList: {
      handler (val, oval) {
        this.currOcpcType = this.ideaList[this.activeTab.slice(3) - 1].ocpcType
      },
      deep: true
    },
    keywordPackage (val) {
      if (!val) return
      getKeywordList({
        packageName: val
      }).then(res => {
        const len = this.ideaList[this.currTabIndex].keyWordPrices.length
        const keyWordPrices = this.ideaList[this.currTabIndex].keyWordPrices
        let isRepeat
        let count = 0
        res.value.data.forEach((kw, idx) => {
          isRepeat = false
          keyWordPrices.forEach(item => {
            if (item.kw === kw.keyword) isRepeat = true
          })
          if (isRepeat) return
          const rObj = {
            kw: kw.keyword,
            price: 0,
            hot: kw.hot || 0
          }
          this.$set(this.ideaList[this.currTabIndex].keyWordPrices, len + count, rObj)
          count++
        })
      })
    },
    currTabIndex () {
      this.keywordPackage = ''
    },
    showAddKwPackage (val) {
      if (!val) this.addKwPackageName = ''
    },
    userInfo (val) {
      if (val.hasOwnProperty('status')) {
        this.$store.dispatch('getSlotBundleList')
      }
    }
  },
  created () {
    this.init()
    this.fetchAdvicePrice()
    if (this.userInfo.hasOwnProperty('status')) {
      this.$store.dispatch('getSlotBundleList')
    }
    this.$store.dispatch('getAllLandingPageList')
    this.$store.dispatch('getAccountState')
    this.fetchKeywordPackageList()
  },
  components: {
    Preview,
    KeywordSelector,
    LandingPageSelector,
    DynamicLine
  }
}
</script>
<style lang="scss">
// .el-input__inner {
//  -webkit-touch-callout:none; /*系统默认菜单被禁用*/
//  -webkit-user-select:none; /*webkit浏览器*/
//  -khtml-user-select:none; /*早期浏览器*/
//  -moz-user-select:none;/*火狐*/
//  -ms-user-select:none; /*IE10*/
//  user-select:none;
// }
.adedit-tabs {
  .el-tabs__header {
    padding-left: 36px;
    background-color: #fcfcfc;
  }
  .el-tabs__header {
    .el-tabs__item {
      padding: 0 !important;
      min-width: 160px;
      background: #fff;
      border-bottom: 1px solid #e4e7ed;
      border-top-left-radius: 4px;
      border-top-right-radius: 4px;
      >span {
        padding: 0 16px;
        display: block;
        overflow: hidden;
        margin-bottom: -2px;
        >span {
          padding-right: 20px;
          @include ellipsis;
          max-width: 200px;
          display: block;
          float: left;
        }

        .el-icon-circle-close {
          color: #fff;
          background: #ccc;
          border-radius: 3px;
          position: absolute;
          right: 16px;
          top: 50%;
          margin-top: -7px;
          &:before {
            content: "\E60F"
          }
        }
        .el-icon-plus {
          font-weight: bold;
          margin-right: 3px;
        }
      }
      &.is-active {
        background: #f5f5f5;
        border-bottom-color: #f5f5f5;
      }
      &:last-child {
        text-align: center;
        color: #3A75FF;
      }
    }
  }
}
.popoverRule {
  font-size: 12px;
  line-height: 24px;
  img {
    vertical-align: middle;
    width: 120px;
  }
}
.deeplink-tip {
  display: inline-block;
  margin-left: -65px;
  margin-right: 47px;
  cursor: pointer;
}
.game-tip {
  display: inline-block;
  .money-icon {
    font-size: 20px;
    color: gold;
    vertical-align: middle;
    cursor: pointer;
  }
}

.assets-imgs-tip {
  width: 46%;
}
.red {
  color: red;
}

</style>
