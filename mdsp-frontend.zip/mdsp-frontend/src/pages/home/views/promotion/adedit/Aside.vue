<template lang="html">
  <el-aside class="home-aside">
    <el-menu class="home-aside__menu inset-shadow" :default-openeds="['1','2','3']" router>
      <el-submenu v-for="menu in menus" :key="menu.index" :index="menu.index">
        <template slot="title">
          <i :class="`menu-icon-${menu.icon}`"></i>
          <span>{{menu.name}}</span>
        </template>
        <el-menu-item v-for="sub in menu.children" :key="sub.index"
          v-if="showMenu(sub.index)"
          :index="sub.index"
          :data-path="sub.index"
          :class="{'is-active': activeIndex === sub.index}"
          :disabled="isDisabled(sub.index)"
          :ref="sub.index">
          <span slot="title">
            <span>{{sub.name}}</span>
            <i v-if="isFinished(sub.index)" class="el-icon-circle-check"></i>
            <i v-else-if="activeIndex === sub.index" class="el-icon-more"></i>
          </span>
        </el-menu-item>
      </el-submenu>
    </el-menu>
  </el-aside>
</template>

<script>
import qs from 'qs'

export default {
  data () {
    const href = window.location.href
    const showSteps = !/\/ActiveEdit/.test(href)
    const STEPS = [
      {
        name: '广告计划',
        icon: 'plan',
        index: '1',
        children: [
          { name: '推广目标', index: '/promotion/AdEdit/PlanEdit' },
          { name: '计划设置', index: '/promotion/AdEdit/PlanEdit' }
        ]
      },
      {
        name: '广告单元',
        icon: 'unit',
        index: '2',
        children: [
          { name: '广告类型', index: '/promotion/AdEdit/UnitEdit' },
          { name: '定向设置', index: '/promotion/AdEdit/UnitEdit' },
          { name: '单元名称', index: '/promotion/AdEdit/UnitEdit' }
        ]
      },
      {
        name: '广告创意',
        icon: 'asset',
        index: '3',
        children: [
          { name: '创意设置', index: '/promotion/AdEdit/IdeaEdit' },
          { name: '落地页设置', index: '/promotion/AdEdit/IdeaEdit' },
          { name: '监控设置', index: '/promotion/AdEdit/IdeaEdit' }
        ]
      }
    ]
    const STEPS_PUSH = [
      {
        name: '应用拉活',
        icon: 'push',
        index: '3',
        children: [
          { name: '广告资源', index: '/promotion/AdEdit/ActiveEdit' },
          { name: '应用设置', index: '/promotion/AdEdit/ActiveEdit' },
          { name: '定向设置', index: '/promotion/AdEdit/ActiveEdit' },
          { name: '计费设置', index: '/promotion/AdEdit/ActiveEdit' },
          { name: '创意素材', index: '/promotion/AdEdit/ActiveEdit' },
          { name: '广告名称', index: '/promotion/AdEdit/ActiveEdit' }
        ]
      }
    ]
    return {
      steps: showSteps ? STEPS : STEPS_PUSH
    }
  },
  computed: {
    menus () {
      const query = {...this.$route.query}
      return this.steps.map(step => {
        step.children = step.children.map((child, idx) => {
          query.s = idx + 1
          child.index = `${child.index.split('?')[0]}?${qs.stringify(query)}`
          return child
        })
        return step
      })
    },
    activeIndex () {
      return this.$route.fullPath
    }
  },
  methods: {
    isFinished (index) {
      const currStep = this.$route.name.substr(6)
      const currS = this.$route.query.s || '1'
      const [step, s] = /AdEdit\/(\w+)Edit\?.*&?s=(\d)/.exec(index).slice(1)
      if (currStep === 'Idea' && step !== 'Idea') {
        return true
      }
      if (currStep === 'Unit' && step === 'Plan') {
        return true
      }
      if (currStep === step) {
        return ~~currS > ~~s
      }
      return false
    },
    isDisabled (index) {
      const currStep = this.$route.name.substr(6)
      const [step] = /AdEdit\/(\w+)Edit/.exec(index).slice(1)
      return currStep !== step && !this.isFinished(index)
    },
    showMenu (index) {
      return true
    },
    onSelect () {
      Object.values(this.$refs).forEach(item => {
        if (item[0]) {
          let $el = item[0].$el
          this.$nextTick(() => {
            if (this.$route.fullPath !== $el.dataset.path) {
              $el.className = $el.className.replace('is-active', '')
            }
          })
        }
      })
    }
  },
  watch: {
    '$route.path': 'onSelect',
    '$route.query': 'onSelect'
  },
  created () {
    const value = this.$route.query.s
    if (!value) {
      const query = {...this.$route.query}
      if (!query.s) {
        query.s = 1
        this.$router.push(`${this.$route.path}?${qs.stringify(query)}`)
      }
    }
  }
}
</script>
