export default {
  methods: {
    validate () {
      return Promise.all(Object.values(this.$refs).filter(form => form && form.validate).map(form => form.clearValidate() && form.validate()))
        .then(res => res.reduce((a, c) => a && c))
    }
  }
}
