<template>
  <div class="home-container">
    <el-aside class="home-aside">
      <div class="inset-shadow pm-nav">
        <div class="pm-subnav" v-for="(menu, idx) in menus" :key="idx" :class="{expand: menu.icon === active}">
          <router-link class="pm-subnav__title" :to="{ name: menu.code }" exact>
            <i :class="`menu-icon-${menu.icon}`"></i>
            <span>{{menu.name}}</span>
            <i class="el-icon-arrow-right" @click.prevent="onToggleExpand(menu.icon, $event)" ></i>
          </router-link>
          <div class="pm-subnav__content">
            <router-link class="pm-subnav-item" v-if="menu.icon === 'plan'" v-for="plan in planList" :key="'plan_'+plan.id" :to="{ name: 'AdUnit', query: { planId: plan.id }}" exact>{{ plan.name }}</router-link>
            <router-link class="pm-subnav-item" v-if="menu.icon === 'unit'" v-for="unit in unitList" :key="'unit_'+unit.id" :to="{ name: 'AdAsset', query: { unitId: unit.id }}" exact>{{ unit.name }}</router-link>
            <router-link class="pm-subnav-item" v-if="menu.icon === 'asset'" v-for="idea in ideaList" :key="'idea_'+idea.id" :to="{ name: 'AdEditIdea', query: { planId: idea.planId, unitId: idea.unitId }}" exact target="_blank">{{ idea.name }}</router-link>
          </div>
        </div>
      </div>
    </el-aside>
    <main class="home-main">
      <router-view :consume="consume"/>
    </main>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import { getAllPlanList, getAllUnitList, getAllIdeaList, getConsume } from '@/api'
export default {
  data () {
    return {
      active: '',
      planList: [],
      unitList: [],
      ideaList: [],
      consume: 0
    }
  },
  computed: {
    ...mapGetters(['userInfo']),
    menus () {
      let menusArr = [
        { name: '全部计划', icon: 'plan', code: 'AdPlan' },
        { name: '全部单元', icon: 'unit', code: 'AdUnit' },
        { name: '全部创意', icon: 'asset', code: 'AdAsset' }
      ]
      if (this.userInfo.whiteList && this.userInfo.whiteList['push_sponsor']) {
        menusArr.push({ name: '应用拉活', icon: 'push', code: 'AdActive' })
      }
      return menusArr
    }
  },
  methods: {
    onToggleExpand (index, evt) {
      this.active = this.active === index ? '' : index
    },
    fetchPlanList () {
      getAllPlanList().then(planList => {
        this.planList = planList
      })
    },
    fetchUnitList () {
      getAllUnitList().then(unitList => {
        this.unitList = unitList
      })
    },
    fetchIdeaList () {
      getAllIdeaList().then(ideaList => {
        this.ideaList = ideaList
      })
    },
    fetchStatData () {
      getConsume().then(res => {
        if (res.code === 200) {
          this.consume = res.value
        }
      })
    }
  },
  created () {
    this.fetchPlanList()
    this.fetchUnitList()
    this.fetchIdeaList()
    this.fetchStatData()
  }
}
</script>

<style lang="scss">
.home-promotion__stat {
  margin-left: 96px;
  font-size: 22px;
  line-height: 72px;
  font-weight: 400;
  em {
    float: right;
    font-size: 42px;
    color: #ca2b2b;
  }
  dl {
    float: right;
  }
  dd+dt {
    margin-left: 50px;
  }
  dt,dd {
    float: left;
    display: block;
    font-size: 18px;
  }
  dd {
    color: $blue;
  }
}
.el-table .cell {
  display: block;
  position: relative;
  .editable {
    display: block;
    padding-right: 14px;
  }
  .el-icon-edit-outline {
    position: absolute;
    top: 50%;
    margin-top: -7px;
    right: 7px;
  }
}
.el-icon-edit-outline {
  color: $blue;
  font-size: 14px;
  cursor: pointer;
}
</style>
