<template>
  <div>
    <div class="mg24">
      <div class="home-card pd24">
        <div class="home-card__main">
          <div class="home-searchform-wrap">
            <div class="batch-operation">
              <router-link class="home-searchform-btn create-btn" :to="{ name: 'AdEditActive', query: { ideaId: '', action: 'new' } }" target="_blank"><i>＋</i>新建应用拉活广告</router-link>
            </div>
            <super-form class="home-searchform" label-width="0px" :form-list="searchOptions" v-model="formData"></super-form>
          </div>
          <el-table class="table-border" :data="ideaListTable" v-loading="fetching" @sort-change="onSortChange" @selection-change="onSelectionChange">
            <el-table-column header-align="center" :align="col.align || 'center'" v-for="col in tableColumn" :key="col.prop"
              :minWidth="col.minWidth"
              :prop="col.prop"
              :sortable="col.sortable ? 'custom' : false"
              :label="col.label">
              <template slot-scope="scope">
                <div v-if="col.prop === 'assets' && scope.row[col.prop]" class="pm-assets" >
                  <p>{{ scope.row[col.prop].title }}</p>
                  <img v-if="scope.row[col.prop].icon_img" :src="scope.row[col.prop].icon_img.url" />
                  <img v-else-if="scope.row[col.prop].main_img" :src="scope.row[col.prop].main_img.url" />
                  <div v-else-if="scope.row[col.prop].muti_img" :style="getImgBoxSize(scope.row[col.prop].muti_img)">
                    <img v-for="img in scope.row[col.prop].muti_img.url.split(';')" :key="img" :src="img" :style="getImgBoxSize(scope.row[col.prop].muti_img, 'img')"/>
                  </div>
                  <img v-else-if="scope.row[col.prop].video" :src="scope.row[col.prop].video.cover_url" />
                </div>
                <el-switch v-else-if="col.prop === 'switch' && ~[0, 1].indexOf(scope.row.status)" v-model="scope.row.status" :active-value="0" :inactive-value="1" @change="onChangeStatus(scope.row, $event)"></el-switch>
                <el-switch v-else-if="col.prop === 'switch' && [0, 1].indexOf(scope.row.status) === -1" disabled></el-switch>
                <el-popover v-else-if="col.prop === 'auditStatus' && scope.row.refuseReason" trigger="hover" placement="top" :diabled="true">
                  <p class="refusal-reason">{{ scope.row.refuseReason }}</p>
                  <div slot="reference" class="name-wrapper">
                    <p style="white-space: nowrap;">{{ getStatusName(scope.row.auditStatus) }}<i class="el-icon-question"></i></p>
                  </div>
                </el-popover>
                <div v-else :class="{editable: col.editable && scope.row.status !== 999}">{{col.formatter ? col.formatter(scope.row) : scope.row[col.prop]}} <i v-if="col.editable && scope.row.status !== 999 && scope.row.status !== 1111" class="el-icon-edit-outline"></i></div>
              </template>
            </el-table-column>
            <el-table-column
              fixed="right"
              label="操作"
              width="160">
              <template slot-scope="scope" v-if="scope.row.auditStatus !== 999 && scope.row.auditStatus !== 1111">
                <el-button type="text" size="small" @click="onEdit(scope.row.id, 'view')">查看</el-button>
                <el-button type="text" size="small" v-if="scope.row.auditStatus === 0" @click="onEdit(scope.row.id, 'edit')">修改</el-button>
                <el-button type="text" size="small" v-if="scope.row.auditStatus === 2 || scope.row.auditStatus === 3" @click="onWhitePush(scope.row.id)">白名单投放</el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <div class="home-card__footer">
          <el-pagination class="pull-right"
            v-if="ideaListTotal > defaultPageSize"
            background
            :page-size="PAGE_SIZE"
            :page-sizes="PAGE_SIZES"
            :current-page="formData.pageNumber"
            :total="ideaListTotal"
            @size-change="onSizeChange"
            @current-change="onPageChanged"
            layout="total, sizes, prev, pager, next, jumper">
          </el-pagination>
        </div>
      </div>
    </div>
    <el-dialog class="white-dialog" :visible.sync="showWhite" title="白名单投放" width="700px">
      <el-form :model="ruleForm" ref="ruleForm" label-width="150px">
        <el-form-item prop="whiteImei" :rules="{ required: true, message: '请输入测试设备号', trigger: 'blur' }" label="设备白名单">
          <el-input v-model="ruleForm.whiteImei" placeholder="请输入测试设备号，一次只可填写一个。" style="width: 400px;"></el-input>
        </el-form-item>
        <div class="white-tip">说明：一个订单最多白名单投放5次。</div>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="showWhite = false">取消</el-button>
        <el-button type="primary" @click="onSave">投放</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { ACTIVE_STATUS, ACTIVE_TYPE, PAGE_SIZE, PAGE_SIZES } from '@/enums'
import sortable from '@/mixins/sortable'
import batchOpr from '@/mixins/batchOpr'
import { getPushList, getPushSummary, whitePush } from '@/api'
import SuperForm from '@/components/SuperForm'
import utils from '@/utils'

export default {
  mixins: [sortable, batchOpr],
  props: ['consume'],
  data () {
    return {
      PAGE_SIZE,
      PAGE_SIZES,
      defaultPageSize: PAGE_SIZE,
      fetching: false,
      formData: null,
      searchOptions: [
        { type: 'hidden', key: 'pageNumber', default: 1 },
        { type: 'hidden', key: 'pageSize', default: PAGE_SIZE },
        { type: 'text', key: 'id', placeholder: '广告 ID' },
        { type: 'text', key: 'pushAdName', placeholder: '广告名称' },
        { type: 'select', key: 'auditStatus', label: '状态', options: Object.values(ACTIVE_STATUS).map(({value, name: label}) => ({value, label})) },
        { type: 'select', key: 'resourceType', label: '类型', options: Object.values(ACTIVE_TYPE).map(({value, name: label}) => ({value, label})) },
        { type: 'daterange', key: 'Time', label: '选择日期', startPlaceholder: '投放开始日期', endPlaceholder: '投放结束日期', default: ['', ''], width: '270px' }
      ],
      ideaList: [],
      ideaListTotal: 0,
      tableColumn: [
        { prop: 'pushAdName', label: '广告名称', minWidth: '100px' },
        { prop: 'id', label: '广告ID' },
        { prop: 'resourceType', label: '资源类型', formatter: row => this.formatResourceType(row.resourceType) },
        { prop: 'pushCrowdCount', label: '目标量', formatter: row => row.pushCrowdCount },
        { prop: 'exposure', label: '曝光量' },
        { prop: 'click', label: '点击量' },
        { prop: 'clickRate', label: '点击率', formatter: row => row.clickRate + '%' },
        { prop: 'clickPrice', label: '点击单价' },
        { prop: 'cost', label: '消费' },
        { prop: 'pushDate', label: '投放时间' },
        { prop: 'createdTime', label: '创建时间' },
        { prop: 'auditStatus', label: '状态', formatter: row => this.getStatusName(row.auditStatus) }
      ],
      tableColumnObj: {
        pushAdName: '',
        id: '',
        resourceType: '',
        pushCrowdCount: '',
        exposure: '',
        click: '',
        clickRate: '',
        price: '',
        cost: '',
        pushDate: '',
        createdTime: '',
        auditStatus: ''
      },
      showWhite: false,
      ruleForm: {
        id: '',
        whiteImei: ''
      },
      summary: null
    }
  },
  computed: {
    ideaListTable () {
      return (this.summary ? [{ ...this.tableColumnObj, ...this.summary }] : []).concat(this.ideaList)
    }
  },
  methods: {
    onSizeChange (currSize) {
      this.formData.pageSize = currSize
      this.fetchIdeaList()
    },
    onPageChanged (currPage) {
      this.formData.pageNumber = currPage
      this.fetchIdeaList()
    },
    fetchIdeaList () {
      getPushList({
        ...this.formData
      }).then(res => {
        if (res.code === 200) {
          if (!res.value.data || res.value.data.length === 0) {
            this.summary = null
          } else {
            this.fetchSummary()
          }
          this.ideaListTotal = res.value.total
          this.ideaList = res.value.data || []
          this.ideaList.forEach(item => {
            if (item.cost === null) {
              item.cost = '-'
            }
          })
        }
      })
    },
    fetchSummary () {
      getPushSummary({
        ...this.formData
      }).then(res => {
        if (res.code === 200) {
          let summary = res.value[0]
          summary.pushAdName = '合计'
          summary.auditStatus = 1111
          if (summary.cost === null) {
            summary.cost = '-'
          }
          if (summary.clickPrice === null) {
            summary.clickPrice = '-'
          }
          this.summary = summary
        }
      })
    },
    formatResourceType (resourceType) {
      if (resourceType === 8) {
        return 'push推送'
      } else if (resourceType === 9) {
        return '桌面通知'
      }
    },
    getStatusName (auditStatus) {
      return auditStatus !== 1111 ? ACTIVE_STATUS[auditStatus]['name'] : ''
    },
    onWhitePush (id) {
      this.ruleForm.id = id
      this.showWhite = true
    },
    onEdit (pushId, action) {
      utils.newTab(this.$router.resolve({ name: 'AdEditActive', query: { pushId, action } }))
    },
    onSave () {
      this.$refs['ruleForm'].validate((valid) => {
        if (valid) {
          whitePush(this.ruleForm).then(res => {
            if (res.code === 200) {
              this.$message.success('投放成功!')
              this.showWhite = false
              this.debounceFetchIdeaList()
            }
          }).catch(error => {
            this.$message.error(error.message)
          })
        }
      })
    }
  },
  watch: {
    formData (val) {
      this.debounceFetchIdeaList()
    }
  },
  created () {
    this.debounceFetchIdeaList = utils.debounce(this.fetchIdeaList)
    this.fetchList = this.debounceFetchIdeaList
  },
  components: {
    SuperForm
  }
}
</script>

<style lang="scss">
  .create-btn {
    width: 200px;
  }
  .white-tip {
    padding-left: 50px;
  }
</style>
