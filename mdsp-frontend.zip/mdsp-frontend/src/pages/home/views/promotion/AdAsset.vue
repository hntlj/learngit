<template>
  <div>
    <div class="mg24" v-if="!unit">
      <el-row :gutter="24">
        <el-col :span="12">
          <div class="home-card pd24">
            <i class="consume-icon-consume"></i>
            <div class="home-promotion__stat">
              <span>今日账户消费（元）</span>
              <em>{{ consume | currency }}</em>
            </div>
          </div>
        </el-col>
        <el-col :span="12">
          <div class="home-card pd24">
            <i class="consume-icon-stat"></i>
            <div class="home-promotion__stat">
              <span>广告统计</span>
              <dl>
                <dt>广告创意数：</dt><dd>{{ ideaCount.total | number }}</dd>
                <dt>有效创意数：</dt><dd>{{ ideaCount.play | number }}</dd>
              </dl>
            </div>
          </div>
        </el-col>
      </el-row>
    </div>
    <div v-else class="home-promotion__header inset-shadow">
      <h1 class="home-promotion__header--title">{{unit.unitName}} <i class="el-icon-edit-outline" @click="onEditUnit('unitName')"></i></h1>
      <dl class="home-promotion__header--desc">
        <dt>今日单元消费（元）:</dt> <dd class="blue">{{ unitCount.consume | currency }}</dd>
        <dt>包含创意数:</dt> <dd class="blue">{{ unitCount.total | number }}</dd>
        <dt>有效创意数:</dt> <dd class="blue">{{ unitCount.play | number }}</dd>
      </dl>
    </div>
    <div class="mg24">
      <div class="home-card pd24">
        <div class="home-card__main">
          <div class="home-searchform-wrap">
            <div class="batch-operation">
              <div class="home-searchform-btnwrap">
                <a v-if="unit && validIdeas.length < 5" class="home-searchform-btn new-idea-btn" @click="onNewIdea"><i>＋</i>新建创意</a>
                <a v-if="unit && validIdeas.length >= 5" class="home-searchform-btn disabled"><i>＋</i>新建创意</a>
                <span v-if="unit && validIdeas.length >= 5" class="home-searchform-tip">同一个单元只允许5个创意</span>
              </div>
              <el-select v-model="batchOptStatus" class="batch-select" placeholder="批量修改状态" style="width: 160px; margin-left: 10px;">
                <el-option
                  v-for="item in batchStatus"
                  :key="item.value"
                  :label="item.name"
                  :value="item.value">
                </el-option>
              </el-select>
              <div style="margin-left: 10px;">
                <el-button @click="onShowPriceDialog">批量修改出价</el-button>
              </div>
            </div>
            <super-form class="home-searchform" label-width="0px" :form-list="searchOptions" v-model="formData"></super-form>
          </div>
          <el-table class="table-border" :data="ideaListTable" v-loading="fetching" @sort-change="onSortChange" @selection-change="onSelectionChange">
            <el-table-column
              type="selection"
              width="50"
              :selectable="(row, idx) => row.status !== 1111">
            </el-table-column>
            <el-table-column header-align="center" :align="col.align || 'center'" v-for="col in tableColumn" :key="col.prop"
              :minWidth="col.minWidth"
              :prop="col.prop"
              :sortable="col.sortable ? 'custom' : false"
              :label="col.label">
              <template slot-scope="scope">
                <div v-if="col.prop === 'assets' && scope.row[col.prop]" class="pm-assets" >
                  <p>{{ scope.row[col.prop].title }}</p>
                  <img v-if="scope.row[col.prop].icon_img" :src="scope.row[col.prop].icon_img.url" />
                  <img v-else-if="scope.row[col.prop].main_img" :src="scope.row[col.prop].main_img.url" />
                  <div v-else-if="scope.row[col.prop].muti_img" :style="getImgBoxSize(scope.row[col.prop].muti_img)">
                    <img v-for="img in scope.row[col.prop].muti_img.url.split(';')" :key="img" :src="img" :style="getImgBoxSize(scope.row[col.prop].muti_img, 'img')"/>
                  </div>
                  <img v-else-if="scope.row[col.prop].video" :src="scope.row[col.prop].video.cover_url" />
                </div>
                <el-switch v-else-if="col.prop === 'switch' && ~[0, 1].indexOf(scope.row.status)" v-model="scope.row.status" :active-value="0" :inactive-value="1" @change="onChangeStatus(scope.row, $event)"></el-switch>
                <el-switch v-else-if="col.prop === 'switch' && [0, 1].indexOf(scope.row.status) === -1" disabled></el-switch>
                <el-popover v-else-if="col.prop === 'status' && scope.row.widgetReason" trigger="hover" placement="top" :diabled="true">
                  <p class="refusal-reason">{{ scope.row.widgetReason }}</p>
                  <div slot="reference" class="name-wrapper">
                    <p style="white-space: nowrap;">{{ getStatusName(scope.row.status) }}<i class="el-icon-question"></i></p>
                  </div>
                </el-popover>
                <div v-else :class="{editable: col.editable && scope.row.status !== 999}">{{col.formatter ? col.formatter(scope.row) : scope.row[col.prop]}} <i v-if="col.editable && scope.row.status !== 999 && scope.row.status !== 1111" class="el-icon-edit-outline" @click="onEdit(scope.row, col.prop, $event)"></i></div>
              </template>
            </el-table-column>
            <el-table-column
              fixed="right"
              label="操作"
              width="150">
              <template slot-scope="scope" v-if="scope.row.status !== 999 && scope.row.status !== 1111">
                <el-button type="text" size="small" @click="onEdit(scope.row)">编辑</el-button>
                <el-button type="text" size="small" @click="onDelete(scope.row)">删除</el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <div class="home-card__footer">
          <el-pagination class="pull-right"
            v-if="ideaListTotal > defaultPageSize"
            background
            :page-size="PAGE_SIZE"
            :page-sizes="PAGE_SIZES"
            :current-page="formData.pageNumber"
            :total="ideaListTotal"
            @size-change="onSizeChange"
            @current-change="onPageChanged"
            layout="total, sizes, prev, pager, next, jumper">
          </el-pagination>
        </div>
      </div>
    </div>
    <unit-edit-dialog :unit="currUnit" :form-list="currUnitFormList" @change="onUnitChanged" />
    <idea-edit-dialog :idea="currIdea" :form-list="currIdeaFormList" @change="fetchIdeaList" />
    <idea-price-dialog :showPriceDialog="showPriceDialog" :ideasData="multipleSelectionIdeas" @close="showPriceDialog=false" @refreshIdeaList="fetchIdeaList"></idea-price-dialog>
    <el-dialog
      title="批量修改状态"
      width="30%"
      :visible.sync="showBatchOprTip"
      class="batch-tip-dialog">
      <span v-if="batchOptStatus !== 999">{{`是否${batchStatusName}所有所选${batchTargetName}？`}}</span>
      <div v-else class="tip-cont">
        <p class="tip-text">{{batchTipText}}</p>
        <ul class="tip-ul">
          <li class="tip-li" v-for="(list, idx) in multipleSelectionNames" :key="idx">{{list}}</li>
        </ul>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="showBatchOprTip = false">取 消</el-button>
        <el-button type="primary" @click="updateStatusBatch">确 定</el-button>
      </span>
    </el-dialog>
    <el-dialog
      width="30%"
      :visible.sync="showBatchOprInconformity"
      class="batch-tip-dialog">
      <span>以下单元不符合修改条件：</span>
      <div class="tip-cont">
        <ul class="tip-ul">
          <li class="tip-li" v-for="(list, idx) in batchOprInconformity" :key="idx">{{list.name}}</li>
        </ul>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="showBatchOprInconformity = false">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { IDEA_STATUS, PAGE_SIZE, PAGE_SIZES } from '@/enums'
import { filters } from '@/utils/filters'
import sortable from '@/mixins/sortable'
import batchOpr from '@/mixins/batchOpr'
import { getUnitDetail, getIdeaList, destroyIdea, updateIdea, getIdeaCount, getConsume, getIdeaSummary } from '@/api'
import SuperForm from '@/components/SuperForm'
import UnitEditDialog from '@/components/home/promotion/UnitEditDialog'
import IdeaEditDialog from '@/components/home/promotion/IdeaEditDialog'
import IdeaPriceDialog from '@/components/home/promotion/IdeaPriceDialog'
import utils from '@/utils'

export default {
  mixins: [sortable, batchOpr],
  props: ['consume'],
  data () {
    return {
      PAGE_SIZE,
      PAGE_SIZES,
      defaultPageSize: PAGE_SIZE,
      fetching: false,
      formData: null,
      searchOptions: [
        { type: 'hidden', key: 'pageNumber', default: 1 },
        { type: 'hidden', key: 'pageSize', default: PAGE_SIZE },
        { type: 'text', key: 'ideaName', placeholder: '创意名称' },
        { type: 'select', key: 'status', label: '状态', options: Object.values(IDEA_STATUS).map(({value, name: label}) => ({value, label})) },
        { type: 'daterange', key: 'Time', label: '选择日期', default: [new Date(), new Date()], width: '270px' },
        { type: 'switch', key: 'filter', label: '过滤已删除', default: 1 }
      ],
      ideaList: [],
      ideaListTotal: 0,
      tableColumn: [
        { prop: 'name', label: '创意名称', align: 'left', minWidth: '100px', editable: true },
        { prop: 'switch', label: '投放' },
        { prop: 'bid', label: '出价', editable: true },
        { prop: 'assets', label: '创意内容', minWidth: '150px' },
        { prop: 'unitName', label: '所属单元', align: 'left' },
        { prop: 'planName', label: '所属计划', align: 'left' },
        { prop: 'exposure', label: '曝光量', sortable: true },
        { prop: 'click', label: '点击量', sortable: true },
        { prop: 'clickRate', label: '点击率', sortable: true, formatter: row => filters.percentange(row.clickRate) },
        { prop: 'clickPrice', label: '点击单价', sortable: false },
        { prop: 'download', label: '下载量', sortable: true },
        { prop: 'downloadRate', label: '下载率', sortable: true, formatter: row => filters.percentange(row.downloadRate) },
        { prop: 'downloadPrice', label: '下载单价', sortable: false },
        { prop: 'exposurePrice', label: '千次曝光消费', sortable: false },
        { prop: 'cost', label: '消费', sortable: true },
        { prop: 'createTime', label: '创建日期', sortable: true, minWidth: '100px', formatter: row => utils.formatDate(row.createTime) },
        { prop: 'status', label: '状态', formatter: row => IDEA_STATUS[row.status].name }
      ],
      tableColumnObj: {
        name: '',
        switch: '',
        bid: '',
        assets: '',
        unitName: '',
        planName: '',
        exposure: '',
        click: '',
        clickRate: '',
        clickPrice: '',
        download: '',
        downloadRate: '',
        downloadPrice: '',
        exposurePrice: '',
        cost: '',
        createTime: '',
        status: 1111
      },
      unit: null,
      currUnit: null,
      currUnitFormList: [],
      currIdea: null,
      currIdeaFormList: [],
      ideaCount: {},
      unitCount: {},
      summary: null,
      showPriceDialog: false
    }
  },
  computed: {
    validIdeas () {
      return this.ideaList.filter(idea => idea.status !== 999)
    },
    ideaListTable () {
      return (this.summary && !this.$route.query.unitId ? [{ ...this.tableColumnObj, ...this.summary }] : []).concat(this.ideaList)
    }
  },
  methods: {
    onEdit (idea, prop) {
      if (prop) {
        this.currIdea = idea
        this.currIdeaFormList = [prop]
      } else {
        const { planId, unitId } = idea
        utils.newTab(this.$router.resolve({ name: 'AdEditIdea', query: { planId, unitId, ideaId: idea.id } }))
      }
    },
    onEditUnit (prop) {
      this.currUnit = this.unit
      this.currUnitFormList = [prop]
    },
    onDelete (idea) {
      this.$confirm('确定要删除该广告创意吗？', '', {
        type: 'warning'
      }).then(() => {
        destroyIdea(idea.ideaId).then(res => {
          if (res.code === 200) {
            this.$message.success('删除成功')
            this.fetchIdeaList()
          } else {
            this.$message.error(res.message)
          }
        })
      })
    },
    onSizeChange (currSize) {
      this.formData.pageSize = currSize
      this.fetchIdeaList()
    },
    onPageChanged (currPage) {
      this.formData.pageNumber = currPage
      this.fetchIdeaList()
    },
    onUnitChanged (unit) {
      this.unit = unit
    },
    onChangeStatus (idea) {
      const { ideaId, status } = idea
      updateIdea({ ideaId, status }).then(res => {
        if (res.code !== 200) {
          idea.status = +!status
        }
      })
    },
    onNewIdea () {
      if (this.unit.isComplete) {
        this.$router.push({ name: 'AdEditIdea', query: { planId: this.unit.planId, unitId: this.unit.unitId, create: true } })
        return
      }
      this.$confirm('当前广告单元缺少必填信息：应用包名，请前往完善。', '', {
        confirmButtonText: '去完善',
        cancelButtonText: '取消',
        customClass: 'leaveConfirm'
      }).then(() => {
        this.$router.push({ name: 'AdEditUnit', query: { planId: this.unit.planId, unitId: this.unit.unitId, s: this.unit.slotBundleId, create: true } })
      })
    },
    async fetchUnitDetail (unitId) {
      this.unit = await getUnitDetail(unitId)
      const [consumeRes, countRes] = await Promise.all([getConsume({type: 2, id: unitId}), getIdeaCount({unitId})])
      if (consumeRes.code === 200 && countRes.code === 200) {
        this.unitCount = {
          ...countRes.value,
          consume: consumeRes.value
        }
      }
    },
    fetchIdeaList () {
      const unitId = this.$route.query.unitId
      this.fetching = true
      getIdeaList({
        ...this.formData,
        unitId,
        desc: (this.order === 'descending') * 1,
        orderBy: this.orderBy
      }).then(res => {
        if (res.code === 200) {
          this.fetchSummary()
          this.ideaListTotal = res.value.total
          this.ideaList = res.value.data.map(idea => {
            idea.unitId = this.formData.unitId || idea.unitId
            idea.assets = idea.assets ? JSON.parse(idea.assets) : null
            idea.exposurePrice = idea.exposure ? Number(((idea.cost / idea.exposure) * 1000).toFixed(2)) : 0
            idea.clickPrice = idea.click ? Number((idea.cost / idea.click).toFixed(2)) : 0
            idea.downloadPrice = idea.download ? Number((idea.cost / idea.download).toFixed(2)) : 0
            return idea
          })
        }
      }).finally(() => {
        setTimeout(() => {
          this.fetching = false
        }, 300)
      })
    },
    fetchSummary () {
      getIdeaSummary({
        ...this.formData
      }).then(res => {
        if (res.code === 200) {
          if (!this.ideaListTable || (this.ideaListTable[this.ideaListTable.length - 1] || {}).hasOwnProperty('unitId')) {
            let summary = res.value
            summary.status = 1111
            summary.exposurePrice = summary.exposure ? Number(((summary.cost / summary.exposure) * 1000).toFixed(2)) : 0
            summary.clickPrice = summary.click ? Number((summary.cost / summary.click).toFixed(2)) : 0
            summary.downloadPrice = summary.download ? Number((summary.cost / summary.download).toFixed(2)) : 0
            this.summary = summary
          }
        }
      })
    },
    fetchCount () {
      getIdeaCount().then(res => {
        if (res.code === 200) {
          this.ideaCount = res.value
        }
      })
    },
    getStatusName (status) {
      return IDEA_STATUS[status].name
    },
    /* eslint-disable */
    getImgBoxSize(image, type = 'box', dfw = 128, gap = 4) {
      if(image){
        let len = image.url.split(';').length,
            gp = len>1? gap: 0,
            imgwid = (dfw+gp-len*gp)/len,
            imghei = imgwid / image.w * image.h;
        return type=='box' ? `width: ${dfw+gp}px;height: ${imghei.toFixed(2)}px` : `width: ${imgwid.toFixed(2)}px;height: ${imghei.toFixed(2)}px;margin-right: ${gp}px;`
      }
      return ''
    }
    /* eslint-enable */
  },
  watch: {
    formData (val) {
      this.debounceFetchIdeaList()
    },
    '$route.query.unitId' (unitId) {
      this.formData = { ...this.formData, unitId }
      if (unitId) {
        this.fetchUnitDetail(unitId)
      } else {
        this.unit = null
      }
    }
  },
  created () {
    const unitId = this.$route.query.unitId
    if (unitId) {
      this.fetchUnitDetail(unitId)
    }
    this.debounceFetchIdeaList = utils.debounce(this.fetchIdeaList)
    this.fetchList = this.debounceFetchIdeaList
    this.fetchCount()
    this.$store.dispatch('getAccountState')
  },
  components: {
    SuperForm,
    UnitEditDialog,
    IdeaEditDialog,
    IdeaPriceDialog
  }
}
</script>

<style lang="scss">
.pm-assets {
  width: 128px;
  p {
    @include ellipsis;
  }
  div{
    width: 128px;
  }
  img {
    width: 128px;
  }
}
.refusal-reason {
  max-width: 450px;
}
.leaveConfirm {
  .el-message-box__btns .el-button--primary {
    background-color: #DF3737;
    border-color: #DF3737;
  }
}
.new-idea-btn {
  cursor: pointer;
}
</style>
