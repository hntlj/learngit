<template>
  <div>
    <div class="mg24" style="padding-bottom:0" v-if="!plan">
      <el-row :gutter="24">
        <el-col :span="12">
          <div class="home-card pd24">
            <i class="consume-icon-consume"></i>
            <div class="home-promotion__stat">
              <span>今日账户消费（元）</span>
              <em><em>{{ consume | currency }}</em></em>
            </div>
          </div>
        </el-col>
        <el-col :span="12">
          <div class="home-card pd24">
            <i class="consume-icon-stat"></i>
            <div class="home-promotion__stat">
              <span>广告统计</span>
              <dl>
                <dt>广告单元数：</dt><dd>{{ unitCount.total | number }}</dd>
                <dt>有效单元数：</dt><dd>{{ unitCount.play | number }}</dd>
              </dl>
            </div>
          </div>
        </el-col>
      </el-row>
    </div>
    <div v-else class="home-promotion__header inset-shadow">
      <h1 class="home-promotion__header--title">{{plan.planName}} <i class="el-icon-edit-outline" @click="onEditPlan('planName')"></i></h1>
      <dl class="home-promotion__header--desc">
        <dt>预算:</dt> <dd>{{ planBudget }} <i class="el-icon-edit-outline" @click="onEditPlan('budget')"></i></dd>
        <dt>今日计划消费（元）:</dt> <dd class="blue">{{ planCount.consume | currency }}</dd>
        <dt>包含单元数:</dt> <dd class="blue">{{ planCount.total | number }}</dd>
        <dt>有效单元数:</dt> <dd class="blue">{{ planCount.play | number }}</dd>
      </dl>
    </div>
    <div class="mg24">
      <div class="home-card pd24">
        <div class="home-card__main">
          <div class="home-searchform-wrap">
            <div class="batch-operation">
              <div class="home-searchform-btnwrap" v-if="plan">
                <router-link class="home-searchform-btn" :to="{ name: 'AdEditUnit', query: {planId: plan.planId} }" target="_blank"><i>＋</i>新建单元</router-link>
              </div>
              <el-select v-model="batchOptStatus" class="batch-select" placeholder="批量修改状态" style="width: 160px; margin-left: 10px;">
                <el-option
                  v-for="item in batchStatus"
                  :key="item.value"
                  :label="item.name"
                  :value="item.value">
                </el-option>
              </el-select>
            </div>
            <super-form class="home-searchform" label-width="0px" :form-list="searchOptions" v-model="formData"></super-form>
          </div>
          <el-table class="table-border" :data="unitListTable" v-loading="fetching" @sort-change="onSortChange" @selection-change="onSelectionChange">
            <el-table-column
              type="selection"
              width="50"
              :selectable="(row, idx) => row.status !== 1111">
            </el-table-column>
            <el-table-column header-align="center" :align="col.align || 'center'" v-for="col in tableColumn" :key="col.prop"
              :prop="col.prop"
              :sortable="col.sortable ? 'custom' : false"
              :label="col.label"
              :formatter="col.formatter">
              <template slot-scope="scope">
                <el-switch v-if="col.prop === 'switch' && ~[0, 1].indexOf(scope.row.status)" v-model="scope.row.status" :active-value="0" :inactive-value="1" @change="onToggleStatus(scope.row, $event)"></el-switch>
                <router-link class="editable" v-else-if="scope.row.status !== 999 && scope.row.status !== 1111 && col.prop === 'unitName'" :to="{name: 'AdAsset', query: {unitId: scope.row.unitId}}">{{ scope.row[col.prop] }} <i v-if="scope.row.status !== 999 && scope.row.status !== 1111" class="el-icon-edit-outline" @click.prevent="onEdit(scope.row, col.prop, $event)"></i></router-link>
                <span v-else-if="col.prop === 'timeSeg' && scope.row.status !== 1111">
                  <el-popover v-if="scope.row.timeSeg"
                    placement="top-start"
                    width="1200"
                    trigger="hover">
                    <el-time-grid read-only v-model="scope.row[col.prop]"></el-time-grid>
                    <span slot="reference">分时段 <i v-if="scope.row.status !== 999" class="el-icon-edit-outline" @click.prevent="onEdit(scope.row, col.prop, $event)"></i></span>
                  </el-popover>
                  <span v-else>{{ formatTimeSeg(scope.row) }} <i v-if="scope.row.status !== 999" class="el-icon-edit-outline" @click.prevent="onEdit(scope.row, col.prop, $event)"></i></span>
                </span>
                <span v-else>{{col.formatter ? col.formatter(scope.row) : scope.row[col.prop]}}</span>
              </template>
            </el-table-column>
            <el-table-column
              fixed="right"
              label="操作"
              width="150">
              <template slot-scope="scope" v-if="scope.row.status !== 999 && scope.row.status !== 1111">
                <el-button type="text" size="small" @click="onEdit(scope.row)">编辑</el-button>
                <el-button type="text" size="small" @click="onDelete(scope.row)">删除</el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <div class="home-card__footer">
          <el-pagination class="pull-right"
            v-if="unitListTotal > defaultPageSize"
            background
            :page-size="PAGE_SIZE"
            :page-sizes="PAGE_SIZES"
            :current-page="formData.pageNumber"
            :total="unitListTotal"
            @size-change="onSizeChange"
            @current-change="onPageChanged"
            layout="total, sizes, prev, pager, next, jumper">
          </el-pagination>
        </div>
      </div>
    </div>
    <unit-edit-dialog :unit="currUnit" :form-list="currUnitFormList" @change="fetchUnitList" />
    <plan-edit-dialog :plan="currPlan" :form-list="currPlanFormList" @change="onPlanChanged" />
    <el-dialog
      title="批量修改状态"
      width="30%"
      :visible.sync="showBatchOprTip"
      class="batch-tip-dialog">
      <span v-if="batchOptStatus !== 999">{{`是否${batchStatusName}所有所选${batchTargetName}？`}}</span>
      <div v-else class="tip-cont">
        <p class="tip-text">{{batchTipText}}</p>
        <ul class="tip-ul">
          <li class="tip-li" v-for="(list, idx) in multipleSelectionNames" :key="idx">{{list}}</li>
        </ul>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="showBatchOprTip = false">取 消</el-button>
        <el-button type="primary" @click="updateStatusBatch">确 定</el-button>
      </span>
    </el-dialog>
    <el-dialog
      width="30%"
      :visible.sync="showBatchOprInconformity"
      class="batch-tip-dialog">
      <span>以下单元不符合修改条件：</span>
      <div class="tip-cont">
        <ul class="tip-ul">
          <li class="tip-li" v-for="(list, idx) in batchOprInconformity" :key="idx">{{list.name}}</li>
        </ul>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="showBatchOprInconformity = false">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { UNIT_STATUS, MAX_BUDGET, PAGE_SIZE, PAGE_SIZES } from '@/enums'
import { filters } from '@/utils/filters'
import sortable from '@/mixins/sortable'
import batchOpr from '@/mixins/batchOpr'
import { getPlanDetail, getUnitList, destroyUnit, postUnit, getUnitCount, getConsume, getUnitSummary, getUnitDetail } from '@/api'
import SuperForm from '@/components/SuperForm'
import UnitEditDialog from '@/components/home/promotion/UnitEditDialog'
import PlanEditDialog from '@/components/home/promotion/PlanEditDialog'
import utils from '@/utils'
export default {
  mixins: [sortable, batchOpr],
  props: ['consume'],
  data () {
    return {
      PAGE_SIZE,
      PAGE_SIZES,
      defaultPageSize: PAGE_SIZE,
      fetching: false,
      formData: null,
      unitList: [],
      unitListTotal: 0,
      tableColumn: [
        { prop: 'unitName', label: '单元名称', align: 'left', minWidth: '100px', editable: true },
        { prop: 'switch', label: '投放' },
        { prop: 'planName', label: '所属计划', align: 'left' },
        { prop: 'slotBundleId', label: '资源类型', formatter: row => this.formatSlotBundleName(row.slotBundleId) },
        { prop: 'exposure', label: '曝光量', sortable: true },
        { prop: 'click', label: '点击量', sortable: true },
        { prop: 'clickRate', label: '点击率', sortable: true, formatter: row => filters.percentange(row.clickRate) },
        { prop: 'clickPrice', label: '点击单价', sortable: false },
        { prop: 'download', label: '下载量', sortable: true },
        { prop: 'downloadRate', label: '下载率', sortable: true, formatter: row => filters.percentange(row.downloadRate) },
        { prop: 'downloadPrice', label: '下载单价', sortable: false },
        { prop: 'exposurePrice', label: '千次曝光消费', sortable: false },
        { prop: 'cost', label: '消费', sortable: true },
        { prop: 'timeSeg', label: '投放时段', editable: true },
        { prop: 'createTime', label: '创建日期', sortable: true, formatter: row => utils.formatDate(row.createTime) },
        { prop: 'status', label: '状态', formatter: row => UNIT_STATUS[row.status].name }
      ],
      tableColumnObj: {
        unitName: '',
        switch: '',
        planName: '',
        slotBundleId: '',
        exposure: '',
        click: '',
        clickRate: '',
        clickPrice: '',
        download: '',
        downloadRate: '',
        downloadPrice: '',
        exposurePrice: '',
        cost: '',
        timeSeg: '',
        createTime: '',
        status: 1111
      },
      plan: null,
      currUnit: null,
      currUnitFormList: [],
      currPlan: null,
      currPlanFormList: [],
      unitCount: {},
      planCount: {},
      summary: null
    }
  },
  computed: {
    ...mapGetters(['slotBundle']),
    searchOptions () {
      return [
        { type: 'hidden', key: 'pageNumber', default: 1 },
        { type: 'hidden', key: 'pageSize', default: PAGE_SIZE },
        { type: 'text', key: 'unitName', placeholder: '单元名称' },
        { type: 'select', key: 'status', label: '状态', options: Object.values(UNIT_STATUS).map(({value, name: label}) => ({value, label})) },
        { type: 'select', key: 'slotBundleId', label: '类型', options: this.slotBundle ? Object.values(this.slotBundle).map(({value, name: label}) => ({value, label})) : [] },
        { type: 'daterange', key: 'Time', label: '选择日期', default: [new Date(), new Date()], width: '270px' },
        { type: 'switch', key: 'filter', label: '过滤已删除', default: 1 }
      ]
    },
    planBudget () {
      return this.plan.budget >= MAX_BUDGET ? '不限额' : filters.currency(this.plan.budget) + ' 元 / 天'
    },
    unitListTable () {
      return (this.summary && !this.$route.query.planId ? [{ ...this.tableColumnObj, ...this.summary }] : []).concat(this.unitList)
    }
  },
  methods: {
    // http://mzdsp.meizu.com/console/mdsp/unit/detail?unitId=105911
    async onEdit (unit, prop) {
      const { planId, unitId } = unit
      if (prop) {
        this.currUnit = await getUnitDetail(unitId)
        this.currUnitFormList = [prop]
      } else {
        utils.newTab(this.$router.resolve({ name: 'AdEditUnit', query: { planId, unitId } }))
      }
    },
    onEditPlan (prop) {
      this.currPlan = this.plan
      this.currPlanFormList = [prop]
    },
    onDelete (unit) {
      this.$confirm('删除广告单元，会导致广告单元下的所有创意都被删除，且无法恢复，请确认是否要继续删除？', '', {
        type: 'warning'
      }).then(() => {
        destroyUnit(unit.unitId).then(res => {
          if (res.code === 200) {
            this.$message.success('删除成功')
            this.fetchUnitList()
          }
        }).catch(error => {
          this.$message.error(error.message)
        })
      })
    },
    onSizeChange (currSize) {
      this.formData.pageSize = currSize
      this.fetchUnitList()
    },
    onPageChanged (currPage) {
      this.formData.pageNumber = currPage
      this.fetchUnitList()
    },
    onPlanChanged (plan) {
      this.plan = plan
    },
    async onToggleStatus (unit) {
      const { unitId, status: unitStatus } = unit
      const unitData = await getUnitDetail(unitId)
      postUnit({ ...unitData, unitStatus: unitStatus }).then(res => {
        if (res.code !== 200) {
          unit.status = unitStatus
        }
      })
    },
    async fetchPlanDetail (planId) {
      this.plan = await getPlanDetail(planId)
      const [consumeRes, res] = await Promise.all([getConsume({ type: 1, id: planId }), getUnitCount({ planId })])
      if (consumeRes.code === 200 && res.code === 200) {
        this.planCount = {
          consume: consumeRes.value,
          ...res.value
        }
      }
    },
    fetchUnitList () {
      const planId = this.$route.query.planId
      this.fetching = true
      getUnitList({
        ...this.formData,
        planId,
        desc: (this.order === 'descending') * 1,
        orderBy: this.orderBy
      }).then(res => {
        if (res.code === 200) {
          this.fetchSummary()
          this.unitListTotal = res.value.total
          this.unitList = res.value.data.map(unit => {
            unit.planId = this.formData.planId || unit.planId
            unit.exposurePrice = unit.exposure ? Number(((unit.cost / unit.exposure) * 1000).toFixed(2)) : 0
            unit.clickPrice = unit.click ? Number((unit.cost / unit.click).toFixed(2)) : 0
            unit.downloadPrice = unit.download ? Number((unit.cost / unit.download).toFixed(2)) : 0
            return unit
          })
        }
      }).finally(() => {
        setTimeout(() => {
          this.fetching = false
        }, 300)
      })
    },
    fetchSummary () {
      getUnitSummary({
        ...this.formData
      }).then(res => {
        if (res.code === 200) {
          if (!this.unitListTable || this.unitListTable[this.unitListTable.length - 1].hasOwnProperty('unitId')) {
            let summary = res.value
            summary.exposurePrice = summary.exposure ? Number(((summary.cost / summary.exposure) * 1000).toFixed(2)) : 0
            summary.clickPrice = summary.click ? Number((summary.cost / summary.click).toFixed(2)) : 0
            summary.downloadPrice = summary.download ? Number((summary.cost / summary.download).toFixed(2)) : 0
            this.summary = summary
          }
        }
      })
    },
    fetchCount () {
      getUnitCount().then(res => {
        if (res.code === 200) {
          this.unitCount = res.value
        }
      })
    },
    formatSlotBundleName (slotBundleId) {
      if (!this.slotBundle || !slotBundleId || !this.slotBundle[slotBundleId]) {
        return ''
      } else {
        return this.slotBundle[slotBundleId].name
      }
    },
    formatTimeSeg (unit) {
      return unit.timeSeg ? '分时段' : '全时段'
    }
  },
  watch: {
    formData (val) {
      this.slotBundle && this.debounceFetchUnitList()
    },
    '$route.query.planId' (planId) {
      this.formData = { ...this.formData, planId }
      if (planId) {
        this.fetchPlanDetail(planId)
      } else {
        this.formData.planId = ''
        this.plan = null
      }
    },
    slotBundle: 'fetchUnitList'
  },
  created () {
    const planId = this.$route.query.planId
    if (planId) {
      this.fetchPlanDetail(planId)
    } else {
      this.fetchCount()
    }
    this.$store.dispatch('getSlotBundleList')
    this.debounceFetchUnitList = utils.debounce(this.fetchUnitList)
    this.fetchList = this.debounceFetchUnitList
  },
  components: {
    SuperForm,
    PlanEditDialog,
    UnitEditDialog
  }
}
</script>
