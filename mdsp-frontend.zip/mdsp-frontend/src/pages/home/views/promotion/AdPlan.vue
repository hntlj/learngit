<template>
  <div>
    <div class="mg24">
      <el-row :gutter="24">
        <el-col :span="12">
          <div class="home-card pd24">
            <i class="consume-icon-consume"></i>
            <div class="home-promotion__stat">
              <span>今日账户消费（元）</span>
              <em>{{ consume | currency }}</em>
            </div>
          </div>
        </el-col>
        <el-col :span="12">
          <div class="home-card pd24">
            <i class="consume-icon-stat"></i>
            <div class="home-promotion__stat">
              <span>广告统计</span>
              <dl>
                <dt>广告计划数：</dt><dd>{{ planCount.total | number }}</dd>
                <dt>有效计划数：</dt><dd>{{ planCount.play | number }}</dd>
              </dl>
            </div>
          </div>
        </el-col>
      </el-row>
    </div>
    <div class="mg24">
      <div class="home-card pd24">
        <div class="home-card__main">
          <div class="home-searchform-wrap">
            <div class="batch-operation">
              <router-link class="home-searchform-btn" :to="{ name: 'AdEditPlan' }" target="_blank"><i>＋</i>新建计划</router-link>
              <el-select v-model="batchOptStatus" class="batch-select" placeholder="批量修改状态" style="width: 160px; margin-left: 10px;">
                <el-option
                  v-for="item in batchStatus"
                  :key="item.value"
                  :label="item.name"
                  :value="item.value">
                </el-option>
              </el-select>
            </div>
            <super-form class="home-searchform" label-width="0px" :form-list="searchOptions" v-model="formData"></super-form>
          </div>
          <el-table class="table-border" :data="planListTable" v-loading="fetching" @sort-change="onSortChange" @selection-change="onSelectionChange">
            <el-table-column
              type="selection"
              width="50"
              :selectable="(row, idx) => row.status !== 1111">
            </el-table-column>
            <el-table-column header-align="center" :align="col.align || 'center'" v-for="col in tableColumn" :key="col.prop"
              :minWidth="col.minWidth"
              :prop="col.prop"
              :sortable="col.sortable ? 'custom' : false"
              :label="col.label">
              <template slot-scope="scope">
                <el-switch v-if="col.prop === 'switch' && ~[0, 1].indexOf(scope.row.status)" v-model="scope.row.status" :active-value="0" :inactive-value="1" @change="onChangeStatus(scope.row, $event)"></el-switch>
                <el-switch v-else-if="col.prop === 'switch' && [0, 1].indexOf(scope.row.status) === -1" disabled></el-switch>
                <router-link class="editable" v-else-if="scope.row.status !== 999 && scope.row.status !== 1111 && col.prop === 'planName'" :to="{name: 'AdUnit', query: {planId: scope.row.planId}}">{{ scope.row[col.prop] }} <i v-if="col.editable && scope.row.status !== 999 && scope.row.status !== 1111" class="el-icon-edit-outline" @click.prevent="onEdit(scope.row, col.prop, $event)"></i></router-link>
                <span v-else :class="{editable: col.editable && scope.row.status !== 999}">{{col.formatter ? col.formatter(scope.row) : scope.row[col.prop]}} <i v-if="col.editable && scope.row.status !== 999 && scope.row.status !== 1111" class="el-icon-edit-outline" @click="onEdit(scope.row, col.prop, $event)"></i></span>
              </template>
            </el-table-column>
            <el-table-column
              fixed="right"
              label="操作"
              width="150">
              <template slot-scope="scope" v-if="scope.row.status !== 999 && scope.row.status !== 1111">
                <el-button type="text" size="small" @click="onEdit(scope.row)">编辑</el-button>
                <el-button type="text" size="small" @click="onDelete(scope.row)">删除</el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <div class="home-card__footer">
          <el-pagination class="pull-right"
            v-if="planListTotal > defaultPageSize"
            background
            :page-size="PAGE_SIZE"
            :page-sizes="PAGE_SIZES"
            :current-page="formData.pageNumber"
            :total="planListTotal"
            @size-change="onSizeChange"
            @current-change="onPageChanged"
            layout="total, sizes, prev, pager, next, jumper">
          </el-pagination>
        </div>
      </div>
    </div>
    <plan-edit-dialog :plan="currPlan" :form-list="currPlanFormList" @change="fetchPlanList" />
    <el-dialog
      title="批量修改状态"
      width="30%"
      :visible.sync="showBatchOprTip"
      class="batch-tip-dialog">
      <span v-if="batchOptStatus !== 999">{{`是否${batchStatusName}所有所选${batchTargetName}？`}}</span>
      <div v-else class="tip-cont">
        <p class="tip-text">{{batchTipText}}</p>
        <ul class="tip-ul">
          <li class="tip-li" v-for="(list, idx) in multipleSelectionNames" :key="idx">{{list}}</li>
        </ul>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="showBatchOprTip = false">取 消</el-button>
        <el-button type="primary" @click="updateStatusBatch">确 定</el-button>
      </span>
    </el-dialog>
    <el-dialog
      width="30%"
      :visible.sync="showBatchOprInconformity"
      class="batch-tip-dialog">
      <span>以下单元不符合修改条件：</span>
      <div class="tip-cont">
        <ul class="tip-ul">
          <li class="tip-li" v-for="(list, idx) in batchOprInconformity" :key="idx">{{list.name}}</li>
        </ul>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="showBatchOprInconformity = false">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { getPlanList, destroyPlan, togglePlanStatus, getPlanCount, getPlanSummary } from '@/api'
import sortable from '@/mixins/sortable'
import batchOpr from '@/mixins/batchOpr'
import utils from '@/utils'
import { filters } from '@/utils/filters'
import SuperForm from '@/components/SuperForm'
import PlanEditDialog from '@/components/home/promotion/PlanEditDialog'
import { PROMOTION_TARGET, PLAN_STATUS, MAX_BUDGET, PAGE_SIZE, PAGE_SIZES } from '@/enums'
export default {
  mixins: [sortable, batchOpr],
  props: ['consume'],
  data () {
    return {
      PAGE_SIZE,
      PAGE_SIZES,
      defaultPageSize: PAGE_SIZE,
      fetching: false,
      formData: null,
      searchOptions: [
        { type: 'hidden', key: 'pageNumber', default: 1 },
        { type: 'hidden', key: 'pageSize', default: PAGE_SIZE },
        { type: 'text', key: 'planName', label: '计划名称', placeholder: '计划名称' },
        { type: 'select', key: 'promotionTarget', label: '推广目的', options: Object.values(PROMOTION_TARGET).map(({ value, name: label }) => ({ value, label })) },
        { type: 'select', key: 'status', label: '状态', options: Object.values(PLAN_STATUS).map(({ value, name: label }) => ({ value, label })) },
        { type: 'daterange', key: 'Time', label: '选择日期', default: [new Date(), new Date()], width: '270px' },
        { type: 'switch', key: 'filter', label: '过滤已删除', default: 1 }
      ],
      planList: [],
      planListTotal: 0,
      tableColumn: [
        { prop: 'planName', label: '计划名称', align: 'left', minWidth: '100px', editable: true },
        { prop: 'switch', label: '投放' },
        { prop: 'budget', label: '预算', editable: true },
        { prop: 'surplusBudget', label: '剩余预算' },
        { prop: 'exposure', label: '曝光量', sortable: true },
        { prop: 'click', label: '点击量', sortable: true },
        { prop: 'clickRate', label: '点击率', sortable: true, formatter: row => filters.percentange(row.clickRate) },
        { prop: 'clickPrice', label: '点击单价', sortable: false },
        { prop: 'download', label: '下载量', sortable: true },
        { prop: 'downloadRate', label: '下载率', sortable: true, formatter: row => filters.percentange(row.downloadRate) },
        { prop: 'downloadPrice', label: '下载单价', sortable: false },
        { prop: 'exposurePrice', label: '千次曝光消费', sortable: false },
        { prop: 'cost', label: '消费', sortable: true },
        { prop: 'createTime', label: '创建日期', sortable: true, formatter: row => utils.formatDate(row.createTime) },
        { prop: 'status', label: '状态', formatter: row => PLAN_STATUS[row.status].name }
      ],
      tableColumnObj: {
        planName: '',
        switch: '',
        budget: '',
        surplusBudget: '',
        exposure: '',
        click: '',
        clickRate: '',
        clickPrice: '',
        download: '',
        downloadRate: '',
        downloadPrice: '',
        exposurePrice: '',
        cost: '',
        createTime: '',
        status: 1111
      },
      currPlan: null,
      currPlanFormList: [],
      planCount: {},
      summary: null,
      configCost: 50
    }
  },
  computed: {
    planListTable () {
      return (this.summary ? [{ ...this.tableColumnObj, ...this.summary }] : []).concat(this.planList)
    }
  },
  methods: {
    onEdit (plan, prop) {
      if (prop) {
        this.currPlan = plan._formData
        this.currPlan.configCost = this.configCost
        this.currPlanFormList = [prop]
      } else {
        utils.newTab(this.$router.resolve({ name: 'AdEditPlan', query: { planId: plan.planId } }))
      }
    },
    onDelete (plan) {
      this.$confirm('删除广告计划，会导致广告计划下的所有单元、创意都被删除，且无法恢复，请确认是否要继续删除？', '', {
        type: 'warning'
      }).then(() => {
        destroyPlan(plan.planId).then(res => {
          if (res.code === 200) {
            this.$message.success('删除成功')
            this.fetchPlanList()
          }
        }).catch(error => {
          this.$message.error(error.message)
        })
      })
    },
    onSizeChange (currSize) {
      this.formData.pageSize = currSize
      this.fetchPlanList()
    },
    onPageChanged (currPage) {
      this.formData.pageNumber = currPage
      this.fetchPlanList()
    },
    onChangeStatus (plan) {
      togglePlanStatus(plan.status === 0, plan.planId).then(res => {
        if (res.code !== 200) {
          plan.status = +!plan.status
        }
      })
    },
    fetchPlanList () {
      this.fetching = true
      getPlanList({
        ...this.formData,
        desc: (this.order === 'descending') * 1,
        orderBy: this.orderBy
      }).then(res => {
        if (res.code === 200) {
          this.fetchSummary()
          this.configCost = res.value.configCost
          this.planListTotal = res.value.total
          this.planList = res.value.data.map(plan => {
            plan._formData = {...plan}
            plan.exposurePrice = plan.exposure ? Number(((plan.cost / plan.exposure) * 1000).toFixed(2)) : 0
            plan.clickPrice = plan.click ? Number((plan.cost / plan.click).toFixed(2)) : 0
            plan.downloadPrice = plan.download ? Number((plan.cost / plan.download).toFixed(2)) : 0
            if (plan.budget >= MAX_BUDGET) {
              plan.budget = '不限额'
              plan.surplusBudget = '-'
            }
            return plan
          })
        }
      }).finally(() => {
        setTimeout(() => {
          this.fetching = false
        }, 300)
      })
    },
    fetchSummary () {
      getPlanSummary({
        ...this.formData
      }).then(res => {
        if (res.code === 200) {
          let summary = res.value
          summary.exposurePrice = summary.exposure ? Number(((summary.cost / summary.exposure) * 1000).toFixed(2)) : 0
          summary.clickPrice = summary.click ? Number((summary.cost / summary.click).toFixed(2)) : 0
          summary.downloadPrice = summary.download ? Number((summary.cost / summary.download).toFixed(2)) : 0
          this.summary = summary
        }
      })
    },
    fetchCount () {
      getPlanCount().then(res => {
        if (res.code === 200) {
          this.planCount = res.value
        }
      })
    }
  },
  watch: {
    formData (val) {
      this.debounceFetchPlanList()
    }
  },
  created () {
    this.debounceFetchPlanList = utils.debounce(this.fetchPlanList)
    this.fetchList = this.debounceFetchPlanList
    this.fetchCount()
  },
  components: {
    SuperForm,
    PlanEditDialog
  }
}
</script>
