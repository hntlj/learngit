<template>
  <div class="home-index">
    <!-- <div class="home-card pd24" v-if="activityVisible" style="margin-bottom: 24px;position: relative;">
      <a class="home-activity__close" @click="onCloseActivity"><i class="el-icon-close"></i></a>
      <div class="home-activity">
        <img src="https://about.canva.com/wp-content/uploads/sites/3/2017/02/congratulations_-banner.png" alt="" class="home-activity__banner">
        <div class="home-activity__btn">
          <a href="#">申请加入</a>
        </div>
        <div class="home-activity__main">
          <div class="middleWrap">
            <h2>五一期间推广费用 7折起</h2>
            <p>活动时间：2018-04-27 ~ 2018-05-01</p>
            <p>推广资源：首页轮播图、悬浮窗、搜索热词、活动push等资源位，共 12个，竞价得出资源位和排序 <a href="#">活动详情</a></p>
          </div>
        </div>
      </div>
    </div> -->
    <el-row :gutter="24">
      <el-col :span="17">
        <div class="home-card home-consume index-consume">
          <div class="home-consume__btn"><router-link :to="{ name: 'Recharge' }">充值</router-link></div>
          <div class="home-consume__wrap">
            <div class="stat">
              <i class="consume-icon-balance"></i><p><small>总余额（元）</small><b :title="accountState.accountBalance | currency">{{ accountState.accountBalance | currency }}</b></p>
            </div>
            <div class="stat">
              <i class="consume-icon-cash"></i><p><small>现金余额（元）</small><b :title="accountState.rebateBalance | currency">{{ accountState.accountBalance - accountState.rebateBalance | currency }}</b></p>
            </div>
            <div class="stat">
              <i class="consume-icon-rebate"></i><p><small>返点余额（元）</small><b :title="accountState.rebateBalance | currency">{{ accountState.rebateBalance | currency }}</b></p>
            </div>
            <div class="stat">
              <i class="consume-icon-consume"></i><p><small>今日消费（元）</small><b :title="accountState.cost | currency">{{ accountState.cost | currency }}</b></p>
            </div>
          </div>
        </div>
      </el-col>
      <el-col :span="7">
        <div class="home-card home-stat">
          <h2 class="home-stat__title">广告创意统计</h2>
          <dl><dt>今日投放：</dt> <dd>{{ accountState.releaseCount | number }}</dd></dl>
          <dl><dt>待审核：</dt> <dd>{{ accountState.unverifyCount | number }}</dd></dl>
          <dl><dt>有效投放：</dt> <dd>{{ accountState.effectiveCount | number }}</dd></dl>
          <dl><dt>未通过：</dt> <dd>{{ accountState.verifyFail | number }}</dd></dl>
        </div>
      </el-col>
    </el-row>
    <!-- 整体数据 -->
    <div class="home-card pd20 mt12">
      <div class="home-card__header margin-no">
        <h3>账户概览<small>（当天数据存在延迟，仅供参考）</small></h3>
        <!-- <simple-date-picker class="pull-right" v-model="dateRange" /> -->
        <el-date-picker class="pull-right" v-model="dateRangeVal" type="daterange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" :picker-options="pickerOptions"></el-date-picker>
      </div>
      <div class="home-card__main">
        <dl class="home-statData">
          <dt>曝光量（次）</dt>
          <dd>{{ userDataSum.exposure | number }}</dd>
        </dl>
        <dl class="home-statData">
          <dt>点击量（次）</dt>
          <dd>{{ userDataSum.click | number }}</dd>
        </dl>
        <dl class="home-statData">
          <dt>下载量（次）</dt>
          <dd>{{ userDataSum.download | number }}</dd>
        </dl>
        <dl class="home-statData">
          <dt>消费金额（元）</dt>
          <dd>{{ userDataSum.cost | currency }}</dd>
        </dl>
      </div>
      <div class="home-indicatorlist">
        <el-select v-model="userDataInd[0]">
          <el-option v-for="ind in indicatorList" :key="ind.key" :value="ind.key" :label="ind.name" v-if="ind.key !== userDataInd[1]"></el-option>
        </el-select>
        <el-select v-model="userDataInd[1]" class="pull-right">
          <el-option v-for="ind in indicatorList" :key="ind.key" :value="ind.key" :label="ind.name" v-if="ind.key !== userDataInd[0]"></el-option>
        </el-select>
      </div>
      <line-chart :hour="isHour" :data="charData" :ind="multiInd" :times="timeRange"></line-chart>
    </div>
    <!-- 数据排行 -->
    <el-row :gutter="24" class="mt12">
      <el-col :span="6" v-for="(_, idx) in rankInd" :key="idx">
        <div class="home-ranklist home-card pd24">
          <div class="home-card__header">
            <h3>TOP 5</h3>
            <el-select class="pull-right" v-model="rankInd[idx]">
              <el-option v-for="ind in indicatorList" :key="ind.key" :value="ind.key" :label="ind.name"></el-option>
            </el-select>
          </div>
          <div class="home-card__main">
            <dl v-for="(item, _idx) in rankList[rankInd[idx]]" :key="_idx">
              <dt>{{ item.ideaName }}</dt>
              <dd class="pull-right" v-if="rankInd[idx] === 'cost'">{{ item.value | currency }}</dd>
              <dd class="pull-right" v-else-if="rankInd[idx].indexOf('Rate') > 0">{{ item.value + '%' }}</dd>
              <dd class="pull-right" v-else>{{ item.value | number }}</dd>
             </dl>
          </div>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import utils from '@/utils'
import { STAT_INDICATOR } from '@/enums'
import { getStatSponsorList, getTopIdeaList } from '@/api'
import SimpleDatePicker from '@/components/SimpleDatePicker'
import LineChart from '@/components/LineChart'
const DEFULAT_DIMENSION = Object.keys(STAT_INDICATOR)
export default {
  data () {
    return {
      activityVisible: true,
      dateRangeVal: [new Date(), new Date()].map(v => utils.formatDate(v)),
      dateRange: [new Date(), new Date()].map(v => utils.formatDate(v)),
      indicatorList: Object.values(STAT_INDICATOR),
      rankInd: DEFULAT_DIMENSION.slice(0, 4),
      rankList: [],
      userDataInd: DEFULAT_DIMENSION.slice(0, 2),
      userData: [],
      userDataSum: {
        exposure: 0,
        click: 0,
        download: 0,
        cost: 0
      },
      pickerOptions: {
        disabledDate (time) {
          return time.getTime() > Date.now()
        },
        shortcuts: [{
          text: '今天',
          onClick (picker) {
            picker.$emit('pick', [new Date(), new Date()])
          }
        }, {
          text: '昨天',
          onClick (picker) {
            const date = new Date()
            date.setTime(date.getTime() - 3600 * 1000 * 24)
            picker.$emit('pick', [date, date])
          }
        }, {
          text: '一周前',
          onClick (picker) {
            const date = new Date()
            date.setTime(date.getTime() - 3600 * 1000 * 24 * 6)
            picker.$emit('pick', [date, new Date()])
          }
        }, {
          text: '最近30天',
          onClick (picker) {
            const date = new Date()
            date.setTime(date.getTime() - 3600 * 1000 * 24 * 29)
            picker.$emit('pick', [date, new Date()])
          }
        }]
      }
    }
  },
  computed: {
    ...mapGetters(['accountState']),
    isHour () {
      return this.dateRange[0] === this.dateRange[1]
    },
    multiInd () {
      return this.userDataInd.map(ind => STAT_INDICATOR[ind])
    },
    timeRange () {
      let range = []
      if (this.isHour) {
        for (let i = 0; i <= 24; i++) {
          range.push(('0' + i).slice(-2) + ':00')
        }
      } else {
        let start = new Date(this.dateRange[0]).getTime()
        let end = new Date(this.dateRange[1]).getTime()
        while (start <= end) {
          range.push(utils.formatDate(start))
          start += 86400000
        }
      }
      return range
    },
    charData () {
      const data1 = this._formatData(this.userDataInd[0])
      const data2 = this._formatData(this.userDataInd[1])
      return [data1, data2]
    }
  },
  methods: {
    onCloseActivity () {
      this.activityVisible = false
    },
    fetchUserData () {
      const [startTime, endTime] = this.dateRange
      getStatSponsorList({
        startTime,
        endTime
      }).then(res => {
        if (res.code === 200) {
          this.userData = (res.value.data || []).map(item => {
            item.clickRate = item.exposure !== 0 ? Math.round(item.click / item.exposure * 10000) / 100 : 0
            item.downloadRate = item.exposure !== 0 ? Math.round(item.download / item.exposure * 10000) / 100 : 0
            item.exposurePrice = item.exposure ? Number(((item.cost / item.exposure) * 1000).toFixed(2)) : 0
            item.clickPrice = item.click ? Number((item.cost / item.click).toFixed(2)) : 0
            item.downloadPrice = item.download ? Number((item.cost / item.download).toFixed(2)) : 0
            return item
          })
          this.userDataSum = this.userData.reduce((mem, curr) => {
            return {
              exposure: (mem.exposure || 0) + curr.exposure,
              click: (mem.click || 0) + curr.click,
              download: (mem.download || 0) + curr.download,
              cost: (mem.cost || 0) + curr.cost
            }
          }, {})
        }
      })
    },
    fetchTopIdeaList () {
      const [startTime, endTime] = this.dateRange
      getTopIdeaList({
        dimension: DEFULAT_DIMENSION.join(','),
        startTime,
        endTime
      }).then(res => {
        if (res.code === 200) {
          this.rankList = res.value
        }
      })
    },
    _formatData (ind) {
      const result = new Array(this.timeRange.length).fill(0)
      if (this.isHour) {
        this.userData.forEach(data => {
          const idx = utils.formatDate(data.statTime, 'H')
          result[idx] = data[ind]
        })
      } else {
        this.userData.forEach(data => {
          const idx = this.timeRange.indexOf(utils.formatDate(data.statTime))
          result[idx] = data[ind]
        })
      }
      return result
    }
  },
  watch: {
    dateRangeVal: {
      handler: function (val) {
        this.dateRange = val.map(date => {
          return utils.formatDate(new Date(date).getTime())
        })
      },
      immediate: true
    },
    dateRange: {
      handler: function (val) {
        this.fetchUserData()
        this.fetchTopIdeaList()
      },
      immediate: true
    }
  },
  created () {
    this.$store.dispatch('getAccountState')
  },
  components: {
    SimpleDatePicker,
    LineChart
  }
}
</script>

<style lang="scss">
.home-index {
  padding: 12px 24px;
  background-color: #efefef;
}
.home-activity {
  position: relative;
  overflow: hidden;
  &__close {
    position: absolute;
    top: 14px;
    right: 17px;
    color: #999;
    cursor: pointer;
  }
  &__banner {
    float: left;
    display: block;
    width: 492px;
    height: 210px;
  }
  &__main {
    margin-left: 528px;
    margin-right: 401px;
    display: flex;
    height: 210px;
    h2 {
      margin-top: 21px;
      margin-bottom: 48px;
      font-size: 30px;
      line-height: 40px;
    }
    p {
      font-size: 16px;
      color: gray(.4);
      line-height: 32px;
      a {
        display: inline-block;
      }
    }
  }
  &__btn {
    margin-top: 65px;
    float: right;
    padding: 16px 56px 16px 80px;
    border-left: 1px solid gray(.1);
    a {
      display: inline-block;
      text-align: center;
      width: 240px;
      height: 57px;
      color: #fff;
      font-size: 20px;
      line-height: 57px;
      border-radius: 6px;
      background-image: linear-gradient(to right, #3a71ee 0%, #448ef0 100%);
    }
  }
}

.home-indicatorlist {
  margin-top: 5px;
}
.home-stat {
  padding: 10px 20px;
  font-size: 18px;

  &__title {
    line-height: 24px;
    font-weight: 700;
  }
  dl {
    display: inline-block;
    width: 48%;
    dt,dd {
      display: inline-block;
      line-height: 24px;
    }
    dt {
      margin-top: 9px;
    }
    dd {
      color: $blue;
    }
  }
}
.home-statData {
  display: inline-block;
  min-width: 210px;
  box-sizing: border-box;
  padding: 5px 10px;
  border: 1px solid gray(.1);
  border-radius: 4px;
  margin-right: 12px;
  dt {
    font-size: 12px;
    line-height: 16px;
    color: gray(.4)
  }
  dd {
    font-size: 24px;
    line-height: 25px;
    color: #ca2b2b;
  }
}
.home-ranklist {
  min-height: 320px;
  dl:not(:last-child) {
    margin-bottom: 30px
  }
  dt,dd {
    display: inline;
    line-height: 19px;
  }
}
.margin-no {
  margin: 0 !important;
}
.index-consume {
  padding: 10px 0 !important;
}
</style>
