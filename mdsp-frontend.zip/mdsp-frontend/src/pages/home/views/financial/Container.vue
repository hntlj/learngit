<template>
  <div class="home-container">
    <home-aside :nav-list="navList" module="financial"></home-aside>
    <main class="home-main">
      <router-view/>
    </main>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import HomeAside from '@/components/Aside'
export default {
  data () {
    return {
      navList: [
        { name: 'Recharge', title: '充值' },
        { name: 'Transaction', title: '交易申请记录' },
        { name: 'FinancialDetails', title: '财务明细' }

      ]
    }
  },
  components: {
    HomeAside
  },
  computed: {
    ...mapGetters(['userInfo'])
  },
  watch: {
    userInfo (val) {
      if (val.busDepartment === 12) {
        this.navList.splice(3, 0, { name: 'invoiceList', title: '发票申请记录' })
      }
    }
  },
  mounted () {
    if (this.userInfo.busDepartment === 12) {
      this.navList.splice(3, 0, { name: 'invoiceList', title: '发票申请记录' })
    }
  }
}
</script>

<style lang="scss">
</style>
