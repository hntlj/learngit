<template>
  <div class="pd24">
    <div class="home-card pd24">
      <div class="home-card__header line">
        <h2>交易申请记录</h2>
        <el-button type="primary" class="pull-right" style="width: 130px" @click="onExport">导出报表</el-button>
      </div>
      <div class="home-card__main">
        <super-form class="home-searchform" label-width="0px" :form-list="searchOptions" v-model="formData"></super-form>
        <el-table class="table-border" :data="dataList" :row-class-name="summaryRowIndex" v-loading="fetching">
          <el-table-column header-align="center" :align="col.align || 'center'" v-for="col in tableColumn" :key="col.prop"
            :prop="col.prop"
            :label="col.label"
            :formatter="col.formatter">
          </el-table-column>
        </el-table>
      </div>
      <div class="home-card__footer">
        <el-pagination class="pull-right"
          v-if="dataListTotal > defaultPageSize"
          background
          :page-size="PAGE_SIZE"
          :page-sizes="PAGE_SIZES"
          :current-page="formData.pageNumber"
          :total="dataListTotal"
          @size-change="onSizeChange"
          @current-change="onPageChanged"
          layout="total, sizes, prev, pager, next, jumper">
        </el-pagination>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { getRechargeTransferList, exportRechargeTransferList } from '@/api'
import utils from '@/utils'
import { MONEY_TYPE, TRANSCATION_STATUS, PAGE_SIZE, PAGE_SIZES } from '@/enums'
import { filters } from '@/utils/filters'
import SuperForm from '@/components/SuperForm'
export default {
  data () {
    return {
      fetching: false,
      formData: null,
      dataListTotal: 0,
      dataList: [],
      tableColumn: [
        { prop: 'date', label: '交易日期', formatter: row => utils.formatDate(row.date) },
        { prop: 'type', label: '交易类型', formatter: row => MONEY_TYPE[row.type].name },
        { prop: 'money', label: '金额', formatter: row => filters.currency(row.money) },
        { prop: 'name', label: '转入方' },
        { prop: 'transferName', label: '转出方' },
        { prop: 'status', label: '状态', formatter: row => this.formatStatus(row) }
      ],
      defaultPageSize: PAGE_SIZE,
      PAGE_SIZE,
      PAGE_SIZES
    }
  },
  computed: {
    ...mapGetters(['isSponsor']),
    searchOptions () {
      const date = new Date()
      date.setTime(date.getTime() - 3600 * 1000 * 24 * 6)
      let options = [
        { type: 'hidden', key: 'pageNumber', default: 1 },
        { type: 'hidden', key: 'pageSize', default: PAGE_SIZE },
        { type: 'text', key: 'name', placeholder: '客户名称', default: this.$route.query.name || '' },
        { type: 'select', key: 'moneyType', label: '类型', options: Object.values(MONEY_TYPE).map(({name: label, value}) => ({label, value})) },
        { type: 'daterange', key: 'Time', label: '选择日期', default: [date, new Date()] }
      ]
      if (this.isSponsor) {
        options.splice(2, 1)
      }
      return options
    }
  },
  methods: {
    onExport () {
      exportRechargeTransferList(this.isSponsor, this.formData)
    },
    onSizeChange (currSize) {
      this.formData.pageSize = currSize
      this.debounceFetchTransferList()
    },
    onPageChanged (currPage) {
      this.formData.pageNumber = currPage
      this.debounceFetchTransferList()
    },
    summaryRowIndex ({row, rowIndex}) {
      if (rowIndex === 0) {
        return 'summary-row'
      }
      return ''
    },
    fetchTransferList () {
      this.fetching = true
      getRechargeTransferList(this.isSponsor, this.formData).then(res => {
        if (res.code === 200) {
          this.dataListTotal = res.value.total
          this.dataList = res.value.data
          this.dataList.forEach(element => {
            if (element.type === 3) element.transferName = '魅族广告平台'
          })
        }
      }).finally(() => {
        setTimeout(() => {
          this.fetching = false
        }, 300)
      })
    },
    formatStatus (log) {
      if (log.status === 1 && log.type === 1) {
        return '审核通过'
      }
      return TRANSCATION_STATUS[log.status].name
    }
  },
  watch: {
    formData (val) {
      this.debounceFetchTransferList()
    },
    '$route.query.name' (val) {
      this.formData.name = val || ''
      this.debounceFetchTransferList()
    }
  },
  created () {
    this.debounceFetchTransferList = utils.debounce(this.fetchTransferList)
  },
  components: {
    SuperForm
  }
}
</script>

<style lang="scss">
</style>
