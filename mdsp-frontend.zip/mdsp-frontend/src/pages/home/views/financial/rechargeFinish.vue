<template>
    <div class="rechargeFinish">
        <div class="rechargeInfo">
            当前充值正在审核中，平台会尽快通过
        </div>
        <div>
            <el-button type="primary" @click="jumpUrl('/promotion/AdPlan')">去投放广告</el-button>
            <el-button type="primary" @click="jumpUrl('/financial/Transaction')">查看充值记录</el-button>
        </div>
    </div>
</template>
<script>
export default {
  data () {
    return {

    }
  },
  methods: {
    jumpUrl (url) {
      this.$router.push(url)
    }
  }
}
</script>
<style lang="scss">
.rechargeFinish{
    width: 100%;
    text-align: center;
    .rechargeInfo{
        margin: 100px 0 100px 0;
    }
}
</style>
