<template>
  <div class="pd24">
    <div class="home-recharge home-card pd24">
      <div class="recharge-type" v-if="userInfo.busDepartment == 12">
        <div class="recharge-btn" v-for="(item, index) in rechargeType" :key="index" :class="[actionIndex == index ? 'btn-action' : '']" @click="changeRechar(index)">{{item}}</div>
      </div>
      <div class="home-card__header line">
        <!-- <small>(目前只提供线下转账的方式，其他支付方式正在开发，敬请期待)</small> -->
        <h2>充值</h2>
      </div>
      <div class="offline-recharge" v-if="!actionIndex">
        <div class="home-card__main">
          <p class="home-recharge__desc">请转账到以下银行账户</p>
          <div class="bankcard">
            <dl>
              <dt>开户名</dt><dd>{{ bankInfo.company }}</dd>
            </dl>
            <dl>
              <dt>开户行</dt><dd>{{ bankInfo.bank }}</dd>
            </dl>
            <dl>
              <dt>账号</dt><dd>{{ bankInfo.cardNo }}</dd>
            </dl>
          </div>
        </div>
        <div class="home-card__footer">
          <el-button type="primary" @click="dialogVisible=true">上传充值凭证</el-button>
        </div>

        <div class="recharge-cert" v-if="rechargeList.length > 0">
          <h4>待审核的充值凭证</h4>
          <div class="clearfix">
            <div class="recharge-cert__card" v-for="record in rechargeList" :key="record.id">
              <a @click="onDelete(record)" class="closebtn"><i class="el-icon-close"></i></a>
              <dl>
                <dt>公司名称</dt><dd>{{ record.name }}</dd>
              </dl>
              <dl>
                <dt>账号</dt><dd>{{ record.bankNum }}</dd>
              </dl>
              <dl>
                <dt>金额</dt><dd>{{ record.money | currency }} 元</dd>
              </dl>
              <dl>
                <dt>流水号</dt><dd>{{ record.orderId }}</dd>
              </dl>
              <dl v-if="record.receiptFile">
                <dt>流水号</dt><dd><img :src="record.receiptFile" alt=""></dd>
              </dl>
              <dl>
                <dt>备注</dt><dd>{{ record.remark || '无' }}</dd>
              </dl>
            </div>
          </div>
          <p class="tip"><em>*</em> 审核通过后立即为你充值到账号余额</p>
        </div>

        <el-dialog title="上传充值凭证" :visible.sync="dialogVisible" width="750px" class="recharge-dialog">
          <el-form label-width="220px" ref="form_1" :model="formData" :rules="rules">
            <el-form-item label="广告主名称" class="lh1">{{ userInfo.flyme }}</el-form-item>
            <el-form-item label="账户 ID" class="lh1">{{ userInfo.uid }}</el-form-item>
            <el-form-item label="汇款 / 转账公司名称" prop="name">
              <el-input v-model="formData.name" :maxlength="32"></el-input>
            </el-form-item>
            <el-form-item label="汇款 / 转账账号" prop="bankNum">
              <el-input v-model="formData.bankNum" :maxlength="32"></el-input>
            </el-form-item>
            <el-form-item label="汇款 / 转账金额" prop="money">
              <el-input v-model.number="formData.money">
                <template slot="append">元</template>
              </el-input>
            </el-form-item>
            <el-form-item label="银行流水号" prop="orderId">
              <el-input v-model="formData.orderId" :maxlength="100"></el-input>
            </el-form-item>
            <el-form-item label="汇款 / 转账凭证" prop="receiptFile">
              <image-upload v-model="formData.receiptFile"></image-upload>
            </el-form-item>
            <el-form-item label="备注">
              <el-input v-model="formData.remark" type="textarea"></el-input>
            </el-form-item>
          </el-form>
          <div slot="footer">
            <el-button @click="onClose">取消</el-button>
            <el-button type="primary" @click="onConfirm">保存</el-button>
          </div>
        </el-dialog>

        <confirmation-dialog
          :confirmation-dialog-visible="confirmationDialogVisible"
          :confirmation-title="confirmationTitle"
          :confirmation-info="confirmationInfo"
          @close="confirmationDialogVisible=false"
          @confirmHandle="debounceOnSave">
        </confirmation-dialog>
      </div>
      <div class="online-recharge" v-else>
        <el-form label-position="left" label-width="120px" ref="form_2" :model="rechargeFormData" :rules="rules_2">
          <el-form-item label="充值账户" class="lh1">{{ userInfo.flyme }}</el-form-item>
          <el-form-item label="账户总余额" class="lh1">
            {{ accountState.accountBalance }}
            <span class="padd-l-50">现金余额： <span>{{accountState.accountBalance - accountState.rebateBalance}}</span></span>
            <span class="padd-l-50">返点余额： <span>{{accountState.rebateBalance}}</span></span>
          </el-form-item>
          <el-form-item label="充值金额" prop="money">
            <el-input v-model.number="rechargeFormData.money">
              <template slot="append">元</template>
            </el-input>
          </el-form-item>
          <el-form-item label="支付方式" prop="type">
            <el-radio-group class="padd-l-50" v-model="rechargeFormData.type">
              <el-radio :label="1">支付宝</el-radio>
              <!-- <el-radio :label="2">微信</el-radio> -->
            </el-radio-group>
          </el-form-item>
        </el-form>
        <el-button class="goRecharge" type="primary" @click="goRecharge">去充值</el-button>
        <div class="recharge-tip">
          说明：<br/>
          1、必须使用公司支付帐号充值。<br/>
          2、首次充值3000元起，后续续费1000元起，小于10万元。<br/>
          3、关于第三方支付平台扣取的手续费，营销平台会在您的返点余额中增加相应的金额，且在广告消耗中优先使用返点金额。<br/>
        </div>
        <!-- <div ref="formCont" class="formCont" v-html="payGateWay">{{payGateWay}}</div> -->
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { BANK_INFO } from '@/enums'
import { addRecharge, onlineAdd, getUnauditTransferList, deleteUnauditTransferList } from '@/api'
import validateMixin from '@/mixins/validate'
import utils from '@/utils/index'
import ImageUpload from '@/components/home/ImageUpload'
import ConfirmationDialog from '@/components/ConfirmationDialog'
export default {
  mixins: [validateMixin],
  data () {
    const moneyValidator = (rule, value, callback) => {
      if (isNaN(value)) {
        callback(new Error('汇款 / 转账金额格式不正确'))
      } else if (value < 10000) {
        callback(new Error('汇款 / 转账金额至少为10,000元'))
      } else if (value > 21474836.47) {
        callback(new Error('汇款 / 转账金额不能超过21,474,836.47元'))
      } else {
        callback()
      }
    }
    return {
      bankInfo: BANK_INFO,
      dialogVisible: false,
      formData: {
        name: '',
        bankNum: '',
        money: '',
        orderId: '',
        receiptFile: '',
        remark: ''
      },
      rechargeFormData: {
        money: '',
        type: 1
      },
      rules: {
        name: { required: true, message: '请输入汇款 / 转账公司名称', trigger: 'change' },
        bankNum: { required: true, message: '请输入汇款 / 转账账号', trigger: 'change' },
        money: [
          { required: true, message: '请输入汇款 / 转账金额', trigger: 'change' },
          { validator: moneyValidator, trigger: 'change' }
        ],
        orderId: [{ required: true, message: '请输入银行流水号', trigger: 'change' }],
        receiptFile: [{ required: true, message: '请上传充值凭证', trigger: 'change' }]
      },
      rules_2: {
        money: { required: true, message: '请输入充值金额', trigger: 'change' },
        type: { required: true, message: '请选择支付方式', trigger: 'change' }
      },
      rechargeList: [],
      confirmationDialogVisible: false,
      confirmationTitle: '请确认您的充值信息',
      confirmationInfo: [],
      rechargeType: ['线下充值', '在线充值'],
      actionIndex: 0,
      payGateWay: ''
    }
  },
  computed: {
    ...mapGetters(['userInfo', 'isSponsor', 'accountState'])
  },
  methods: {
    async onConfirm () {
      const valid = await this.validate()
      if (valid) {
        this.confirmationInfo = [
          {
            label: '账户名称',
            value: this.userInfo.flyme
          }, {
            label: '账户ID',
            value: this.userInfo.uid
          }, {
            label: '充值金额',
            value: this.formData.money
          }
        ]
        this.confirmationDialogVisible = true
      }
    },
    onSave () {
      let flowId = String(new Date().getTime()) +
                  String(this.userInfo.uid) +
                  'ad' + 0
      addRecharge({
        ...this.formData, flowId
      }).then(res => {
        if (res.code === 200) {
          this.$message.success('上传成功')
          this.fetchRechargeList()
          this.onClose()
        }
      }).catch(error => {
        this.$message.error(error.message)
      })
    },
    debounceOnSave () {},
    onDelete (record) {
      this.$confirm('该充值凭证尚未审核，确定要移除吗？', '', {
        type: 'warning'
      }).then(() => {
        deleteUnauditTransferList(this.isSponsor, { rechargeReceiptId: record.id }).then(res => {
          if (res.code === 200) {
            this.fetchRechargeList()
          }
        }).catch(error => {
          this.$message.error(error.message)
        })
      })
    },
    onClose () {
      this.formData = {
        name: '',
        bankNum: '',
        money: '',
        orderId: '',
        receiptFile: '',
        remark: ''
      }
      this.dialogVisible = false
    },
    fetchRechargeList () {
      const date = new Date()
      date.setTime(date.getTime() - 3600 * 1000 * 24 * 30)
      getUnauditTransferList(this.isSponsor).then(res => {
        if (res.code === 200) {
          this.rechargeList = res.value
        }
      })
    },
    changeRechar (i) {
      this.$store.dispatch('getAccountState')
      console.log(this.accountState)
      this.actionIndex = i
    },
    async goRecharge () {
      const valid = await this.validate()
      if (valid) {
        onlineAdd(this.rechargeFormData).then(res => {
          console.log(res)
          let divForm = document.getElementsByTagName('divform')
          if (divForm.length) {
            document.body.removeChild(divForm[0])
          }
          const div = document.createElement('divform')
          div.innerHTML = res.data
          document.body.appendChild(div)
          document.forms[1].setAttribute('target', '_self') // 新开窗口跳转
          document.forms[1].submit()
        }).catch(error => {
          this.$message.error(error.message)
        })
      }
    }
  },
  watch: {
    dialogVisible (val) {
      console.log(this.$refs.form_1)
      if (val && this.$refs.form_1) {
        this.$refs.form_1.clearValidate()
      }
    },
    isSponsor (val) {
      this.fetchRechargeList()
    }
  },
  created () {
    this.fetchRechargeList()
    this.debounceOnSave = utils.debounce(this.onSave)
  },
  components: {
    ImageUpload,
    ConfirmationDialog
  }
}
</script>
<style lang="scss">
.home-recharge {
  padding-bottom: 48px;
  .el-button {
    padding: 11px 32px;
  }
}
.home-recharge__desc {
  font-size: 16px;
  padding-bottom: 20px;
}
.recharge-type{
  height: 40px;
  width: 280px;
  display: flex;
  align-items: center;
  // background-image: linear-gradient(90deg,#3a71ee 0,#448ef0);
  background: #fff;
  color: #448ef0;
  border-radius: 4px;
  cursor: pointer;
  border: 1px solid #448ef0;
}
.recharge-btn{
  text-align: center;
  width: 140px;
  height: 40px;
  line-height: 40px;
}
.btn-action{
  background: #448ef0;
  color: #fff;
  box-sizing: border-box;
}
.padd-l-50{
  padding-left: 50px;
}
.online-recharge{
  font-size: 14px;
  width: 600px;
  .goRecharge{
    float: right;
  }
  .recharge-tip{
    line-height: 25px;
    background: #f0f0f0;
    padding: 10px 20px;
    margin-top: 50px;
  }
}
.bankcard {
  margin-left: -14px;
  width: 419px;
  height: 240px;
  background: url('~assets/img/bankcard.png') no-repeat;
  padding: 110px 0 0 40px;
  color: #fff;
  font-size: 16px;
  line-height: 30px;
  box-sizing: border-box;
  dt,dd {
    display: inline-block;
  }
  dt {
    width: 68px;
    opacity: .6;
  }
}
.recharge-dialog {
  .el-dialog__footer {
    text-align: left;
    margin-left: 220px;
  }
  .el-form-item__content {
    width: 360px;
  }
}
.recharge-cert {
  padding-top: 36px;
  overflow: hidden;
  h4 {
    font-size: 16px;
    line-height: 21px;
  }

  .tip {
    margin-top: 24px;
    font-size: 16px;
    color: gray(.3);
    em {
      color: $red;
    }
  }
  &__card {
    float: left;
    position: relative;
    padding: 24px;
    margin-top: 24px;
    margin-right: 24px;
    background-color: #fafafa;
    border: 1px solid gray(.1);
    width: 370px;
    height: 325px;
    box-sizing: border-box;
    border-radius: 4px;

    .closebtn {
      position: absolute;
      top: 20px;
      right: 20px;
      border-radius: 4px;
      background-color: gray(.2);
      width: 15px;
      height: 15px;
      line-height: 12px;
      text-align: center;
      cursor: pointer;
      i {
        color: #fff;
        font-size: 9px;
      }
    }
    dl {
      margin-bottom: 16px;
      overflow: hidden;
    }
    dt,dd {
      font-size: 14px
    }
    dt {
      float: left;
      width: 56px;
      text-align: right;
    }
    dd {
      word-break: break-all;
      margin-left: 56px;
      padding-left: 24px;
    }
    img {
      width: 120px;
      height: 80px;
    }
  }
}
</style>
