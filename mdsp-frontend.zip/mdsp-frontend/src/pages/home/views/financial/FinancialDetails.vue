<template>
  <div class="pd24">
    <div class="home-card pd24">
      <div class="home-card__header line">
        <h2>财务明细</h2>
        <el-button type="primary" class="pull-right" style="width: 130px" @click="onExport">导出报表</el-button>
      </div>
      <div class="home-card__main">
        <super-form class="home-searchform" label-width="0px" :form-list="searchOptions" v-model="formData"></super-form>
        <el-table class="table-border" :data="dataList" :row-class-name="summaryRowIndex" v-loading="fetching">
          <el-table-column header-align="center" :align="col.align || 'center'" v-for="col in tableColumn" :key="col.prop"
            :prop="col.prop"
            :label="col.label"
            :formatter="col.formatter">
          </el-table-column>
          <el-table-column
            label="操作"
            width="108">
            <template slot-scope="scope">
            <el-button
            v-if="scope.row.rechargeType == 1"
            :disabled="scope.row.hasReceipt"
                @click="showInvoiceCont(scope.row)"
                type="text"
                size="small">
                申请发票
            </el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="home-card__footer">
        <el-pagination class="pull-right"
          v-if="dataListTotal > defaultPageSize"
          background
          :page-size="PAGE_SIZE"
          :page-sizes="PAGE_SIZES"
          :current-page="formData.pageNumber"
          :total="dataListTotal"
          @size-change="onSizeChange"
          @current-change="onPageChanged"
          layout="total, sizes, prev, pager, next, jumper">
        </el-pagination>
      </div>
      <invoice-dialog :dialog-visible="dialogVisible" :InvoiceFormData="InvoiceFormData" @close="hidenInvoiceCont"></invoice-dialog>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { getFinanicalList, exportFinanicalList } from '@/api'
import utils from '@/utils'
import { FINANCILA_TYPE, PAGE_SIZE, PAGE_SIZES } from '@/enums'
import InvoiceDialog from '@/components/home/financial/InvoiceDialog'
import { filters } from '@/utils/filters'
import SuperForm from '@/components/SuperForm'
import Storage from '@/utils/storage'
export default {
  data () {
    return {
      fetching: false,
      formData: null,
      dataListTotal: 0,
      dataList: [],
      tableColumn: [
        { prop: 'createTime', label: '日期', formatter: row => row.statDate },
        { prop: 'type', label: '类型', formatter: row => FINANCILA_TYPE[row.type].name },
        { prop: 'money', label: '现金金额', formatter: row => filters.currency(row.cash) },
        { prop: 'rebatesMoney', label: '返点金额', formatter: row => filters.currency(row.rebatesMoney) }
      ],
      defaultPageSize: PAGE_SIZE,
      PAGE_SIZE,
      PAGE_SIZES,
      showInvoice: false,
      addKwPackageName: '',
      dialogVisible: false,
      InvoiceFormData: {
        registrationNumber: '',
        depositBank: '',
        bankAccount: '',
        companyRegisteredAddress: '',
        companyRegisteredPhone: '',
        receiptType: '',
        addresseeName: '',
        addresseePhone: '',
        receiverAddress: ''
      }
    }
  },
  computed: {
    ...mapGetters(['userInfo', 'isSponsor']),
    searchOptions () {
      const date = new Date()
      date.setTime(date.getTime() - 3600 * 1000 * 24 * 6)
      let options = [
        { type: 'hidden', key: 'pageNumber', default: 1 },
        { type: 'hidden', key: 'pageSize', default: PAGE_SIZE },
        { type: 'select', key: 'type', label: '类型', options: Object.values(FINANCILA_TYPE).map(({name: label, value}) => ({label, value})) },
        { type: 'daterange', key: 'Time', label: '选择日期', default: [date, new Date()] }
      ]
      return options
    }
  },
  methods: {
    onExport () {
      exportFinanicalList(this.formData)
    },
    onSizeChange (currSize) {
      this.formData.pageSize = currSize
      this.debounceFetchTransferList()
    },
    onPageChanged (currPage) {
      this.formData.pageNumber = currPage
      this.debounceFetchTransferList()
    },
    summaryRowIndex ({row, rowIndex}) {
      if (rowIndex === 0) {
        return 'summary-row'
      }
      return ''
    },
    fetchTransferList () {
      this.fetching = true
      getFinanicalList(this.formData).then(res => {
        if (res.code === 200) {
          this.dataListTotal = res.value.size
          this.dataList = res.value.data
        }
      }).finally(() => {
        setTimeout(() => {
          this.fetching = false
        }, 300)
      })
    },
    hidenInvoiceCont () {
      this.debounceFetchTransferList()
      this.dialogVisible = false
    },
    showInvoiceCont (row) {
      let InvoiceFormData = {}
      if (Storage.get('InvoiceFormData')) {
        InvoiceFormData = Storage.get('InvoiceFormData')
      }
      this.InvoiceFormData = {
        name: row.name,
        registrationNumber: InvoiceFormData.registrationNumber || '',
        depositBank: InvoiceFormData.depositBank || '',
        bankAccount: InvoiceFormData.bankAccount || '',
        companyRegisteredAddress: InvoiceFormData.companyRegisteredAddress || '',
        companyRegisteredPhone: InvoiceFormData.companyRegisteredPhone || '',
        receiptType: InvoiceFormData.receiptType || '',
        addresseeName: InvoiceFormData.addresseeName || '',
        addresseePhone: InvoiceFormData.addresseePhone || '',
        receiverAddress: InvoiceFormData.receiverAddress || ''
      }
      this.InvoiceFormData['rechargeReceiptId'] = row.rechargeId
      this.dialogVisible = true
    }
  },
  watch: {
    formData (val) {
      this.debounceFetchTransferList()
    },
    '$route.query.name' (val) {
      this.formData.name = val || ''
      this.debounceFetchTransferList()
    }
  },
  created () {
    this.debounceFetchTransferList = utils.debounce(this.fetchTransferList)
  },
  components: {
    SuperForm,
    InvoiceDialog
  }
}
</script>

<style lang="scss">
.invoice-flex {
    display: flex;
    justify-content: space-between;
}
.invoice-width{
    width: 530px;
    .invoice-title{
        padding: 0px 0 30px 73px;
        font-weight: bold;
    }
}
.bottom{
    width: 470px;
}
</style>
