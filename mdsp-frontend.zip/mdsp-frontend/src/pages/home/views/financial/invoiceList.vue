<template>
  <div class="pd24">
    <div class="home-card pd24">
      <div class="home-card__header line">
        <h2>发票申请记录</h2>
        <!-- <el-button type="primary" class="pull-right" style="width: 130px" @click="onExport">导出报表</!-->
      </div>
      <div class="home-card__main">
        <super-form class="home-searchform" label-width="0px" :form-list="searchOptions" v-model="formData"></super-form>
        <el-table class="table-border" :data="dataList" :row-class-name="summaryRowIndex" v-loading="fetching">
          <el-table-column header-align="center" :align="col.align || 'center'" v-for="col in tableColumn" :key="col.prop"
            :prop="col.prop"
            :label="col.label"
            :formatter="col.formatter">
          </el-table-column>
          <el-table-column
            label="操作"
            width="108">
            <template slot-scope="scope">
            <el-button
            v-if="scope.row.status == 2"
                @click="showInvoiceCont(scope.row)"
                type="text"
                size="small">
                重新申请
            </el-button>
            </template>
          </el-table-column>
        </el-table>
        <div class="tip">
          <span>说明：1. 发票申请审核通过后，我司财务于次月15日之前出票，以邮寄方式寄出</span>
          <br>
           <span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>2. 当月多笔交易申请，我司财务会根据情况统一汇总开票
        </div>
      </div>
      <div class="home-card__footer">
        <el-pagination class="pull-right"
          v-if="dataListTotal > defaultPageSize"
          background
          :page-size="PAGE_SIZE"
          :page-sizes="PAGE_SIZES"
          :current-page="formData.pageNumber"
          :total="dataListTotal"
          @size-change="onSizeChange"
          @current-change="onPageChanged"
          layout="total, sizes, prev, pager, next, jumper">
        </el-pagination>
      </div>
      <invoice-dialog :dialog-visible="dialogVisible" :InvoiceFormData="InvoiceFormData" @close="hidenInvoiceCont"></invoice-dialog>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { getReceiptList, getReceipt } from '@/api'
import utils from '@/utils'
import { INVOICE_STATUS, INVOICE_TYPE, PAGE_SIZE, PAGE_SIZES } from '@/enums'
import InvoiceDialog from '@/components/home/financial/InvoiceDialog'
import { filters } from '@/utils/filters'
import SuperForm from '@/components/SuperForm'
export default {
  data () {
    return {
      fetching: false,
      formData: null,
      dataListTotal: 0,
      dataList: [],
      tableColumn: [
        { prop: 'createTime', label: '申请日期', formatter: row => utils.formatDate(row.createTime) },
        { prop: 'companyName', label: '发票抬头', formatter: row => row.companyName },
        { prop: 'money', label: '发票金额（元）', formatter: row => filters.currency(row.money) },
        { prop: 'receiptType', label: '发票类型', formatter: row => INVOICE_TYPE[row.receiptType].name },
        { prop: 'status', label: '当前状态', formatter: row => INVOICE_STATUS[row.status].name },
        { prop: 'remark', label: '备注', formatter: row => row.remark }
      ],
      defaultPageSize: PAGE_SIZE,
      PAGE_SIZE,
      PAGE_SIZES,
      showInvoice: false,
      addKwPackageName: '',
      dialogVisible: false,
      InvoiceFormData: {
        registrationNumber: '',
        depositBank: '',
        bankAccount: '',
        companyRegisteredAddress: '',
        companyRegisteredPhone: '',
        receiptType: '',
        addresseeName: '',
        addresseePhone: '',
        receiverAddress: ''
      }
    }
  },
  computed: {
    ...mapGetters(['userInfo', 'isSponsor']),
    searchOptions () {
      const date = new Date()
      date.setTime(date.getTime() - 3600 * 1000 * 24 * 6)
      let options = [
        { type: 'hidden', key: 'pageNumber', default: 1 },
        { type: 'hidden', key: 'pageSize', default: PAGE_SIZE },
        { type: 'select', key: 'status', label: '状态', options: Object.values(INVOICE_STATUS).map(({name: label, value}) => ({label, value})) },
        { type: 'daterange', key: 'Time', label: '选择日期', default: [date, new Date()] }
      ]
      return options
    }
  },
  methods: {
    onSizeChange (currSize) {
      this.formData.pageSize = currSize
      this.debounceFetchTransferList()
    },
    onPageChanged (currPage) {
      this.formData.pageNumber = currPage
      this.debounceFetchTransferList()
    },
    summaryRowIndex ({row, rowIndex}) {
      if (rowIndex === 0) {
        return 'summary-row'
      }
      return ''
    },
    fetchTransferList () {
      this.fetching = true
      getReceiptList(this.formData).then(res => {
        if (res.code === 200) {
          this.dataListTotal = res.value.size
          this.dataList = res.value.data
        }
      }).finally(() => {
        setTimeout(() => {
          this.fetching = false
        }, 300)
      })
    },
    hidenInvoiceCont () {
      this.debounceFetchTransferList()
      this.dialogVisible = false
    },
    showInvoiceCont (row) {
      getReceipt({rechargeId: row.rechargeReceiptId})
        .then(res => {
          if (res.code === 200) {
            // eslint-disable-next-line standard/object-curly-even-spacing
            let {registrationNumber, depositBank, bankAccount, companyRegisteredAddress, companyRegisteredPhone, receiptType, addresseeName, addresseePhone, receiverAddress, rechargeReceiptId } = res.value
            this.InvoiceFormData = {
              name: row.companyName,
              registrationNumber: registrationNumber,
              depositBank: depositBank,
              bankAccount: bankAccount,
              companyRegisteredAddress: companyRegisteredAddress,
              companyRegisteredPhone: companyRegisteredPhone,
              receiptType: receiptType,
              addresseeName: addresseeName,
              addresseePhone: addresseePhone,
              receiverAddress: receiverAddress,
              rechargeReceiptId: rechargeReceiptId
            }
            this.dialogVisible = true
          }
        })
    }
  },
  watch: {
    formData (val) {
      this.debounceFetchTransferList()
    },
    '$route.query.name' (val) {
      this.formData.name = val || ''
      this.debounceFetchTransferList()
    }
  },
  created () {
    this.debounceFetchTransferList = utils.debounce(this.fetchTransferList)
  },
  components: {
    SuperForm,
    InvoiceDialog
  }
}
</script>

<style lang="scss">
.invoice-flex {
    display: flex;
    justify-content: space-between;
}
.invoice-width{
    width: 530px;
    .invoice-title{
        padding: 0px 0 30px 73px;
        font-weight: bold;
    }
}
.bottom{
    width: 470px;
}
.tip{
  line-height: 25px;
  padding: 10px 20px;
  margin-top: 30px;
}
</style>
