<template>
  <div class="home-container">
    <el-aside class="home-aside help-aside">
      <el-menu class="home-aside__menu inset-shadow" :default-openeds="openMenu" router>
        <el-submenu v-for="(menu, idx) in helpList" :key="idx" :index="`module_${idx}`">
          <template slot="title">
            <span class="aside-title">{{ menu.moduleName }}</span>
          </template>
          <el-menu-item v-for="help in menu.adHelps" :key="help.id" :index="`/help?id=${help.id}`" :class="{'is-active': activeIndex === `/help?id=${help.id}`}">
            <span slot="title" class="aside-title">{{ help.name }}</span>
          </el-menu-item>
        </el-submenu>
      </el-menu>
    </el-aside>
    <main class="help-main">
      <div class="pd24">
        <div class="home-card pd24 helpitem">
          <h2 class="helpitem__title">{{ helpItem.name }}</h2>
          <div class="ql-container ql-snow">
            <div class="helpitem__content ql-editor" v-html="helpItem.content"></div>
            <video v-if="helpItem.videoUrl" :src="helpItem.videoUrl" class="helpitem__video" controls>
              您的浏览器不支持video标签
            </video>
            <img class="helpitem__video" v-if="helpItem.imgUrl" :src="helpItem.imgUrl" />
            <div v-if="helpItem.fileUrl" style="margin: 18px 24px;">
              附件：
              <a :href="helpItem.fileUrl" target="_blank" v-text="helpItem.fileName"></a>
            </div>
          </div>
        </div>
      </div>
    </main>
  </div>
</template>
<script>
import 'quill/dist/quill.core.css'
import 'quill/dist/quill.bubble.css'
import 'quill/dist/quill.snow.css'
import 'quill'
import { mapGetters } from 'vuex'
import { getAdHelpItem } from '@/api'
export default {
  data () {
    return {
      articles: {},
      helpItem: {},
      fetching: false
    }
  },
  computed: {
    ...mapGetters(['helpList']),
    openMenu () {
      return this.helpList.map((o, i) => `module_${i}`)
    },
    activeIndex () {
      return this.$route.fullPath
    }
  },
  methods: {
    fetchAdHelpItem (id) {
      const imgSufList = ['png', 'jpg', 'jpeg', 'gif', 'webp']
      const videoSufList = ['mp4', 'rmvb', 'mov']
      if (id && !this.articles[id]) {
        this.fetching = true
        getAdHelpItem({ id }).then(res => {
          if (res.code === 200) {
            let value = res.value
            const url = value.url || ''
            const paths = url.split('/')
            const name = paths[paths.length - 1]
            if (this.indexOfList(name, imgSufList) > -1) {
              value.imgUrl = url
            } else if (this.indexOfList(name, videoSufList) > -1) {
              value.videoUrl = url
            } else {
              value.fileUrl = url
              value.fileName = name
            }
            this.articles[id] = value
            this.helpItem = value
          }
        }).finally(() => {
          this.fetching = false
        })
      } else {
        this.helpItem = this.articles[id]
      }
    },
    indexOfList (str, list) {
      let i = -1
      let ok = false
      for (const it of list) {
        i++
        if (str.indexOf(it) > -1) {
          ok = true
          break
        }
      }
      return ok ? i : -1
    }
  },
  watch: {
    '$route.query.id': {
      handler: function (id) {
        this.fetchAdHelpItem(id)
      },
      immediate: true
    },
    helpList (list) {
      if (!this.$route.query.id) {
        const items = list.reduce((a, c) => a.concat(c.adHelps), [])
        if (items.length > 0) {
          this.$router.replace({name: 'Help', query: {id: items[0].id}})
        }
      }
    }
  },
  created () {
    this.$store.dispatch('getHelpList')
  }
}
</script>
<style lang="scss" scoped>
/deep/.helpitem {
  &__title {
    font-size: 24px;
    padding-bottom: 24px;
    font-weight: 700;
    margin: 24px auto;
    border-bottom: 1px solid gray(.1);
  }
  &__content {
    margin: 24px auto;
    font-size: 16px;
    line-height: 1.5;
    img {
      max-width: 100%;
    }
    p {
      text-indent: 2em;
    }
  }
  &__video {
    display: block;
    margin: auto;
    max-height: 400px;
  }
  html, body, div, span, applet, object, iframe,
  p, blockquote, pre,
  a, abbr, acronym, address, big, cite, code,
  del, dfn, img, ins, kbd, samp,
  small, strike, strong, sub, tt, var, i, center,
  dl, dt, dd, fieldset, form, label, legend,
  table, caption, tbody, tfoot, thead, tr, th, td,
  article, aside, canvas, details, embed,
  figure, figcaption, footer, header, hgroup,
  main, menu, nav, output, ruby, section, summary,
  time, mark, audio, video {
    // font-style: normal;
    // font-variant: small-caps !important;
    font-weight: normal !important;
    font-family: 'Times New Roman' !important;
    vertical-align: baseline !important;
    outline: 0 !important;
  }
  ol {
    display: block;
    list-style-type: decimal;
    margin-block-start: 1em;
    margin-block-end: 1em;
    margin-inline-start: 0px;
    margin-inline-end: 0px;
    padding-inline-start: 40px;
  }
  li {
    display: list-item !important;
    // text-align: -webkit-match-parent !important;
  }
  sup {
    vertical-align: super;
  }
  h3, h4, h5, h6, b{
    margin: 0 !important;
    padding: 0 !important;
    font-style: normal !important;
    // font-variant: small-caps !important;
    font-weight: bold !important;
    font-family: 'Times New Roman' !important;
    vertical-align: baseline !important;
    outline: 0 !important;
    font-size: normal !important;
  }
  strong {
    font-weight: bold !important;
  }
  em {
    margin: 0 !important;
    padding: 0 !important;
    font-style: italic !important;
    // font-variant: small-caps !important;
    font-family: 'Times New Roman' !important;
    vertical-align: baseline !important;
    outline: 0 !important;
  }
  h1 {
    // font-variant: small-caps !important;
    font-weight: bold !important;
    font-family: 'Times New Roman' !important;
    vertical-align: baseline !important;
    outline: 0 !important;
    font-size: 2em !important;
  }
  h2 {
    // font-variant: small-caps !important;
    font-weight: bold !important;
    font-family: 'Times New Roman' !important;
    vertical-align: baseline !important;
    outline: 0 !important;
    font-size: 1.5em !important;
  }
}

.home-container{
  .help-aside{
    padding: 0;
    margin: 0;
    height: 800px;
    overflow-y: scroll;
    .home-aside__menu{
      .aside-title{
        display: inline-block;
        width: 190px;
        @include ellipsis;
      }
    }
  }
  .help-main{
    padding: 0;
    margin: 0;
    height: 800px;
    overflow-y: scroll;
  }
}
</style>
