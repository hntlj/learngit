// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import 'babel-polyfill'
import Vue from 'vue'
import VueScrollTo from 'vue-scrollto'
import VueCookie from 'vue-cookie'
import router from './router'
import store from './store'
import filters from '@/utils/filters'
import ElementUI from '@/element-ui/index'
import App from './App'
Vue.use(VueCookie)
Vue.use(ElementUI)
Vue.use(VueScrollTo)
Vue.use(filters)
Vue.config.productionTip = false
/* eslint-disable no-new */
new Vue({
  el: '#app',
  data: {
    showNotify: false
  },
  router,
  store,
  components: { App },
  template: '<App/>'
})
