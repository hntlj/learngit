import Vue from 'vue'
import Vuex from 'vuex'
import { TAG_TYPE, USER_TYPE, USER_STATUS } from '@/enums'
import { getUserInfo, getUserProfile, getUnitSlotBundleList, getCertCategoryList,
  getAllPlanList, getAllLandingPageList, getSponsorAccountState, getKeywordSetting,
  getUnreadNum, getAdHelpList } from '@/api'
import Storage from '@/utils/storage'
Vue.use(Vuex)

export default new Vuex.Store({
  getters: {
    isSponsor: state => state.userInfo.isSponsor,
    userInfo: state => state.userInfo,
    userProfile: state => state.userProfile,
    adEdit: state => state.adEdit,
    specList: state => state.specList,
    tagList: state => state.tagList,
    slotBundle: state => state.slotBundle,
    certList1: state => state.certCategory ? Object.values(state.certCategory.cert1) : [],
    certList2: state => state.certCategory ? Object.values(state.certCategory.cert2) : [],
    certCategory: state => state.certCategory,
    planList: state => state.planList,
    landingPageList: state => state.landingPageList,
    accountState: state => state.accountState,
    keywordSetting: state => state.keywordSetting,
    unreadNum: state => state.unreadNum,
    openNotify: state => state.openNotify,
    helpList: state => state.helpList
  },
  mutations: {
    setUserInfo (state, userInfo) {
      if (userInfo && userInfo.agentType !== null) {
        userInfo.isSponsor = userInfo.status === USER_STATUS.NONE || !USER_TYPE[userInfo.agentType].agent
        if (!userInfo.isSponsor) {
          userInfo.nickName = userInfo.name
          userInfo.uid = userInfo.agentUid
          userInfo.icon = state.userInfo.icon
        }
        state.userInfo = userInfo
      } else {
        state.userInfo = {
          ...state.userInfo,
          ...userInfo,
          nickName: userInfo.name,
          uid: userInfo.agentUid,
          isSponsor: false
        }
      }
    },
    setUserProfile (state, userProfile) {
      let _certificates = {}
      userProfile.certificates = userProfile.certificates || []
      userProfile.websiteInfo = userProfile.websiteInfo || []
      userProfile.certificates.forEach(c => {
        let key = c.cert1Id + '-' + c.cert2Id
        if (_certificates[key]) {
          _certificates[key].certFile.push(c.certFile)
        } else {
          _certificates[key] = { ...c, certFile: c.certFile ? [c.certFile] : [] }
        }
      })
      userProfile.certList = userProfile.certificates
      userProfile.certificates = Object.values(_certificates)
      state.userProfile = userProfile
    },
    setAdEditPlan (state, plan) {
      state.adEdit.plan = plan
    },
    setAdEditUnit (state, unit) {
      state.adEdit.unit = unit
    },
    setSlotBundle (state, slotBundle) {
      let sb = {}
      slotBundle = slotBundle.sort((a, b) => a.keyId > b.keyId)
      slotBundle.forEach(slot => {
        const { id, name, specDesc: size, desc, keyId: value } = slot
        sb[slot.id] = { id, name, size, desc, value }
      })
      state.slotBundle = sb
      Storage.set('slotBundle', sb)
    },
    clearAdEdit (state) {
      state.adEdit = {
        plan: {},
        unit: {}
      }
    },
    setSpecList (state, { slotBundle, specList }) {
      state.specList[slotBundle] = specList
    },
    setTagList (state, value) {
      let tagList = {}
      Object.keys(value).forEach(key => {
        const type = TAG_TYPE[key]
        if (key === 'cityTag') {
          tagList[type] = value[key].map(({ province, cities }, idx) => {
            return {
              id: idx,
              label: province,
              children: cities.map(({ id, name, value }) => {
                return {
                  id: `${idx}-${id}`,
                  label: name,
                  value,
                  tagId: id
                }
              })
            }
          })
        } else if (key === 'interestTag') {
          tagList[type] = value[key].map(({ name, Tag }, idx) => {
            return {
              id: idx,
              label: name,
              children: Tag.map(({ id, name, tagValue }) => {
                return {
                  id: `${idx}-${id}`,
                  label: name,
                  children: tagValue.map(({ id: tagId, name, value }) => {
                    return {
                      id: `${idx}-${id}-${tagId}`,
                      label: name,
                      value
                    }
                  })
                }
              })
            }
          })
        } else {
          tagList[type] = value[key]
        }
      })
      state.tagList = tagList
      Storage.set('tagList', tagList)
    },
    setCertCategory (state, certList) {
      let cert1 = {}
      let cert2 = {}
      certList.filter(c => c.cert2_id === 0).forEach(({ cert1_id: id, cert_desc: desc, cert_name: name, isEnable }) => {
        cert1[id] = { id, name, desc, isEnable }
      })
      certList.filter(c => c.cert2_id !== 0).forEach(({ cert2_id: id, cert1_id: parentId, cert_desc: desc, cert_name: name, isEnable }) => {
        cert2[id] = { id, parentId, name, desc, isEnable }
      })
      state.certCategory = {
        cert1,
        cert2
      }
    },
    setPlanList (state, planList) {
      state.planList = planList.map(({id: value, name: label}) => ({value, label}))
    },
    setLandingPageList (state, landingPageList) {
      state.landingPageList = landingPageList.map(({ id, name, packageName, url, templateStyle }) => ({ id, name, packageName, url, templateStyle }))
    },
    setAccountState (state, accountState) {
      state.accountState = accountState
    },
    setKeywordSetting (state, setting) {
      state.keywordSetting = setting
    },
    setUnreadNum (state, num) {
      state.unreadNum = num || ''
    },
    setOpenNotify (state, msg) {
      state.openNotify = msg
    },
    setHelpList (state, helpList) {
      state.helpList = helpList || []
    }
  },
  actions: {
    getUserInfo ({ state, commit }, isSponsor) {
      getUserInfo(isSponsor).then(res => {
        commit('setUserInfo', res.value)
      })
    },
    getUserInfoProfile ({ state, commit }, ctxSponsorId) {
      getUserProfile(ctxSponsorId).then(res => {
        commit('setUserProfile', res.value)
      })
    },
    getSlotBundleList ({ state, commit }) {
      if ([USER_STATUS.VERIFYED, USER_STATUS.CHECKING].indexOf(state.userInfo.status) !== -1) {
        getUnitSlotBundleList().then(slotBundleList => {
          commit('setSlotBundle', slotBundleList)
        })
      }
    },
    getCertList ({ state, commit }) {
      if (!state.certCategory) {
        getCertCategoryList().then(certList => {
          commit('setCertCategory', certList)
        })
      }
    },
    getAllPlanList ({ state, commit }) {
      if (state.planList.length === 0) {
        getAllPlanList().then(planList => {
          commit('setPlanList', planList)
        })
      }
    },
    getAllLandingPageList ({ state, commit }, force = false) {
      if (force || state.landingPageList.length === 0) {
        getAllLandingPageList().then(landingPageList => {
          commit('setLandingPageList', landingPageList)
        })
      }
    },
    getAccountState ({ state, commit }) {
      getSponsorAccountState().then(res => {
        if (res.code === 200 && res.value) {
          commit('setAccountState', res.value)
        }
      })
    },
    getKeywordSetting ({ state, commit }) {
      if (!state.keywordSetting) {
        getKeywordSetting().then(res => {
          if (res.code === 200) {
            commit('setKeywordSetting', res.value)
          }
        })
      }
    },
    getUnreadNum ({ state, commit }) {
      [USER_STATUS.VERIFYED, USER_STATUS.CHECKING].indexOf(state.userInfo.status) !== -1 && getUnreadNum(state.userInfo.isSponsor).then(res => {
        if (res.code === 200) {
          commit('setUnreadNum', res.value.msgNum)
        }
      })
    },
    openNotify ({ state, commit }, msg) {
      commit('setOpenNotify', msg)
    },
    getHelpList ({ state, commit }) {
      getAdHelpList().then(res => {
        if (res.code === 200) {
          commit('setHelpList', res.value)
        }
      })
    }
  },
  state: {
    userInfo: {
      icon: require('@/assets/img/portal.png')
    },
    userProfile: null,
    adEdit: {
      plan: {},
      unit: {}
    },
    specList: {},
    tagList: Storage.get('tagList') || null,
    slotBundle: Storage.get('slotBundle') || null,
    certCategory: null,
    planList: [],
    landingPageList: [],
    accountState: {
      init: true,
      accountBalance: 0,
      rebateBalance: 0,
      cost: 0,
      releaseCount: 0,
      unverifyCount: 0,
      effectiveCount: 0,
      verifyFail: 0
    },
    keywordSetting: null,
    unreadNum: '',
    openNotify: null,
    helpList: []
  }
})
