<template>
  <div id="app" v-if="typeof userInfo.status !== undefined" :class="{'agent': !isSponsor}">
    <home-header @notify="showNotify=!showNotify" :show-notify="showNotify" :class="{fixed: showNotify}"/>
    <home-nav v-if="isSponsor && !$route.meta.agent" />
    <home-stick-notify @notify="showNotify=!showNotify" />
    <router-view />
    <div class="home-notifybox__mask" v-if="showNotify" @click="showNotify=!showNotify"></div>
    <el-dialog
      title="提示"
      :visible.sync="showLoginTip"
      width="30%"
      top="35vh"
      center>
      <span>{{loginTipTxt}}</span>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="onLoginOut">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import { USER_STATUS, CLIENT_TYPE, AGENT_HOST } from '@/enums'
import { getUserInfo } from '@/api'
import Home from '@/components/home'
export default {
  name: 'App',
  data () {
    return {
      showNotify: false,
      showLoginTip: false,
      loginTipTxt: ''
    }
  },
  computed: {
    ...mapGetters(['isSponsor', 'userInfo'])
  },
  methods: {
    onLoginOut () {
      window.location.href = '/logout'
    }
  },
  watch: {
    '$route' (to, from) {
      if (from.name !== to.name) {
        this.showNotify = false
      }
    }
  },
  created () {
    const isAgentPlatform = window.location.hostname === AGENT_HOST
    getUserInfo(!isAgentPlatform && !this.$route.meta.agent).then(res => {
      this.$store.commit('setUserInfo', res.value)
      const flag = [USER_STATUS.NONE, USER_STATUS.VERIFYING, USER_STATUS.REJECT].indexOf(res.value.status)
      if (res.code === 200 && flag !== -1) {
        const hash = location.hash
        console.log(hash)
        const AGENT_PATH = ['/client', '/Client', '/DailyStat', '/Agent']
        let registerPath
        if (res.value.status === USER_STATUS.VERIFYING) {
          registerPath = 'UserInfo'
        } else if (res.value.status === USER_STATUS.NONE) {
          registerPath = 'SelectType'
        }
        AGENT_PATH.forEach(path => {
          if (hash.indexOf(path) > -1) {
            registerPath = 'AgentRegister'
          }
        })
        if (USER_STATUS.REJECT === res.value.status && registerPath !== 'AgentRegister') {
          registerPath = 'UserInfo'
        }
        this.$router.push({name: registerPath})
      } else if (!this.isSponsor && !this.$route.meta.agent && this.$route.path !== '/') {
        this.$router.push({name: 'Client', query: { clientType: CLIENT_TYPE.SPONSOR }})
      }
      this.$store.dispatch('getUnreadNum')
      setInterval(() => {
        this.$store.dispatch('getUnreadNum')
      }, 2 * 60000)
    })
    if (this.$route.path.indexOf('/LoginTip') > -1) {
      let tipInfo = {
        'agentDisable': '该账号已经成为代理商，无法登录广告主平台。',
        'invalidSponsor': '该账号是无效账号，无法登录广告主平台。',
        'freezeSponsor': '该账号是冻结账号，无法登录广告主平台。'
      }
      this.loginTipTxt = tipInfo[this.$route.params.tipType]
      if (this.loginTipTxt) this.showLoginTip = true
    }
  },
  components: Home
}
</script>
<style src="@/assets/style/home.scss" lang="scss"></style>
