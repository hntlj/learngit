import * as TemplatePage from '@/utils/templatePage'

export default {
  methods: {
    renderPage (templateStyle, appInfo, iframeForm) {
      TemplatePage[`renderPage${templateStyle}`](this._getIframeDoc(), {
        appInfo: appInfo,
        form: iframeForm
      }, this._getIframeWindow())
    },
    _getIframeDoc () {
      const iframe = this.$refs.iframe
      const doc = iframe.contentDocument || iframe.document
      return doc
    },
    _getIframeWindow () {
      const iframe = this.$refs.iframe
      return iframe.contentWindow
    }
  }
}
