<script>
import { postStatusBatch } from '@/api'
import { BATCH_STATUS } from '@/enums'
export default {
  data () {
    return {
      batchOptStatus: '',
      batchStatus: BATCH_STATUS,
      multipleSelectionNames: [],
      multipleSelectionIds: [],
      multipleSelectionIdeas: [],
      batchTarget: '',
      batchTargetName: '',
      batchCallback: '',
      showBatchOprTip: false,
      showBatchOprInconformity: false,
      batchOprInconformity: []
    }
  },
  computed: {
    batchStatusName () {
      const batchStatus = this.batchStatus
      for (let i = 0; i < batchStatus.length; i++) {
        if (batchStatus[i].value === this.batchOptStatus) return batchStatus[i].name
      }
      return ''
    },
    batchTipText () {
      const tipObj = {
        plan: '删除广告计划，会导致广告计划下的所有单元、创意都被删除，且无法恢复，是否删除 所有选中计划？',
        unit: '删除广告单元，会导致广告单元下所有创意都被删除，且无法恢复，是否删除所有选中单元？',
        idea: '是否删除所有选中创意？'
      }
      return tipObj[this.batchTarget]
    }
  },
  methods: {
    onSelectionChange (val) {
      if (this.batchTarget === 'idea') {
        this.multipleSelectionIdeas = val.map(idea => {
          let rObj = {}
          rObj.name = idea.name
          rObj.bid = idea.bid
          rObj.floor = idea.floor
          rObj.ideaId = idea.ideaId
          rObj.modifyPrice = ''
          return rObj
        })
      }
      this.multipleSelectionIds = val.map(item => item.ideaId || item.unitId || item.planId)
      this.multipleSelectionNames = val.map(item => item.idealName || item.unitName || item.planName)
    },
    onShowPriceDialog () {
      if (!this.multipleSelectionIds.length) {
        this.batchOptStatus = ''
        return this.$message.error('请选择要批量操作的内容')
      }
      this.showPriceDialog = true
    },
    updateStatusBatch (status) {
      postStatusBatch({
        type: this.batchTarget,
        ids: this.multipleSelectionIds.join(','),
        status: this.batchOptStatus
      }).then(res => {
        this.$message.success('批量修改成功')
        this.batchCallback && this.batchCallback()
      }).catch(error => {
        if (error.code === 110001) {
          this.batchOprInconformity = error.value
          this.showBatchOprInconformity = true
        } else {
          this.$message.error(error.message)
        }
      }).finally(() => {
        this.showBatchOprTip = false
      })
    }
  },
  created () {
    const batchInfoMap = new Map([
      ['planList', { target: 'plan', name: '计划', cb: this.fetchPlanList }],
      ['unitList', { target: 'unit', name: '单元', cb: this.fetchUnitList }],
      ['ideaList', { target: 'idea', name: '创意', cb: this.fetchIdeaList }]
    ])
    batchInfoMap.forEach((value, key) => {
      if (this.$data.hasOwnProperty(key)) {
        this.batchTarget = value.target
        this.batchTargetName = value.name
        this.batchCallback = value.cb
      }
    })
  },
  watch: {
    batchOptStatus (val) {
      if (val === '') return
      if (!this.multipleSelectionIds.length) {
        this.batchOptStatus = ''
        return this.$message.error('请选择要批量操作的内容')
      }
      this.showBatchOprTip = true
    },
    showBatchOprTip (val) {
      if (!val) this.batchOptStatus = ''
    }
  }
}
</script>

<style lang="scss" scoped>
.home-searchform-wrap {
  display: flex;
  justify-content: space-between;
  .batch-operation {
    display: flex;
    .batch-select {
      width: 160px;
      margin-left: 10px;
    }
  }
}
.batch-tip-dialog {
  .tip-cont {
    .tip-text {
      line-height: 25px;
    }
    .tip-ul {
      margin: 20px 20px 0 20px;
      max-height: 500px;
      overflow-y: auto;
      border: 1px solid #ebebeb;
      .tip-li {
        height: 40px;
        line-height: 40px;
        text-align: center;
        border-bottom: 1px solid #ebebeb;
      }
      .tip-li:nth-last-of-type(1) {
        border-bottom: none;
      }
    }
  }
}
</style>
