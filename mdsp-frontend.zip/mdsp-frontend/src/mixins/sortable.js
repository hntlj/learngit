export default {
  data () {
    return {
      order: 'descending',
      orderBy: 'createTime',
      fetchList: function () {}
    }
  },
  computed: {
    defaultSort () {
      return {
        prop: this.orderBy,
        order: this.order
      }
    }
  },
  methods: {
    onSortChange ({column, prop, order}) {
      this.order = order
      this.orderBy = prop
      if (this.formData) {
        this.formData.pageNumber = 1
      }
      this.fetchList()
    }
  }
}
