import axios from 'axios'
import qs from 'qs'
const ERROR_MSG = '服务器错误，请稍候再试'
const baseURL = process.env.NODE_ENV === 'development' ? 'http://mzdsp.meizu.com' : ''

const request = axios.create({
  baseURL,
  crossDomain: true,
  withCredentials: true
})
request.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded'

// Add a request interceptor
request.interceptors.request.use(function (config) {
  // Add params.t=[now] when request method is GET
  if (config.method === 'get') {
    let params = config.params || {}
    if (params.nocache) {
      params.t = new Date().getTime()
      config.params = params
      delete params.nocache
    }
  } else if (config.data) {
    config.data = qs.stringify(config.data)
  }
  // 测试环境添加proxy和proxy
  if (process.env.NODE_ENV === 'development') {
    if (typeof config.mock === 'boolean' && config.mock) {
      config.url = '/mock' + config.url
    } else {
      // config.url = '/proxy' + config.url
    }
  }
  return config
}, function (error) {
  return Promise.reject(error)
})

// Add a response interceptor
request.interceptors.response.use(function (response) {
  const data = response.data
  if (data instanceof Object) {
    if (data && data.code === 198001) {
      if (~data.message.indexOf('登录')) {
        window.location.href = '/uc/login'
        return
      }
    }
    if (data && data.code === 198000) {
      if (~data.message.indexOf('授权')) {
        window.location.href = '/logout'
        return
      }
    }
    // 110001批量操作 服务端定义返回不符合批量操作的内容
    if (data && data.code === 110001) {
      return Promise.reject(data)
    }
    if (data && data.code !== 200) {
      if (typeof data.value === 'object') {
        return Promise.reject(data)
      }
      var message
      if (typeof data.message !== 'undefined') {
        message = data.message
      } else if (typeof data.model !== 'undefined') {
        message = data.model.message
      }
      return Promise.reject(new Error(message || ERROR_MSG))
    }
  } else {
    // return Promise.resolve(response)
    return response
  }
  return response.data
}, function (error) {
  const message = error.message || ERROR_MSG
  return Promise.reject(new Error(message))
})

request.export = function (url, { params }) {
  const { pageSize, pageNumber, ...args } = params
  const exportUrl = url + '?' + qs.stringify(args)
  window.open(exportUrl)
}

export default request
