import request from './request'
import utils from '@/utils'
const nocache = {
  params: { nocache: true }
}
// 用户信息
// GET 账户状态
export const getSponsorAccountState = () => request.get('/console/mdsp/stat/sponsor/accountState')
// GET 广告主信息
export const getSponsorInfo = () => request.get('/console/mdsp/sponsor/info')
// GET 广告主信息
export const getAgentInfo = () => request.get('/console/mdsp/agent/info')
export const getUserInfo = isSponsor => {
  return isSponsor ? getSponsorInfo() : getAgentInfo()
}
// GET 用户详情
export const getUserProfile = agentSponsorId => request.get('/console/mdsp/sponsor/get', { params: { agent_sponsor_id: agentSponsorId } })
// POST 修改用户信息
export const postUserProfile = (params, isUpdate, type = 0) => {
  const action = isUpdate ? 'update' : type === 0 ? 'add' : 'personal/add'
  return request.post(`/console/mdsp/sponsor/${action}`, params).then(res => {
    if (res.code === 200) {
      return getUserProfile()
    } else {
      return Promise.reject(res.message)
    }
  })
}
// GET 代理商详情
export const getUserAgency = () => request.get('/console/mdsp/agent/apply/info')
// POST 代理商审核
export const auditUserAgent = params => request.post('/console/mdsp/sponsor/binding/audit', params)
// 广告计划
// POST 创建
export const createPlan = async ({ promotionTarget, planName, budget, startTime, endTime }) => {
  planName = planName.trim()
  startTime += ' 00:00:00'
  endTime += ' 00:00:00'
  const res = await request.post('/console/mdsp/plan/create', {
    promotionTarget, planName, budget, startTime, endTime
  })
  if (res.code === 200) {
    return getPlanDetail(res.value)
  } else {
    return res
  }
}
// POST 创建、修改
export const postPlan = async ({ planId, promotionTarget, planName, budget }) => {
  if (planName) {
    planName = planName.trim()
  }
  const action = planId ? 'update' : 'create'
  const res = await request.post(`/console/mdsp/plan/${action}`, {
    planId, promotionTarget, planName, budget
  })
  if (res.code === 200) {
    return getPlanDetail(planId || res.value)
  } else {
    return Promise.reject(new Error(res.message))
  }
}
// GET 详情
export const getPlanDetail = async (planId) => {
  const res = await request.get('/console/mdsp/plan/detail', { params: { planId } })
  if (res.code === 200) {
    let { promotionTarget, startTime, endTime, budget, name: planName, id: planId, cost, configCost } = res.value
    startTime = utils.formatDate(startTime)
    endTime = utils.formatDate(endTime)
    return { promotionTarget, startTime, endTime, budget, planName, planId, cost, configCost }
  } else {
    return Promise.reject(new Error(res.message))
  }
}
// DELETE 删除
export const destroyPlan = (planId) => {
  return request.get('/console/mdsp/plan/delete', { params: { planId } })
}
// GET 列表
export const getPlanList = (params = {}) => {
  params = {
    ...params,
    startTime: params.startTime && params.startTime + ' 00:00:00',
    endTime: params.endTime && params.endTime + ' 23:59:59'
  }
  return request.get('/console/mdsp/plan/list', { params }).then(res => {
    if (res.code === 200) {
      res.value.data = res.value.data || []
    }
    return res
  })
}
export const getAllPlanList = () => {
  return getPlanList({
    startTime: '1970-01-01',
    endTime: '2100-01-01',
    pageNumber: 1,
    pageSize: 9999
  }).then(res => {
    if (res.code === 200) {
      return res.value.data.filter(({ status }) => status !== 999).map(({ planId: id, planName: name }) => ({ id, name }))
    }
    return []
  })
}
export const getPlanSummary = (params = {}) => {
  params = {
    ...params,
    startTime: params.startTime && params.startTime + ' 00:00:00',
    endTime: params.endTime && params.endTime + ' 23:59:59'
  }
  return request.get('/console/mdsp/plan/summary', { params }).then(res => {
    if (res.code === 200) {
      res.value.data = res.value.data || []
    }
    return res
  })
}
export const togglePlanStatus = (on, planId) => {
  return request.get(`/console/mdsp/plan/${on ? 'start' : 'pause'}`, { params: { planId } })
}

// 对计划、单元、创意批量操作
export const postStatusBatch = ({ type, ids, status }) => {
  return request.post(`/console/mdsp/${type}/updateStatusBatch`, {
    ids, status
  })
}
// 创意批量改价
export const updateIdeaBidBatch = ({ ideaIds, bid }) => {
  return request.post('/console/mdsp/idea/bid/updateBatch', {
    ideaIds, bid
  })
}
// 广告单元
// POST 创建、修改
export const postUnit = async ({ unitId, planId, unitName, unitTargeting, slotBundle, timeSeg, unitStatus, startTime, endTime, packageName, downloadUrl, txTrackParam, channelPackageId = '' }) => {
  if (unitName) {
    unitName = unitName.trim()
  }
  if (startTime && startTime !== -1) {
    startTime = new Date(startTime.replace(/-/g, '/') + ' 00:00:00').getTime() / 1000
  }
  if (endTime && endTime !== -1) {
    endTime = new Date(endTime.replace(/-/g, '/') + ' 23:59:59').getTime() / 1000
  }

  const action = unitId ? 'update' : 'create'
  if (txTrackParam) txTrackParam = txTrackParam.replace(/\n/g, ',')
  const res = await request.post(`/console/mdsp/unit/${action}`, {
    unitId, planId, unitName, unitTargeting, slotBundle, timeSeg, unitStatus, startTime, endTime, packageName, downloadUrl, txTrackParam, channelPackageId
  })
  if (res.code === 200) {
    return getUnitDetail(unitId || res.value)
  } else {
    return Promise.reject(new Error(res.message))
  }
}
export const getUnitDetail = async (unitId) => {
  const res = await request.get('/console/mdsp/unit/detail', { params: { unitId } })
  if (res.code === 200) {
    let { unitId, planId, unitName, slotBundleId: slotBundle, unitTargeting, timeSeg, startTime, endTime, packageName, isComplete, downloadUrl, txTrackParam, channelPackageId } = res.value
    if (startTime) {
      startTime = utils.formatDate(startTime * 1)
    }
    if (endTime) {
      endTime = utils.formatDate(endTime * 1)
    }
    return { unitId, planId, unitName, slotBundle, unitTargeting, timeSeg, startTime, endTime, packageName, isComplete, downloadUrl, txTrackParam, channelPackageId }
  } else {
    return Promise.reject(new Error(res.message))
  }
}
export const destroyUnit = unitId => request.get('/console/mdsp/unit/delete', { params: { unitId } })
// GET 单元列表
export const getUnitList = (params = {}) => {
  params = {
    ...params,
    startTime: params.startTime && params.startTime + ' 00:00:00',
    endTime: params.endTime && params.endTime + ' 23:59:59'
  }
  return request.get('/console/mdsp/unit/list', { params }).then(res => {
    if (res.code === 200) {
      res.value.data = res.value.data || []
    }
    return res
  })
}
export const getUnitSummary = (params = {}) => {
  params = {
    ...params,
    startTime: params.startTime && params.startTime + ' 00:00:00',
    endTime: params.endTime && params.endTime + ' 23:59:59'
  }
  return request.get('/console/mdsp/unit/summary', { params }).then(res => {
    if (res.code === 200) {
      res.value.data = res.value.data || []
    }
    return res
  })
}
// GET 广告类型列表
export const getSlotBundleList = (params = {}) => {
  params = {
    ...params
  }
  return request.get('/console/mdsp/slotbundle/getdropdownlist', { params }).then(res => {
    if (res.code === 200) {
      res.value = res.value || []
    }
    return res
  })
}
export const getAllUnitList = () => {
  return getUnitList({
    startTime: '1970-01-01',
    endTime: '2100-01-01',
    pageNumber: 1,
    pageSize: 9999
  }).then(res => {
    if (res.code === 200) {
      return res.value.data.filter(({ status }) => status !== 999).map(({ planId, unitId: id, unitName: name }) => ({ id, planId, name }))
    }
    return []
  })
}
export const getUnitTagList = () => {
  return request.get('/console/mdsp/unit/tag_list').then(res => {
    return res.code === 200 ? res.value : {}
  })
}
export const getUnitTargetingCount = params => {
  return request.get('/console/mdsp/unit/targeting_count', { params }).then(res => {
    return res.code === 200 ? Math.ceil(res.value / 10000) + '万' : '--'
  })
}
export const getUnitSlotBundleList = () => {
  return request.get('/console/mdsp/slotbundle/getall').then(res => {
    return res.code === 200 ? res.value : []
  })
}
export const getSpecList = async (slotBundleId) => {
  const res = await request.get('/console/dsp/spec/list', { params: { slotBundleId } })
  if (res.code === 200) {
    return res.value.map(({ id, name, content }) => {
      content = JSON.parse(content)
      if (content) {
        let rt = {
          id,
          name,
          key: content.img.type,
          assets: new Array(content.imgNum).fill(''),
          imgWidth: content.img.w,
          imgHeight: content.img.h,
          titleMinLen: content.title ? (content.title.minlen || 6) : '',
          titleLen: content.title ? content.title.len : '',
          descMinLen: content.desc ? (content.desc.minlen || 6) : '',
          descLen: content.desc ? content.desc.len : '',
          actionButton: content.action_button
        }
        if (content.hasOwnProperty('video')) {
          rt = Object.assign(rt, {
            video: [''],
            videoWidth: content.video.w,
            videoHeight: content.video.h
          })
        }
        return rt
      } else {
        return {
          id,
          name
        }
      }
    })
  }
  return Promise.reject(new Error(res.message))
}

// 广告创意
// GET 出价底价
export const getBidcostFloor = ({slotBundleId, bidType, ocpcType}) => {
  return request.get('/console/mdsp/bidcost/floor', { params: { slotBundleId, bidType, ocpcType } })
    .then(res => {
      return res.value || {}
    })
}
// GET 出价底价
export const getUnitBidFloor = ({ unitId, bidType: floorPriceType }) => {
  return request.get('/console/mdsp/unit/floor_price', { params: { unitId, floorPriceType } })
    .then(res => {
      return res.value || 0
    })
}
// GET 建议出价
export const getAdvicePrice = (unitId) => {
  return request.get('/console/mdsp/bidcost/advice', { params: { unitId } })
}
// POST 创建
export const postIdea = ({ planId, unitId, ideasJson }) => {
  return request.post('/console/mdsp/idea/createorupdate', {
    planId, unitId, ideasJson
  })
}
// POST 修改创意
export const updateIdea = ({ ideaId, bid, name, status }) => {
  return request.post('/console/mdsp/idea/update', {
    ideaId, bid, name, status
  })
}
// GET 删除创意
export const destroyIdea = ideaId => {
  return request.get('/console/mdsp/idea/delete', { params: { ideaId } })
}
// GET 创意列表
export const getIdeaList = (params) => {
  params = {
    ...params,
    startTime: params.startTime && params.startTime + ' 00:00:00',
    endTime: params.endTime && params.endTime + ' 23:59:59'
  }
  return request.get('/console/mdsp/idea/list', { params }).then(res => {
    if (res.code === 200) {
      res.value = res.value || { total: 0, data: [] }
    }
    return res
  })
}
export const getIdeaSummary = (params = {}) => {
  params = {
    ...params,
    startTime: params.startTime && params.startTime + ' 00:00:00',
    endTime: params.endTime && params.endTime + ' 23:59:59'
  }
  return request.get('/console/mdsp/idea/summary', { params }).then(res => {
    if (res.code === 200) {
      res.value.data = res.value.data || []
    }
    return res
  })
}
export const getAllIdeaList = () => {
  return getIdeaList({
    startTime: '1970-01-01',
    endTime: '2100-01-01',
    pageNumber: 1,
    pageSize: 9999
  }).then(res => {
    if (res.code === 200) {
      return res.value.data.filter(({ status }) => status !== 999).map(({ planId, ideaId: id, unitId, name }) => ({ id, planId, unitId, name }))
    }
    return []
  })
}
// GET 单元下的所有创意
export const getIdeaListByUnitId = (unitId) => {
  return request.get('/console/mdsp/idea/get', { params: { unitId } }).then(res => {
    if (res.code === 200) {
      return res.value
    }
  })
}

// 广告拉活
// GET 拉活列表
export const getPushList = params => {
  params = {
    ...params,
    startTime: params.startTime && params.startTime + ' 00:00:00',
    endTime: params.endTime && params.endTime + ' 23:59:59'
  }
  return request.get('/console/mdsp/push/list', { params }).then(res => {
    return res
  })
}
// GET 合计数据
export const getPushSummary = params => {
  params = {
    ...params,
    startTime: params.startTime && params.startTime + ' 00:00:00',
    endTime: params.endTime && params.endTime + ' 23:59:59'
  }
  return request.get('/console/mdsp/push/summary', { params }).then(res => {
    if (res.code === 200) {
      res.value.data = res.value.data || []
    }
    return res
  })
}
// POST 获取定向设置和单价
export const getPushConfigPrice = params => {
  params = {
    ...params,
    costType: 0
  }
  return request.post('/console/mdsp/push/getPushConfigPrice', params).then(res => {
    return res.value
  })
}
// POST 获取时间点配置
export const getPushConfig = params => {
  return request.post('/console/mdsp/push/getPushConfig', params).then(res => {
    return res.value
  })
}
// POST 获取人群包数量和人群包ID
export const getPushCrowdIdAndCount = params => {
  return request.post('/console/mdsp/push/crowdIdAndCount', params).then(res => {
    return res.value
  })
}
// POST 白名单推送
export const whitePush = params => {
  return request.post('/console/mdsp/push/whitePush', params)
}
// POST 创建
export const createPush = ({ resourceType, appId, appPackageName, deepLink, pushDate, pushCrowdSubDate, pushCrowdCount, blackImeiCrowd, originCrowdCount, originDuplicateCrowdCount, feeType, price, pushStyle, title, content, image, pushAdName, crowdId, expandContent, expandImage }) => {
  let params = { resourceType, appId, appPackageName, deepLink, pushDate, pushCrowdSubDate, pushCrowdCount, blackImeiCrowd, originCrowdCount, originDuplicateCrowdCount, feeType, price, pushStyle, title, content, image, pushAdName, originCrowdId: crowdId, expandContent, expandImage }
  if (resourceType === 9) {
    delete params.expandContent
    delete params.expandImage
  }
  return request.post('/console/mdsp/push/create', {
    ...params
  })
}
// POST 修改
export const updatePush = ({ resourceType, id, title, content, image, expandContent, expandImage }) => {
  let params = {}
  if (resourceType === 8) {
    params = { id, title, content, image: '', expandContent, expandImage }
  } else {
    params = { id, title, content, image }
  }
  return request.post('/console/mdsp/push/update', {
    ...params
  })
}
// POST 详情
export const getPushDetail = id => {
  return request.post('/console/mdsp/push/detail', { id })
}

// 应用
// GET 应用列表
export const getAppList = () => request.get('/console/mdsp/sponsor/app')
// GET 应用详情
export const getAppDetail = ({ packageName, appId }) => request.get('/console/mdsp/app/detail', { params: { packageName, appId } })
// GET 回传参数
export const getAllSponsorParams = () => request.get('/console/mdsp/idea/getAllSponsorParams')
// 落地页
// GET 落地页列表
export const getLandingPageList = params => request.get('/console/mdsp/landpage/list', { params })
// GET 落地页列表不分页
export const getAllLandingPageList = () => {
  return getLandingPageList({
    startTime: '1970-01-01',
    endTime: '2100-01-01',
    pageNumber: 1,
    pageSize: 9999,
    status: 1
  }).then(res => {
    if (res.code === 200) {
      return res.value.data
    }
    return []
  })
}
// GET 站点数据列表
export const getLandingPageDailyList = params => request.get('/console/mdsp/landpage/dailyList', { params })
// GET 落地页详情
export const getLandingPageDetail = params => request.get('/console/mdsp/landpage/detail', { params })
// POST 更新落地页
export const postLandingPage = params => {
  const action = params.id ? 'update' : 'create'
  return request.post(`/console/mdsp/landpage/${action}`, params)
}
// POST 更新落地页状态 0：下线；1：发布；2：删除
export const updateLandingPageStatus = (lpId, status) => request.post('/console/mdsp/landpage/status/update', { lp_id: lpId, status })

// 词包
// GET 关键词包
export const getKeywordPackageList = params => request.get('/console/mdsp/kw/manage/packageList', { params })
// GET 关键词列表
export const getKeywordList = params => request.get('/console/mdsp/kw/manage/keywordList', { params })
// POST 删除关键词包
export const destroyKeyword = packageName => {
  return request.post('/console/mdsp/kw/manage/delete', { packageName })
}
// POST 新增关键词包
export const postKeyword = ({ operType, packageName, keywords }) => {
  return request.post(`/console/mdsp/kw/manage/${operType}`, {
    packageName,
    keywords: keywords.join('\n')
  })
}
// POST 导出关键词包
export const exportKeyword = params => request.export('/console/mdsp/kw/manage/export', { params })
// GET 获取词包配置
export const getKeywordSetting = () => request.get('/console/mdsp/kwpackage/setting/get')

// 拉活黑名单
// GET 拉活黑名单列表
export const getBlacklistList = params => request.get('/console/mdsp/blackImeiCrowd/list', { params })
// GET 拉活黑名单详情
export const getBlacklistDetail = ({ id }) => request.post('/console/mdsp/blackImeiCrowd/detail', { id })
// POST 创建黑名单
export const postBlocklist = ({ operType, id, name, imei }) => {
  let params = { name, imei: imei.join('\n') }
  if (operType === 'update') {
    params.id = id
  }
  return request.post(`/console/mdsp/blackImeiCrowd/${operType}`, params)
}
// POST 删除黑名单
export const destroyBlacklist = id => {
  return request.post('/console/mdsp/blackImeiCrowd/delete', { id })
}

// GET 广告主资质分类  type : 行业类型 0 行业资质，1 公司行业
export const getCertCategoryList = (type = 0) => {
  return request.get('/console/mdsp/sponsor/cert_category', { params: { type } }).then(res => {
    return res.code === 200 ? res.value : []
  })
}
// GET 主体资质类型
export const getNameAndValue = type => request.get('/console/mdsp/admin/sponsor/getNameAndValue', { params: { type } })
// 人群包
// GET 获取人群包列表
export const getCrowdList = params => request.get('/console/mdsp/crowd/list', { params })
// GET 扩展人群包
export const extendCrowd = ({ crowdName, seedCrowdId, inclusive, targetSize }) => {
  return request.get('/console/mdsp/crowd/extend', { params: { crowdName, seedCrowdId, inclusive, targetSize } })
}
// GET 更新人群包
export const updateCrowdValidTime = params => request.get('/console/mdsp/crowd/updateValidTime', { params })
// GET 删除人群包
export const deleteCrowd = params => request.get('/console/mdsp/crowd/delete', { params })

// GET 获取应用渠道包列表
export const getAppChannelList = params => request.get('/console/mdsp/channel/package/list', { params })

// GET 删除渠道包
export const deleteAppChannel = params => request.get('/console/mdsp/channel/package/delete', { params })

// post 添加渠道包
export const addChannelPackage = params => request.get('/console/mdsp/channel/package/add', { params })

// post 修改渠道包
export const updateChannelPackage = params => request.get('/console/mdsp/channel/package/update', { params })

// POST 代理商注册
export const updateAgent = params => {
  return request.post('/console/mdsp/agent/save', params)
}
// GET 省市列表
export const getCityList = () => request.get('/console/mdsp/admin/agent/city')
// GET 代理商列表
export const getAgentList = params => request.get('/console/mdsp/agent/list', { params })
// GET 代理商列表导出
export const exportAgentList = params => request.export('/console/mdsp/agent/exportList', { params })
// GET 操作日志列表
export const getLogList = params => {
  return request.get('/console/mdsp/operate/log/list', { params })
}
// GET 操作日志类型
export const getLogTypeList = () => request.get('/console/mdsp/operate/log/type/list')

// 投放数据
// GET 账户数据
export const getStatSponsorList = params => {
  return request.get('/console/mdsp/stat/sponsor/list', { params })
}
// GET 创意排行
export const getTopIdeaList = params => {
  return request.get('/console/mdsp/stat/sponsor/topIdea', { params })
}
// GET 广告计划数据
export const getStatPlanList = params => {
  return request.get('/console/mdsp/stat/plan/list', { params })
}
export const getStatPlanSummary = params => {
  return request.get('/console/mdsp/stat/plan/summary', { params })
}
// GET 账号数据
export const getStatAccountList = params => {
  return request.get('/console/mdsp/stat/account/list', { params })
}
export const getStatAccountSummary = params => {
  return request.get('/console/mdsp/stat/account/summary', { params })
}
// GET 广告单元数据
export const getStatUnitList = params => {
  return request.get('/console/mdsp/stat/unit/list', { params })
}
export const getStatUnitSummary = params => {
  return request.get('/console/mdsp/stat/unit/summary', { params })
}
// GET 广告创意数据
export const getStatIdeaList = params => {
  return request.get('/console/mdsp/stat/idea/list', { params })
}
export const getStatIdeaSummary = params => {
  return request.get('/console/mdsp/stat/idea/summary', { params })
}
// GET 广告拉活数据
export const getStatPushList = params => {
  return request.get('/console/mdsp/pushStat/list', { params })
}
export const exportStatPushList = params => {
  return request.export('/console/mdsp/pushStat/export', { params })
}
export const getStatPushSummary = params => {
  return request.get('/console/mdsp/pushStat/summary', { params })
}
// GET 关键词数据
export const getStatKeywordList = params => {
  return request.get('/console/mdsp/stat/keyword/list', { params })
}
// GET 广告计划数据导出
export const exportStatPlanList = params => {
  return request.export('/console/mdsp/stat/plan/export', { params })
}
// GET 账号数据导出
export const exportStatAccountList = params => {
  return request.export('/console/mdsp/stat/account/export', { params })
}
// GET 广告单元数据导出
export const exportStatUnitList = params => {
  return request.export('/console/mdsp/stat/unit/export', { params })
}
// GET 广告创意数据导出
export const exportStatIdeaList = params => {
  return request.export('/console/mdsp/stat/idea/export', { params })
}
// GET 关键词数据导出
export const exportStatKeywordList = params => {
  return request.export('/console/mdsp/stat/keyword/export', { params })
}

// GET 关键词数据
export const getStatKeywordList2 = params => {
  return request.get('/console/mdsp/app/kw/data/list', { params })
}
// GET 关键词数据导出
export const exportStatKeywordList2 = params => {
  return request.export('/console/mdsp/app/kw/data/export', { params })
}
// GET 关键词数据导出
export const exportStatLandpage = params => {
  return request.export('/console/mdsp/landpage/export', { params })
}

// 财务管理
// GET 账户信息
export const getRechargeAccount = () => request.get('/console/mdsp/recharge/account')
// POST 提交充值
export const addRecharge = ({ bankNum, name, money, receiptFile, remark, orderId, flowId }, isAgent) => {
  return request.post(`/console/mdsp/recharge/${isAgent ? 'agent/' : ''}add`, {
    bankNum, name, money, receiptFile, remark, orderId, flowId
  })
}
export const getRechargeList = params => {
  return request.get('/console/mdsp/recharge/list', { params })
}
// POST 代理充值提交
export const addAgentRecharge = params => addRecharge(params, true)
// GET 充值记录
export const getRechargeTransferList = (isSponsor, params) => {
  const role = isSponsor ? 'sponsor' : 'agent'
  return request.get(`/console/mdsp/recharge/transfer/${role}/list`, { params })
}
// GET 充值记录导出
export const exportRechargeTransferList = (isSponsor, params) => {
  const role = isSponsor ? 'sponsor' : 'agent'
  return request.export(`/console/mdsp/recharge/transfer/${role}/export`, { params })
}
// GET 财务明细
export const getFinanicalList = (params) => {
  return request.get(`/console/mdsp/recharge/finance`, { params })
}
// GET 发票记录
export const getReceiptList = (params) => {
  return request.get(`/console/mdsp/recharge/online/receipt/list`, { params })
}
// GET 财务明细导出
export const exportFinanicalList = (params) => {
  return request.export(`/console/mdsp/recharge/finance/export`, { params })
}
// GET 待审核充值记录
export const getUnauditTransferList = (isSponsor, params) => {
  const role = isSponsor ? 'sponsor' : 'agent'
  return request.get(`/console/mdsp/recharge/transfer/${role}/unaudited/record`, { params })
}
// 在线充值
export const onlineAdd = params => {
  return request.post(`/console/mdsp/recharge/online/add`, params)
}
// 发票申请
export const receiptSave = (params) => {
  return request.get(`/console/mdsp/recharge/online/receipt/save`, { params })
}
// 发票查询
export const getReceipt = (params) => {
  return request.get(`/console/mdsp/recharge/online/receipt`, { params })
}
// POST 删除待审核充值记录
export const deleteUnauditTransferList = (isSponsor, params) => {
  const role = isSponsor ? 'sponsor' : 'agent'
  return request.get(`/console/mdsp/recharge/transfer/${role}/delete/unaudited/record`, { params })
}
// GET 代理账户余额
export const getAgentAccount = () => request.get('/console/mdsp/agent/account')
// GET 代理账户列表
export const getAgentAccountList = params => {
  return request.get('/console/mdsp/agent/account/list', {
    params
  })
}
// POST 代理转账
export const transferRecharge = params => {
  return request.post('/console/mdsp/recharge/transfer', params)
}
// 代理商数据效果
// GET 每日数据
export const getAgentDailyStat = params => {
  return request.get('/console/mdsp/agent/stat/day', { params })
}
// GET 每日数据图表
export const getAgentDailyGraphStat = params => {
  return request.get('/console/mdsp/agent/stat/graph', { params })
}
// GET 每日数据导出
export const exportAgentDailyStat = params => {
  return request.export('/console/mdsp/agent/stat/exportDay', { params })
}
// GET 每日数据汇总
export const getAgentDailyStatSum = params => {
  return request.get('/console/mdsp/agent/stat/sumDay', { params })
}
// GET 客户数据列表
export const getAgentClientStat = params => {
  return request.get('/console/mdsp/agent/client/list', { params })
}
// GET 客户数据导出
export const exportAgentClientStat = params => {
  return request.export('/console/mdsp/agent/client/exportDay', { params })
}
// GET 客户数据汇总
export const getAgentClientStatSum = params => {
  return request.get('/console/mdsp/agent/client/sumDay', { params })
}
// GET 消息通知列表
export const getNotifyList = (isSponsor, params) => {
  const role = isSponsor ? 'sponsor' : 'agent'
  return request.get(`/console/mdsp/notify/${role}/list`, { params })
}
// POST 删除消息通知
export const updateNotify = (isSponsor, id, action) => {
  const role = isSponsor ? 'sponsor' : 'agent'
  return request.post(`/console/mdsp/notify/${role}/update`, { msgId: id, action })
}
// GET 置顶消息列表
export const getStickNotifyList = isSponsor => {
  const role = isSponsor ? 'sponsor' : 'agent'
  return request.get(`/console/mdsp/notify/${role}/stick`)
}
// GET 获取未读数量
export const getUnreadNum = isSponsor => {
  const role = isSponsor ? 'sponsor' : 'agent'
  return request.get(`/console/mdsp/notify/${role}/unread_num`, nocache)
}
// GET 获取消息通知设置
export const getNotifySetting = isSponsor => {
  const role = isSponsor ? 'sponsor' : 'agent'
  return request.get(`/console/mdsp/notify/${role}/setting/get`)
}
// GET 保存消息通知设置
export const updateNotifySetting = (isSponsor, params) => {
  const role = isSponsor ? 'sponsor' : 'agent'
  return request.post(`/console/mdsp/notify/${role}/setting/save`, params)
}
export const getConsume = params => request.get('/console/mdsp/stat/getconsume', { params })
export const getPlanCount = params => request.get('/console/mdsp/plan/getcount', { params })
export const getUnitCount = params => request.get('/console/mdsp/unit/getcount', { params })
export const getIdeaCount = params => request.get('/console/mdsp/idea/getcount', { params })
// GET 帮助文档
export const getAdHelpList = () => request.get('/console/mdsp/ad/help/list')
export const getAdHelpItem = params => request.get('/console/mdsp/ad/help/get', { params })
// GET 查询关键词热度
export const getKwHot = params => {
  return request.get('/console/mdsp/idea/getKwHot', { params }).then(res => {
    return res.code === 200 ? res.value : []
  })
}
// POST 新增意见反馈
export const addOpinion = params => {
  return request.post(`/console/mdsp/userFeedback/add`, params)
}

// 获取动态词包
export const getDynamicList = params => {
  return request.get(`/console/mdsp/dynamic/list`, { params, mock: params.mock })
}
