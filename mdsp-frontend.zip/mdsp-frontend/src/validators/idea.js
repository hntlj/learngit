import { OCPC_TYPE } from '@/enums'
import utils from '@/utils'

export const schemaValidator = function (rule, value, callback) {
  if (value) {
    const reg = new RegExp("^([A-Za-z0-9.])+://[0-9A-Za-z_!~*'()-]+.*$")
    if (!reg.test(value)) {
      return callback(new Error('请输入正确的Deeplink地址'))
    }
  }
  callback()
}
export const httpsValidator = function (rule, value, callback) {
  if (value) {
    const reg = new RegExp("^https://[0-9a-z_!~*'()-]+.*$")
    if (!reg.test(value)) {
      return callback(new Error('请输入以https://开头的链接'))
    }
    callback()
  }
}
export const httpValidator = function (rule, value, callback) {
  if (value) {
    const reg = new RegExp("^(https|http)://[0-9a-z_!~*'()-]+.*$")
    if (!reg.test(value)) {
      return callback(new Error('请输入以http://或https://开头的链接'))
    }
  }
  callback()
}
export const bidPriceValidator = function (form, rule, value, callback) {
  let minPrice, maxPrice
  if (this.adEdit.unit.slotBundle === 7) {
    if (form.bidType === 0) {
      minPrice = this.bidPriceFloor.cpmPrice.floorPrice
    } else if (form.bidType === 1) {
      minPrice = this.bidPriceFloor.cpcPrice.floorPrice
    }
    maxPrice = 100
  } else {
    minPrice = form.ocpcType === OCPC_TYPE.INSTALL ? this.bidPriceFloor.downloadPrice.floorPrice : this.bidPriceFloor.clickPrice.floorPrice
    maxPrice = form.ocpcType === OCPC_TYPE.INSTALL ? 100 : 20
  }
  const balance = this.accountState.accountBalance + this.accountState.rebateBalance
  if (value === '') {
    return callback(new Error('请输入出价'))
  } else if (isNaN(value) || value < minPrice) {
    return callback(new Error(`出价不能低于${minPrice}元`))
  } else if (!this.accountState.init && value > balance) {
    callback(new Error(`出价不能超过账户余额`))
  } else if (value > maxPrice) {
    callback(new Error(`出价不能高于${maxPrice}元`))
  } else if (!(utils.validateNum(value, 2))) {
    callback(new Error('请输入正确的金额，出价仅支持2位小数'))
  } else {
    callback()
  }
}
export const kwPriceValidator = function (form, gvalue, rule, value, callback) {
  const minPrice = form.ocpcType === OCPC_TYPE.INSTALL ? this.bidPriceFloor.downloadPrice.kwFloorPrice : this.bidPriceFloor.clickPrice.kwFloorPrice
  const maxPrice = form.ocpcType === OCPC_TYPE.INSTALL ? 100 : 20

  let val = parseFloat(gvalue)
  if (isNaN(val)) {
    this.$message.error(`请输入出价`)
    return callback(new Error('请输入出价'))
  } else if (val < minPrice) {
    this.$message.error(`关键词出价不能低于${minPrice}元`)
    return callback(new Error(`关键词出价不能低于${minPrice}元`))
  } else if (val > maxPrice) {
    this.$message.error(`关键词出价不能高于${maxPrice}元`)
    callback(new Error(`关键词出价不能高于${maxPrice}元`))
  } else if (!(utils.validateNum(gvalue, 2))) {
    this.$message.error('请输入正确的金额，出价仅支持2位小数')
    callback(new Error('请输入正确的金额，出价仅支持2位小数'))
  } else {
    callback()
  }
}

export const crowdCountValidator = function (form, rule, value, callback) {
  value = Number(value)
  if (value <= 0) {
    return callback(new Error('请输入大于 0 的数值'))
  } else if (value !== parseInt(value)) {
    return callback(new Error('请输入整数'))
  } else if (form.crowdCount < value) {
    return callback(new Error('投放用户数量不能大于覆盖人群数量'))
  } else {
    callback()
  }
}
