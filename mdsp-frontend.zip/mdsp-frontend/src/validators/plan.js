export const budgetValidator = (rule, value, callback) => {
  value = parseInt(value || 0)
  if (isNaN(value) || value < 0) {
    callback(new Error('预算金额不能小于0'))
  } else {
    callback()
  }
}
