import Vue from 'vue'
export const filters = {
  currency: value => {
    if (isNaN(value)) {
      value = 0
    }
    value = Number(value).toFixed(2)
    return (value || 0).toString().replace(/^(-?)(\d+)((\.\d+)?)$/, function (s, s1, s2, s3) {
      return s1 + s2.replace(/\d{1,3}(?=(\d{3})+$)/g, '$&,') + s3
    })
  },
  number: value => {
    if (isNaN(value)) {
      value = 0
    }
    return Number(value).toLocaleString()
  },
  percentange: value => {
    if (isNaN(value)) {
      value = 0
    }
    return parseInt(Number(value) * 10000) / 100 + '%'
  }
}
export default {
  install () {
    for (let key in filters) {
      Vue.filter(key, filters[key])
    }
  }
}
