
function _getSizeText (size) {
  if (!size) return ''
  if (size < 1024) {
    return parseInt(size) + 'B'
  }
  if (size < 1024 * 1024) {
    return parseInt(size / 1024) + 'KB'
  }
  if (size < 1024 * 1024 * 100) {
    let num = size / 1024 / 1024
    return (num.toFixed(1)) + 'MB'
  }
  if (size < 1024 * 1024 * 1024) {
    return (size / 1024 / 1024).toFixed(0) + 'MB'
  }
  if (size < 1024 * 1024 * 1024 * 10) {
    let num = size / 1024 / 1024 / 1024
    return (num.toFixed(1)) + 'GB'
  }
  if (size < 1024 * 1024 * 1024 * 100) {
    let num = size / 1024 / 1024 / 1024
    return (num.toFixed(0)) + 'GB'
  }
  return parseInt(size / 1024 / 1024 / 1024) + 'GB'
}

function _getDownloadCount (count) {
  if (!count) return ''
  if (count < 1000) {
    count = '少于1千'
  } else if (count <= 9000) {
    count = Math.ceil(count / 1000) + '千'
  } else if (count <= 9000 * 10000) {
    count = Math.ceil(count / 10000) + '万'
  } else {
    count = Math.ceil(count / 100000000) + '亿'
  }
  return count + '次安装'
}

function _getStar (star) {
  if (!star) return 5
  const starBig = Math.floor(star / 10)
  const starSmall = star % 10
  return starBig + (starSmall > 7 ? 1 : 0)
}

function _renderInstallButton (btn, data) {
  if (!data.appInfo || data.appInfo.id === 0) return
  btn.dataset.pkgname = data.appInfo.packageName
  btn.dataset.appid = data.appInfo.id
  btn.dataset.version = data.appInfo.versionCode
  btn.dataset.installtext = data.form.config[data.form.tplType].installText || '安装'
}

function _escapeHTML (unsafeStr) {
  return unsafeStr
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
    .replace(/\//g, '&#x2F;')
}

// render template page fullpage
export const renderPage1 = function (doc, data, win) {
  const body = doc.body
  if (!body) return
  const content = doc.getElementsByClassName('content')[0]
  if (!content) return
  const appWrap = content.getElementsByTagName('dl')[0]
  const appIcon = content.getElementsByTagName('img')[0]
  const appName = content.getElementsByTagName('h5')[0]
  const appInfo = content.getElementsByTagName('em')[0]
  const desc = content.getElementsByTagName('p')[0]
  const btn = content.getElementsByTagName('button')[0]
  const star = content.getElementsByTagName('span')[0]
  const starText = content.getElementsByTagName('i')[0]
  const tplType = data.form.tplType
  if (data.appInfo && data.appInfo.id > 0) {
    appName.innerHTML = _escapeHTML(data.appInfo.name)
    appIcon.src = data.appInfo.icon
    appInfo.innerHTML = _escapeHTML(`${_getSizeText(data.appInfo.size)} ${_getDownloadCount(data.appInfo.download_count)}`)
    if (data.appInfo.star) {
      starText.innerHTML = _escapeHTML((data.appInfo.star / 10).toFixed(1))
      const starBig = _getStar(data.appInfo.star)
      const starSmall = data.appInfo.star % 10
      const starChildEl = [].slice.call(star.getElementsByTagName('b'))
      for (let i = 0; i < starChildEl.length; i++) {
        starChildEl[i].classList.remove('half')
      }
      let isPlus = false
      if (starSmall >= 3 && starSmall <= 7) {
        isPlus = true
        starChildEl[starBig].classList.add('half')
      }
      star.className = `star star-${starBig + (isPlus ? 1 : 0)}`
    }
  }
  if (data.form.config[tplType].content) {
    desc.innerHTML = _escapeHTML(data.form.config[tplType].content)
  }
  btn.innerHTML = _escapeHTML(data.form.config[tplType].installText || '安装')
  if (data.form.config[tplType].installBgColor) {
    btn.style.backgroundColor = data.form.config[tplType].installBgColor
  }
  if (data.form.config[tplType].bgImage) {
    body.style.backgroundImage = `url(${data.form.config[tplType].bgImage})`
  }
  const isChangeApp = data.appInfo && btn && data.appInfo.id !== btn.dataset.appid
  _renderInstallButton(btn, data)

  if (win.getAppInfo && isChangeApp) {
    appWrap.classList.add('invisibility')
    win.getAppInfo()
  }
}

// render template page longpage
export const renderPage2 = function (doc, data, win) {
  const body = doc.body
  if (!body) return
  let header = body.getElementsByTagName('header')
  if (!header || header.length === 0) return
  header = header[0]
  const headerImg = header.getElementsByTagName('img')[0]
  const h3 = body.getElementsByTagName('h3')[0]
  const content = body.getElementsByClassName('content')[0]
  const footer = body.getElementsByTagName('footer')[0]
  if (!footer) return
  const appIcon = footer.getElementsByTagName('img')[0]
  const appName = footer.getElementsByTagName('h5')[0]
  const appInfo = footer.getElementsByTagName('em')[0]
  const btn = footer.getElementsByTagName('button')[0]
  const tplType = data.form.tplType
  if (data.form.config[tplType].topImage) {
    headerImg.src = data.form.config[tplType].topImage
  }
  h3.innerHTML = _escapeHTML(data.form.config[tplType].title || '不止带你看世界，还告诉你旅行的意义')
  if (data.appInfo && data.appInfo.id > 0) {
    appName.innerHTML = _escapeHTML(data.appInfo.name)
    appIcon.src = data.appInfo.icon
    appInfo.innerHTML = _escapeHTML(`${_getSizeText(data.appInfo.size)} ${_getDownloadCount(data.appInfo.download_count)}`)
  }
  btn.innerHTML = _escapeHTML(data.form.config[tplType].installText || '安装')
  if (data.form.config[tplType].installBgColor) {
    btn.style.backgroundColor = data.form.config[tplType].installBgColor
  }
  const isChangeApp = data.appInfo && btn && data.appInfo.id !== btn.dataset.appid
  _renderInstallButton(btn, data)
  if (data.form.config[tplType].content && data.form.config[tplType].content.length > 0) {
    content.innerHTML = data.form.config[tplType].content.map((p) => {
      if (p.img) {
        return `<img src="${p.img}" ${p.clickInstall ? 'data-install="1"' : ''}/>`
      } else if (p.text) {
        return `<p>${p.text}</p>`
      }
      return ''
    }).join('')
  }
  if (win.getAppInfo && isChangeApp) {
    footer.classList.add('invisibility')
    win.getAppInfo()
  }
}

// render template page newlongpage
export const renderPage3 = function (doc, data, win) {
  const body = doc.body
  if (!body) return
  const content = body.getElementsByClassName('content')[0]
  const footer = body.getElementsByTagName('footer')[0]
  if (!content || !footer) return
  const appIcon = footer.getElementsByTagName('img')[0]
  const appName = footer.getElementsByTagName('h5')[0]
  const appInfo = footer.getElementsByTagName('em')[0]
  const btn = footer.getElementsByTagName('button')[0]
  const tplType = data.form.tplType
  if (data.appInfo && data.appInfo.id > 0) {
    appName.innerHTML = _escapeHTML(data.appInfo.name)
    appIcon.src = data.appInfo.icon
    appInfo.innerHTML = _escapeHTML(`${_getSizeText(data.appInfo.size)} ${_getDownloadCount(data.appInfo.download_count)}`)
  }
  btn.innerHTML = _escapeHTML(data.form.config[tplType].installText || '安装')
  if (data.form.config[tplType].installBgColor) {
    btn.style.backgroundColor = data.form.config[tplType].installBgColor
  }
  const isChangeApp = data.appInfo && btn && data.appInfo.id !== btn.dataset.appid
  _renderInstallButton(btn, data)
  if (data.form.config[tplType].content && data.form.config[tplType].content.length > 0) {
    content.innerHTML = data.form.config[tplType].content.map((p) => {
      if (p.img) {
        return `<img src="${p.img}" ${p.clickInstall ? 'data-install="1"' : ''}/>`
      } else if (p.text) {
        return `<p>${p.text}</p>`
      }
      return ''
    }).join('')
  }
  if (data.form.config[tplType].btnStyle === 1) {
    footer.style.backgroundColor = '#fff'
    body.classList.remove('simple')
  } else {
    footer.style.backgroundColor = data.form.config[tplType].layerBgColor
    body.classList.add('simple')
  }
  if (win.getAppInfo && isChangeApp) {
    footer.classList.add('invisibility')
    win.getAppInfo()
  }
}
