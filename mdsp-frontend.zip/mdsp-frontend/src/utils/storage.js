export default {
  prefix: '_mdsp_',
  supportStorage: !!window.localStorage,
  storage: window.localStorage,
  get (key) {
    if (this.supportStorage) {
      let value = this.storage.getItem(this.prefix + key)
      try {
        return JSON.parse(value)
      } catch (e) {
        return value
      }
    }
    return ''
  },
  set (key, value) {
    if (this.supportStorage && value) {
      return this.storage.setItem(this.prefix + key, JSON.stringify(value))
    }
  },
  delete (key) {
    if (this.supportStorage) {
      this.storage.removeItem(this.prefix + key)
    }
  }
}
