export default {
  formatDate (time, format) {
    if (!time) {
      return ''
    }
    format = format || 'yyyy-MM-dd'
    typeof (time) === 'number' && (time + '').length === 10 && (time *= 1000)
    if (Object.prototype.toString.call(time) !== '[object Date]') {
      if (typeof time === 'string' && /^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2})$/.test(time)) {
        time = time.replace(/-/g, '/')
      }
      time = new Date(time)
    }
    // 小时的区间范围显示，比如：1：00会变成1：00~2：00
    if (format === 'hoursRange') {
      var startHours = time.getHours()
      var endHours = startHours + 1
      return ('0' + startHours).slice(-2) + ':00 ~ ' + ('0' + endHours).slice(-2) + ':00'
    }
    const year = time.getFullYear() // 年份
    const month = time.getMonth() + 1 // 月份
    const day = time.getDate() //
    const hours24 = time.getHours() // 小时
    const hours = hours24 % 12 === 0 ? 12 : hours24 % 12
    const minutes = time.getMinutes() // 分
    const seconds = time.getSeconds() // 秒
    const milliseconds = time.getMilliseconds() // 毫秒
    var map = {
      yyyy: year,
      MM: ('0' + month).slice(-2),
      M: month,
      dd: ('0' + day).slice(-2),
      d: day,
      HH: ('0' + hours24).slice(-2),
      H: hours24,
      hh: ('0' + hours).slice(-2),
      h: hours,
      mm: ('0' + minutes).slice(-2),
      m: minutes,
      ss: ('0' + seconds).slice(-2),
      s: seconds,
      S: milliseconds
    }
    return format.replace(/y+|M+|d+|H+|h+|m+|s+|S+/g, function (str) {
      return map[str]
    })
  },
  afterDays (date, days) {
    const daystime = days * 86400 * 1000
    return this.formatDate(+date + daystime)
  },
  getObjectType (obj) {
    return Object.prototype.toString.call(obj).slice(8, -1)
  },
  today () {
    const date = new Date()
    return date.getTime()
  },
  yesterday () {
    const date = new Date()
    return date.getTime() - 1000 * 3600 * 24
  },
  findByKey (arr, key) {
    const result = arr.filter(a => a.key === key)
    if (result.length > 0) {
      return result[0]
    } else {
      return null
    }
  },
  copyObjectValue (obj, option) {
    let result = {}
    for (let key in obj) {
      result[key] = option[key] || obj[key]
    }
    return result
  },
  arrayToMap (arr, key, value) {
    let ret = {}
    arr.forEach(item => {
      ret[item[key]] = item[value]
    })
    return ret
  },
  getStringRealLength (str) {
    if (str == null) return 0
    if (typeof str !== 'string') {
      str += ''
    }
    /* eslint no-control-regex: "off" */
    return str.replace(/[^\x00-\xff]/g, '01').length
  },
  newTab (location) {
    window.open(location.href, '_blank')
  },
  // throttle (fn, threshhold = 250) {
  //   var last, timer
  //   return function () {
  //     var context = this
  //     var args = arguments
  //     var now = +new Date()

  //     if (last && now < last + threshhold) {
  //       clearTimeout(timer)
  //       timer = setTimeout(function () {
  //         last = now
  //         fn.apply(context, args)
  //       }, threshhold)
  //     } else {
  //       last = now
  //       fn.apply(context, args)
  //     }
  //   }
  // },
  throttle (fn, threshhold = 250) {
    let timer
    return function (...args) {
      if (timer) return
      timer = setTimeout(() => {
        clearTimeout(timer)
        timer = null
      }, threshhold)
      fn.apply(this, args)
    }
  },
  debounce (fn, delay = 250) {
    var timer
    return function () {
      var context = this
      var args = arguments

      clearTimeout(timer)
      timer = setTimeout(function () {
        fn.apply(context, args)
      }, delay)
    }
  },
  deepCopy (originObj, objType) {
    const temp = objType || {}
    Object.keys(originObj).forEach((key) => {
      if (typeof originObj[key] === 'object') {
        if (originObj[key] === null) {
          temp[key] = originObj[key]
        } else {
          temp[key] = (originObj[key].constructor === Array) ? [] : {}
          this.deepCopy(originObj[key], temp[key])
        }
      } else {
        temp[key] = originObj[key]
      }
    })
    return temp
  },
  once (fn, that) {
    let called = false
    return function () {
      if (!called) {
        called = true
        fn.apply(that, arguments)
      }
    }
  },
  // 获取匹配词包的数组
  getExecStrs (str) {
    const reg = /\{(.*?)\}/g
    let list = []
    let result = null
    do {
      result = reg.exec(str)
      result && list.push({ val: result[0], str: result[1], start: result.index, end: result.index + result[0].length - 1 })
    } while (result)
    return list
  },
  // 获取光标位置
  getCursortPosition (textDom) {
    var cursorPos = 0
    if (document.selection) {
      // IE Support
      textDom.focus()
      var selectRange = document.selection.createRange()
      selectRange.moveStart('character', -textDom.value.length)
      cursorPos = selectRange.text.length
    } else if (textDom.selectionStart || Number(textDom.selectionStart) === 0) {
      // Firefox support
      cursorPos = textDom.selectionStart
    }
    return cursorPos
  },
  // 设置光标位置
  setCaretPosition (input, pos) {
    input.focus()
    if (document.selection) {
      var sel = input.createTextRange()
      sel.moveStart('character', pos)
      sel.collapse()
      sel.select()
    } else if (typeof input.selectionStart === 'number' && typeof input.selectionEnd === 'number') {
      input.selectionStart = input.selectionEnd = pos
    }
  },
  /**
   * 校验输入的数值
   * @param  val       输入的数值
   * @param  decimals  精确到小数点位
  */
  validateNum (val, decimals = 2) {
    val = String(val)
    const arr = val.split('.')
    if (arr.length > 2) {
      return false
    }
    if (!(/^(0|([1-9]+[0-9]*))$/g.test(arr[0]))) {
      return false
    }
    if (arr.length === 2) {
      const reg = new RegExp(`^([0-9]{1,${decimals}})$`, 'g')
      if (!(reg.test(arr[1]))) {
        return false
      }
    }
    return true
  }
}
