<template>
  <el-select class="lp-select" v-model="lpId" @visible-change="onVisibleChange" placeholder="请选择落地页" no-data-text="该包名下没有匹配的落地页模板，请前往新建">
    <el-option v-for="lp in landingPageList"
      :key="lp.id"
      :label="lp.name"
      :value="lp.id"
      ></el-option>
  </el-select>
</template>
<script>
import { getAllLandingPageList } from '@/api'
export default {
  props: {
    value: [String, Number],
    packageName: {
      type: String,
      default: ''
    }
  },
  data () {
    return {
      lpId: this.value,
      landingPageList: [],
      packageNameChangeNum: 0
    }
  },
  computed: {},
  methods: {
    onVisibleChange (val) {
      if (val) {
        getAllLandingPageList().then(landingPageList => {
          this.landingPageList = landingPageList.filter(item => item.packageName === this.packageName)
        })
      }
    }
  },
  mounted () {
    this.onVisibleChange('init')
  },
  watch: {
    lpId (value, oldValue) {
      this.$emit('input', value)
    },
    value (value) {
      this.lpId = value
    },
    packageName (val) {
      this.packageNameChangeNum += 1
      this.landingPageList = []
      if (this.packageNameChangeNum > 1) { this.lpId = '' }
    }
  }
}
</script>

<style lang="scss">
.lp-select {
  width: 350px;
}
</style>
