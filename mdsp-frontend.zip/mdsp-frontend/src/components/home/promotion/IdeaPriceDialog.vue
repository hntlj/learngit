<template>
  <div>
    <el-dialog :visible.sync="showDialog" width="860px" title="批量修改出价">
      <div class="table-wrap">
        <el-table :data="ideasData">
          <el-table-column
            prop="name"
            label="创意名称">
          </el-table-column>
          <el-table-column
            prop="bid"
            label="当前出价（元）">
          </el-table-column>
          <el-table-column
            prop="modifyPrice"
            label="修改后出价（元）">
          </el-table-column>
        </el-table>
      </div>
      <div class="modify-price">
        <span>修改为（元）： </span><el-input v-model="bid"></el-input>
      </div>
      <p style="color: red; margin-top: 10px;">{{`提示：根据选择的创意，出价的范围是 ${floorPrice} - 100 元，出价仅支持 2 位小数。`}}</p>
      <div slot="footer" class="dialog-footer">
        <el-button @click="showDialog = false">取 消</el-button>
        <el-button type="primary" :disabled="isDisabled" @click="ideaBidUpdate">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import { updateIdeaBidBatch } from '@/api'
import utils from '@/utils'
export default {
  props: {
    showPriceDialog: false,
    ideasData: Array
  },
  data () {
    return {
      showDialog: this.showPriceDialog,
      bid: '',
      isDisabled: true,
      debounceOnInputPrice: () => {}
    }
  },
  computed: {
    floorPrice () {
      let floor = 0
      this.ideasData.forEach(idea => {
        if (idea.floor > floor) floor = idea.floor
      })
      return floor
    }
  },
  methods: {
    onInputPrice (val) {
      if (utils.validateNum(val, 2) && val >= this.floorPrice && val <= 100) {
        this.ideasData.forEach(item => {
          item.modifyPrice = val
          return item
        })
        this.isDisabled = false
      } else {
        this.ideasData.forEach(item => {
          item.modifyPrice = ''
          return item
        })
        this.$message.error('您输入的值不符合要求，请重新输入')
        this.bid = ''
      }
    },
    ideaBidUpdate () {
      updateIdeaBidBatch({
        ideaIds: this.ideasData.map(idea => idea.ideaId).join(','),
        bid: this.bid
      }).then(res => {
        this.$emit('refreshIdeaList')
        this.$message.success('批量出价修改成功')
        this.showDialog = false
      }).catch(error => {
        this.$message.error(error.message)
      })
    }
  },
  created () {
    this.debounceOnInputPrice = utils.debounce(this.onInputPrice, 1250)
  },
  watch: {
    showPriceDialog (val) {
      this.showDialog = val
      if (val) {
        this.isDisabled = true
        this.bid = ''
        this.ideasData.forEach(item => {
          item.modifyPrice = ''
          return item
        })
      }
    },
    showDialog (val) {
      if (!val) {
        this.$emit('close')
      }
    },
    bid (val) {
      this.isDisabled = true
      if (this.bid !== '') this.debounceOnInputPrice(val)
    }
  }
}
</script>
<style lang="scss" scoped>
.table-wrap {
  max-height: 500px;
  overflow: auto;
}
.modify-price {
  margin-top: 20px;
  display: flex;
  justify-content: left;
  align-items: center;
  .el-input {
    width: 180px;
  }
}
</style>
