<template>
  <el-dialog :visible.sync="show" width="460px" @open="handleOpen">
    <el-form :model="form" :rules="rules" ref="form" style="margin:0 auto;width: 260px" v-if="form" @submit.native.prevent>
      <template v-if="formList.indexOf('planName') > -1">
        <h3>计划名称</h3>
        <el-form-item prop="planName">
          <el-input type="text" v-model="form.planName" placeholder="计划名称" />
          <p class="name-tip" v-show="nameTipShow">{{nameTip}}</p>
        </el-form-item>
      </template>
      <template v-if="formList.indexOf('budget') > -1">
        <h3>预算</h3>
        <el-form-item prop="budget">
          <el-radio v-model="form.budgetFlag" :label="true">不限额</el-radio><br>
          <el-radio v-model="form.budgetFlag" :label="false">限额</el-radio>
          <el-input class="form-input--small" style="margin-left:24px;width:130px" v-model="form.budget" placeholder="预算金额" :disabled="form.budgetFlag"></el-input> 元 / 天
        </el-form-item>
      </template>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="show = false">取 消</el-button>
      <el-button type="primary" @click="onSave">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
import { MAX_BUDGET } from '@/enums'
import validateMixin from '@/mixins/validate'
import utils from '@/utils'
import { postPlan } from '@/api'
export default {
  mixins: [validateMixin],
  props: {
    plan: Object,
    formList: Array
  },
  data () {
    const onValidBudget = (rules, value, callback) => {
      if (!this.form.budgetFlag) {
        let tip = ''
        const sum = this.plan.cost + this.plan.configCost
        if (!(utils.validateNum(value, 2))) {
          return callback(new Error('请输入正确的金额, 出价仅支持 2 位小数'))
        }
        if (value < 200) {
          tip = '200元'
        } else if (value < sum) {
          tip = '当前消耗'
        }
        const temp = sum < 200 ? 200 : sum
        if (value < temp) {
          return callback(new Error(`预算金额不能小于${tip}`))
        }
      }
      callback()
    }
    return {
      show: false,
      form: null,
      rules: {
        planName: [{ required: true, message: '请输入计划名称', trigger: 'change' }],
        budget: [{ validator: onValidBudget, trigger: 'change' }]
      },
      nameTip: '',
      nameTipShow: false
    }
  },
  computed: {
    formatForm () {
      const { planId, planName, budget, budgetFlag } = this.form
      return {
        planId,
        planName,
        budget: budgetFlag ? MAX_BUDGET : budget
      }
    }
  },
  methods: {
    onSave () {
      this.submit()
    },
    async submit () {
      const valid = await this.validate()
      if (valid) {
        postPlan(this.formatForm).then(plan => {
          this.$message.success('保存成功')
          this.$emit('change', plan)
          this.show = false
        }).catch(error => {
          this.$message.error(error.message)
          // this.show = false
          this.nameTip = error.message
          this.nameTipShow = true
        })
      }
    },
    handleOpen () {
      if (this.plan && this.plan.planName) {
        this.form.planName = this.plan.planName
      }
      this.nameTipShow = false
    }
  },
  watch: {
    plan (val) {
      if (val) {
        this.form = { ...val,
          budgetFlag: val.budget >= MAX_BUDGET,
          budget: val.budget >= MAX_BUDGET ? '' : val.budget
        }
        this.show = true
      } else {
        this.form = null
      }
    },
    formList () {
      this.show = true
    },
    'form.budgetFlag' (val) {
      if (val) this.form.budget = ''
    },
    'form.planName' (val) {
      this.nameTipShow = false
    }
  }
}
</script>
<style lang="scss" scoped>
h3 {
  font-size: 18px;
  line-height: 24px;
  text-align: center;
  margin-bottom: 40px;
}
.el-input {
  width: 260px;
}
.dialog-footer {
  text-align: center;
}
.name-tip {
  color: red;
}
</style>
