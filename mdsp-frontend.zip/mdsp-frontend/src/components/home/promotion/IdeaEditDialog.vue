<template>
  <el-dialog :visible.sync="show" width="460px">
    <el-form :model="form" :rules="rules" ref="form" style="margin:0 auto;width: 260px" v-if="form" @submit.native.prevent>
      <template v-if="formList.indexOf('name') > -1">
        <h3>创意名称</h3>
        <el-form-item prop="name">
          <el-input type="text" v-model="form.name" placeholder="创意名称" />
        </el-form-item>
      </template>
      <template v-if="formList.indexOf('bid') > -1">
        <el-form-item prop="bid">
          <div style="display: flex;">
            <el-input type="text" v-model="form.bid" placeholder="创意出价" />
            <span style="padding-left: 10px;">元</span>
          </div>
        </el-form-item>
        <el-form-item label="优化目标：">
          <span>{{ ocpcType }}</span>
        </el-form-item>
      </template>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="show = false">取 消</el-button>
      <el-button type="primary" @click="onSave">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
import validateMixin from '@/mixins/validate'
import { OCPC_TYPE } from '@/enums'
import { updateIdea, getBidcostFloor } from '@/api'
import utils from '@/utils'
export default {
  mixins: [validateMixin],
  props: {
    idea: Object,
    formList: Array
  },
  data () {
    const onValidPrice = (rule, value, callback) => {
      const balance = this.accountState.accountBalance + this.accountState.rebateBalance
      const maxPrice = this.idea.ocpcType === OCPC_TYPE.INSTALL || this.idea.slotBundleId === 7 ? 100 : 20
      if (value === '') {
        return callback(new Error('请输入出价'))
      } else if (isNaN(value) || value < this.minPrice) {
        return callback(new Error(`出价不能低于${this.minPrice}元`))
      } else if (value > balance) {
        return callback(new Error('出价不能超过账户余额'))
      } else if (value > maxPrice) {
        return callback(new Error(`出价不能高于${maxPrice}元`))
      } else if (!(utils.validateNum(value, 2))) {
        return callback(new Error('请输入正确的金额, 出价仅支持 2 位小数'))
      } else {
        callback()
      }
    }
    return {
      show: false,
      form: null,
      floorParams: {
        ideaId: 0,
        slotBundleId: 0,
        bidType: 0,
        ocpcType: 1
      },
      rules: {
        name: [{ required: true, message: '请输入创意名称', trigger: 'change' }],
        bid: [{ validator: onValidPrice.bind(this), trigger: 'change' }]
      },
      minPrice: 0
    }
  },
  computed: {
    accountState () {
      return this.$store.getters.accountState
    },
    formatForm () {
      const { ideaId, name, bid } = this.form
      return { ideaId, name, bid }
    },
    ocpcType () {
      switch (this.idea.ocpcType) {
        case OCPC_TYPE.INSTALL: return '下载'
        case OCPC_TYPE.CLICK: return '点击'
        case OCPC_TYPE.ACTIVE: return '激活'
        default: return '-'
      }
    }
  },
  methods: {
    onSave () {
      this.submit()
    },
    async submit () {
      const valid = await this.validate()
      if (valid) {
        updateIdea(this.formatForm).then(idea => {
          this.$message.success('保存成功')
          this.$emit('change', idea)
          this.show = false
        })
      }
    },
    fetchUnitBidFloor () {
      this.minPrice = 0
      const { slotBundleId, bidType, ocpcType, ideaId } = this.idea
      this.floorParams = { slotBundleId, bidType, ocpcType, ideaId }
      getBidcostFloor(this.floorParams).then(prices => {
        this.minPrice = prices.floorPrice
      })
    }
  },
  watch: {
    idea (val) {
      if (val) {
        this.form = { ...val }
        this.show = true
      } else {
        this.form = null
      }
    },
    formList (val) {
      this.show = true
      if (val.indexOf('bid') !== -1) {
        this.fetchUnitBidFloor()
      }
    }
  }
}
</script>
<style lang="scss" scoped>
h3 {
  font-size: 18px;
  line-height: 24px;
  text-align: center;
  margin-bottom: 40px;
}
.el-input {
  width: 260px;
}
.dialog-footer {
  text-align: center;
}
</style>
