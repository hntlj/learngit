<template>
  <el-dialog :visible.sync="show" :width="formList.indexOf('timeSeg') > -1 ? '1500px' : '460px'">
    <el-form :model="form" :rules="rules" ref="form" class="unitEditDialog" :class="formList.join(' ')" v-if="form" @submit.native.prevent>
      <template v-if="formList.indexOf('unitName') > -1">
        <h3>单元名称</h3>
        <el-form-item prop="unitName">
          <el-input type="text" v-model="form.unitName" placeholder="单元名称" />
        </el-form-item>
      </template>
      <template v-if="formList.indexOf('timeSeg') > -1">
        <h3>投放时段</h3>
        <el-form-item style="margin-bottom:24px;">
          <el-radio v-model="form.timeSegFlag" :label="false">全时段</el-radio>
          <el-radio v-model="form.timeSegFlag" :label="true">分时段</el-radio>
          <el-time-grid v-if="form.timeSegFlag" v-model="form.timeSeg"></el-time-grid>
        </el-form-item>
      </template>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="show = false">取 消</el-button>
      <el-button type="primary" @click="onSave">确 定</el-button>
    </div>
  </el-dialog>
</template>
<script>
import validateMixin from '@/mixins/validate'
import { postUnit } from '@/api'
export default {
  mixins: [validateMixin],
  props: {
    unit: Object,
    formList: Array
  },
  data () {
    return {
      show: false,
      form: null,
      rules: {
        unitName: [{ required: true, message: '请输入单元名称', trigger: 'change' }]
      }
    }
  },
  computed: {
    formatForm () {
      const {
        planId,
        unitId,
        unitName,
        timeSegFlag,
        timeSeg,
        unitTargeting,
        startTime,
        endTime,
        packageName,
        isComplete,
        downloadUrl,
        txTrackParam,
        channelPackageId
      } = this.form
      const reg = /0{42}/
      return {
        planId,
        unitId,
        unitName,
        unitTargeting,
        startTime,
        endTime,
        packageName,
        isComplete,
        downloadUrl,
        txTrackParam,
        channelPackageId,
        timeSeg: timeSegFlag && !reg.test(timeSeg) ? timeSeg : -1
      }
    }
  },
  methods: {
    onSave () {
      this.submit()
    },
    async submit () {
      const valid = await this.validate()
      if (valid) {
        postUnit({
          ...this.formatForm
        }).then(unit => {
          this.$message.success('保存成功')
          this.$emit('change', unit)
          this.show = false
        })
      }
    }
  },
  watch: {
    unit (val) {
      if (val) {
        this.form = { ...val,
          timeSegFlag: !!val.timeSeg
        }
        this.show = true
      } else {
        this.form = null
      }
    },
    formList () {
      this.show = true
    }
  }
}
</script>
<style lang="scss" scoped>
.unitEditDialog {
  margin:0 auto;
  &.unitName {
    width: 260px;
  }
}
h3 {
  font-size: 18px;
  line-height: 24px;
  text-align: center;
  margin-bottom: 40px;
}
.el-input {
  width: 260px;
}
.dialog-footer {
  text-align: center;
}
</style>
