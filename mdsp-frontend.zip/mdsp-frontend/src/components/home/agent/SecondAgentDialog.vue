<template>
  <div>
    <el-dialog :visible.sync="myDialogVisible" width="1000px" class="agent-dialog">
      <el-form label-width="150px" ref="form_1" :model="formData" :rules="rules">
        <h3 class="form-title">企业信息</h3>
        <el-form-item label="Flyme帐号" prop="flyme">
          <el-input v-model="formData.flyme" :maxlength="25" placeholder="请输入Flyme帐号  用于登录、找回密码"></el-input>
        </el-form-item>
        <el-form-item label="公司名称" prop="name">
          <el-input v-model="formData.name" :maxlength="60"></el-input>
        </el-form-item>
        <el-form-item label="联系人" prop="contact">
          <el-input v-model="formData.contact" :maxlength="25"></el-input>
        </el-form-item>
        <el-form-item label="联系电话" prop="phone">
          <el-input v-model="formData.phone" :maxlength="25"></el-input>
        </el-form-item>
        <el-form-item label="联系邮箱" prop="email">
          <el-input v-model="formData.email" :maxlength="125"></el-input>
        </el-form-item>
        <el-form-item label="联系地址" prop="address">
          <el-input v-model="formData.address" :maxlength="125"></el-input>
        </el-form-item>
        <h3 class="form-title">财务信息</h3>
        <el-form-item label="开户银行" prop="depositBank">
          <el-input v-model="formData.depositBank" :maxlength="60"></el-input>
        </el-form-item>
        <el-form-item label="开户地" prop="depositCity">
          <el-cascader
            v-model="formData.depositCity"
            :options="cityData"
            change-on-select
          ></el-cascader>
        </el-form-item>
        <el-form-item label="银行帐号" prop="bankAccount">
          <el-input v-model="formData.bankAccount" :maxlength="25"></el-input>
        </el-form-item>
        <el-form-item style="width: 100%;">
          <el-checkbox v-model="check">我已阅读并接受 <a href="/views/agreement.html" target="_blank">《魅族广告投放平台合作协议》</a></el-checkbox>
        </el-form-item>
      </el-form>
      <div slot="footer">
        <el-button @click="onClose">取消</el-button>
        <el-button type="primary" @click="onSave" :disabled="!check">保存</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import validateMixin from '@/mixins/validate'
import { updateAgent, getCityList } from '@/api'
import { phoneValidator } from '@/validators/user'
import util from '@/utils'
export default {
  mixins: [validateMixin],
  props: {
    agentDialogVisible: false
  },
  data () {
    return {
      myDialogVisible: this.agentDialogVisible,
      check: false,
      formData: this.initFormData(),
      rules: {
        flyme: { required: true, message: '请输入Flyme帐号', trigger: 'change' },
        name: { required: true, message: '请输入公司名称', trigger: 'change' },
        contact: { required: true, message: '请输入联系人', trigger: 'change' },
        phone: [
          { required: true, message: '请输入联系电话', trigger: 'change' },
          { validator: phoneValidator.bind(this, '联系电话'), trigger: 'change' }
        ],
        email: [
          { required: true, message: '请输入联系邮箱', trigger: 'change' },
          { type: 'email', message: '邮箱格式不正确', trigger: 'blur' }
        ],
        address: { required: true, message: '请输入联系地址', trigger: 'change' }
      },
      cityData: []
    }
  },
  methods: {
    initFormData () {
      return {
        uid: '',
        newUid: '',
        agentType: '',
        flyme: '',
        name: '',
        contact: '',
        phone: '',
        email: '',
        address: '',
        depositBank: '',
        depositCity: [],
        bankAccount: ''
      }
    },
    onClose () {
      this.formData = this.initFormData()
      this.$emit('close')
    },
    async onSave () {
      const valid = await this.validate()
      if (valid) {
        const data = util.deepCopy(this.formData)
        data.agentType = 2
        data.depositCity = data.depositCity.join(',')
        updateAgent(data).then(res => {
          this.$message.success('保存成功')
          this.$emit('close', true)
        }).catch(error => {
          this.$message.error(error.message)
        })
      }
    },
    getCityData () {
      getCityList().then(res => {
        this.cityData = Object.keys(res.value).map(key => {
          return {
            value: key,
            label: key,
            children: res.value[key].map(city => {
              return {
                value: city.fname,
                label: city.fname
              }
            })
          }
        })
      })
    }
  },
  created () {
    this.getCityData()
  },
  watch: {
    agentDialogVisible (val) {
      this.myDialogVisible = val
    },
    myDialogVisible (val) {
      if (!val) this.$emit('close')
    }
  }
}
</script>
<style lang="scss" scoped>
.agent-dialog {
  .el-form {
    overflow: hidden;
    .form-title {
      margin: 0 0 20px 0;
      line-height: 50px;
      padding-left: 20px;
      border-bottom: 1px solid #ebebeb;
    }
    .el-form-item {
      width: 50%;
      float: left;
    }
  }
}
</style>
