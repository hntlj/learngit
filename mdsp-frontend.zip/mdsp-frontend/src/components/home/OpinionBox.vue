<template>
    <el-dialog :visible.sync="show"
        width="750px"
        :title="title"
        class="dialog-opinion">
        <div class="dialog-text">关于开户、充值、广告投放的部分问题已在<a style="cursor:pointer" @click="toHelp">帮助中心</a>做出解答，可以前往查阅</div>
        <el-form :model="form" :rules="rules" label-position="left" label-width="106px" ref="form" >
            <el-form-item label="标题" prop="title">
                <el-input type="text" v-model="form.title" :maxlength="30" placeholder="30个字符以内"></el-input>
            </el-form-item>
            <el-form-item label="问题描述" prop="description">
                <el-input type="textarea" :rows="6" v-model="form.description" :minlength="10" :maxlength="200" placeholder="200个字符以内"></el-input>
            </el-form-item>
            <el-form-item label="问题类型" prop="type">
                <el-select v-model="form.type" placeholder="请选择" @change="getValue">
                    <el-option
                        v-for="item in issueTypes"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                        >
                    </el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="图片上传" prop="imageFile">
                <image-upload v-model="form.imageFile" />
            </el-form-item>
            <el-form-item label="姓名" prop="name">
                <el-input type="text" v-model="form.name" placeholder="请填写姓名方便业务人员与您对接"></el-input>
            </el-form-item>
            <el-form-item label="联系方式" prop="phone">
                <el-input type="text" v-model="form.phone" placeholder="请填写电话方便业务人员与您对接"></el-input>
            </el-form-item>
        </el-form>
        <span slot="footer" class="dialog-footer">
            <el-button @click="show = false">取消</el-button>
            <el-button type="primary" @click="onSave">确定</el-button>
        </span>
  </el-dialog>
</template>
<script>
import validateMixin from '@/mixins/validate'
import ImageUpload from '@/components/home/ImageUpload'
import { addOpinion } from '@/api'
import { phoneValidator } from '@/validators/user'
import { ISSUE_TYPES } from '@/enums'
export default {
  mixins: [validateMixin],
  props: {
    showOpinion: {
      type: Boolean,
      default () {
        return false
      }
    }
  },
  data () {
    return {
      title: '意见反馈',
      form: {
        title: '',
        description: '',
        type: '',
        imageFile: '',
        name: '',
        phone: ''
      },
      show: false,
      issueTypes: ISSUE_TYPES,
      rules: {
        title: [{ required: true, message: '请输入标题', trigger: 'change' }],
        description: [{ required: true, message: '请输入问题描述', trigger: 'change' }],
        type: [{ required: true, message: '请选择问题类型', trigger: 'change' }],
        phone: [
          { validator: phoneValidator.bind(this, '联系电话'), trigger: 'change' }
        ]
      },
      errMessage: ''
    }
  },
  watch: {
    showOpinion (val) {
      if (val) {
        this.show = val
      } else {
        this.form = {
          title: '',
          description: '',
          type: '',
          imageFile: '',
          name: '',
          phone: ''
        }
      }
    },
    show (val) {
      if (!val) {
        this.$emit('update:showOpinion', null)
      }
    }
  },
  computed: {
  },
  methods: {
    async onSave () {
      const valid = await this.validate()
      if (valid) {
        try {
          const res = await addOpinion(this.form)
          if (res.code === 200) {
            this.$message.success('新增成功，非常感谢您的宝贵意见')
            this.show = false
          }
        } catch (err) {
          this.$message.error(`新增意见错误[${err.message}]，请重试!`)
        }
      }
    },
    toHelp () {
      this.$router.push({name: 'Help'})
      this.show = false
    },
    getValue () {
    }
  },
  components: {
    ImageUpload
  }
}
</script>
<style>
.dialog-text{
  height: 40px;
  line-height: 40px;
  padding-bottom: 15px;
}
.dialog-opinion .el-dialog__header {
  padding-bottom: 0px;
}
.dialog-opinion .el-dialog__body{
  padding: 0 20px 30px 20px !important;
}
</style>
