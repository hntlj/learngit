<template>
  <div class="home-nav-wrap">
    <nav class="home-nav">
      <router-link to="/" exact><i class="icon-index"></i>首页</router-link>
      <router-link v-for="nav in navList" :key="nav.name" :to="nav.path"><i :class="`icon-${nav.icon}`"></i>{{ nav.title }}</router-link>
    </nav>
  </div>
</template>

<script>
export default {
  data () {
    return {
      navList: [
        {
          path: '/promotion',
          title: '推广管理',
          icon: 'repost'
        },
        {
          path: '/analysis',
          title: '数据分析',
          icon: 'analyze'
        },
        {
          path: '/financial',
          title: '财务管理',
          icon: 'finance'
        },
        {
          path: '/toolkit',
          title: '工具箱',
          icon: 'tool'
        }
      ]
    }
  }
}
</script>
<style lang="scss">
$nav-height: 60px;
.home-nav-wrap{
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #fff;
  width: 100%;
  .home-nav {
    height: $nav-height;
    a {
      font-size: 16px;
      line-height: $nav-height;
      color: #000;
      display: inline-block;
      margin-left: 60px;

      &.router-link-active,&.router-link-exact-active {
        color: #3A75FF;
        .icon {
          &-index {
            background-position-y: -55px;
          }
          &-repost {
            background-position-y: -143px;
          }
          &-analyze {
            background-position-y: -231px;
          }
          &-finance {
            background-position-y: -319px;
          }
          &-tool {
            background-position-y: -407px;
          }
        }
      }
      i[class^="icon-"] {
        display: inline-block;
        vertical-align: middle;
        width: 22px;
        height: 22px;
        background-image: url('~assets/img/nav-icon.png');
        background-repeat:  no-repeat;
        background-position-x: -11px;
        margin-right: 14px;
        margin-top: -2px;
      }
      .icon {
        &-index {
          background-position-y: -11px;
        }
        &-repost {
          background-position-y: -99px;
        }
        &-analyze {
          background-position-y: -187px;
        }
        &-finance {
          background-position-y: -275px;
        }
        &-tool {
          background-position-y: -363px;
        }
      }
    }
  }
  .link-platform {
    margin-right: 60px;
  }
}

</style>
