<template>
  <el-header class="home-header" height="70px">
    <!-- <div class="logo"><a href="/">魅族广告{{ isSponsor ? '' : '代理商'}}平台</a></div> -->
    <div class="logo"><a href="/"></a></div>
    <div class="home-header__userinfo">
      <div class="home-header__userinfo__wrap">
        <img :src="userInfo.icon" alt="" class="avatar">
        <p>{{ userInfo.nickName }}</p>
        <p><small>ID: {{ userInfo.uid }}</small></p>
      </div>
      <nav class="home-header__dropdown">
        <router-link v-if="isSponsor" :to="{ name: 'UserInfo' }">我的账号</router-link>
        <a href="/logout">退出</a>
      </nav>
    </div>
    <nav class="home-header__main">
      <router-link v-if="isSponsor && userInfo.status !== USER_STATUS.NONE" class="button" :to="{ name: 'AdEditPlan' }" target="_blank"><i>＋</i>新建广告</router-link>
      <router-link  class="icon" :to="{ name: isSponsor ? 'Recharge' : 'AgentRecharge' }"><i class="icon-recharge"></i></router-link>
      <a @click="$emit('notify')" class="icon" :class="{active: showNotify}"><el-badge :max="99" :value="unreadNum"><i class="icon-notify"></i></el-badge></a>
      <router-link :to="{ name: 'Help' }" class="icon"><i class="icon-info"></i></router-link>
      <a class="icon" @click="showOpinion = true"><i class="icon-opinion"></i></a>
      <notify-box v-show="showNotify" @close="$emit('notify')"></notify-box>
      <opinion-box :showOpinion.sync="showOpinion"></opinion-box>
    </nav>
  </el-header>
</template>
<script>
import { mapGetters } from 'vuex'
import { USER_STATUS, CLIENT_TYPE } from '@/enums'
import NotifyBox from '@/components/home/NotifyBox'
import OpinionBox from '@/components/home/OpinionBox'
export default {
  props: {
    showNotify: Boolean
  },
  data () {
    return {
      notifyBadge: true,
      currKeyword: null,
      showOpinion: false,
      operType: '',
      USER_STATUS,
      CLIENT_TYPE
    }
  },
  computed: {
    ...mapGetters(['userInfo', 'isSponsor', 'unreadNum'])
  },
  components: {
    NotifyBox,
    OpinionBox
  }
}
</script>
<style lang="scss">
.home-header {
  width: 100%;
  height: $header-height;
  background: #282b30;
  &.fixed {
    position: fixed;
    top: 0;
    z-index: 201;

    &+* {
      padding-top: $header-height;
    }
  }

  .logo {
    float: left;
    width: 220px;
    height: $header-height;
    padding-left: 43px;
    background: url('~assets/img/logo.png') no-repeat left center;
    background-size: 180px 60px;
    a {
      color: #fff;
      font-size: 22px;
      font-weight: 600;
      line-height: $header-height;
      display: inline-block;
      width: 100%;
      height: 100%;
    }
  }

  &__userinfo {
    position: relative;
    margin-left: 17px;
    float: right;
    max-width: 180px;
    padding: 16px 0;
    color: #fff;
    font-size: 12px;
    &:hover {
      background-color: #353940;
    }
    &__wrap {
      padding-left: 12px;
    }
    .avatar {
      width: 36px;
      height: 36px;
      float: left;
      border-radius: 50%;
      background: #fff;
    }
    p {
      margin-top: 3px;
      margin-left: 48px;
      line-height: 16px;
      width: 100px;
      @include ellipsis;
    }
    small {
      opacity: .4
    }
    &:hover {
      .home-header__dropdown {
        height: auto;
      }
    }
  }
  &__dropdown {
    position: absolute;
    top: 70px;
    width: 100%;
    height: 0;
    transition: .3s;
    background-color: #fff;
    overflow: hidden;
    z-index: 100;
    box-shadow: -3px 2px 17px 1px rgba(0,0,0,0.1);
    a {
      display: block;
      line-height: 60px;
      font-size: 16px;
      color: #000;
      padding-left: 30px;
      &:hover {
        color: $blue;
        background-color: $light-blue;
      }
    }
  }

  &__main {
    position: relative;
    float: right;
    line-height: $header-height;
    > .button {
      margin-right: 20px;
      display: inline-block;
      color: #fff;
      width: 160px;
      height: 38px;
      line-height: 38px;
      font-size: 16px;
      font-weight: 400;
      text-align: center;
      border-radius: 4px;
      background-image: linear-gradient(to right, #3a71ee 0%, #448ef0 100%);
      i {
        padding-bottom: 1px;
        transform: scale(1.6);
        display: inline-block;
        margin-right: 7px;
        font-weight: 300;
      }
    }
    > .icon {
      cursor: pointer;
      display: inline-block;
      vertical-align: top;
      padding: 0 20px;
      height: 70px;
      margin-left: 10px;
      &:hover,&.active {
        background-color: #353940;
      }
      > i {
        display: inline-block;
        vertical-align: middle;
      }
    }
    [class^="icon-"] {
      display: block;
      width: 22px;
      height: 22px;
      background: url('~assets/img/header-icon.png') no-repeat;
    }
    .icon {
      &-recharge {
        background-position: -11px -55px;
      }
      &-notify {
        background-position: -55px -11px;
        &.badge {
          position: relative;
          &:before {
            position: absolute;
            top: -1px;
            right: -2px;
            background: #ff3333;
            content: '';
            width: 8px;
            height: 8px;
            border-radius: 50%;
          }
        }
      }
      &-info {
        background-position: -11px -11px;
      }
      &-opinion {
        background-position: -55px -55px;
      }
    }
  }
}
</style>
