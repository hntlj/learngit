<template>
  <div>
    <el-dialog title="上传充值凭证" :visible.sync="myDialogVisible" width="750px" class="recharge-dialog">
      <el-form label-width="220px" ref="form_1" :model="formData" :rules="rules">
        <el-form-item label="广告主名称" class="lh1">{{ userInfo.flyme }}</el-form-item>
        <el-form-item label="账户 ID" class="lh1">{{ userInfo.uid }}</el-form-item>
        <el-form-item label="汇款 / 转账公司名称" prop="name">
          <el-input v-model="formData.name" :maxlength="32"></el-input>
        </el-form-item>
        <el-form-item label="汇款 / 转账账号" prop="bankNum">
          <el-input v-model="formData.bankNum" :maxlength="32"></el-input>
        </el-form-item>
        <el-form-item label="汇款 / 转账金额" prop="money">
          <el-input v-model.number="formData.money">
            <template slot="append">元</template>
          </el-input>
        </el-form-item>
        <el-form-item label="银行流水号" prop="orderId">
          <el-input v-model="formData.orderId" :maxlength="100"></el-input>
        </el-form-item>
        <el-form-item label="汇款 / 转账凭证" prop="receiptFile">
          <image-upload v-model="formData.receiptFile"></image-upload>
        </el-form-item>
        <el-form-item label="备注">
          <el-input v-model="formData.remark" type="textarea"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer">
        <el-button @click="onClose">取消</el-button>
        <el-button type="primary" @click="onConfirm">保存</el-button>
      </div>
    </el-dialog>
    <confirmation-dialog
      :confirmation-dialog-visible="confirmationDialogVisible"
      :confirmation-title="confirmationTitle"
      :confirmation-info="confirmationInfo"
      @close="confirmationDialogVisible=false"
      @confirmHandle="debounceOnSave">
    </confirmation-dialog>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
import validateMixin from '@/mixins/validate'
import { addRecharge } from '@/api'
import utils from '@/utils/index'
import ImageUpload from '@/components/home/ImageUpload'
import ConfirmationDialog from '@/components/ConfirmationDialog'
export default {
  mixins: [validateMixin],
  props: {
    dialogVisible: false
  },
  data () {
    const moneyValidator = (rule, value, callback) => {
      if (isNaN(value)) {
        callback(new Error('汇款 / 转账金额格式不正确'))
      } else if (value < 10000) {
        callback(new Error('汇款 / 转账金额至少为10,000元'))
      } else if (value > 21474836.47) {
        callback(new Error('汇款 / 转账金额不能超过21,474,836.47元'))
      } else {
        callback()
      }
    }
    return {
      myDialogVisible: this.dialogVisible,
      formData: {
        name: '',
        bankNum: '',
        money: '',
        orderId: '',
        receiptFile: '',
        remark: ''
      },
      rules: {
        name: { required: true, message: '请输入汇款 / 转账公司名称', trigger: 'change' },
        bankNum: { required: true, message: '请输入汇款 / 转账账号', trigger: 'change' },
        money: [
          { required: true, message: '请输入汇款 / 转账金额', trigger: 'change' },
          { validator: moneyValidator, trigger: 'change' }
        ],
        orderId: [{ required: true, message: '请输入银行流水号', trigger: 'change' }],
        receiptFile: [{ required: true, message: '请上传充值凭证', trigger: 'change' }]
      },
      confirmationDialogVisible: false,
      confirmationTitle: '请确认您的充值信息',
      confirmationInfo: []
    }
  },
  computed: {
    ...mapGetters(['userInfo'])
  },
  methods: {
    onClose () {
      this.formData = {
        name: '',
        bankNum: '',
        money: '',
        orderId: '',
        receiptFile: '',
        remark: ''
      }
      this.$emit('close')
    },
    async onConfirm () {
      const valid = await this.validate()
      if (valid) {
        this.confirmationInfo = [
          {
            label: '账户名称',
            value: this.userInfo.flyme
          }, {
            label: '账户ID',
            value: this.userInfo.uid
          }, {
            label: '充值金额',
            value: this.formData.money
          }
        ]
        this.confirmationDialogVisible = true
      }
    },
    onSave () {
      let flowId = String(new Date().getTime()) +
                  String(this.userInfo.uid) +
                  'ad' + 0
      addRecharge({
        ...this.formData, flowId
      }).then(res => {
        if (res.code === 200) {
          this.$message.success('上传成功')
          this.$emit('success')
          this.onClose()
        }
      }).catch(error => {
        this.$message.error(error.message)
      })
    },
    debounceOnSave () {}
  },
  created () {
    this.debounceOnSave = utils.debounce(this.onSave)
  },
  watch: {
    dialogVisible (val) {
      this.myDialogVisible = val
      if (val && this.$refs.form_1) {
        this.$refs.form_1.clearValidate()
      }
    },
    myDialogVisible (val) {
      if (!val) {
        this.$emit('close')
      }
    }
  },
  components: {
    ImageUpload,
    ConfirmationDialog
  }
}
</script>
