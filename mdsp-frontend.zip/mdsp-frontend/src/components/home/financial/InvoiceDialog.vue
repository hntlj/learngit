<template>
    <div>
        <el-dialog :visible.sync="showInvoice" title="发票申请" width="1000px">
            <div class="invoice-flex">
                <div class="invoice-width">
                    <div class="invoice-title">发票信息</div>
                    <el-form :inline="true" label-width="180px" ref="form_1" :model="InvoiceFormData" :rules="rules">
                        <el-form-item label="公司名称" class="lh1">{{ InvoiceFormData.name }}</el-form-item>
                        <el-form-item label="纳税人识别号" prop="registrationNumber">
                        <el-input v-model="InvoiceFormData.registrationNumber" :maxlength="32"></el-input>
                        </el-form-item>
                        <el-form-item label="开户银行" prop="depositBank">
                        <el-input v-model="InvoiceFormData.depositBank" :maxlength="32"></el-input>
                        </el-form-item>
                        <el-form-item label="银行帐号" prop="bankAccount">
                        <el-input v-model.number="InvoiceFormData.bankAccount">
                        </el-input>
                        </el-form-item>
                        <el-form-item label="公司注册地址" prop="companyRegisteredAddress">
                        <el-input v-model="InvoiceFormData.companyRegisteredAddress" :maxlength="100"></el-input>
                        </el-form-item>
                        <el-form-item label="公司注册电话" prop="companyRegisteredPhone">
                        <el-input v-model="InvoiceFormData.companyRegisteredPhone" :maxlength="100"></el-input>
                        </el-form-item>
                        <el-form-item label="发票类型" prop="receiptType">
                        <el-radio-group class="padd-l-50" v-model="InvoiceFormData.receiptType">
                        <el-radio :label="1">增值税普通发票</el-radio>
                        <el-radio :label="2">增值税专用发票</el-radio>
                        </el-radio-group>
                        </el-form-item>
                    </el-form>
                </div>
                <div class="invoice-width bottom">
                    <div class="invoice-title">收件人信息</div>
                    <el-form :inline="true" label-width="180px" ref="form_2" :model="InvoiceFormData" :rules="rules_2">
                        <el-form-item label="收件人名称" prop="addresseeName">
                        <el-input v-model="InvoiceFormData.addresseeName" :maxlength="32"></el-input>
                        </el-form-item>
                        <el-form-item label="联系电话" prop="addresseePhone">
                        <el-input v-model="InvoiceFormData.addresseePhone" :maxlength="32"></el-input>
                        </el-form-item>
                        <el-form-item label="收件地址" prop="receiverAddress">
                        <el-input v-model="InvoiceFormData.receiverAddress" :maxlength="100"></el-input>
                        </el-form-item>
                    </el-form>
                </div>
            </div>
            <span slot="footer" class="dialog-footer">
                <el-button @click="onClose">取消</el-button>
                <!-- :disabled="!addKwPackageName" -->
                <el-button type="primary" @click="onSave" >申请发票</el-button>
            </span>
        </el-dialog>
    </div>
</template>
<script>
import { mapGetters } from 'vuex'
import validateMixin from '@/mixins/validate'
import { receiptSave } from '@/api'
import Storage from '@/utils/storage'
export default {
  mixins: [validateMixin],
  props: {
    dialogVisible: false,
    InvoiceFormData: {}
  },
  data () {
    return {
      showInvoice: this.dialogVisible,
      rules: {
        registrationNumber: { required: true, message: '请输入纳税人识别号', trigger: 'change' },
        depositBank: { required: true, message: '请输入开户银行', trigger: 'change' },
        bankAccount: [{ required: true, message: '请输入银行账号', trigger: 'change' }],
        companyRegisteredAddress: [{ required: true, message: '请输入公司注册地址', trigger: 'change' }],
        companyRegisteredPhone: [{ required: true, message: '请输入公司注册号码', trigger: 'change' }],
        receiptType: [{ required: true, message: '请选择发票类型', trigger: 'change' }]
      },
      rules_2: {
        addresseeName: [{ required: true, message: '请输入收件人名称', trigger: 'change' }],
        addresseePhone: [{ required: true, message: '请输入收件人电话', trigger: 'change' }],
        receiverAddress: [{ required: true, message: '请输入收件人地址', trigger: 'change' }]
      }
    }
  },
  computed: {
    ...mapGetters(['userInfo'])
  },
  mounted () {
  },
  methods: {
    onClose () {
      this.$emit('close')
    },
    async onSave () {
      const valid = await this.validate()
      if (valid) {
        receiptSave(this.InvoiceFormData).then(res => {
          if (res.code === 200) {
            Storage.set('InvoiceFormData', this.InvoiceFormData)
            this.$emit('close')
            // this.dataList = res.value.data || []
            // this.dataListTotal = res.value.total
          }
        }).catch(error => {
          this.$message.error(error.message)
        })
      }
    }
  },
  watch: {
    dialogVisible (val) {
      this.showInvoice = val
      if (val && this.$refs.form_1) {
        this.$refs.form_1.clearValidate()
      }
    },
    showInvoice (val) {
      if (!val) {
        this.$emit('close')
      }
    }
  }
}
</script>
<style lang="scss">
.invoice-flex {
    display: flex;
    justify-content: space-between;
}
.invoice-width{
    width: 550px;
    .invoice-title{
        padding: 0px 0 30px 73px;
        font-weight: bold;
    }
}
.bottom{
    width: 450px;
}
</style>
