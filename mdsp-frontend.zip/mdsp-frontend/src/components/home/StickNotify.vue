<template lang="html">
  <div class="sticknotify__container" :class="{hidden: msgList.length === 0}">
    <div class="sticknotify__content" :key="msg.id" v-for="msg in msgList" @click="onOpen(msg)" :class="{pointer: msg.type !== 11}">
      <a class="sticknotify__btn" @click="onClose(msg.id)">×</a>
      <i class="el-icon-warning"></i>
      <p v-if="msg.type === 11" v-html="msg.content"></p>
      <p v-else >{{ msg.title }} <span>{{ msg.typeText}}</span></p>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import utils from '@/utils'
import Bus from '@/utils/bus'
import { USER_STATUS } from '@/enums'
import { getStickNotifyList } from '@/api'
const STORE_KEY = '_notify_closed'
export default {
  data () {
    return {
      messageList: [],
      closeIds: []
    }
  },
  computed: {
    ...mapGetters(['isSponsor', 'userInfo']),
    msgList () {
      return this.messageList.filter(msg => this.closeIds.indexOf(msg.id + '') === -1)
    }
  },
  methods: {
    onClose (id) {
      this.closeIds.push(id + '')
      this.$cookie.set(STORE_KEY, this.closeIds.join(','))
    },
    onOpen (msg) {
      if (msg.type !== 11) {
        this.$store.dispatch('openNotify', msg)
        this.onClose(msg.id)
        this.$emit('notify')
        Bus.$emit('openNotify', msg)
      }
    },
    fetchStickNotifyList () {
      [USER_STATUS.VERIFYED, USER_STATUS.CHECKING].indexOf(this.userInfo.status) !== -1 && getStickNotifyList(this.isSponsor).then(res => {
        if (res.code === 200) {
          this.messageList = res.value
        }
      })
    }
  },
  watch: {
    userInfo () {
      this.fetchStickNotifyList()
    }
  },
  created () {
    this.debounceFetchStickNotifyList = utils.debounce(this.fetchStickNotifyList)
    this.closeIds = (this.$cookie.get('_notify_closed') || '').split(',').filter(m => m)
    Bus.$on('fetchStickNotify', () => {
      this.fetchStickNotifyList()
    })
  }
}
</script>

<style lang="scss">
.sticknotify {
  &__container {
    width: 100%;
    max-height: 36px;
    overflow: hidden;
    border-top: 1px solid #F5E1B9;
    border-bottom: 1px solid #F5E1B9;
    &.hidden {
      visibility: hidden;
    }
  }
  &__content {
    padding-left: 15px;
    background: #FFF7E6;
    line-height: 36px;
    overflow: hidden;
    p {
      display: inline;
      color: #666;
      margin-left: 10px;
      margin-right: 50px;
      font-size: 12px;
      a {
        margin-left: 6px;
        color: #438CF0;
      }
    }
    .el-icon-warning {
      color: #FA0;
      vertical-align: middle;
    }
    &.pointer {
      cursor: pointer;
    }
  }
  &__btn {
    float: right;
    margin-right: 12px;
    color: #999;
    font-size: 20px;
    font-weight: 100;
    cursor: pointer;
  }
}
.agent .sticknotify__container {
  border-top: none;
}
</style>
