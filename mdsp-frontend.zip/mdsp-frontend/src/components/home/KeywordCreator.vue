<template>
  <el-dialog :visible.sync="show"
    width="462px"
    :title="title">
    <el-form :model="form" :rules="rules" label-position="left" label-width="106px" ref="form">
      <el-form-item label="词包名称" prop="packageName">
        <el-input type="text" v-model="form.packageName" :disabled="operType === 'view'"></el-input>
      </el-form-item>
      <el-form-item label="关键词" prop="keyword">
        <el-input type="textarea" :rows="10" v-model="form.keywords" :disabled="operType === 'view'" placeholder="每行输入一个关键词"></el-input>
        <p class="pull-right" v-if="keywordSetting">{{ result.keywords.length }} / {{ keywordSetting.packageMaxKeywordNum }}</p>
        <p :class="{'color-red': !result.errMessage}"><small v-html="errMessage"></small></p>
      </el-form-item>
    </el-form>
    <div class="keyword-tip" v-if="operType !== 'view'">
      说明：<br/>
      1、一行一个关键词，按回车键换行。<br/>
      2、一个词包的关键词数量上限是50个。<br/>
      3、一个关键词的字数不能超过20，且字之间不能加空格。<br/>
      4、词包名称不能重复，否则无法区分词包。
    </div>
    <span slot="footer" class="dialog-footer">
      <el-button @click="show = false">取消</el-button>
      <el-button type="primary" @click="onSave" :disabled="!!errMessage" v-if="operType !== 'view'">保存</el-button>
    </span>
  </el-dialog>
</template>
<script>
import { getKeywordList, postKeyword } from '@/api'
import validateMixin from '@/mixins/validate'
export default {
  mixins: [validateMixin],
  props: {
    keywordPackage: Object,
    operType: String
  },
  data () {
    return {
      form: {
        // packageId: '',
        packageName: '',
        keyword: ''
      },
      rules: {
        packageName: [{ required: true, message: '请输入词包名称', trigger: 'change' }],
        keywords: [{ required: true, message: '请输入关键词', trigger: 'change' }]
      },
      show: false,
      result: {
        keywords: [],
        errors: []
      },
      errMessage: '',
      operTypes: {
        add: '新建',
        update: '修改',
        view: '查看'
      },
      keywordSetting: {
        packageMaxKeywordNum: 50, // 关键词数量上限个数
        posterMaxPackageNum: 5,
        sponsorMaxPackageNum: 30
      }
    }
  },
  computed: {
    title () {
      return `${this.operTypes[this.operType]}词包`
    }
  },
  methods: {
    getKeyword (keywords) {
      let result = []
      let errors = []
      keywords.split('\n').forEach(keyword => {
        keyword = keyword.trim()
        if (keyword && result.indexOf(keyword) === -1) {
          if (keyword.length > 20) {
            if (errors.indexOf(keyword) === -1) {
              errors.push(keyword)
            }
          } else if (/\s/.test(keyword)) {
            errors.push(keyword)
          } else {
            result.push(keyword)
          }
        }
      })
      return {
        valid: result.length > 0 && result.length <= this.max && errors.length === 0,
        keywords: result,
        errors
      }
    },
    async onSave () {
      const valid = await this.validate()
      if (valid && this.form.keywords) {
        let { keywords, packageName } = this.form
        keywords = this.getKeyword(this.form.keywords).keywords
        try {
          const res = await postKeyword({ operType: this.operType, packageName, keywords })
          if (res.code === 200) {
            this.$message.success('保存成功')
            this.$emit('refetch', res.value)
            this.show = false
          }
        } catch (error) {
          this.$message.error(error.message)
        }
      }
    },
    fetchKeywordList () {
      getKeywordList({
        packageName: this.keywordPackage.kwPackageName
      }).then(res => {
        const val = res.value
        this.form = {
          packageName: val.packageName,
          keywords: val.data.map(kw => kw.keyword).join('\n')
        }
      })
    }
  },
  watch: {
    keywordPackage (val) {
      if (val) {
        if (val.kwPackageName) {
          this.fetchKeywordList()
        } else {
          this.form = {
            packageName: '',
            keywords: ''
          }
        }
        this.show = true
      }
    },
    show (val) {
      if (!val) {
        this.$emit('update:keywordPackage', null)
      }
    },
    'form.keywords' (val) {
      const r = this.getKeyword(val)
      if (this.keywordSetting.packageMaxKeywordNum < r.keywords.length) {
        this.errMessage = `关键词数量不能超过${this.keywordSetting.packageMaxKeywordNum}个`
      } else if (r.errors.length > 0) {
        this.errMessage = `关键词的字数不能超过20个且字之间不能有空格，以下关键词需要调整：<br>${r.errors.join('、')}`
      } else if (r.keywords.length === 0) {
        this.errMessage = '请输入关键词'
      } else {
        this.errMessage = ''
      }
      this.result = r
    }
  },
  created () {}
}
</script>
<style lang="scss" scoped>
.el-form-item:not(:last-child) {
  margin-bottom: 36px;
}
.el-form {
  margin-bottom: 0;
}
.keyword-tip {
  line-height: 25px;
  background: #f0f0f0;
  padding: 10px 20px;
}
</style>
