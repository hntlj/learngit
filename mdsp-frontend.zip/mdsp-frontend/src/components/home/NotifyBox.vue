<template>
  <div class="home-notifybox">
    <div class="home-notifybox__header">
      <el-radio-group v-model="formData.notifyType">
        <el-radio-button v-for="ntype in NOTIFY_CATS" :key="ntype.value" :label="ntype.value">{{ ntype.name }}</el-radio-button>
      </el-radio-group>
      <el-select v-model="formData.read">
        <el-option v-for="status in NOTIFY_STATUS" :key="status.value" :value="status.value" :label="status.name"></el-option>
      </el-select>
      <a @click="goSetting" class="button"><i class="icon-setting"></i>消息设置</a>
    </div>
    <div class="home-notifybox__main" v-loading="fetching">
      <div class="empty" v-if="!fetching && dataList.length === 0">
        <p>暂无消息通知</p>
      </div>
      <div class="item" v-for="notify in dataList" :key="notify.id" :class="{unread: !notify.readed, unfold: notify.id === activeId}">
        <div class="item__title" @click="onClick(notify, $event)">
          <p><i class="icon"></i><span class="notify_type">{{formatNotifyType(notify.type)}}</span><span class="notify_content">{{ notify.title }}</span></p>
          <span class="notify_time">{{formatDate(notify.update_time, 'yyyy-MM-dd')}}</span>
        </div>
        <div class="item__main">
          <div class="item__content" v-html="notify.content"></div>
          <div class="item__footer">
            <a @click="onDelete(notify, $event)">删除</a>
          </div>
        </div>
      </div>
    </div>
    <div class="home-notifybox__footer" v-if="dataListTotal > 0">
      <el-button icon="el-icon-arrow-left" :disabled="formData.pageNumber === 1" @click="onPageChanged(formData.pageNumber - 1)"></el-button>
      <span class="pagenum">{{ formData.pageNumber }} / {{ pageTotal }}</span>
      <el-button icon="el-icon-arrow-right" :disabled="formData.pageNumber === pageTotal" @click="onPageChanged(formData.pageNumber + 1)"></el-button>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import utils from '@/utils'
import Bus from '@/utils/bus'
import { NOTIFY_TYPE, USER_STATUS } from '@/enums'
import { getNotifyList, updateNotify } from '@/api'
const PAGE_SIZE = 10
export default {
  data () {
    return {
      formData: {
        notifyType: '',
        read: '',
        pageSize: PAGE_SIZE,
        pageNumber: 1
      },
      params: null,
      NOTIFY_CATS: [{ value: '', name: '全部' }].concat(Object.values(NOTIFY_TYPE)),
      NOTIFY_STATUS: [
        { value: '', name: '所有状态' },
        { value: '0', name: '未读' },
        { value: '1', name: '已读' }
      ],
      fetching: false,
      dataList: [],
      dataListTotal: 0,
      activeId: -1
    }
  },
  computed: {
    ...mapGetters(['isSponsor', 'userInfo', 'openNotify']),
    pageTotal () {
      return Math.ceil(this.dataListTotal / PAGE_SIZE)
    }
  },
  methods: {
    goSetting () {
      this.$emit('close')
      this.$router.push({ name: this.isSponsor ? 'MessageSetting' : 'AgentMessageSetting' })
    },
    onClick (notify) {
      this.activeId = this.activeId === notify.id ? -1 : notify.id
      if (!notify.readed) {
        notify.readed = true
        updateNotify(this.isSponsor, notify.id, 'read').then(() => {
          Bus.$emit('fetchStickNotify')
          this.$store.dispatch('getUnreadNum')
        })
      }
    },
    onDelete (notify) {
      this.$confirm('确定要删除该消息吗？', '', {
        type: 'warning'
      }).then(() => {
        updateNotify(this.isSponsor, notify.id, 'delete').then(res => {
          if (res.code === 200) {
            this.$message.success('删除成功')
            this.fetchNotifyList()
          }
        })
      })
    },
    onPageChanged (currPage) {
      this.formData.pageNumber = currPage
    },
    onOpenNotify (msg) {
      const idList = this.dataList.map(v => v.id)
      let idx = idList.indexOf(msg.id)
      if (idx === -1) {
        idx = 0
        this.dataList.unshift(msg)
      }
      this.$nextTick(() => {
        this.onClick(this.dataList[idx])
      })
    },
    fetchNotifyList () {
      const userStatus = [USER_STATUS.VERIFYED, USER_STATUS.CHECKING]
      if (userStatus.indexOf(this.userInfo.status) === -1) {
        return
      }
      this.fetching = true
      this.activeId = -1
      getNotifyList(this.isSponsor, this.formData).then(res => {
        if (res.code === 200) {
          const { msgCount, voList } = res.value
          this.dataListTotal = msgCount
          this.dataList = voList
          if (voList.length === 0 && this.formData.pageNumber > 1) {
            this.formData.pageNumber -= 1
          }
        }
      }).finally(() => {
        setTimeout(() => {
          this.fetching = false
        }, 300)
      })
    },
    formatNotifyType (msgType) {
      if (this.formData.notifyType) {
        return NOTIFY_TYPE[this.formData.notifyType].name
      } else {
        return Object.values(NOTIFY_TYPE).find(({subTypes}) => subTypes.indexOf(msgType) > -1).name
      }
    },
    formatDate (time, format) {
      return utils.formatDate(time, format)
    }
  },
  watch: {
    formData: {
      deep: true,
      handler: function (val) {
        this.params = { ...val }
      }
    },
    params (val, oldVal) {
      if (oldVal && val.pageNumber !== 1 && (val.notifyType !== oldVal.notifyType || val.read !== oldVal.read)) {
        this.formData.pageNumber = 1
      } else {
        this.debounceFetchNotfiyList()
      }
    },
    userInfo () {
      this.debounceFetchNotfiyList()
    }
  },
  mounted () {
    this.debounceFetchNotfiyList = utils.debounce(this.fetchNotifyList)
    this.debounceFetchNotfiyList()
    Bus.$on('openNotify', msg => {
      this.onOpenNotify(msg)
    })
  }
}
</script>

<style lang="scss">
.home-notifybox {
  position: absolute;
  background: #fff;
  width: 1000px;
  right: 120px;
  box-shadow: 0 10px 12px 0 rgba(0,0,0,0.10);
  border-radius: 4px;
  font-size: 14px;
  &:before {
    content: '';
    position: absolute;
    top: -5px;
    right: 60px;
    background-color: #fff;
    width: 10px;
    height: 10px;
    transform: rotate(45deg);
  }

  &__header {
    position: relative;
    padding: 24px;
    line-height: 1;
    .el-radio-button__inner {
      width: 120px;
      font-size: 14px;
      padding: 11px;
    }
    .el-select {
      margin-left: 24px;
      width: 150px;
    }
    .button {
      cursor: pointer;
      float: right;
      color: $blue;
      line-height: 38px;
    }
    .icon-setting {
      display: inline-block;
      vertical-align: middle;
      margin-right: 6px;
      width: 16px;
      height: 16px;
      background: url('~assets/img/notify-icon.png') -10px -109px;
    }
  }

  &__main {
    margin-bottom: 24px;
    min-height: 250px;
    max-height: 600px;
    overflow: auto;
    > .empty {
      padding-top: 100px;
      background: url('~assets/img/notify-empty.png') no-repeat center;
      background-size: 60px;
      text-align: center;
      font-size: 18px;
      color: gray(.2);
    }
    > .item {
      line-height: 38px;
      overflow: hidden;
      &:after {
        display: block;
        margin-left: 15px;
        content: '';
        width: 960px;
        border-bottom: 1px solid rgba(0,0,0,.1);
      }
      &:hover {
        background-color: $light-blue;
      }
      p {
        float: left;
        padding-left: 15px;
      }
      .item__title {
        cursor: pointer;
        overflow: hidden;
      }
      &.unread {
        color: $blue;
        .icon {
         background-position-y: -42px;
       }
      }
      &.unfold {
        color: #000 !important;
        background-color: #f7f7f7 !important;
        margin-top: -1px;
        border-top: 1px solid rgba(0,0,0,.1);
        border-bottom: 1px solid rgba(0,0,0,.1);
        overflow: auto;

        &:after {
          display: none;
        }
        .item__main {
          height: auto;
          overflow: auto;
        }
        .item__content {
          word-wrap: break-word;
          img {
            max-width: 100%;
          }
          p {
            float: none;
            padding-left: 0;
          }
        }
        .icon {
         height: 15px;
         background-position-y: -74px;
       }
      }
    }
    .item__main {
      height: 0;
      transition: .3s;
      padding: 0 24px;
      overflow: hidden;
    }
    .item__footer {
      text-align: right;
      font-size: 14px;
      color: $blue;
      a {
        cursor: pointer;
      }
    }
    .icon {
      display: inline-block;
      vertical-align: middle;
      margin-left: 10px;
      width: 16px;
      height: 12px;
      background: url('~assets/img/notify-icon.png') -10px -10px;
    }
    .notify_type {
      margin-left: 24px;
    }
    .notify_content {
      margin-left: 36px;
    }
    .notify_time {
      display: block;
      margin-left: 863px;
    }
  }

  &__footer {
    padding-right: 24px;
    padding-bottom: 24px;
    text-align: right;
    line-height: 1;
    .el-button {
      padding: 10px;
      font-size: 14px;
    }
    .pagenum {
      padding: 0 24px;
      font-size: 16px;
    }
  }
}
</style>
