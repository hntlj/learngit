const context = require.context('./', false, /\.vue$/)

const Home = context.keys().reduce((memo, key) => {
  const name = 'Home' + key.match(/([^/]+)\.vue$/)[1]
  memo[name] = context(key).default
  return memo
}, {})

export default Home
