<template>
  <span class="home-card__header back" @click="goBack">
    <i class="el-icon-arrow-left"></i> {{title}}
  </span>
</template>

<script>
export default {
  props: {
    title: String
  },
  data () {
    return {
      headerTitle: this.title
    }
  },
  methods: {
    goBack () {
      this.$router.push('../toolkit')
    }
  }
}
</script>

<style lang="scss">
.home-card__header .back {
  cursor: pointer;
}
</style>
