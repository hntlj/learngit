<template>
  <el-dialog :visible.sync="show"
    width="462px"
    :title="title">
    <el-form :model="form" :rules="rules" label-position="left" label-width="116px" ref="form">
      <el-form-item label="黑名单名称" prop="name">
        <el-input type="text" v-model="form.name" :disabled="operType === 'detail'" placeholder="请输入黑名单名称"></el-input>
      </el-form-item>
      <el-form-item label="设备号">
        <el-input type="textarea" :rows="10" v-model="form.imei" :disabled="operType === 'detail'" placeholder="每行输入一个设备IMEI"></el-input>
        <p class="pull-right" v-if="setting">{{ result.imei.length }} / {{ setting.imeiMaxNum }}</p>
        <p :class="{'color-red': !result.errMessage}"><small v-html="errMessage"></small></p>
      </el-form-item>
    </el-form>
    <div class="imei__tip" v-if="operType !== 'detail'">
      说明：<br/>
      1、一行一个设备号，按回车键换行。<br/>
      2、设备号只支持IMEI。<br/>
      3、一个黑名单的设备号数量上限是500个。<br/>
      4、黑名单名称不能重复，否则无法区黑名单。
    </div>
    <span slot="footer" class="dialog-footer">
      <el-button @click="show = false">取消</el-button>
      <el-button type="primary" @click="onSave" :disabled="!!errMessage" v-if="operType !== 'detail'">保存</el-button>
    </span>
  </el-dialog>
</template>

<script>
import { postBlocklist, getBlacklistDetail } from '@/api'
import validateMixin from '@/mixins/validate'
import utils from '@/utils'
export default {
  mixins: [validateMixin],
  props: {
    blacklist: Object,
    operType: String
  },
  data () {
    return {
      form: {
        id: '',
        name: ''
        // imei: ''
      },
      rules: {
        name: [{ required: true, message: '请输入黑名单名称', trigger: 'change' }],
        imei: [{ required: true, message: '请输入设备IMEI号', trigger: 'change' }]
      },
      show: false,
      result: {
        imei: [],
        errors: []
      },
      errMessage: '',
      operTypes: {
        create: '新建',
        update: '修改',
        detail: '查看'
      },
      setting: {
        imeiMaxNum: 500 // imei数量上限个数
        // posterMaxPackageNum: 5,
        // sponsorMaxPackageNum: 30
      }
    }
  },
  computed: {
    title () {
      return `${this.operTypes[this.operType]}黑名单`
    }
  },
  methods: {
    getImei (imeis) {
      let result = []
      let errors = []
      imeis.split('\n').forEach(imei => {
        imei = imei.trim()
        if (imei && result.indexOf(imei) === -1) {
          if (imei.length > 20) {
            if (errors.indexOf(imei) === -1) {
              errors.push(imei)
            }
          } else if (/\s/.test(imei)) {
            errors.push(imei)
          } else {
            result.push(imei)
          }
        }
      })
      return {
        valid: result.length > 0 && result.length <= this.max && errors.length === 0,
        imei: result,
        errors
      }
    },
    async onSave () {
      const valid = await this.validate()
      if (valid && this.form.imei) {
        let { id, name, imei } = this.form
        imei = this.getImei(this.form.imei).imei
        try {
          const res = await postBlocklist({ operType: this.operType, id, name, imei })
          if (res.code === 200) {
            this.$message.success('保存成功')
            this.$emit('refetch', res.value)
            this.show = false
          }
        } catch (error) {
          this.$message.error(error.message)
        }
      }
    },
    fetchBlacklistDetail () {
      getBlacklistDetail({
        id: this.blacklist.id
      }).then(res => {
        const val = res.value
        this.form = {
          id: val.id,
          name: val.name,
          // imei: val.imei.replace(/↵/g, '\n')
          imei: val.imei.join('\n')
        }
      })
    },
    postReq (fn, context) {

    }
  },
  created () {
    this.onSave = utils.throttle(this.onSave, 1500)
  },
  watch: {
    blacklist (val) {
      if (val) {
        if (val.imei) {
          this.fetchBlacklistDetail()
        } else {
          this.form = {
            name: '',
            imei: ''
          }
        }
        this.show = true
      }
    },
    show (val) {
      if (!val) {
        this.$emit('update:blacklist', null)
      }
    },
    'form.imei' (val) {
      const r = this.getImei(val)
      if (this.setting.imeiMaxNum < r.imei.length) {
        this.errMessage = `IMEI数量不能超过${this.setting.imeiMaxNum}个`
      } else if (r.errors.length > 0) {
        this.errMessage = `IMEI的字数不能超过20个且字之间不能有空格，以下IMEI需要调整：<br>${r.errors.join('、')}`
      } else if (r.imei.length === 0) {
        this.errMessage = '请输入设备IMEI'
      } else {
        this.errMessage = ''
      }
      this.result = r
    }
  }
}
</script>

<style lang="scss" scoped>
.el-form-item:not(:last-child) {
  margin-bottom: 36px;
}
.el-form {
  margin-bottom: 0;
}
.imei__tip {
  line-height: 25px;
  background: #f0f0f0;
  padding: 10px 20px;
}
</style>
