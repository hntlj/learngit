<template>
  <div style="display: inline-block">
    <el-upload drag action="/common/upload" :show-file-list="false" style="display: inline-block;margin-right: 20px"
      :on-error="onUploadError"
      :on-success="onUploadSuccess"
      :before-upload="onUploadBefore">
      <div v-if="value" class="el-upload__preview">
        <img :src="value" :style="previewStyle">
        <span @click.stop="onRemoveImg"><i class="el-icon-close"></i></span>
      </div>
      <div class="el-upload__placeholder" v-else>
        <i class="el-icon-uploader"></i>
        <div class="el-upload__text"><em>点击上传图片</em><br></div>
      </div>
    </el-upload>
    <div class="el-form-item__tip" style="width: 320px">建议{{ specDesc }}格式为 jpg、png、jpeg 并且大小在 300k 以内。</div>
  </div>
</template>
<script>
export default {
  props: {
    limitSize: {
      type: Number,
      default: 300
    },
    width: Number,
    height: Number,
    minHeight: Number,
    value: String
  },
  data () {
    return {
      limitExt: ['image/jpeg', 'image/png'],
      imgWidth: 0,
      imgHeight: 0
    }
  },
  computed: {
    previewStyle () {
      if (this.value) {
        const ratio = this.imgWidth / this.imgHeight
        return {
          width: (ratio > 1.5 ? 140 * ratio : 210) + 'px',
          height: (ratio > 1.5 ? 140 : 210 / ratio) + 'px'
        }
      }
    },
    specDesc () {
      if (this.width && this.height) {
        return `图片尺寸为${this.width}x${this.height}，`
      } else if (this.width && this.minHeight) {
        return `图片宽度为${this.width}px且高度至少为${this.minHeight}px，`
      } else {
        return '图片'
      }
    }
  },
  methods: {
    onUploadError () {
      this.$message.error('图片上传失败')
    },
    onUploadSuccess (res, file) {
      if (res.code === 200 && res.value.length > 0) {
        const url = '/upload/' + res.value[0].url
        this.$emit('input', url)
      } else {
        this.onUploadError()
      }
    },
    onUploadBefore (file) {
      const self = this
      const img = new Image()
      return new Promise((resolve, reject) => {
        img.onload = () => {
          self.imgWidth = this.width
          self.imgHeight = this.height
          let errMessage = ''
          if (!this.isAllowFileExt(file.type)) {
            errMessage = '图片只能是 jpg,png 格式'
            reject(new Error(errMessage))
          } else if (!this.isAllowSize(file.size)) {
            errMessage = `图片大小不能超过 ${this.limitSize}KB`
            reject(new Error(errMessage))
          } else if (this.width && this.height && (img.width !== this.width || img.height !== this.height)) {
            errMessage = `图片尺寸必须为 ${this.width}x${this.height}`
            reject(new Error(errMessage))
          } else if (this.width && img.width !== this.width) {
            errMessage = `图片宽度必须为 ${this.width}px`
            reject(new Error(errMessage))
          } else if (this.minHeight && img.height < this.minHeight) {
            errMessage = `图片高度至少为 ${this.minHeight}px`
            reject(new Error(errMessage))
          } else {
            resolve()
          }
          if (errMessage) {
            this.$message.error(errMessage)
          }
        }
        img.src = URL.createObjectURL(file)
      })
    },
    onRemoveImg () {
      this.$emit('input', '')
    },
    isAllowSize (fileSize) {
      return fileSize / 1024 <= this.limitSize
    },
    isAllowFileExt (fileType) {
      return this.limitExt.indexOf(fileType) !== -1
    }
  }
}
</script>
