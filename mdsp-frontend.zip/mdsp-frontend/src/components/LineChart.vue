<template>
<div class="linechart__container mt24">
  <slot></slot>
  <div class="line-chart" ref="chart"></div>
</div>
</template>

<script>
import Echarts from 'echarts/lib/echarts'
import 'echarts/lib/chart/line'
import 'echarts/lib/component/tooltip'
export default {
  props: {
    ind: Array,
    times: Array,
    data: Array,
    multiple: Boolean,
    hour: Boolean
  },
  data () {
    return {
      chart: null
    }
  },
  computed: {
    maxData () {
      return Math.max.apply(null, [...this.data[0], ...this.data[1]])
    }
  },
  methods: {
    getMax (idx) {
      return Math.max.apply(null, this.data[idx])
    },
    getUnit (type) {
      if (type === 'rate') {
        return '{value}%'
      } else {
        return null
      }
    },
    generateOptions () {
      var colors = ['rgba(81,148,235, 0.9)', 'rgba(238,85,143, 0.9)']
      const ind = [...this.ind]
      const data = [...this.data]
      return {
        color: colors,
        grid: {
          top: '38px',
          left: '85px',
          right: '85px',
          bottom: '80px'
        },
        tooltip: {
          backgroundColor: 'rgba(31,33,38,.8)',
          padding: 18,
          trigger: 'axis',
          axisPointer: {
            type: 'cross'
          },
          textStyle: {
            color: 'rgba(255,255,255,.7)',
            fontSize: 14
          },
          extraCssText: 'width: 240px;line-height: 36px',
          formatter: (obj) => {
            const [data1, data2] = obj
            let [value1, value2] = [data1.data, data2.data]
            if (ind[0].type === 'rate') {
              value1 += '%'
            }
            if (ind[1].type === 'rate') {
              value2 += '%'
            }
            return `${data1.axisValue}<br><span class="tooltip-point" style="background-color:${data1.color};"></span>${ind[0].name}：${value1}<br><span class="tooltip-point" style="background-color:${data2.color};"></span>${ind[1].name}：${value2}`
          }
        },
        toolbox: {
          feature: {
            dataView: {
              show: true,
              readOnly: false
            },
            restore: {
              show: true
            },
            saveAsImage: {
              show: true
            }
          }
        },
        xAxis: [{
          type: 'category',
          axisLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          axisLabel: {
            fontSize: 14,
            margin: 30
          },
          data: this.times
        }],
        yAxis: [{
          type: 'value',
          position: 'left',
          offset: -10,
          min: 0,
          max: this.getMax(0),
          splitLine: {
            lineStyle: {
              color: '#000',
              type: 'dashed',
              width: 2,
              opacity: 0.1
            }
          },
          axisLabel: {
            fontSize: 14,
            margin: 20,
            formatter: this.getUnit(this.ind[0].type)
          },
          axisLine: {
            show: false
          },
          axisTick: {
            show: false
          }
        },
        {
          type: 'value',
          position: 'right',
          min: 0,
          max: this.getMax(1),
          splitLine: {
            lineStyle: {
              color: '#000',
              type: 'dashed',
              width: 2,
              opacity: 0.1
            }
          },
          axisLabel: {
            fontSize: 14,
            margin: 20,
            formatter: this.getUnit(this.ind[1].type)
          },
          axisLine: {
            show: false
          },
          axisTick: {
            show: false
          }
        }],
        series: [{
          name: ind[0].name,
          type: 'line',
          smooth: true,
          showSymbol: false,
          yAxisIndex: 0,
          lineStyle: {
            width: 6,
            shadowColor: 'rgba(0, 0, 0, 0.08)',
            shadowBlur: 10
          },
          data: data[0]
        },
        {
          name: ind[1].name,
          type: 'line',
          smooth: true,
          showSymbol: false,
          yAxisIndex: 1,
          lineStyle: {
            width: 6,
            shadowColor: 'rgba(0, 0, 0, 0.08)',
            shadowBlur: 10
          },
          data: data[1]
        }]
      }
    }
  },
  watch: {
    data () {
      this.chart.setOption(this.generateOptions())
    }
  },
  mounted () {
    this.chart = Echarts.init(this.$refs.chart)
    this.chart.setOption(this.generateOptions())
  }
}
</script>

<style lang="scss">
.line-chart {
  padding: 0 24px;
  // height: 528px;
  height: 400px;
  border: 1px solid gray(.08);
  border-radius: 4px;
}
.tooltip-point {
  display: inline-block;
  margin-right: 5px;
  border-radius: 10px;
  width: 10px;
  height: 10px;
}
</style>
