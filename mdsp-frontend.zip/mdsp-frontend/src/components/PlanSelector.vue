<template lang="html">
  <el-select v-model="planId">
    <el-option v-for="plan in planList" :key="plan.id" :label="plan.name" :value="plan.id"></el-option>
  </el-select>
</template>

<script>
export default {
  props: {
    planId: Number
  },
  data () {
    return {
      planList: []
    }
  },
  methods: {
    fetchPlanList () {

    }
  }
}
</script>

<style lang="css">
</style>
