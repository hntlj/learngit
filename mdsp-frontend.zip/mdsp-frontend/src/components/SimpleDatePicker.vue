<template>
  <div class="simpledatepicker__container">
    <el-select v-model="date">
      <el-option v-for="opt in options" :key="opt.label" :value="opt.value.join(',')" :label="opt.label" />
    </el-select>
  </div>
</template>

<script>
import utils from '@/utils'
const today = utils.today()
const yesterday = today - 86400000
const lastWeek = today - 86400000 * 6
const lastMonth = today - 86400000 * 29
export default {
  props: {
    value: Array
  },
  data () {
    return {
      options: [
        { label: '过去30天', value: [lastMonth, today].map(v => utils.formatDate(v)) },
        { label: '过去7天', value: [lastWeek, today].map(v => utils.formatDate(v)) },
        { label: '昨天', value: [yesterday, yesterday].map(v => utils.formatDate(v)) },
        { label: '今天', value: [today, today].map(v => utils.formatDate(v)) }
      ],
      date: this.value.join(',')
    }
  },
  watch: {
    date (value) {
      if (value) {
        this.$emit('input', value.split(','))
      }
    }
  }
}
</script>

<style lang="css">
</style>
