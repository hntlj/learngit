<template>
  <div class="dynamic-package d-p">
    <div class="d-p-line">
      <span>插入动态词包：</span>
      <span class="d-p-tips">
        <el-popover
          placement="top-start"
          width="100"
          trigger="hover">
          <div class="popoverRule">动态词包根据用户特征动态将默认词调整为替换词</div>
          <i class="icon-question" slot="reference"></i>
        </el-popover>
      </span>
      <span class="d-p-line-li" v-for="(it, idx) in dynamicList.slice(0, 3)" :key="idx" @click="(e) => {clickDynamicPkg(it)}">+{{it.name}}</span>
      <span class="d-p-line-more" @click="showMore">更多</span>
    </div>
    <el-dialog title="动态词包列表" :visible.sync="showListDialog">
      <div class="home-card__main">
        <el-table class="table-border" :data="dynamicList" >
          <el-table-column header-align="center" align="center" v-for="col in tableColumn" :key="col.prop"
            :prop="col.prop" :sortable="col.sortable"
            :label="col.label">
            <template slot-scope="scope">
              <span v-if="col.prop === 'name'" v-html="col.formatter(scope.row)"></span>
              <div class="textOverflow" v-else>{{ col.formatter ? col.formatter(scope.row) : scope.row[col.prop] }}</div>
            </template>
          </el-table-column>
          <el-table-column width="200px" align="center" label="操作">
            <template slot-scope="scope">
              <el-button @click="onShowDetails(scope.row, $event)" type="text">查看</el-button>
              <el-button @click="onInsert(scope.row, $event)" type="text">插入</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="home-card__footer">
        <el-pagination class="pull-right"
          v-if="dynamicListTotal > defaultPageSize"
          background
          :page-size="PAGE_SIZE"
          :page-sizes="PAGE_SIZES"
          :current-page="pageNumber"
          :total="dynamicListTotal"
          @size-change="onSizeChange"
          @current-change="onPageChanged"
          layout="total, sizes, prev, pager, next, jumper">
        </el-pagination>
      </div>
      <div slot="footer">
        <el-button @click="showListDialog = false">确定</el-button>
      </div>
    </el-dialog>
    <el-dialog title="查看词包" :visible.sync="showDetailsDialog" >
      <ul class="dialog-list" v-if="detailsDialog">
        <li class="dialog-list-item"><p class="label">词包名称</p><p class="text">{{detailsDialog.name}}</p></li>
        <li class="dialog-list-item"><p class="label">默认词</p><p class="text">{{detailsDialog.defaultKeyword}}</p></li>
        <li class="dialog-list-item"><p class="label">替换词</p><p class="text" v-html="detailsDialog.keywords.join('<br>')"></p></li>
        <li class="dialog-list-item"><p class="label">替换词数量</p><p class="text" v-text="detailsDialog.keywords.length"></p></li>
      </ul>
      <div slot="footer">
        <el-button @click="showDetailsDialog = false">确定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
// import utils from '@/utils'
import { getDynamicList } from '@/api'
import { PAGE_SIZE, PAGE_SIZES } from '@/enums'
import Bus from '@/utils/bus'
export default {
  props: {
    autoGet: {
      type: Boolean,
      default: true
    }
  },
  data () {
    return {
      dynamicList: [],
      dynamicListTotal: 0,
      showListDialog: false,
      pageNumber: 1,
      pageSize: 10,

      showDetailsDialog: false,
      detailsDialog: null,

      tableColumn: [
        { prop: 'id', label: '词包id', formatter: row => row.id },
        { prop: 'name', label: '词包名称', formatter: row => row.name },
        { prop: 'defaultKeyword', label: '默认词', formatter: row => row.defaultKeyword },
        { prop: 'keywords', label: '替换词', formatter: row => (row.keywords || []).join('，') }
      ],
      page: 1,
      PAGE_SIZE,
      PAGE_SIZES,
      defaultPageSize: PAGE_SIZE
    }
  },
  methods: {
    clickDynamicPkg (val) {
      this.$emit('setDynamicPkg', val)
    },
    fetchDynamicList (first) {
      getDynamicList({ name: '', pageNumber: this.pageNumber, pageSize: this.pageSize }).then(res => {
        if (res.code === 200) {
          this.fatData(res.value)
          first && Bus.$emit('fetchDynamicList', res.value)
        }
      })
    },
    onInsert (val) {
      this.$emit('setDynamicPkg', val)
    },
    showMore () {
      this.showListDialog = true
    },
    onShowDetails (val) {
      this.showDetailsDialog = true
      this.detailsDialog = val
    },
    onSizeChange (currSize) {
      this.pageSize = currSize
      this.fetchDynamicList()
    },
    onPageChanged (currPage) {
      this.pageNumber = currPage
      this.fetchDynamicList()
    },
    fatData (val) {
      const list = JSON.parse(JSON.stringify(val.data || []))
      this.dynamicList = list.map(it => {
        let maxLen = 0;
        // 获取最长词的长度
        (it.keywords || []).map(it2 => {
          if (it2.length > maxLen) {
            maxLen = it2.length
          }
        })
        it.maxLen = maxLen
        it.diffLen = maxLen - it.name.length
        if (it.name === '日期') {
          it.keywords = [`系统时间如：${it.keywords[0]}`]
        }
        return it
      })
      this.dynamicListTotal = val.total || 0
    }
  },
  created () {
    if (this.autoGet) {
      this.fetchDynamicList(true)
    } else {
      Bus.$on('fetchDynamicList', (val) => {
        this.fatData(val)
      })
    }
  },
  watch: {
  }
}
</script>
<style lang="scss">
.d-p {
  &-line-li, &-line-more {
    color: #3A75FF;
    margin-left: 10px;
    cursor: pointer;
  }
  &-line-more {margin-left: 20px;}
}
.dialog-list {
  border: 1px solid #f3f3f3;
  border-bottom: 0;
}
.dialog-list-item {
  display: flex;
  padding: 12px 0;
  border-bottom: 1px solid #f3f3f3;
  text-align: center;
  font-size: 14px;
  line-height: 21px;
  overflow: hidden;
  justify-content: center;
  align-items: center;

  .label {
    width: 120px;
    flex-shrink: 0;
  }
  .text {
    width: 100%;
    flex-grow: 1;
  }
}

.textOverflow {
  width: 100%;
  overflow: hidden;
  white-space:nowrap;
  text-overflow:ellipsis;
}
.el-table td {
  padding: 6px 0;
}
</style>
