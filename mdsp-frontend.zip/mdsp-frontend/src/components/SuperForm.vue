<template>
  <el-form ref="form" v-loading="loading" :inline="inline" :model="formData" :label-width="labelWidth" :label-position="labelPosition" class="app-form" @submit="$emit('submit')" :rules="rules">
    <el-form-item :label="item.name" v-if="item.type !== 'hidden'" :prop="item.key" v-for="item in formList" :key="item.key" :style="`width:${item.width || width}`">
      <span v-if="item.type === 'format'">{{ formData[item.key] }}</span>
      <el-input v-else-if="item.type === 'text' || item.type === 'textarea'"
        v-model="formData[item.key]"
        :type="item.type"
        :placeholder="item.placeholder">
      </el-input>
      <el-date-picker v-else-if="item.type === 'date'"
        v-model="formData[item.key]"
        type="date"
        :placeholder="item.placeholder"
        :picker-options="pickerOptions">
      </el-date-picker>
      <el-date-picker v-else-if="item.type === 'daterange'"
        v-model="formData[item.key]"
        type="daterange"
        :start-placeholder="item.startPlaceholder"
        :end-placeholder="item.endPlaceholder"
        :picker-options="pickerOptions"
        :default-time="['00:00:00', '23:59:59']">
      </el-date-picker>
      <el-select v-else-if="item.type === 'select'" v-model="formData[item.key]" :filterable="item.filterable">
        <el-option :label="`全部${item.label}`" value="" v-if="!item.withoutAll"></el-option>
        <el-option v-for="opt in item.options" v-if="opt.label" :label="opt.label" :value="opt.value" :key="opt.idx || opt.value"></el-option>
      </el-select>
      <el-upload v-else-if="item.type === 'image'"
        class="app-upload"
        :action="uploadConfig.action"
        :name="uploadConfig.fieldName"
        :show-file-list="false"
        :on-success="handleImageSuccess(item)">
        <img v-if="formData[item.key]" :src="formData[item.key]" class="image" />
        <i v-else class="el-icon-plus"></i>
      </el-upload>
      <template v-else-if="item.type === 'switch'">
        <el-switch
          v-model="formData[item.key]"
          :active-value="1"
          :inactive-value="0">
        </el-switch> <span>{{item.label}}</span>
      </template>
    </el-form-item>
    <slot />
  </el-form>
</template>

<script>
import utils from '@/utils'
export default {
  props: {
    labelWidth: {
      type: String,
      default: '200px'
    },
    labelPosition: {
      type: String,
      default: 'left'
    },
    width: {
      type: String,
      default: '192px'
    },
    formList: {
      type: Array,
      required: true
    },
    changeFromList: {
      type: Boolean,
      default: false
    },
    inline: {
      type: Boolean,
      default: true
    },
    loading: Boolean
  },
  data () {
    return {
      formData: null,
      pickerOptions: {
        shortcuts: [{
          text: '今天',
          onClick (picker) {
            picker.$emit('pick', [new Date(), new Date()])
          }
        }, {
          text: '昨天',
          onClick (picker) {
            const date = new Date()
            date.setTime(date.getTime() - 3600 * 1000 * 24)
            picker.$emit('pick', [date, date])
          }
        }, {
          text: '一周前',
          onClick (picker) {
            const date = new Date()
            date.setTime(date.getTime() - 3600 * 1000 * 24 * 6)
            picker.$emit('pick', [date, new Date()])
          }
        }, {
          text: '最近30天',
          onClick (picker) {
            const date = new Date()
            date.setTime(date.getTime() - 3600 * 1000 * 24 * 29)
            picker.$emit('pick', [date, new Date()])
          }
        }]
      },
      uploadConfig: {
        action: '/upload',
        fieldName: 'upload'
      }
    }
  },
  computed: {
    rules () {
      let rules = {}
      this.formList.forEach(item => {
        if (item.required) {
          let message = '请输入'
          if (item.type === 'select') {
            message = `请选择${item.label}`
          }
          message += item.name
          rules[item.key] = [{ required: true, message, trigger: 'blur' }]
        }
      })
      return rules
    }
  },
  methods: {
    updateRich (key, content) {
      this.formData[key] = content
    },
    handleImageSuccess (item) {
      return (res, file) => {
        if (item.type === 'picture-card' && this.formData[item.key]) {
          this.formData[item.key] = this.formData[item.key].concat([res.url])
        } else {
          this.formData[item.key] = res.url
        }
      }
    },
    handleImageRemove (item) {
      return (file, fileList) => {
        this.formData[item.key] = fileList.map(file => file.url)
      }
    },
    refreshFormData () {
      this.formData = this.formList.reduce((memo, item) => {
        memo[item.key] = typeof item.default === 'undefined' ? '' : item.default
        return memo
      }, {})
    }
  },
  created () {
    this.$on('refresh', this.refreshFormData.bind(this))
    this.refreshFormData()
  },
  watch: {
    formList: {
      handler: function (formList) {
        if (this.changeFromList) {
          this.formData = formList.reduce((memo, item) => {
            memo[item.key] = typeof item.default === 'undefined' ? '' : item.default
            return memo
          }, {})
        }
      },
      deep: true
    },
    formData: {
      handler: function (formData) {
        let _formData = {...formData}
        this.formList.map(item => {
          if (item.type === 'date') {
            _formData[item.key] = utils.formatDate(formData[item.key])
          } else if (item.type === 'daterange') {
            let startTime = ''
            let endTime = ''
            if (_formData[item.key]) {
              [startTime, endTime] = _formData[item.key]
              startTime = utils.formatDate(startTime)
              endTime = utils.formatDate(endTime)
              _formData[`start${item.key}`] = startTime
              _formData[`end${item.key}`] = endTime
              delete _formData[item.key]
            } else {
              _formData['startTime'] = ''
              _formData['endTime'] = ''
            }
          }
        })
        this.$emit('input', _formData)
      },
      deep: true
    }
  }
}
</script>
