<template>
  <el-aside class="home-aside">
    <el-menu class="home-aside__menu inset-shadow" :default-active="active" @select="selectMenu" router>
      <el-menu-item :key="menu.name" :index="`/${module}/${menu.name}`" v-for="menu in navList">
        <template slot="title">
          <i :class="`menu-icon-${menu.icon || menu.name.toLowerCase()}`"></i>
          <span>{{menu.title}}</span>
        </template>
      </el-menu-item>
    </el-menu>
  </el-aside>
</template>

<script>
export default {
  props: {
    module: String,
    navList: {
      type: Array,
      required: true
    }
  },
  computed: {
    active () {
      let act = this.$route.path
      this.navList.forEach(menu => {
        let menuPath = `/${this.module}/${menu.name}`
        if (act.indexOf(menuPath) > -1) {
          act = menuPath
        }
      })
      return act
    }
  },
  methods: {
    selectMenu (index) {
      this.$router.push(index)
    }
  }
}
</script>
