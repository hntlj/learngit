<template>
  <el-dialog :title="confirmationTitle" :visible.sync="myDialogVisible" width="600px">
    <el-form label-width="220px">
      <el-form-item v-for="(item, key) in confirmationInfo"
        :label="item.label" :key="key">{{ item.value }}
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="onClose">取消</el-button>
      <el-button type="primary" @click="onConfirm">确认</el-button>
    </div>
  </el-dialog>
</template>
<script>
export default {
  props: {
    confirmationTitle: {
      type: String,
      default () {
        return ''
      }
    },
    confirmationDialogVisible: {
      type: Boolean,
      default () {
        return false
      }
    },
    confirmationInfo: {
      type: Array,
      default () {
        return []
      }
    }
  },
  data () {
    return {
      myDialogVisible: this.confirmationDialogVisible
    }
  },
  methods: {
    onClose () {
      this.$emit('close')
    },
    onConfirm () {
      this.$emit('confirmHandle')
      this.$emit('close')
    }
  },
  watch: {
    confirmationDialogVisible (val) {
      this.myDialogVisible = val
    },
    myDialogVisible (val) {
      if (!val && this.confirmationDialogVisible) {
        this.$emit('close')
      }
    }
  }
}
</script>
