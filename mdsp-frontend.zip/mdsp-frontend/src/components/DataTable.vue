<template lang="html">
  <div class="datatable__container">

  </div>
</template>

<script>
export default {
}
</script>

<style lang="css">
</style>
