<template lang="html">
  <div class="el-time-grid">
    <div class="el-time-grid__header">
      <span v-for="time in timeRange" :key="time.value">{{ time.title }}</span>
    </div>
    <div class="el-time-grid__main">
      <div class="el-time-grid__row" v-for="(day, idx) in rows" :key="idx">
        <span class="head disabled">{{ day }}</span>
        <span v-for="(_,h) in hour" :key="h"
          :data-value="idx * hour.length + h" @mousedown="handleSelect" @mouseover="handleMouseover"
          :class="{active: selectHour[idx * hour.length + h] === 1, disabled: readOnly}"></span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'el-time-grid',
  props: {
    value: String,
    readOnly: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      start: 0,
      end: 25,
      pressed: false,
      turnOn: true,
      rows: ['一', '二', '三', '四', '五', '六', '日'],
      hour: new Array(24).fill(null),
      selectHour: [],
      startPos: 0,
      endPos: 0
    }
  },
  computed: {
    timeRange () {
      var times = []
      if (this.start > this.end) {
        times = new Array(25).fill(null)
      } else {
        times = new Array(this.end - this.start).fill(null)
      }
      return times.map((o, i) => {
        const time = i > 9 ? i : '0' + i
        return {
          value: i,
          title: `${time}:00`
        }
      })
    },
    formatValue () {
      return this.toHex(this.selectHour)
    }
  },
  methods: {
    handleSelect (e) {
      if (this.readOnly) {
        return
      }
      this.pressed = true
      const { value } = e.target.dataset
      if (this.selectHour[value] === 0) {
        this.selectHour[value] = 1
        this.turnOn = true
      } else {
        this.selectHour[value] = 0
        this.turnOn = false
      }
      this.startPos = value
      this.selectHour = [...this.selectHour]
    },
    handleMouseover (e) {
      const { value } = e.target.dataset
      if (this.pressed && value) {
        this.endPos = value
        this.setArea()
      }
    },
    handleMouseup (e) {
      if (this.pressed) {
        this.pressed = false
      }
    },
    setArea () {
      if (this.endPos) {
        const { x: startX, y: startY } = this.value2XY(this.startPos)
        const { x: endX, y: endY } = this.value2XY(this.endPos)
        const minX = Math.min(startX, endX)
        const minY = Math.min(startY, endY)
        const maxX = Math.max(startX, endX)
        const maxY = Math.max(startY, endY)
        for (let y = minY; y <= maxY; y++) {
          for (let x = minX; x <= maxX; x++) {
            const value = this.xy2Value(x, y)
            this.selectHour[value] = +this.turnOn
          }
        }
        this.selectHour = [...this.selectHour]
      }
    },
    value2XY (value) {
      return {x: value % 24, y: parseInt(value / 24)}
    },
    xy2Value (x, y) {
      return y * 24 + x
    },
    toArray (value) {
      let hours = value.split('')
      let day = []
      let result = []
      while ((day = hours.splice(0, 6).join('')).length > 0) {
        result = result.concat(parseInt(day, 16).toString(2).padStart(24, 0).split('').map(v => +v).reverse())
      }
      return result
    },
    toHex (value) {
      const hours = [...value]
      let s = []
      let result = []
      while ((s = hours.splice(0, 24).reverse()).length > 0) {
        result.push(parseInt(s.join(''), 2).toString(16).padStart(6, 0))
      }
      return result.join('').toUpperCase()
    }
  },
  watch: {
    value (val, oldVal) {
      if (val !== oldVal) {
        this.selectHour = this.toArray(val)
      }
    },
    selectHour (value) {
      this.$emit('input', this.toHex(value))
    }
  },
  created () {
    this.selectHour = this.toArray(this.value || new Array(43).join('0'))
  },
  mounted () {
    !this.readOnly && document.addEventListener('mouseup', this.handleMouseup, false)
  },
  unmounted () {
    !this.readOnly && document.removeEventListener('mouseup', this.handleMouseup)
  }
}
</script>

<style lang="scss">
.el-time-grid {
  margin-top: 14px;
  border: 1px solid gray(.08);
  border-radius: 4px;
  font-size: 10px;
  -webkit-text-size-adjust: none;
  user-select: none;
  &__header {
    display: flex;
    padding: 0 48px;
    line-height: 30px;
    span {
      flex: 1;
      text-align: center;
    }
  }
  &__row {
    padding-right: 72px;
    display: flex;
    line-height: 30px;
    &:nth-child(odd) {
      background-color: #f3f3f3;
    }
    .head {
      margin-left: 24px;
      text-align: left;
      border-right: 2px dotted gray(.1);
    }
    span {
      text-align: center;
      flex: 1;
      border-right: 2px dotted transparent;
      &.active {
        background-color: rgba(87,155,241,.8) !important;
        border-color: transparent;
      }
      &:not(.disabled) {
        border-color: gray(.1);
        &:hover {
          background-color: rgba(87,155,241,.4);
          border-color: transparent;
        }
      }
    }
  }
}
</style>
