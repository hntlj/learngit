<template>
  <div class="el-tree-transfer">
    <div class="el-tree-transfer__header">
      <div class="el-tree-transfer__label">{{ label }}</div>
      <div class="el-tree-transfer__status">
        <span>已选择 <em>{{ checkedNum }}</em> 个</span>
        <a @click="handleClear">清空</a>
      </div>
    </div>
    <div class="el-tree-transfer__main">
      <div class="el-tree-transfer__list">
        <el-tree ref="tree" show-checkbox :data="dataList" :props="props"
          @check-change="handleCheckChanged"
          node-key="id"
          :default-checked-keys="defaultCheckedKeys"
          :render-after-expand="false"></el-tree>
      </div>
      <div class="el-tree-transfer__list selected-tree">
        <el-tree :data="checkedDataList" :props="props" empty-text="暂未选择" default-expand-all>
          <div class="custom-tree-node" slot-scope="{ node, data }">
            <span>{{ node.label }}</span>
            <span class="pull-right">
              <i class="el-icon-close" @click="(
              ) => handleRemove(node, data)"></i>
            </span>
          </div>
        </el-tree>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'el-tree-transfer',
  props: {
    label: String,
    dataList: Array,
    defaultCheckedKeys: Array,
    deepth: Number
  },
  data () {
    return {
      props: {
        label: 'label',
        children: 'children'
      },
      checkedDataList: [],
      value: [],
      checkedNum: 0
    }
  },
  methods: {
    getCheckedDataList () {
      const checkedKeys = this.$refs.tree.getCheckedKeys(true)
      const checkedDataList = []
      this.checkedNum = checkedKeys.length
      this.dataList.map(item => {
        const node = {
          id: item.id,
          label: item.label
        }
        if (item.children) {
          const _children = []
          item.children.map(child => {
            const childNode = {
              id: child.id,
              label: child.label,
              children: []
            }
            if (child.children) {
              childNode.children = child.children.filter(({id}) => ~checkedKeys.indexOf(id))
            }
            if (~checkedKeys.indexOf(child.id) || childNode.children.length > 0) {
              _children.push(childNode)
            }
          })
          node.children = _children
        }
        if (~checkedKeys.indexOf(node.id) || (node.children && node.children.length > 0)) {
          checkedDataList.push(node)
        }
      })
      return checkedDataList
    },
    handleCheckChanged () {
      this.checkedDataList = this.getCheckedDataList()
      if (this.deepth === 1) {
        this.value = this.checkedDataList.map(list => {
          return { id: list.id, label: list.label, value: list.id }
        })
      } else if (this.deepth === 2) {
        this.value = this.checkedDataList.reduce((c, a) => c.concat(a.children.map(child => {
          const idx = child.id.lastIndexOf('-') + 1
          return {id: child.id.substr(idx), value: child.label, treeId: child.id}
        })), [])
      } else if (this.deepth === 3) {
        this.value = this.checkedDataList.reduce((c, a) => c.concat(a.children.reduce((cc, aa) => cc.concat(aa.children.map(child => ({value: child.value}))), [])), [])
      }
    },
    handleClear () {
      this.$refs.tree.setCheckedKeys([])
      this.checkedDataList = []
    },
    handleRemove (node, data) {
      let checkedKeys = this.$refs.tree.getCheckedKeys(true)
      const { id, children } = data
      if (children) {
        checkedKeys = checkedKeys.filter(key => !key.startsWith(id))
      } else {
        checkedKeys = checkedKeys.filter(key => key !== id)
      }
      this.$refs.tree.setCheckedKeys(checkedKeys)
    }
  },
  watch: {
    value (value, oldValue) {
      if (value.join('') !== oldValue.join('')) {
        this.$emit('change', value)
      }
    },
    defaultCheckedKeys (checkedKeys) {
      if (checkedKeys && checkedKeys.length > 0) {
        this.$refs.tree.setCheckedKeys(checkedKeys)
      }
    }
  },
  mounted () {
    this.handleCheckChanged()
  }
}
</script>

<style lang="scss">
.el-tree-transfer {
  margin-top: 14px;
  border-radius: 4px;
  border: 1px solid #E6E6E6;
  padding: 18px;
  font-size: 14px;
  width: 640px;
  box-sizing: border-box;

  .el-icon-caret-right:before {
    content: "\E604" !important;
  }
  .el-tree-node:focus>.el-tree-node__content,.el-tree-node__content:hover {
    background-color: transparent
  }
  .custom-tree-node {
    flex: 1;
    .el-icon-close {
      cursor: pointer;
      font-size: 16px;
      color: gray(.4)
    }
  }
  .selected-tree {
    padding-left: 18px;
    .el-tree-node__content {
      cursor: default
    }
  }

  &__header {
    line-height: 19px;
    padding-bottom: 12px;
    border-bottom: 1px solid gray(.1);
    overflow: hidden;
  }
  &__main {
    padding-top: 14px;
    @include clearfix;
  }
  &__label {
    float: left;
    width: 50%;
  }
  &__status {
    float: left;
    width: 50%;
    a {
      float: right;
    }
  }
  &__list {
    float: left;
    box-sizing: border-box;
    height: 270px;
    width: 50%;
    overflow: auto;
  }
}
</style>
