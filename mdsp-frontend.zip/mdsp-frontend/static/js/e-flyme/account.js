$('.j-register').on('click', function() {
  var host = location.protocol + '//' + location.host;
  location.href = 'https://i.flyme.cn/register?service=dsp&appuri=' + 
    encodeURIComponent(host + '/login') +
    '&useruri=' +
    encodeURIComponent(host + (location.host.indexOf('ea') == 0 ? '/views/agent_index.html' : '/views/index.html'));
});