'use strict';

$(function () {
  var header = $('#header');
  $('#fullpage').fullpage({
    verticalCentered: false,
    anchors: ['head', 'storeapp', 'system', 'music', 'bottom'],
    navigationTooltips: ['', '应用广告', '开屏广告', '轮播图', '信息流广告', ''],
    navigation: true,
    scrollBar: true,
    fitToSection: false,
    bigSectionsDestination: 'top',
    onLeave: function onLeave(index, nextIndex, direction) {
      index === 1 && header.stop().animate({
        top: '-90px'
      }, 'fast');
      index === 2 && direction === 'up' && header.stop().animate({
        top: '0px'
      }, 'fast');
    }
  });
});