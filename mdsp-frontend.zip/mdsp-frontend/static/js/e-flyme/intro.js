'use strict';

$(function () {
  var header = $('#header');
  $('#fullpage').fullpage({
    verticalCentered: false,
    anchors: ['head', 'flyme', 'system', 'app', 'music', 'news', 'flow', 'bottom'],
    navigationTooltips: ['', 'Flyme系统', '系统级应用', '应用商店', '音乐', '资讯', '第三方流量', ''],
    navigation: true,
    scrollBar: true,
    fitToSection: false,
    bigSectionsDestination: 'top',
    onLeave: function onLeave(index, nextIndex, direction) {
      index === 1 && header.stop().animate({
        top: '-90px'
      }, 'fast');
      index === 2 && direction === 'up' && header.stop().animate({
        top: '0px'
      }, 'fast');
    }
  });
});