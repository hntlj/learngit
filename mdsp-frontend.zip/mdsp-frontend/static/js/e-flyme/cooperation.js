/*
 * @Date: 2019-09-29 15:07:44
 * @LastEditors: PoloHuang
 * @LastEditTime: 2020-05-13 12:45:21
 */
'use strict'

$(function () {
  const POST_URL = window.location.href.split('views')[0]
  var $navs = $('#agpage .ag-inner-top span')
  var $contents = $('#agpage .ag-list-content')
  $navs.on('click', function () {
    $navs.removeClass('active')
    $(this).addClass('active')
    $contents.removeClass('active')
    $contents.eq($(this).index()).addClass('active')
  })

  $.ajax({
    type: 'GET',
    url: `${POST_URL}console/mdsp/ad/help/popularize/list`,
    data: {
      name: ''
    },
    success: function (res) {
      if (res.code === 200) {
        let list = res.value.data
        list.forEach(element => {
          // eslint-disable-next-line no-undef
          $('.ag-list-content').append(`<div class="ag-inner-list aglist">
                <p class="list-img aglist"><img src=${element.agentLogoUrl}></p>
                <dl class="list-detail aglist">
                  <dt>${element.agentName}</dt>
                  <dd>${element.contactName}</dd>
                  <dd>${element.agentPhone}</dd>
                  <dd>${element.agentEmail}</dd>
                </dl>
              </div>`)
        })
      }
    }
  })

  $.ajax({
    type: 'GET',
    url: `${POST_URL}console/mdsp/ad/help/popularize/title/get`,
    success: function (res) {
      if (res.code === 200) {
        $('.ad-title').text(res.value)
      }
    }
  })
})
