import Vue from 'vue'
import App from '@/App.vue'
import { Track, CallAndroid, GetAndroidVal } from '@/native/index'

import store from '@/store/index'

if (!document.querySelector('html').getAttribute('style')) {
  document.querySelector('html')
          .setAttribute('style', 'font-size:' + (window.innerWidth || 360) / 10 + 'px;')
}
Vue.config.productionTip = false
export default new Vue({
  el: '#app',
  store,
  render: h => h(App)
})

document.querySelector('title').innerText = window.site.pageTitle

// 是在终端打开，才可以
if (GetAndroidVal('addListener')) {
  Track('exposure_page')
}
