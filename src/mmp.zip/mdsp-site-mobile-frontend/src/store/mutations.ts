import { RootStateTypes } from './types'
import { MutationTree } from 'vuex'

const mutations: MutationTree<RootStateTypes> = {
  setAppInfo (state: RootStateTypes, appInfo: any) {
    state.packageName = appInfo.packageName
    state.appId = appInfo.id
    state.appVersion = appInfo.versionCode
  },
  setBtnStatus (state: RootStateTypes, btnStatus) {
    state.btnStatus = btnStatus
  },
  setBtnInstallstatus (state: RootStateTypes, btnInstallstatus) {
    state.btnInstallstatus = btnInstallstatus
  },
  setBtnText (state: RootStateTypes, btnText) {
    state.btnText = btnText
  }
}

export default mutations
