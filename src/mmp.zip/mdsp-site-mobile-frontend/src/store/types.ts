export interface RootStateTypes {
  btnStatus: string | number,
  btnInstallstatus: string,
  btnText: string | number,
  packageName: string,
  appId: string | number,
  appVersion: string | number
}
