import state from './state'

const getter: any = {
  btnStatus: state => state.btnStatus,
  btnInstallstatus: state => state.btnInstallstatus,
  btnText: state => state.btnText,
  packageName: state => state.packageName,
  appId: state => state.appId,
  appVersion: state => state.appVersion
}

export default getter
