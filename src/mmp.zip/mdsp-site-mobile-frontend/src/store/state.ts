import { RootStateTypes } from './types'

const state: RootStateTypes = {
  btnStatus: '',
  btnInstallstatus: '',
  btnText: '',
  packageName: '',
  appId: '',
  appVersion: ''
}

export default state
