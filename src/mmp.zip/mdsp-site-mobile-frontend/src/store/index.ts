import Vue from 'vue'
import Vuex, { Store } from 'vuex'
import state from './state'
import getters from './getters'
import mutations from './mutations'

Vue.use(Vuex)

const store: Store<any> = new Vuex.Store({
  state,
  getters,
  mutations
})

export default store
