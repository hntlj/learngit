<template>
  <div class="comp-content comp-phone btn btn_size_large" @click="trackCall">
    <a v-if="compData.content.phone" :href="`tel:${compData.content.phone}`">
      <span class="iconfont iconfont-phone"></span> {{ compData.content.buttonText }}
    </a>
    <template v-else>
      <span class="iconfont iconfont-phone"></span> {{ compData.content.buttonText }}
    </template>
  </div>
</template>

<script lang="ts">
import { Vue, Component, Prop } from 'vue-property-decorator'
import { Track } from '@/native/index'

@Component
export default class OPhone extends Vue {
  @Prop(Object) compData: any
  trackCall () {
    Track('call')
  }
}
</script>
<style lang="scss"></style>
