<template>
  <div class="comp-content comp-store">
    <div class="store-wrap">
      <div class="store-app">
        <img class="store-app__icon" :class="{'icon-border': !packageInfo.icon }" :src="packageInfo.icon" alt="">
        <span class="store-app__name">{{packageInfo.name}}</span>
      </div>
      <div class="store-btn"
        ref="download"
        :style="compData.attr.style">{{btnText || compData.content.buttonText}}
        </div>
    </div>
  </div>
</template>

<script lang="ts">
import { Vue, Component, Prop } from 'vue-property-decorator'
import DownloadActMixin from '@/mixins/downloadAct.ts'

@Component({
  name: 'StoreApp',
  mixins: [DownloadActMixin],
  mounted() {
    const ele = this.$refs.download
    ele.setAttribute('data-deeplink', this.compData.content.deeplink)
    this.init({
      btns: ele
    })
  }
})
export default class Store extends Vue {
  @Prop(Object) compData: any
  public packageInfo: any = window.site.appInfo
}
</script>
<style lang="scss">
.store-wrap {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 5px 20px;
  background: #fff;
  .store-app {
    height: 50px;
    display: flex;
    align-items: center;
    .store-app__icon {
      width: 50px;
      height: 50px;
      margin-right: 10px;
    }
    .icon-border {
      border: 1px solid $backGray;
    }
  }
  .store-btn {
    height: 30px;
    line-height: 30px;
    padding: 0 20px;
    border-radius: 3px;
  }
}
</style>
