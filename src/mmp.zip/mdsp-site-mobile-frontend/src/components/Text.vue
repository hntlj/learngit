<template>
  <div class="comp-content comp-text">
    <a v-if="compData.content.link" :href="compData.content.link">
      {{compData.content.text}}
    </a>
    <template v-else>{{compData.content.text}}</template>
  </div>
</template>

<script lang="ts">
import { Vue, Component, Prop } from 'vue-property-decorator'

@Component
export default class OText extends Vue {
  @Prop(Object) compData: any
}
</script>
<style lang="scss">
.comp-text {
  min-height: 1.5em;
  line-height: 1.5em;
  padding: 10px;
}
</style>
