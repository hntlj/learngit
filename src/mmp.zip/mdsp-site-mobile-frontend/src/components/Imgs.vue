<template>
  <div class="comp-content comp-imgs" ref="download" data-canceldownload="false">
    <img class="comp-imgs__img"
      v-for="(img, idx) in compData.content.urls"
      :src="img.src"
      @click="goto(img)"
      :ref="refName(idx)"
      :key="idx">
  </div>
</template>

<script lang="ts">
import { Vue, Component, Prop } from 'vue-property-decorator'
import DownloadActMixin from '@/mixins/downloadAct.ts'

@Component({
  mixins: [DownloadActMixin],
  mounted() {
    if (this.compData.content.download) {
      this.compData.content.urls.forEach((img, idx) => {
        const ele = this.$refs[`download${idx}`][0]
        ele.setAttribute('data-deeplink', img.deeplink)
        this.init({
          btns: ele
        })
      })
    }
  }
})
export default class Imgs extends Vue {
  @Prop(Object) compData: any
  goto (imgInfo) {
    if (imgInfo.link) {
      window.location.href = imgInfo.link
    } else if (imgInfo.deeplink) {
      // Native.openDeeplink(imgInfo.deeplink)
    }
  }
  refName (idx) {
    return `download${idx}`
  }
}
</script>
<style lang="scss">
.comp-imgs {
  .comp-imgs__img {
    display: block;
    width: 100%;
  }
}
</style>
