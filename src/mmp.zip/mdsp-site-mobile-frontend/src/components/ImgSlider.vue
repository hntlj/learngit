<template>
  <div class="comp-content comp-imgs-slider" ref="download" data-canceldownload="false">
    <slider ref="slider"
      :options="sliderOptions"
      v-if="compData.content.urls.length > 0">
      <slideritem v-for="(item, idx) in compData.content.urls" :key="idx">
        <img :src="item.src" @click="goto(item)" :ref="refName(idx)" alt="">
      </slideritem>
      <div slot="loading">loading...</div>
    </slider>
  </div>
</template>

<script lang="ts">
import { Vue, Component, Prop } from 'vue-property-decorator'
import { slider, slideritem } from 'vue-concise-slider'
import DownloadActMixin from '@/mixins/downloadAct.ts'

@Component({
  name: 'SiteImgSlider',
  mixins: [DownloadActMixin],
  mounted() {
    if (this.compData.content.download) {
      this.compData.content.urls.forEach((item, idx) => {
        const ele = this.$refs[`download${idx}`][0]
        ele.setAttribute('data-deeplink', item.deeplink)
        this.init({
          btns: ele
        })
      })
    }
  },
  components: {
    slider, slideritem
  }
})
export default class ImgSlider extends Vue {
  @Prop(Object) compData: any
  showSlider: boolean = true
  sliderOptions: any = {
    autoplay: Number(this.compData.content.slideSpeed)*1000,
    loop: true
  }
  goto (imgInfo) {
    if (imgInfo.link) {
      window.location.href = imgInfo.link
    } else if (imgInfo.deeplink) {
      // Native.openDeeplink(imgInfo.deeplink)
    }
  }
  refName (idx) {
    return `download${idx}`
  }
}
</script>
<style lang="scss">
.comp-imgs-slider {
  img {
    width: 100%;
  }
}
</style>