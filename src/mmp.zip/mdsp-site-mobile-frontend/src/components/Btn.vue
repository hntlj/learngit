<template>
  <div class="comp-content comp-btn btn btn_size_large" @click="jumpToTop">
    <a v-if="compData.content.link" :href="compData.content.link">
      {{ compData.content.buttonText }}
    </a>
    <template v-else>{{compData.content.buttonText}}</template>
  </div>
</template>

<script lang="ts">
import { Vue, Component, Prop, Watch } from 'vue-property-decorator'

@Component
export default class Btn extends Vue {
  @Prop(Object) compData: any
  jumpToTop () {
    if (this.compData.content.jumpType === 'pageTop') {
      let timer = setInterval(() => {
        let oTop = document.body.scrollTop || document.documentElement.scrollTop
        if (oTop > 0) {
          window.scrollTo(0, oTop - 100)
        } else {
          clearInterval(timer)
        }
      }, 30)
    }
  }
}
</script>
<style lang="scss">

</style>
