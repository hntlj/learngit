<template>
  <div class="comp-content comp-consult btn btn_size_large" @click="trackConsult">
    <a v-if="compData.content.link" :href="compData.content.link">
      <span class="iconfont iconfont-consult"></span> {{ compData.content.buttonText }}
    </a>
    <template v-else>
      <span class="iconfont iconfont-consult"></span> {{ compData.content.buttonText }}
    </template>
  </div>
</template>

<script lang="ts">
import { Vue, Component, Prop } from 'vue-property-decorator'
import { Track } from '@/native/index'

@Component
export default class Consult extends Vue {
  @Prop(Object) compData: any
  trackConsult () {
    Track('consult')
  }
}
</script>
<style lang="scss"></style>
