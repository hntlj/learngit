<template>
  <div class="comp-content comp-mdse-window">
    <div class="mdse"
      :class="{'mdse-style2': compData.content.mdseStyle==='column'}"
      v-for="mdse in compData.content.urls"
      :key="mdse.src">
      <div class="mdse-img">
        <a v-if="mdse.link" :href="mdse.link">
          <img :src="mdse.src">
        </a>
        <img v-else :src="mdse.src">
      </div>
      <div class="mdse-bottom">
        <div class="mdse-bottom__desc mdse-bottom__item">{{mdse.describe}}</div>
        <div class="mdse-bottom__price mdse-bottom__item" v-show="mdse.price">
          <span>¥</span><span>{{mdse.price}}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { Vue, Component, Prop } from 'vue-property-decorator'

@Component
export default class MdseWindow extends Vue {
  @Prop(Object) compData: any
}
</script>
<style lang="scss">
.comp-mdse-window {
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  justify-content: space-between;
  padding: 3px;
  min-height: 100px;
  .mdse {
    width: 49%;
    .mdse-img {
      img {
        width: 100%;
      }
    }
    .mdse-bottom {
      display: flex;
      justify-content: space-between;
      padding: 5px;
      .mdse-bottom__item {
        line-height: 25px;
        min-height: 25px;
      }
      .mdse-bottom__desc {
        width: 60%;
        @include ellipsis
      }
      .mdse-bottom__price {
        width: 40%;
        text-align: right;
        @include ellipsis
      }
    }
  }
  .mdse-style2 {
    .mdse-bottom {
      display: block;
      .mdse-bottom__item {
        width: 100%;
        text-align: left;
        @include ellipsis
      }
    }
  }
}
</style>