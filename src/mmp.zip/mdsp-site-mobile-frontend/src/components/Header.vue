<template>
  <div class="comp-content comp-header"></div>
</template>

<script lang="ts">
import { Vue, Component } from 'vue-property-decorator'

@Component
export default class OHeader extends Vue {
}
</script>
<style lang="scss"></style>
