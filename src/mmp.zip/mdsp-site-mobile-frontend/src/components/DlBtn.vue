<template>
  <div class="comp-content comp-dl-btn btn btn_size_large"
    ref="download">
    {{ btnText || compData.content.buttonText }}
  </div>
</template>

<script lang="ts">
import { Vue, Component, Prop } from 'vue-property-decorator'
import DownloadActMixin from '@/mixins/downloadAct.ts'

@Component({
  mixins: [DownloadActMixin],
  mounted() {
    const ele = this.$refs.download
    ele.setAttribute('data-deeplink', this.compData.content.deeplink)
    this.init({
      btns: ele
    })
  }
})
export default class DlBtn extends Vue {
  @Prop(Object) compData: any
}
</script>
<style lang="scss"></style>
