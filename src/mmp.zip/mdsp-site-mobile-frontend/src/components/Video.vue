<template>
  <div class="comp-content comp-video">
    <div class="video-wrap"
      v-if="compData.content.videoUrl && showVideo">
      <video class="video-player"
        ref="video"
        preload="auto"
        muted="muted"
        tabindex="-1"
        controls
        name="media"
        :src="compData.content.videoUrl"
        :height="videoHeight">
      </video>
      <img class="video-cover-img"
        v-if="showCoverImg && compData.content.coverUrl"
        :src="compData.content.coverUrl"
        @click="onPlayVideo">
      <img class="play-img"
        v-if="showCoverImg && compData.content.coverUrl"
        @click="onPlayVideo"
        src="~assets/img/icon-play.png" alt="">
    </div>
  </div>
</template>

<script lang="ts">
import { Vue, Component, Prop } from 'vue-property-decorator'
import { deepCopy } from '@/utils/index.ts'

@Component
export default class OVideo extends Vue {
  @Prop(Object) compData: any
  public showVideo: boolean = true
  public showCoverImg: boolean = true
  get videoWidth () {
    return document.body.clientWidth
  }
  get videoHeight () {
    const width: number = document.body.clientWidth
    let paddingLeft: number = Number(this.compData.attr.module.paddingLeft)
    let paddingRight: number = Number(this.compData.attr.module.paddingRight)
    paddingLeft = paddingLeft > 0 ? paddingLeft : 0
    paddingRight = paddingRight > 0 ? paddingRight : 0
    return width / this.compData.content.videoAspectRatio
           - paddingLeft - paddingRight
  }
  onPlayVideo () {
    this.showVideo = false
    this.$nextTick(() => {
      this.showVideo = true
      this.$nextTick(() => {
        this.$refs.video['autoplay'] = true
        this.showCoverImg = false
      })
    })
  }
}
</script>
<style lang="scss">
.video-wrap {
  position: relative;
  overflow: hidden;
  .video-player {
    width: 100%;
  }
  .video-cover-img {
    width: 100%;
    height: 100%;
    position: absolute;
    left: 0;
    top: 0;
    z-index: 9;
  }
  .play-img {
    position: absolute;
    width: 50px;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    z-index: 9;
  }
}
</style>