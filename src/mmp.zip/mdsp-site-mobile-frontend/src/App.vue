<template>
  <div id="app" class="main" :style="AppStyle">
    <div class="main-page">
      <div class="comp-list">
        <div v-for="(compData, idx) in compsData"
          class="comp"
          :key="idx"
          :style="addUnitPx(compData.attr.module, !compData.attr.bottom.status &&
                  !(compData.attr.top && compData.attr.top.status))">
          <component
            v-if="!compData.attr.bottom.status &&
                  !(compData.attr.top && compData.attr.top.status)"
            :is="compData.type"
            :style="addUnitPx(compData.attr.style, filterStyleComps(compData.type))"
            :compData="compData">
          </component>
        </div>
      </div>
    </div>
    <div class="main-bottom" ref="appBottom">
      <div v-for="(compData, index) in compsData"
        class="comp"
        :key="index"
        :style="addUnitPx(compData.attr.module, compData.attr.bottom.status)">
        <component
          v-if="compData.attr.bottom.status"
          :is="compData.type"
          :style="addUnitPx(compData.attr.style, filterStyleComps(compData.type))"
          :compData="compData">
        </component>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { Vue, Component } from 'vue-property-decorator'
import { State, Action, Mutation } from 'vuex-class'
import { deepCopy } from '@/utils/index.ts'
import { STYLE_PX } from '@/enums/index.ts'
@Component({
  name: 'ComSorter',
  components: {
    'SiteImgs': () => import(/* webpackChunkName: "SiteImgs" */ '@/components/Imgs.vue'),
    'SiteImgSlider': () => import(/* webpackChunkName: "ImgSlider" */ '@/components/ImgSlider.vue'),
    'SiteText': () => import(/* webpackChunkName: "Text" */ '@/components/Text.vue'),
    'SiteMdseWindow': () => import(/* webpackChunkName: "MdseWindow" */ '@/components/MdseWindow.vue'),
    'SiteBtn': () => import(/* webpackChunkName: "Btn" */ '@/components/Btn.vue'),
    'SiteVideo': () => import(/* webpackChunkName: "Video" */ '@/components/Video.vue'),
    'SiteDlBtn': () => import(/* webpackChunkName: "DlBtn" */ '@/components/DlBtn.vue'),
    'SiteStore': () => import(/* webpackChunkName: "Store" */ '@/components/Store.vue'),
    'SiteFloatCard': () => import(/* webpackChunkName: "FloatCard" */ '@/components/FloatCard.vue'),
    'SiteConsult': () => import(/* webpackChunkName: "Consult" */ '@/components/Consult.vue'),
    'SitePhone': () => import(/* webpackChunkName: "Phone" */ '@/components/Phone.vue')
  }
})
export default class App extends Vue {
  @Mutation setAppInfo
  public compsData: Array<any> = window.site.page.elements
  created () {
    this.setAppInfo(window.site.appInfo)
  }
  get AppStyle () {
    let styleObj: any = {}
    let len: number = this.compsData.length
    for (let i: number = 0; i < len; i++) {
      if (this.compsData[i].type === 'SiteHeader') {
        styleObj = this.compsData[i]['attr']['style']
        break
      }
    }
    return styleObj
  }
  filterStyleComps (compName: string) {
    const compArr = ['SiteFloatCard', 'SiteStore']
    return !~compArr.indexOf(compName)
  }
  addUnitPx (obj: any, isShow: boolean = true) {
    if (!isShow) return ''
    let temp: any = deepCopy(obj, [])
    const deepCircle = (target: any): any => {
      for (let key in target) {
        if (typeof target[key] === 'object') {
          deepCircle(target[key])
        } else {
          if (STYLE_PX.indexOf(key) > -1 && target[key]) {
            target[key] = target[key].replace(/px/g, '') + 'px'
          }
        }
      }
      return target
    }
    return deepCircle(temp)
  }
}
</script>
<style src="@/assets/style/home.scss" lang="scss"></style>
