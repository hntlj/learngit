import businessFit from '@flyme/business-fit'
import { TRACK_ACTION } from '@/enums/index.ts'
import { getUrlParams } from '@/utils/index.ts'

export const Track = (action: string): any => {
  const urlParams: any = businessFit.util.getUrlParams()
  const lpTrackUrl: string | undefined = decodeURIComponent(urlParams.lpTrackUrl)
  const mapAction: any = new Map(TRACK_ACTION)
  const params = getUrlParams(lpTrackUrl)
  const getTrackUrl = (url: string, action: string): string => {
    return `${url}?lp=${params.lp}&p=${params.p}&action=${action}`
  }
  new Image().src = getTrackUrl(lpTrackUrl.split('?')[0], mapAction.get(action))
}

const callAndroidFn = (fnName: string, ...args: Array<any>) => {
  const androidFn = (fnName: string, ...args: Array<any>): any => {
    return businessFit[fnName].apply(businessFit, args)
  }
  const unSupportAndroidFn = (fnName: string, ...args: Array<any>): any => {
    return ''
  }

  return businessFit.addListener ? androidFn : unSupportAndroidFn
}
export const CallAndroid: any = callAndroidFn('init')

export const GetAndroidVal: any = (property: string): any => {
  return businessFit[property]
}

// 返回详细状态: 0－没有安装;1－已经安装最新版本;2－已经安装，但版本不是最新;3－正在安装。
