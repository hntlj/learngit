export const STYLE_PX: Array<string> = [
  'fontSize',
  'borderRadius', 'borderWidth',
  'paddingTop', 'paddingBottom', 'paddingLeft', 'paddingRight'
]

export const TRACK_ACTION: Array<any> = [
  ['exposure_page', 'EXPOSURE'],
  ['download', 'DOWNLOAD'],
  ['open', 'OPEN'],
  ['call', 'CALL'],
  ['consult', 'CONSULT']
]

export const APP_STATUS: any = {
  NONE: 0,
  LATEST: 1,
  PREVIOUS: 2,
  INSTALLING: 3
}
