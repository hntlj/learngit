interface SiteObj {
  [index: string]: any
}
const siteData: SiteObj = {
  appInfo: {
    packageName: 'com.qiyi.video',
    name: '爱奇艺',
    icon: 'http://i4.res.meizu.com/fileserver/app_icon/3169/a2bf4b895a4a4530940faac10856df72.png',
    versionCode: 81010,
    id: 120033,
    status: 0
  },
  id: 666,
  pageName: 'site name',
  pageTitle: 'page title',
  page: {
    elements: [
      {
        'type': 'SiteHeader',
        'content': {
          'pageTitle': '页面标题',
          'pageName': '站点名称'
        },
        'attr': {
          'top': {
            'status': true,
            'index': -1
          },
          'bottom': {
            'status': false,
            'index': -1
          },
          'style': {
            'backgroundColor': 'rgba(254, 243, 243, 1)',
            'backgroundImage': ''
          }
        },
        'code': 'SiteHeader1575010075452'
      },
      {
        'type': 'SiteImgs',
        'content': {
          'text': '',
          'urls': [
            {
              'src': 'http://mzdsp.meizu.com/upload/1575965572013mepMmkdR.png',
              'link': '',
              'deeplink': 'openapp.jdpingou://virtual?params={\'des\':\'m\',\'url\':\'https://wq.jd.com/webportal/event/26954?PTAG=17018.169.5&mpm_share=1&utm_source=iosapp&utm_medium=appshare&utm_campaign=t_335139774&utm_term=CopyURL&ad_od=share\',\'category\':\'jump\'}'
            },
            {
              'src': 'http://mzdsp.meizu.com/upload/15759655814048O3dWYiz.png',
              'link': '',
              'deeplink': 'openapp.jdpingou://virtual?params={\'des\':\'m\',\'url\':\'https://wq.jd.com/webportal/event/26954?PTAG=17018.169.5&mpm_share=1&utm_source=iosapp&utm_medium=appshare&utm_campaign=t_335139774&utm_term=CopyURL&ad_od=share\',\'category\':\'jump\'}'
            }
          ],
          'download': true
        },
        'attr': {
          'bottom': {
            'status': false,
            'index': -1
          },
          'module': {
            'paddingTop': '0',
            'paddingBottom': '0',
            'paddingLeft': '0',
            'paddingRight': '0'
          },
          'style': {}
        },
        'code': 'SiteImgs1575965564923'
      },
      {
        'type': 'SiteImgSlider',
        'content': {
          'slideSpeed': '3',
          'imgAspectRatio': '1.777778',
          'urls': [
            {
              'src': 'http://mzdsp.meizu.com/upload/1575968601956a4LmAeIA.png',
              'link': '',
              'deeplink': ''
            },
            {
              'src': 'http://mzdsp.meizu.com/upload/1575968618115dhEOU1Wd.png',
              'link': '',
              'deeplink': ''
            }
          ]
        },
        'attr': {
          'bottom': {
            'status': false,
            'index': -1
          },
          'module': {
            'paddingTop': '0',
            'paddingBottom': '0',
            'paddingLeft': '0',
            'paddingRight': '0'
          },
          'style': {}
        },
        'code': 'SiteImgSlider1575968592147'
      },
      {
        'type': 'SiteText',
        'content': {
          'text': '默认文本默认文本默认文本默认文本默认文本默认文本默认文本',
          'link': 'www.baidu.com'
        },
        'attr': {
          'bottom': {
            'status': false,
            'index': -1
          },
          'module': {
            'paddingTop': '3',
            'paddingBottom': '4',
            'paddingLeft': '2',
            'paddingRight': '2'
          },
          'style': {
            'backgroundColor': 'rgba(230, 229, 229, 1)',
            'borderColor': 'rgba(64, 10, 10, 1)',
            'borderRadius': '2',
            'borderStyle': '',
            'borderWidth': '2',
            'color': 'rgba(64, 21, 239, 1)',
            'fontSize': '18',
            'fontWeight': 'bold',
            'fontStyle': '',
            'textDecoration': '',
            'textAlign': 'right',
            'border-style': 'dashed'
          }
        },
        'code': 'SiteText1575446416225'
      },
      {
        'type': 'SiteText',
        'content': {
          'text': '文本内容文本内容文本内容文本内容文本内容文本内容文本内容文本内容文本内容文本内容文本内容文本内容文本内容文本内容',
          'link': 'http://www.baidu.com'
        },
        'attr': {
          'bottom': {
            'status': false,
            'index': -1
          },
          'module': {
            'paddingTop': '5',
            'paddingBottom': '3',
            'paddingLeft': '4',
            'paddingRight': '6'
          },
          'style': {
            'backgroundColor': 'rgba(232, 208, 208, 1)',
            'borderColor': 'rgba(247, 128, 128, 1)',
            'borderRadius': '12',
            'borderStyle': '',
            'borderWidth': '3',
            'color': 'rgba(154, 10, 10, 1)',
            'fontSize': '16',
            'fontWeight': 'bold',
            'fontStyle': 'italic',
            'textDecoration': 'underline',
            'textAlign': 'center',
            'border-style': 'dashed'
          }
        },
        'code': 'SiteText1575439510201'
      },
      {
        'type': 'SiteImgSlider',
        'content': {
          'slideSpeed': '3',
          'imgAspectRatio': '1.777778',
          'urls': [
            {
              'src': 'http://mzdsp.meizu.com/upload/1575447938880jBPar889.png',
              'link': '',
              'deeplink': ''
            },
            {
              'src': 'http://mzdsp.meizu.com/upload/1575447948890vCgRhVBu.png',
              'link': '',
              'deeplink': ''
            }
          ]
        },
        'attr': {
          'bottom': {
            'status': false,
            'index': -1
          },
          'module': {
            'paddingTop': '0',
            'paddingBottom': '0',
            'paddingLeft': '0',
            'paddingRight': '0'
          },
          'style': {}
        },
        'code': 'SiteImgSlider1575447896831'
      },
      {
        'type': 'SiteMdseWindow',
        'content': {
          'mdseStyle': 'row',
          'urls': [
            {
              'src': 'http://mzdsp.meizu.com/upload/1575968691677evv5nbqU.png',
              'link': 'http://www.baidu.com',
              'describe': '郁金香',
              'price': '30'
            },
            {
              'src': 'http://mzdsp.meizu.com/upload/15759686983067EbVnn2R.png',
              'link': 'http://www.sina.com',
              'describe': '水母',
              'price': '50'
            }
          ]
        },
        'attr': {
          'bottom': {
            'status': false,
            'index': -1
          },
          'module': {
            'paddingTop': '0',
            'paddingBottom': '0',
            'paddingLeft': '0',
            'paddingRight': '0'
          },
          'style': {}
        },
        'code': 'SiteMdseWindow1575968684227'
      },
      {
        'type': 'SiteBtn',
        'content': {
          'buttonText': '默认按钮文案',
          'link': '',
          'jumpType': 'link'
        },
        'attr': {
          'bottom': {
            'status': false,
            'index': -1
          },
          'module': {
            'paddingTop': '3',
            'paddingBottom': '3',
            'paddingLeft': '10',
            'paddingRight': '10'
          },
          'style': {
            'borderRadius': '8',
            'backgroundColor': 'rgba(88, 103, 137, 1)',
            'color': 'rgba(255, 245, 138, 1)',
            'fontSize': '16'
          }
        },
        'code': 'SiteBtn1575528851944'
      },
      {
        'type': 'SiteVideo',
        'content': {
          'coverUrl': 'http://mzdsp.meizu.com/upload/1575884640614d2Ea9YrF.png',
          'videoUrl': 'http://mzdsp.meizu.com/upload/1575884092061nWhV5Txr.mp4',
          'aspectRatio': 1.7777777777777777,
          'videoAspectRatio': 1.7777777777777777
        },
        'attr': {
          'bottom': {
            'status': false,
            'index': -1
          },
          'module': {
            'paddingTop': '0',
            'paddingBottom': '0',
            'paddingLeft': '0',
            'paddingRight': '0'
          },
          'style': {}
        },
        'code': 'SiteVideo1575603723856'
      },
      {
        'type': 'SiteBtn',
        'content': {
          'buttonText': '固定在底部按钮',
          'link': '',
          'jumpType': 'link'
        },
        'attr': {
          'bottom': {
            'status': true,
            'index': -1
          },
          'module': {
            'paddingTop': '3',
            'paddingBottom': '6',
            'paddingLeft': '1',
            'paddingRight': '1'
          },
          'style': {
            'borderRadius': '6',
            'backgroundColor': 'rgba(237, 112, 124, 1)',
            'color': 'rgba(254, 253, 253, 1)',
            'fontSize': '16'
          }
        },
        'code': 'SiteBtn1575529051804'
      },
      {
        'type': 'SiteDlBtn',
        'content': {
          'buttonText': '下载按钮',
          'deeplink': '',
          'packageName': ''
        },
        'attr': {
          'bottom': {
            'status': true,
            'index': -1
          },
          'module': {
            'paddingTop': '5',
            'paddingBottom': '5',
            'paddingLeft': '2',
            'paddingRight': '2'
          },
          'style': {
            'borderRadius': '5',
            'backgroundColor': 'rgba(11, 154, 197, 1)',
            'color': 'rgba(251, 255, 0, 1)',
            'fontSize': '18'
          }
        },
        'code': 'SiteDlBtn1575535724796'
      },
      {
        'type': 'SiteDlBtn',
        'content': {
          'buttonText': '下载按钮',
          'deeplink': '',
          'packageName': ''
        },
        'attr': {
          'bottom': {
            'status': false,
            'index': -1
          },
          'module': {
            'paddingTop': '2',
            'paddingBottom': '2',
            'paddingLeft': '3',
            'paddingRight': '3'
          },
          'style': {
            'borderRadius': '10',
            'backgroundColor': 'rgba(58, 117, 255, 1)',
            'color': 'rgba(252, 252, 252, 1)',
            'fontSize': '16'
          }
        },
        'code': 'SiteDlBtn1575535666499'
      },
      {
        'type': 'SiteStore',
        'content': {
          'packageName': '',
          'deeplink': '',
          'buttonText': '下载'
        },
        'attr': {
          'bottom': {
            'status': false,
            'index': -1
          },
          'style': {
            'backgroundColor': 'rgba(58, 117, 255, 1)',
            'color': 'rgba(255, 255, 255, 1)'
          }
        },
        'code': 'SiteStore1575534614985'
      },
      {
        'type': 'SiteStore',
        'content': {
          'packageName': '',
          'deeplink': '',
          'buttonText': '下载'
        },
        'attr': {
          'bottom': {
            'status': true,
            'index': -1
          },
          'style': {
            'backgroundColor': 'rgba(156, 144, 9, 1)',
            'color': 'rgba(255, 215, 141, 1)'
          }
        },
        'code': 'SiteStore1575534517184'
      },
      {
        'type': 'SiteFloatCard',
        'content': {
          'packageName': '',
          'deeplink': '',
          'appDesc': '爱奇艺App信息爱奇艺App信息爱奇艺App信息爱奇艺App信息爱奇艺App信息爱奇艺App信息爱奇艺App信息爱奇艺App信息爱奇艺App信息爱奇艺App信息爱奇艺App信息爱奇艺App信息爱奇艺App信息爱奇艺App信息爱奇艺App信息',
          'backgroundImage': 'url(http://mzdsp.meizu.com/upload/1575532234305FWim0PgL.png)',
          'buttonText': '浮层卡片-下载'
        },
        'attr': {
          'bottom': {
            'status': false,
            'index': -1
          },
          'style': {
            'backgroundColor': 'rgba(58, 162, 183, 1)',
            'color': 'rgba(255, 238, 107, 1)'
          }
        },
        'code': 'SiteFloatCard1575532053185'
      },
      {
        'type': 'SiteConsult',
        'content': {
          'buttonText': '在线咨询14font-size',
          'link': ''
        },
        'attr': {
          'bottom': {
            'status': false,
            'index': -1
          },
          'module': {
            'paddingTop': '2',
            'paddingBottom': '2',
            'paddingLeft': '0',
            'paddingRight': '0'
          },
          'style': {
            'borderRadius': '3',
            'backgroundColor': 'rgba(58, 117, 255, 1)',
            'color': 'rgba(255, 255, 255, 1)',
            'fontSize': '14'
          }
        },
        'code': 'SiteConsult1575536274781'
      },
      {
        'type': 'SiteConsult',
        'content': {
          'buttonText': '在线咨询16',
          'link': 'http://www.baidu.com'
        },
        'attr': {
          'bottom': {
            'status': true,
            'index': -1
          },
          'module': {
            'paddingTop': '1',
            'paddingBottom': '1',
            'paddingLeft': '0',
            'paddingRight': '0'
          },
          'style': {
            'borderRadius': '8',
            'backgroundColor': 'rgba(106, 150, 255, 1)',
            'color': 'rgba(255, 234, 0, 1)',
            'fontSize': '16'
          }
        },
        'code': 'SiteConsult1575536302308'
      },
      {
        'type': 'SitePhone',
        'content': {
          'buttonText': '立即拨打14font-size',
          'phone': '1587357',
          'link': '158735'
        },
        'attr': {
          'bottom': {
            'status': true,
            'index': -1
          },
          'module': {
            'paddingTop': '3',
            'paddingBottom': '3',
            'paddingLeft': '5',
            'paddingRight': '5'
          },
          'style': {
            'borderRadius': '0',
            'backgroundColor': 'rgba(107, 150, 251, 1)',
            'color': 'rgba(255, 234, 0, 1)',
            'fontSize': '14'
          }
        },
        'code': 'SitePhone1575536167097'
      },
      {
        'type': 'SitePhone',
        'content': {
          'buttonText': '立即拨打',
          'phone': ''
        },
        'attr': {
          'bottom': {
            'status': false,
            'index': -1
          },
          'module': {
            'paddingTop': '3',
            'paddingBottom': '3',
            'paddingLeft': '2',
            'paddingRight': '2'
          },
          'style': {
            'borderRadius': '0',
            'backgroundColor': 'rgba(58, 117, 255, 1)',
            'color': 'rgba(255, 255, 255, 1)',
            'fontSize': '16'
          }
        },
        'code': 'SitePhone1575536149839'
      },
      {
        'type': 'SiteMdseWindow',
        'content': {
          'mdseStyle': 'row',
          'urls': [
            {
              'src': 'http://mzdsp.meizu.com/upload/15755161617303OYS71iH.png',
              'link': 'http://www.baidu.com',
              'describe': '郁金香',
              'price': '3'
            },
            {
              'src': 'http://mzdsp.meizu.com/upload/1575516168655COTR9VUx.png',
              'link': 'http://www.google.com',
              'describe': '水母',
              'price': '10'
            },
            {
              'src': 'http://mzdsp.meizu.com/upload/15755161809221vGy8qz6.png',
              'link': 'http://www.baidu.com',
              'describe': '水母',
              'price': '16'
            }
          ]
        },
        'attr': {
          'bottom': {
            'status': false,
            'index': -1
          },
          'module': {
            'paddingTop': '0',
            'paddingBottom': '0',
            'paddingLeft': '0',
            'paddingRight': '0'
          },
          'style': {}
        },
        'code': 'SiteMdseWindow1575516143871'
      },
      {
        'type': 'SiteMdseWindow',
        'content': {
          'mdseStyle': 'column',
          'urls': [
            {
              'src': 'http://mzdsp.meizu.com/upload/1575516332008feBFHfEf.png',
              'link': 'http://www.google.com',
              'describe': '郁金香',
              'price': '62'
            }
          ]
        },
        'attr': {
          'bottom': {
            'status': false,
            'index': -1
          },
          'module': {
            'paddingTop': '0',
            'paddingBottom': '0',
            'paddingLeft': '0',
            'paddingRight': '0'
          },
          'style': {}
        },
        'code': 'SiteMdseWindow1575516326966'
      },
      {
        'type': 'SiteVideo',
        'content': {
          'coverUrl': 'http://mzdsp.meizu.com/upload/1575450234460Ez04Kc0Z.png',
          'videoUrl': 'http://mzdsp.meizu.com/upload/1575613210739bJDXhjq6.mp4'
        },
        'attr': {
          'bottom': {
            'status': false,
            'index': -1
          },
          'module': {
            'paddingTop': '2',
            'paddingBottom': '2',
            'paddingLeft': '5',
            'paddingRight': '5'
          },
          'style': {}
        },
        'code': 'SiteVideo1575450207484'
      },
      {
        'type': 'SiteImgs',
        'content': {
          'text': '',
          'urls': [
            {
              'src': 'http://mzdsp.meizu.com/upload/1575443004893MsU6xPvo.png',
              'link': '',
              'deeplink': ''
            },
            {
              'src': 'http://mzdsp.meizu.com/upload/1575443010537vvdtek86.png',
              'link': '',
              'deeplink': ''
            }
          ],
          'download': true
        },
        'attr': {
          'bottom': {
            'status': false,
            'index': -1
          },
          'module': {
            'paddingTop': '5',
            'paddingBottom': '22',
            'paddingLeft': '0',
            'paddingRight': '0'
          },
          'style': {}
        },
        'code': 'SiteImgs1575439858082'
      }
    ]
  }
}

export default siteData
