/* tslint:disable */
import { mapState } from 'vuex'
import { Track, CallAndroid, GetAndroidVal } from '@/native/index'

export default {
  data: {
    _btns: [],
    _config: {},
    _noop: () => { },
    isSDK: window.EventJavascriptInterface && window.EventJavascriptInterface.surfing
  },
  computed: {
    ...mapState(['btnStatus', 'btnInstallstatus', 'btnText', 'packageName', 'appId', 'appVersion'])
  },
  methods: {
    init({ btns }) {
      this.initBtn(btns, {
        onClick: () => {
          // Track('installed')
        },
        onClickDownload: () => {
          if (this.btnStatus !== 1) {
            Track('download')
            this.$store.commit('setBtnStatus', 1)
          }
        },
        onClickCancelDownload: () => {
          this.$store.commit('setBtnStatus', 0)
        },
        onClickOpen: () => {
          if (this.btnStatus !== 2) {
            Track('open')
            this.$store.commit('setBtnStatus', 2)
          }
        },
        onDownloadedCompleted: () => {
          // Track('downloaded')
        },
        onInstallCompleted: () => {
          // Track('installed')
        },
        onProgress: () => {}
      })
      // // 是在终端打开，才可以
      // if (GetAndroidVal('addListener')) {
      //   Track('exposure_page')
      // }
    },
    initBtn (btns, config) {
      this._btns = typeof btns.length !== 'undefined' ? Array.prototype.slice.call(btns, 0) : [btns]
      this._config = {
        onClick: this._noop,
        onClickDownload: this._noop,
        onClickOpen: this._noop,
        onInstallCompleted: this._noop,
        onInstallFailed: this._noop,
        onProgress: this._noop,
        onClickCancelDownload: this._noop,
        onDownloadedCompleted: this._noop,
        ...config
      }
      this._initInstallButton()
      window.mzAdCall = window.meAdCall || function() {}
    },
    _initInstallButton () {
      if (!GetAndroidVal('addListener')) return
      this._btns.forEach(btn => {
        CallAndroid('addListener', btn, 'notifyProgress', this._notifyProgress.bind(this))
        this._checkAppInitStatus(btn)
        btn.addEventListener('click', () => {
          this.clickDownloadApp(btn)
        })
      })
    },
    clickDownloadApp (btn, onlyDownload = false) {
      const status = CallAndroid('isAppInstalled', this.packageName, +this.appVersion)
      if (status === 1) {
        this._config.onClickOpen()
        if (btn.dataset.deeplink) {
          return CallAndroid('openDeepLink', btn.dataset.deeplink, this.packageName)
        }
        if (!onlyDownload) {
          CallAndroid('openApp', this.packageName)
        }
      } else {
        const isSDK = window.EventJavascriptInterface && window.EventJavascriptInterface.surfing
        if ((GetAndroidVal('turnTo') !== 'a' && !isSDK) && this.btnInstallstatus === 'downloadingStatus') {
          if (!onlyDownload) {
            if (btn.dataset.canceldownload !== 'false') {
              this._config.onClickCancelDownload()
              CallAndroid('installApp', this.packageName, +this.appVersion, +this.appId)
            }
          }
        } else if (['startInstallStatus'].indexOf(this.btnInstallstatus) === -1) {
          const downloadApp = () => {
            // 未安装状态才调用
            if (status === 0) {
              this._config.onClickDownload()
            }
            CallAndroid('installApp', this.packageName, +this.versionCode)
          }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      
          if ((GetAndroidVal('turnTo') !== 'a' && !isSDK) && CallAndroid('getNetworkType') === 2) {
            downloadApp()
          } else {
            downloadApp()
          }
        }
      }
      this._config.onClick()
    },
    _notifyProgress (btn, evtObj) {
      const { btnStatus, pkg } = evtObj
      if (pkg !== this.packageName) return
      let btnText = evtObj.btnText
      if (btnStatus === 'startInstallStatus') {
        this._config.onDownloadedCompleted()
      } else if (btnStatus === 'installCompleteStatus') {
        this._config.onInstallCompleted()
      } else if(btnStatus === 'installFailureStatus') {
        this._config.onInstallFailed()
      }
      this._config.onProgress()
      if (btnText === '暂停') {
        btnText = '继续'
      }
      this.$store.commit('setBtnText', btnText)
      this.$store.commit('setBtnInstallstatus', btnStatus)
    },
    _checkAppInitStatus(btn) {
      const status: string | number = CallAndroid('isAppInstalled', this.packageName, +this.appVersion, false)
      let text: string = ''
      if (status === 1) {
        text = '打开'
      } else if (status === 2) {
        text = '更新'
      } else if (status === 4) {
        text = '继续'
      }
      this.$store.commit('setBtnStatus', status)
      if (text) {
        this.$store.commit('setBtnText', text)
      }
    }
  }
}
