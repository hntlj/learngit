declare module '*.vue' {
  import Vue from 'vue'
  export default Vue
}

interface Window {
  [index: string]: any
}

declare module '*.ts' {
  export default ts
}

// declare module 'vuex/store'
