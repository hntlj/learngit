interface DeleteApiItemInfo {
  index: number,
  type: string,
  path: string,
  key: string | number
}

import { RootStateTypes } from './types'
import { MutationTree } from 'vuex'
import { parsePath } from '@/utils/index.ts'
import Vue from 'vue'

const mutations: MutationTree<RootStateTypes> = {
  setApiItem (state: RootStateTypes, comData: any) {
    const compare = (origin: any, target: any): void => {
      for (let key in target) {
        if (typeof origin[key] === 'object' && origin[key] !== null) {
          compare(origin[key], target[key])
        } else {
          if (origin.hasOwnProperty(key)) {
            origin[key] = target[key]
          } else {
            Vue.set(origin, key, target[key])
          }
        }
      }
    }
    let idx: string | number = '0'
    for (let i = 0; i < state.sortApi.length; i++) {
      if (state.sortApi[i].code === comData.code) {
        idx = i
        break
      }
    }
    compare(state.sortApi[idx], comData)
  },
  setCommon (state: RootStateTypes) {
    let arg: any = arguments[1]
    if (arg.hasOwnProperty('index') && arg.hasOwnProperty('flag')) {
      let timer: any = null
      if (state.editIndex === arg['index']) { // 样式编辑栏假装切换
        state.editShow = arg['flag']
      } else {
        state.editShow = !arg['flag']
        clearTimeout(timer)
        timer = setTimeout(() => {
          state.editShow = arg['flag']
        }, 150)
      }
      state.editIndex = arg['index']
    }
  },
  deleteCp (state: RootStateTypes, index: number) {
    state.sortApi.splice(index, 1)
  },
  deleteApiItem (state: RootStateTypes, info: DeleteApiItemInfo) {
    let target: any = state.sortApi[info.index]
    const getter: any = parsePath(info.path)
    target = getter(target)
    if (info.type === 'array') {
      target.splice(info.key, 1)
    } else if (info.type === 'object') {
      delete info.key
    }
  },
  setPackageName (state: RootStateTypes, name: string) {
    state.appInfo.packageName = name
  },
  setPackageInfo (state: RootStateTypes, appInfo) {
    if (appInfo) {
      state.appInfo.packageName = appInfo.packageName,
      state.appInfo.name = appInfo.name
      state.appInfo.icon = appInfo.icon
      state.appInfo.versionCode = appInfo.versionCode
      state.appInfo.id = appInfo.id
      state.appInfo.status = appInfo.status
    } else {
      this._vm.$message.error('不存在该包名信息，请重新输入！')
      state.appInfo.packageName = ''
      state.appInfo.name = ''
      state.appInfo.icon = ''
      state.appInfo.versionCode = ''
      state.appInfo.id = ''
      state.appInfo.status = ''
    }
  },
  setEditIndex (state: RootStateTypes, idx: number) {
    state.editIndex = idx
  },
  setSortApi (state: RootStateTypes, data: Array<any>) {
    state.sortApi = data
  },
  setAppInfo (state: RootStateTypes, appInfo: any) {
    state.appInfo = appInfo
  },
  setPageId (state: RootStateTypes, id: any) {
    state.id = id
  }
}

export default mutations
