import request from './services.ts'

// GET 应用详情
export const getAppDetail = ({ packageName }) => {
  return request.get('/console/mdsp/app/detail', { params: { packageName } })
}
// GET 落地页详情
export const getLandingPageDetail = params => request.get('/console/mdsp/landpage/detail', { params })
// POST 落地页 Create or Update
// id, type, templateStyle, name, packageName, styleModel, status, html
export const postLandingPage = params => {
  const action = params.id ? 'update' : 'create'
  return request.post(`/console/mdsp/landpage/${action}`, params)
}
// POST 更新落地页状态 0：下线；1：发布；2：删除
export const updateLandingPageStatus = (lpId, status) => request.post('/console/mdsp/landpage/status/update', { lp_id: lpId, status })
// POST 落地页预览
// export const getQRCode = params => request.post('/console/mdsp/app/getQRCode', params)
export const getQRCode = params => request.get('/console/mdsp/app/getQRCode')
