<template>
  <div class="btn-edit ui-edit"
    :data-code="comData.code"
    v-if="sortIdx === currentIndex">
    <el-form class="edit-form" ref="form" label-width="80px">
      <div class="form-group">
        <h3 class="form-group__title">文字样式</h3>
        <el-form-item label="按钮文案">
          <el-input size="large" v-model="comData.content.buttonText" placeholder="输入按钮文案"></el-input>
        </el-form-item>
        <el-form-item label="跳转至">
          <div class="jump-type">
            <div class="jump-type-item jump-type__pagetop"
              :class="{'item-active': comData.content.jumpType === 'pageTop'}"
              @click="selectJump('pageTop')">顶部</div>
            <div class="jump-type-item jump-type__link"
              :class="{'item-active': comData.content.jumpType === 'link'}"
              @click="selectJump('link')">外链</div>
          </div>
        </el-form-item>
        <el-form-item label="跳转链接">
            <el-input
              size="large"
              v-model="comData.content.link"
              :disabled="comData.content.jumpType !== 'link'"
              placeholder="输入跳转链接(选填)，必须以http(s)://开头"></el-input>
          </el-form-item>
        <div class="form-row">
          <el-form-item label="字号">
            <el-input type="number"
              v-model="comData.attr.style['fontSize']"
              class="cui-input-box"
              size="small">
            </el-input><span> px</span>
          </el-form-item>
          <el-form-item label="颜色">
            <el-color-picker
              @active-change=" (value) => setStyle(value, 'color')"
              v-model="comData.attr.style['color']"
              show-alpha>
            </el-color-picker>
          </el-form-item>
        </div>
      </div>
      <div class="form-group">
        <h3 class="form-group__title">按钮样式</h3>
        <div class="form-row">
          <el-form-item label="背景颜色">
            <el-color-picker
              @active-change=" (value) => setStyle(value, 'backgroundColor')"
              v-model="comData.attr.style['backgroundColor']"
              show-alpha>
            </el-color-picker>
          </el-form-item>
          <el-form-item label="圆角">
            <el-input v-model="comData.attr.style['borderRadius']"
              type="number"
              class="cui-input-box"
              size="small">
            </el-input><span> px</span>
          </el-form-item>
          <el-form-item label="固定浮在底部">
            <el-switch v-model="comData.attr.bottom.status">
            </el-switch>
          </el-form-item>
        </div>
      </div>
      <div class="form-group">
        <h3 class="form-group__title">组件边距</h3>
        <div class="form-row">
          <el-form-item v-for="(modSt, idx) in styleOpt.module" :key="idx" :label="modSt.label">
            <el-input v-model="comData.attr.module[modSt.name]"
              type="number"
              class="cui-input-box"
              size="small">
            </el-input><span> px</span>
          </el-form-item>
        </div>
      </div>
    </el-form>
  </div>
</template>

<script lang="ts">
import { Vue, Component, Prop, Watch } from 'vue-property-decorator'
import { State, Action, Getter, Mutation } from 'vuex-class'
import { deepCopy } from '@/utils/index.ts'
import { STYLE_MODULE } from '@/enums/index.ts'

@Component
export default class Btn extends Vue {
  @Prop(Object) comContent: any
  @Prop(Object) oStyle: any
  @Prop(Number) sortIdx: number | undefined
  @Prop(Number) currentIndex: number | undefined
  @State sortApi: Array<any>
  @State editIndex: number
  @State editShow: boolean
  @Mutation setApiItem
  comData: any = deepCopy(this.comContent, [])
  styleOpt: Object = {
    module: STYLE_MODULE
  }
  setStyle (value, style) {
    this.$set(this.comData.attr.style, style, value)
  }
  selectJump (type) {
    this.comData.content.jumpType = type
  }
  @Watch('comData.content.jumpType')
  onJumpTypeChanged (newVal: string, oldVal: string) {
    if (newVal === 'pageTop') {
      this.comData.content.link = ''
    }
  }
  @Watch('comData', { deep: true })
  onComDataChanged (newVal: Array<any>, oldVal: Array<any>) {
    this.$store.commit('setApiItem', newVal)
  }
}
</script>

<style lang="scss" scoped>
.form-group {
  .jump-type {
    display: flex;
    .jump-type-item {
      padding: 0 20px;
      border: 1px solid $backGray;
      cursor: pointer;
    }
    .item-active {
      background-color: $blue;
      color: #fff;
    }
  }
}
</style>
