<template>
  <div class="ui-edit"
    :data-code="comData.code"
    v-if="sortIdx === currentIndex">
    <el-form class="edit-form" ref="form" label-width="80px">
      <div class="form-group">
        <h3 class="form-group__title">商品橱窗</h3>
        <el-upload
          class="img-uploader"
          action="/common/upload"
          :show-file-list="false"
          :on-success="handleImgSuccess"
          :before-upload="beforeImgUpload()">
          <div class="img-uploader__btn">
            <i class="el-icon-plus"></i><span> 添加图片</span>
          </div>
        </el-upload>
        <div class="img-tip">图片要求：支持 jpg、png、jpeg 格式，小于300K, 图片比例1:1，商品需居于图片正中。</div>
      </div>
      <div class="form-group form-group-imgs">
        <div v-for="(item, idx) in comData.content.urls" :key="idx">
          <div class="img-wrap">
            <div class="el-icon-close remove-img el-icon-close_bg_blue" @click="removeImg(idx)"></div>
            <img :src="item.src">
          </div>
          <el-form-item label="商品描述">
            <el-input
              size="large"
              v-model="item.describe"
              maxlength=15
              placeholder="输入商品描述"></el-input>
          </el-form-item>
          <el-form-item label="价格">
            <el-input
              size="small"
              type="number"
              v-model="item.price"
              maxlength=12
              placeholder="输入商品价格"></el-input>
          </el-form-item>
          <el-form-item label="跳转链接">
            <el-input
              size="large"
              v-model="item.link"
              placeholder="输入跳转链接(选填)，必须以http(s)://开头"></el-input>
          </el-form-item>
        </div>
      </div>
      <div class="form-group">
        <h3 class="form-group__title">橱窗样式</h3>
        <div class="form-row">
          <el-form-item label="样式">
            <div class="mdse-style-wrap">
              <div class="mdse-style mdse-style1"
                :class="{'mdse-style-active': comData.content.mdseStyle === 'row'}"
                @click="setMdseStyle('row')">
                <div class="mdse-img"></div>
                <div class="mdse-bottom">
                  <div class="mdse-bottom__desc mdse-bottom__item">运动户外</div>
                  <div class="mdse-bottom__price mdse-bottom__item">
                    <span>¥</span><span>2000</span>
                  </div>
                </div>
              </div>
              <div class="mdse-style mdse-style2"
                :class="{'mdse-style-active': comData.content.mdseStyle === 'column'}"
                @click="setMdseStyle('column')">
                <div class="mdse-img"></div>
                <div class="mdse-bottom">
                  <div class="mdse-bottom__desc mdse-bottom__item">运动户外</div>
                  <div class="mdse-bottom__price mdse-bottom__item">
                    <span>¥</span><span>2000</span>
                  </div>
                </div>
              </div>
            </div>
          </el-form-item>
        </div>
      </div>
      <div class="form-group">
        <h3 class="form-group__title">组件边距</h3>
        <div class="form-row">
          <el-form-item v-for="(modSt, idx) in styleOpt.module" :key="idx" :label="modSt.label">
            <el-input v-model="comData.attr.module[modSt.name]"
              type="number"
              class="cui-input-box"
              size="small">
            </el-input><span> px</span>
          </el-form-item>
        </div>
      </div>
    </el-form>
  </div>
</template>

<script lang="ts">
import { Vue, Component, Prop, Watch } from 'vue-property-decorator'
import { State, Action, Getter, Mutation } from 'vuex-class'
import { deepCopy } from '@/utils/index.ts'
import { STYLE_MODULE, HOST } from '@/enums/index.ts'
import mutations from '../../vuex/mutations'
import BeforeUpload from '@/mixins/beforeUpload.ts'

@Component({
  mixins: [BeforeUpload]
})
export default class DlBtnEdit extends Vue {
  @Prop(Object) comContent: any
  @Prop(Object) oStyle: any
  @Prop(Number) sortIdx: number | undefined
  @Prop(Number) currentIndex: number | undefined
  @State sortApi: Array<any>
  @State editIndex: number
  @State editShow: boolean
  @Mutation setApiItem
  @Mutation deleteApiItem
  comData: any = deepCopy(this.comContent, [])
  styleOpt: Object = {
    module: STYLE_MODULE
  }

  handleImgSuccess(res, file) {
    const url: string = `http://${HOST}/upload/${res.value[0].url}`
    const urls: Array<any> = this.comData.content.urls
    const image: any = new Image()
    image.src = url
    image.onload = () => {
      if (image.width !== image.height) {
        return this.$message.error('请上传宽高比例为1:1的图片！')
      }
      urls.push({
        src: url,
        link: '',
        describe: '',
        price: '0'
      })
    }
  }
  removeImg (idx) {
    this.comData.content.urls.splice(idx, 1)
    this.$store.commit('deleteApiItem', {
      index: this.currentIndex,
      type: 'array',
      path: 'content.urls',
      key: idx
    })
  }
  setMdseStyle (style) {
    this.comData.content.mdseStyle = style
  }
  @Watch('comData', { deep: true })
  onComDataChanged (newVal: Array<any>, oldVal: Array<any>) {
    this.$store.commit('setApiItem', newVal)
  }
}
</script>

<style lang="scss" scoped>
.img-uploader {
  font-size: 16px;
  color: $blue;
  border: 1px solid $blue;
  margin: 10px 160px;
  text-align: center;
  line-height: 36px;
  .img-uploader__btn {
    padding: 0 10px;
  }
}
.img-tip {
  font-size: 12px;
  line-height: 20px;
  color: $gray;
  margin: 0 30px;
}
.form-group-imgs {
  margin: 0 10px;
  .img-wrap {
    height: 100px;
    background-color: #f0eeef;
    margin: 10px 0;
    text-align: center;
    position: relative;
    .remove-img {
      position: absolute;
      right: 0;
      top: 0;
    }
    img{
      height: 100%;
    }
  }
}
.mdse-style-wrap {
  width: 350px;
  display: flex;
  justify-content: space-around;
  .mdse-style {
    width: 150px;
    cursor: pointer;
    .mdse-img {
      height: 150px;
      background-color: $backGray;
    }
    .mdse-bottom {
      display: flex;
      justify-content: space-between;
      padding: 5px;
      .mdse-bottom__item {
        line-height: 25px;
        min-height: 25px;
      }
    }
  }
  .mdse-style2 .mdse-bottom{
    display: block;
  }
  .mdse-style-active {
    border: 1px solid $blue;
  }
}
</style>
