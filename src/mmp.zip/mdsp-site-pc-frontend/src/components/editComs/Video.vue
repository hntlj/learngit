<template>
  <div class="btn-edit ui-edit"
    :data-code="comData.code"
    v-if="sortIdx === currentIndex">
    <el-form class="edit-form" ref="form" label-width="80px">
      <div class="form-group">
        <h3 class="form-group__title">视频</h3>
        <el-upload
          class="file-uploader"
          ref="videoUpload"
          action="/common/uploadVideoForLandPage"
          :on-success="handleVideoSuccess"
          :on-error="handleVideoError()"
          :before-upload="beforeVideoUpload"
          :limit="1">
          <div class="file-uploader__btn">
            <i class="el-icon-plus"></i><span> 添加视频</span>
          </div>
        </el-upload>
        <div class="video-tip">视频要求：只支持MP4格式，小于50MB，时长不超过30秒。</div>
        <div class="video-wrap" v-if="comData.content.videoUrl && showVideo">
          <video class="video-player" ref controls name="media">
            <source :src="comData.content.videoUrl" type="video/mp4">
          </video>
        </div>
      </div>
      <div class="form-group">
        <h3 class="form-group__title">封面图</h3>
        <el-upload
          class="file-uploader"
          action="/common/upload"
          :show-file-list="false"
          :on-success="handleImgSuccess"
          :before-upload="beforeImgUpload()">
          <div class="file-uploader__btn">
            <i class="el-icon-plus"></i><span> 添加图片</span>
          </div>
        </el-upload>
        <div class="img-tip">图片要求：支持 jpg、png、jpeg 格式，小于300K。</div>
        <div class="img-wrap" v-if="comData.content.coverUrl">
          <div class="el-icon-close remove-img el-icon-close_bg_blue" @click="removeImg"></div>
          <img :src="comData.content.coverUrl">
        </div>
      </div>
      <div class="form-group">
        <h3 class="form-group__title">组件边距</h3>
        <div class="form-row">
          <el-form-item v-for="(modSt, idx) in styleOpt.module" :key="idx" :label="modSt.label">
            <el-input v-model="comData.attr.module[modSt.name]"
              type="number"
              class="cui-input-box"
              size="small">
            </el-input><span> px</span>
          </el-form-item>
        </div>
      </div>
    </el-form>
  </div>
</template>

<script lang="ts">
import { Vue, Component, Prop, Watch } from 'vue-property-decorator'
import { State, Action, Getter, Mutation } from 'vuex-class'
import { deepCopy } from '@/utils/index.ts'
import { STYLE_MODULE, HOST } from '@/enums/index.ts'
import mutations from '../../vuex/mutations'
import BeforeUpload from '@/mixins/beforeUpload.ts'

@Component({
  mixins: [BeforeUpload]
})
export default class DlBtnEdit extends Vue {
  @Prop(Object) comContent: any
  @Prop(Object) oStyle: any
  @Prop(Number) sortIdx: number | undefined
  @Prop(Number) currentIndex: number | undefined
  @State sortApi: Array<any>
  @State editIndex: number
  @State editShow: boolean
  @Mutation setApiItem
  comData: any = deepCopy(this.comContent, [])
  styleOpt: Object = {
    module: STYLE_MODULE
  }
  showVideo: boolean = true
  handleVideoSuccess(res, file) {
    if (res.code === 200 && res.value.length > 0) {
      const url = `http://${HOST}/upload/${res.value[0].url}`
      const resolution = res.value[0].resolution.split('*')
      this.$set(this.comData.content, 'videoUrl', url)
      this.comData.content.videoAspectRatio = resolution[0] / resolution[1]
      this.showVideo = false
      // 针对请求status为cancel的情况，延时处理
      setTimeout(() => {
        this.showVideo = true
      }, 300)
      const videoUpload = this.$refs.videoUpload
      if (videoUpload) {
        (videoUpload as any).clearFiles()
      }
    } else {
      this.handleVideoError(res)('')
    }
  }
  handleVideoError (res) {
    return (err) => {
      const videoUpload = this.$refs.videoUpload
      if (videoUpload) {
        (videoUpload as any).clearFiles()
      }
      this.$message.error((res && res.message) || err || '文件上传失败')
    }
  }
  handleImgSuccess(res, file) {
    const url = `http://${HOST}/upload/${res.value[0].url}`
    this.$set(this.comData.content, 'coverUrl', url)
  }
  beforeVideoUpload (file) {
    let videoMsg: string = ''
    const UPLOAD_LIMIT: number = 50 // M
    if (file.type === 'video/mp4') {
      if (file.size > 1024 * 1024 * UPLOAD_LIMIT) {
        videoMsg = `视频大小不能超过${UPLOAD_LIMIT}M`
      }
    } else {
      videoMsg = '请上传mp4格式的视频文件'
    }
    if (videoMsg) {
      this.$message.error(videoMsg)
      return false
    } else {
      return true
    }
  }
  removeImg () {
    this.comData.content.coverUrl = ''
  }
  @Watch('comData.content.download')
  onComDataDownloadChanged (newVal: any, oldVal: any) {
    this.comData.content.urls.forEach(item => {
      if (newVal) {
        item.link = ''
      } else {
        item.deeplink = ''
      }
    })
  }
  @Watch('comData', { deep: true })
  onComDataChanged (newVal: Array<any>, oldVal: Array<any>) {
    this.$store.commit('setApiItem', newVal)
  }
}
</script>

<style lang="scss" scoped>
.file-uploader {
  font-size: 16px;
  color: $blue;
  margin-bottom: 20px;
  text-align: center;
  line-height: 36px;
  .file-uploader__btn {
    padding: 0 10px;
    border: 1px solid #3A75FF;
  }
}
.img-tip, .video-tip {
  font-size: 12px;
  line-height: 20px;
  color: $gray;
  margin: 0 30px;
}
.form-group {
  margin: 0 10px;
  .img-wrap {
    height: 100px;
    background-color: #f0eeef;
    margin: 10px 0;
    text-align: center;
    position: relative;
    .remove-img {
      position: absolute;
      right: 0;
      top: 0;
    }
    img{
      height: 100%;
    }
  }
  .video-player {
    width: 100%;
    margin: 10px 0;
  }
}
</style>
