<template>
  <div class="com-sort com-imgs"
    :class="{'com-sort_active': showDel | isActive}"
    :data-code="content.code"
    :style="attrModule"
    @mouseenter="onMouseenter"
    @mouseleave="onMouseleave">
    <div class="com-imgs-wrap">
      <img class="com-imgs__img"
        v-for="img in content.urls"
        :src="img.src"
        :key="img.src">
      <div class="com-imgs__empty" v-if="!content.urls.length"></div>
    </div>
    <DeleteCp :showDel="showDel" :sortIdx="sortIdx"></DeleteCp>
  </div>
</template>

<script lang="ts">
import { Vue, Component } from 'vue-property-decorator'
import DeleteCp from '@/components/common/DeleteCp.vue'
import SiteComAct from '@/mixins/siteComAct.ts'
@Component({
  name: 'SiteImgs',
  components: {
    DeleteCp
  },
  mixins: [SiteComAct]
})

export default class SiteDlBtn extends Vue {}
</script>
<style lang="scss" scoped>
.com-imgs {
  min-height: 100px;
  overflow: hidden;
  .com-imgs__img {
    width: 100%;
    float: left;
  }
  .com-imgs__empty {
    height: 280px;
    background: url('~assets/img/back_imgs.png') no-repeat center;
  }
}
</style>
