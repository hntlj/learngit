<template>
  <div class="com-sort"
    :class="{'com-sort_active': showDel | isActive}"
    :data-code="content.code"
    :style="attrModule"
    @mouseenter="onMouseenter"
    @mouseleave="onMouseleave">
    <div class="float-card-wrap" :style="{backgroundImage: content.backgroundImage}">
      <div class="float-card">
        <div class="float-card-title">
          <img
            class="float-card__appicon"
            :class="{'icon-border': !appInfo.icon }"
            :src="appInfo.icon" alt="">
          <span class="float-card__appname">{{appInfo.name}}</span>
        </div>
        <div class="float-card__text">{{content.appDesc}}</div>
        <div class="float-card__bottom">
          <div class="float-card__btn" :style="attrStyle">{{content.buttonText}}</div>
        </div>
      </div>
    </div>
    <DeleteCp :showDel="showDel" :sortIdx="sortIdx"></DeleteCp>
  </div>
</template>

<script lang="ts">
import { Vue, Component } from 'vue-property-decorator'
import { State, Action, Getter, Mutation } from 'vuex-class'
import DeleteCp from '@/components/common/DeleteCp.vue'
import SiteComAct from '@/mixins/siteComAct.ts'
@Component({
  name: 'SiteFloatCard',
  components: {
    DeleteCp
  },
  mixins: [SiteComAct]
})
export default class SiteFloatCard extends Vue {
  @State appInfo: any
}
</script>
<style lang="scss" scoped>
.float-card-wrap {
  height: 775px;
  position: relative;
  background-size: 100% 100%;
  .float-card {
    position: absolute;
    top: 50%;
    left: 0;
    right: 0;
    transform: translateY(-50%);
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 29px 13px 13px;
    margin: 0 13px;
    box-shadow: 0 0 40px 0 rgba(0,0,0,.1);
    overflow: hidden;
    background: rgba(256,256,256,0.9);
    border-radius: 5px;
    .float-card-title {
      width: 100%;
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: flex-start;
      padding-left: 40px;
      box-sizing: border-box;
      .float-card__appicon {
        width: 50px;
        height: 50px;
        margin-right: 20px;
      }
      .icon-border {
        border: 1px solid $backGray;
      }
    }
    .float-card__text {
      width: 100%;
      line-height: 1.5em;
      padding: 0 10px;
      margin: 20px 0;
      word-wrap: break-word;
    }
    .float-card__bottom {
      width: 100%;
      display: flex;
      justify-content: center;
      .float-card__btn {
        width: 60%;
        background-color: $blue;
        height: 40px;
        line-height: 40px;
        border-radius: 5px;
        text-align: center;
        color: #fff;
      }
    }
  }
}
</style>
