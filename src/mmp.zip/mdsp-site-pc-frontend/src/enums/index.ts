export const HOST: string = 'mzdsp.meizu.com'
export const STYLE_PX: Array<string> = [
  'fontSize',
  'borderRadius', 'borderWidth',
  'paddingTop', 'paddingBottom', 'paddingLeft', 'paddingRight'
]
export const STYLE_MODULE: Array<Object> = [
  {
    label: '上',
    name: 'paddingTop'
  },{
    label: '下',
    name: 'paddingBottom'
  },{
    label: '左',
    name: 'paddingLeft'
  },{
    label: '右',
    name: 'paddingRight'
  }
]
// 下载模块
export const DOWNLOAD_COMP: Array<string> = ['SiteFloatCard', 'SiteStore', 'SiteDlBtn']
// 各个模块默认数据
const BLUE: string = 'rgba(58, 117, 255, 1)'
const WHITE: string = 'rgba(255, 255, 255, 1)'
const BLACK: string = 'rgba(0, 0, 0, 1)'
export const COM_DEFAULT_DATA: any = {
  SiteHeader: {
    type: 'SiteHeader',
    content: {
      pageTitle: '页面标题',
      pageName: '站点名称'
    },
    attr: {
      top: { status: true, index: -1 },
      bottom: { status: false, index: -1 },
      style: {
        backgroundColor: WHITE,
        backgroundImage: ''
      }
    }
  },
  SiteText: {
    type: 'SiteText',
    content: {
      text: '默认文本',
      link: ''
    },
    attr: {
      bottom: { status: false, index: -1 },
      module: {
        paddingTop: '0',
        paddingBottom: '0',
        paddingLeft: '0',
        paddingRight: '0'
      },
      style: {
        backgroundColor: WHITE,
        borderColor: WHITE,
        borderRadius: '0',
        borderStyle: '',
        borderWidth: '',
        color: BLACK,
        fontSize: '14'
      }
    }
  },
  SiteImgs: {
    type: 'SiteImgs',
    content: {
      download: false,
      text: '',
      urls: []
    },
    attr: {
      bottom: { status: false, index: -1 },
      module: {
        paddingTop: '0',
        paddingBottom: '0',
        paddingLeft: '0',
        paddingRight: '0'
      },
      style: {}
    }
  },
  SiteImgSlider: {
    type: 'SiteImgSlider',
    content: {
      download: false,
      slideSpeed: '3',
      imgAspectRatio: '',
      urls: []
    },
    attr: {
      bottom: { status: false, index: -1 },
      module: {
        paddingTop: '0',
        paddingBottom: '0',
        paddingLeft: '0',
        paddingRight: '0'
      },
      style: {}
    }
  },
  SiteVideo: {
    type: 'SiteVideo',
    content: {
      coverUrl: '',
      videoUrl: '',
      videoAspectRatio: ''
    },
    attr: {
      bottom: { status: false, index: -1 },
      module: {
        paddingTop: '0',
        paddingBottom: '0',
        paddingLeft: '0',
        paddingRight: '0'
      },
      style: {}
    }
  },
  SiteMdseWindow: {
    type: 'SiteMdseWindow',
    content: {
      mdseStyle: 'row',
      urls: []
    },
    attr: {
      bottom: { status: false, index: -1 },
      module: {
        paddingTop: '0',
        paddingBottom: '0',
        paddingLeft: '0',
        paddingRight: '0'
      },
      style: {}
    }
  },
  SiteBtn: {
    type: 'SiteBtn',
    content: {
      buttonText: '默认按钮文案',
      link: '',
      jumpType: 'link'
    },
    attr: {
      bottom: { status: false, index: -1 },
      module: {
        paddingTop: '0',
        paddingBottom: '0',
        paddingLeft: '0',
        paddingRight: '0'
      },
      style: {
        borderRadius: '3',
        backgroundColor: BLUE,
        color: 'rgba(255, 255, 255, 1)',
        fontSize: '16'
      }
    }
  },
  SiteFloatCard: {
    type: 'SiteFloatCard',
    content: {
      packageName: '',
      deeplink: '',
      appDesc: '',
      backgroundImage: '',
      buttonText: '下载'
    },
    attr: {
      bottom: { status: false, index: -1 },
      style: {
        backgroundColor: BLUE,
        color: WHITE
      }
    }
  },
  SiteStore: {
    type: 'SiteStore',
    content: {
      packageName: '',
      deeplink: '',
      buttonText: '下载'
    },
    attr: {
      bottom: { status: false, index: -1 },
      style: {
        backgroundColor: BLUE,
        color: WHITE
      }
    }
  },
  SiteDlBtn: {
    type: 'SiteDlBtn',
    content: {
      buttonText: '下载',
      deeplink: '',
      packageName: ''
    },
    attr: {
      bottom: { status: false, index: -1 },
      module: {
        paddingTop: '0',
        paddingBottom: '0',
        paddingLeft: '0',
        paddingRight: '0'
      },
      style: {
        borderRadius: '3',
        backgroundColor: BLUE,
        color: WHITE,
        fontSize: '16'
      }
    }
  },
  SitePhone: {
    type: 'SitePhone',
    content: {
      buttonText: '立即拨打',
      phone: ''
    },
    attr: {
      bottom: { status: false, index: -1 },
      module: {
        paddingTop: '0',
        paddingBottom: '0',
        paddingLeft: '0',
        paddingRight: '0'
      },
      style: {
        borderRadius: '3',
        backgroundColor: BLUE,
        color: WHITE,
        fontSize: '16'
      }
    }
  },
  SiteConsult: {
    type: 'SiteConsult',
    content: {
      buttonText: '在线咨询',
      link: ''
    },
    attr: {
      bottom: { status: false, index: -1 },
      module: {
        paddingTop: '0',
        paddingBottom: '0',
        paddingLeft: '0',
        paddingRight: '0'
      },
      style: {
        borderRadius: '3',
        backgroundColor: BLUE,
        color: WHITE,
        fontSize: '16'
      }
    }
  }
}
